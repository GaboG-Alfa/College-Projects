gline = [ ['Month','umich.edu','ufp.pt','indiana.edu','ucdavis.edu','uct.ac.za','berkeley.edu','columbia.edu','mac.com','gmail.com','virginia.edu'],
['2005-12',57,10,11,10,13,12,13,12,9,9],
['2006-01',76,27,25,21,18,17,14,10,13,12]
];
