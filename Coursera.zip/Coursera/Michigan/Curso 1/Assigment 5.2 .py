largest = None
smallest = None
while True:
    inp = raw_input('Enter a number: ')
 
    if inp == 'done':
        break
 
    try:
        num = int(inp)
        if largest is None or largest < num:
            largest = num
        elif smallest is None or smallest > num:
            smallest = num
    except:
        print('Invalid input')
        continue
print("Maximum is", largest)
print("Minimum is", smallest)