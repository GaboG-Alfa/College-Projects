x=5
print("Hello")
#def permite crear funcionas es decir métodos por lo que llega a ser muy útil
def print_lyrics():
    print("I'm a lumberjack, and I'm okay.")
    print("I sleep all night and I work all day")
print("Yo")
print_lyrics()
x=x+2
print(x)