def greet(lang):
    if lang=="ef":
        return "Hola"
    elif lang=="fr":
        return "Bonjour"
    else:
        return "Hello"
print (greet("en"),"Glen")
print (greet("ef"),"Sally")
print (greet("fr"),"Michael")