while True:
    line=input("Write something: ")
    if line[0]=="#":
        continue
    if line=="done":
        break
    print(line)
print("Done!")