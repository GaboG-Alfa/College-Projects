def computepay(h,r):
    x=h-40
    if h>40:
        pay=40*r+(x*(r*1.5))
    else:
        pay=h*r    
    return pay    
hrs=input("Enter hours:")
rate=input("Enter rate: ")
hs=float(hrs)
rt=float(rate)
p=computepay(hs,rt)
print("Pay: ",p)