def greet(lang):
    if lang=="ef":
        print("Hola")
    elif lang=="fr":
        print("Bonjour")
    else:
        print("Hello")
greet("en")
greet("fr")
greet("ef")