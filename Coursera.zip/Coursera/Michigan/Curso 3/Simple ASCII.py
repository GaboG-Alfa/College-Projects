print(ord('H'))
print(ord('e'))
print(ord('\n'))