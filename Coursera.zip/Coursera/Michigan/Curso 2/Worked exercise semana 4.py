han=open("mbox.txt")
for line in han:
    line=line.rstrip()
    wds=line.split()
    if wds[0] !="It's" or len(wds)<3:
        continue
    print(wds[2])
