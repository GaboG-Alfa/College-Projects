(x,y)=(4,"fred")
print(y)
(a,b)=(99,98)
print(a)