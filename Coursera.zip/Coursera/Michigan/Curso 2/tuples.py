x=["Glenn","Sally","Joseph"]
print(x[2])
print("--------------------")
y=(1,9,2)
print("This is a tuple: ",y)
for iter in y:
    print(iter)
print("Max Number in tuple: ",max(y))