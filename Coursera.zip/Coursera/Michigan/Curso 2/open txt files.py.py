xfile=open("mbox.txt")
for lyrics in xfile:
    print(lyrics)