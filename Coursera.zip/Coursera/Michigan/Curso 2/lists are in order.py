friends=["Jospeh","Glenn","Sally"]
friends.sort()
print(friends)
print(friends[1])