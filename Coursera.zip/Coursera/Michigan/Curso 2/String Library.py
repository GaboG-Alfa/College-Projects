greet="Hello Bob"
zap=greet.lower()
print(zap)
print(greet)
print("Hi There".lower())