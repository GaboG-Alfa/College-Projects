some=[1,9,21,10,16]
print(9 in some)
print(15 in some)
print(20 not in some)