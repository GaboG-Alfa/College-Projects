jjj={"chuck":1,"fred":42,"jan":100}
print(list(jjj))
print(jjj.keys())
print(jjj.values())
print(jjj.items())