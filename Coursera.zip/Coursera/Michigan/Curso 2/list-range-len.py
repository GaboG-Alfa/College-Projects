print(range(4))
friends=["Jospeh","Glenn","Sally"]
print(len(friends))
print(range(len(friends)))