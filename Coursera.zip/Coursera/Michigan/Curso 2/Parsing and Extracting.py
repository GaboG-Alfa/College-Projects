data="From stephen.marquard.@uct.ac.za Sat Jan 09:14:16 2008"
atops=data.find("@")
print(atops)
soppos=data.find("",atops)
print(soppos)
host=data[atops+1:soppos]
print(host)