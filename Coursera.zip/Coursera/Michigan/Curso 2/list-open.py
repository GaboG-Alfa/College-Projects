fhand=open("mbox.txt")
for line in fhand:
    line=line.rstrip()
    if not line.startswith("It's"):continue
    words=line.split()
    print(words[2])