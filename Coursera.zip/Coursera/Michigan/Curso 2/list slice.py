t=[9,41,12,3,74,15]
print(t[1:3])
print(t[:4])
print(t[3:])
print(t[:])