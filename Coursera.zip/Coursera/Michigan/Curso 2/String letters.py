fruit="banana"
letters=fruit[1]
print(letters)
x=3
w=fruit[x-1]
print(w)
print("--------------------------------------")
index=0
while index< len(fruit):
    letter=fruit[index]
    print(index,letter)
    index=index+1
print("--------------------------------------")
fruit="banana"
for letter in fruit:
    print(letter)