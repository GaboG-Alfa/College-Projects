s="Monty Python"
print(s[0:4])
print(s[6:7])
print(s[6:20])
