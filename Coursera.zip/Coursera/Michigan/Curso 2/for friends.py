friends=["Jospeh","Glenn","Sally"]
for friend in friends:
    print("Happy New Year",friend)
for i in range(len(friends)):
    friend=friends[i]
    print("Happy New Year",friend)