d=dict()
d["csev"]=2
d["cwen"]=4
for(k,v) in d.items():
    print(k,v)
tups=d.items()
print(tups)