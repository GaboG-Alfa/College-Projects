jjj={"chuck":1,"fred":42,"jan":100}
for aaa,bbb in jjj.items():
    print(aaa,bbb)
