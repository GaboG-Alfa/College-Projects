purse=dict()
purse["money"]=12
purse["candy"]=3
purse["tissues"]=75
print(purse)
print(purse["candy"])
purse["candy"]=purse["candy"]+2
print(purse)
