x = 'From marquard@uct.ac.za'
print(x[9])