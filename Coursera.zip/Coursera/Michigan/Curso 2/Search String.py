fruit="banana"
pos=fruit.find("na")
print(pos)
aa=fruit.find("z")
print("aa")