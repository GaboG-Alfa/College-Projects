ddd=dict()
ddd["age"]=21
ddd["course"]=182
print(ddd)
ddd["age"]=23
print(ddd)