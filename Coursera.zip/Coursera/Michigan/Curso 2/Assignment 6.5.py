texto = "X-DSPAM-Confidence:    0.8475"
ipos=texto.find(":")  
piece=texto[ipos+1:]
value=float(piece)
print(value)