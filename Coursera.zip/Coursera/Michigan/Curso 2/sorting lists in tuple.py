d={"a":10,"b":1,"c":22}
print(d.items())
print(sorted(d.items()))