ccc=dict()
ccc["csev"]=1
ccc["cwen"]=1
print(ccc)
ccc["cwen"]=ccc["cwen"]+1
print(ccc)