abc="With three words"
stuff=abc.split()
print(stuff)
print(len(stuff))
print(stuff[0])