#abre el archivo de texto llamado mbox
fhand=open("mbox.txt")
#lee los caracteres del archivo que se guardan en la variable fhand
inp=fhand.read()
#imprime la cantidad de caracteres
print(len(inp))
#imprime los primeros 20 caracteres del archivo mbox.tx
print(inp[:20])