line="A lot of        spaces "
etc=line.split()
print(etc)
line="first";"second";"third"
thing=line.split()
print(thing)
print(len(thing))
thing=line.split(";")
print(thing)
print(len(thing))