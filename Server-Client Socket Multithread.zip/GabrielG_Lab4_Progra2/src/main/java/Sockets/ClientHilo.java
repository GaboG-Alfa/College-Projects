/*
El Cliente se ejecuta de esta manera en el shell del sistema operativo:
java ClientHilo servidor_IP numero_puerto
java ClientHilo 127.0.0.1 6990
 */
import java.io.*;
import java.net.*;
import javax.swing.*;

/**
 * 
 * @author Gabriel Guzmán Alfaro
 * @version 28/05/2021
 */
public class ClientHilo {

    //Atributo
    private Socket conectorSimple;
    private ObjectInputStream entrada;
    private ObjectOutputStream salida;

    /**
     * 
     * @param nombreServidor
     * @param puerto 
     */
    public ClientHilo(String nombreServidor, String puerto) {
        try {
            conectorSimple = new Socket(nombreServidor, Integer.parseInt(puerto));
        } catch (Exception e) {
            System.err.println(e);
        }
    }

    /**
     * Obtiene flujos
     */
    public void obtenerFlujos() {
        try {
            salida = new ObjectOutputStream(conectorSimple.getOutputStream());
            salida.flush();
            entrada = new ObjectInputStream(conectorSimple.getInputStream());
        } catch (Exception e) {
            System.err.println(e);
        }
    }

    /**
     * cierra los flujos
     */
    public void cerrarFlujos() {
        try {
            entrada.close();
            salida.close();
            conectorSimple.close();
        } catch (Exception e) {
            System.err.println(e);
        }
    }

    
    /**
     * 
     * @return mensaje 
     */
    public String recibirMensaje() {
        String mensaje = "";
        try {
            mensaje = (String) entrada.readObject();
        } catch (Exception e) {
            System.err.println(e);
        }
        return mensaje;
    }

    /**
     * 
     * @param mensaje 
     */
    public void enviarMensaje(String mensaje) {
        try {
            salida.writeObject(mensaje);
        } catch (Exception e) {
            System.err.println(e);
        }
    }
    

    /**
     * 
     * @param arg 
     */
    public static void main(String arg[]) {

        if (arg.length == 2) {
            ClientHilo c = new ClientHilo(arg[0], arg[1]);
            c.obtenerFlujos();
            String mensaje = "";
            while (!mensaje.equals("cerrar")) {
                mensaje = JOptionPane.showInputDialog("MENSAJE");
                c.enviarMensaje(mensaje);
                String respuesta = c.recibirMensaje();
                System.out.println(respuesta);
            }
            c.cerrarFlujos();
        } else {
            System.out.println("No se han recibido los 2 parametros necesarios...");
        }
        System.exit(0);
    }

}
