/*Este programa acepta UN solo cliente pero en un bucle, hasta que se digite la palabra cerrar
No abre una conexion nueva si el cliente se cierra, sino que se sale del servidor tambien
Por lo tanto no acepta clientes posteriores
El Servidor se ejecuta de esta manera en el shell del sistema operativo:
java ServerHilo numero_puerto cantidadClientes
java ServerHilo 6990 2
 */

import java.io.*;
import java.net.*;

/**
 * 
 * @author Gabriel Guzmán Alfaro
 * @ version 28/05/2021
 */
public class ServerHilo {

    //Atributos
    private ServerSocket conectorDeServicio;
    private Socket conectorSimple;
 
    /**
     * 
     * @param puerto 
     */
    public ServerHilo(String puerto) {
        try {
            conectorDeServicio = new ServerSocket(Integer.parseInt(puerto));
        } catch (Exception e) {
            System.err.println(e);
        }
    }

    
    /**
     * 
     * @return contectorSimple
     */
    public Socket aceptarConexion() {
        try {
            conectorSimple = conectorDeServicio.accept();
        } catch (Exception e) {
            System.err.println(e);
        }

        return conectorSimple;
    }

    /**
     * 
     * @param arg 
     */
    public static void main(String arg[]) {

        if (arg.length == 2) {

            ServerHilo s = new ServerHilo(arg[0]);
            System.out.println("Servidor iniciado");

            int counter = 0;

            while (true) {
                counter++;
                Socket cliente = s.aceptarConexion();
                Thread ch = new ClientHandler(cliente, counter,arg[1]);
                ch.start();
            }
        } else {
            System.out.println("No se ha recibido el parametro del puerto del Servidor...");
        }

    }
}

/**
 * 
 * @author Gabriel Guzmán Alfaro
 * @version 28/05/2021
 */
class ClientHandler extends Thread {

    //Attributos
    private ObjectInputStream dataIn;
    private ObjectOutputStream dataOut;
    private Socket socket;
    private int clientNo;
    private int countHilos; 

    /**
     *
     * @param dataIn
     * @param dataOut
     * @param socket
     */
    public ClientHandler(Socket socket, int counter, String countHilos) {
        this.socket = socket;
        this.clientNo = counter;
        this.countHilos = Integer.parseInt(countHilos);
    }

    /**
     * Obtiene los flujos
     */
    public void obtenerFlujos() {
        try {
            dataIn = new ObjectInputStream(socket.getInputStream());
            dataOut = new ObjectOutputStream(socket.getOutputStream());
            dataOut.flush();
        } catch (Exception e) {
            System.err.println(e);
        }
    }

    /**
     * 
     * @param mensaje 
     */
    public void enviarMensaje(String mensaje) {
        try {
            dataOut.writeObject(mensaje);
            dataOut.flush();
        } catch (Exception e) {
            System.err.println(e);
        }
    }

    /**
     * 
     * @param palabra
     * @return mensaje
     */
    public String convierte(String palabra) {
        return palabra.toUpperCase();
    }

    public String recibirMensaje() {
        String mensaje = "";
        try {
            mensaje = (String) dataIn.readObject(); //Se lee un objeto String
        } catch (Exception e) {
            System.err.println(e);
        }
        return mensaje;
    }

    /**
     * Cierra los flujos
     */
    public void cerrarFlujos() {
        try {
            dataIn.close();
            dataOut.close();
            socket.close();
            dataOut.flush();
        } catch (Exception e) {
            System.err.println(e);
        }
    }

    /**
     * Corre
     */
    public void run() {
        try {
            obtenerFlujos();
            String clientMessage = "";

            while (!clientMessage.equals("cerrar") && clientNo<=countHilos) {
                clientMessage = recibirMensaje();
                System.out.println(clientMessage);
                enviarMensaje(convierte(clientMessage));
                System.out.println("Se envio de vuelta el mensaje en mayuscula");
            }

            cerrarFlujos();
            
            if(clientNo>countHilos){
                throw new IllegalArgumentException("La cantidad de clientes ha superado el parámetro que usted ingresó para conectar n clientes");
            }
            
        } catch (Exception ex) {
            System.out.println(ex);
        } finally {
            System.out.println("Client -" + clientNo + " salió!! ");
        }
    }

}
