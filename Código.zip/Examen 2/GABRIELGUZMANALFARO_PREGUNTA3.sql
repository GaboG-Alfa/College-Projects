Use TSQLV4

--3. Sigas las siguientes instrucciones:
--a. Para aquellos empleados cuyas ventas hist�ricas han superado o son iguales a $ 90,000, hacer un
--reporte del TOP 2 productos m�s vendidas para cada empleado.
--b. A continuaci�n, un ejemplo de resultado y los ALIAS:SELECT CONCAT(E.firstname,' ',E.lastname) AS FullName,
       TOPN.productname AS Product,
       TOPN.TotalAmount
 FROM HR.Employees AS E
CROSS APPLY (SELECT TOP (2) 
             P.productname,
			 SUM(OD.qty*OD.unitprice) AS TotalAmount
FROM Production.Products AS P
INNER JOIN Sales.OrderDetails AS OD
ON(P.productid = OD.productid)
INNER JOIN Production.Categories AS CT
ON(P.categoryid = CT.categoryid)
INNER JOIN Sales.Orders AS O 
ON(O.empid= E.empid )
WHERE (CT.categoryid IN (2,3,7)) AND (E.empid IN(2,3,7,9)) 
GROUP BY P.productname
HAVING SUM(OD.qty*OD.unitprice) >= 90000 
ORDER BY TotalAmount DESC) AS TOPN