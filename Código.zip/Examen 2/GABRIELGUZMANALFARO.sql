USE TSQLV4

--1. Crear un stored procedure que borre los productos, las �rdenes y detalles de las �rdenes, de los productos que
--han comprado los clientes seg�n el siguiente detalle:SELECT P.productid,
       O.custid
FROM Production.Products AS P
  INNER JOIN Sales.OrderDetails AS OD
    ON(P.productid = OD.productid)
  INNER JOIN Sales.Orders AS O
    ON(OD.orderid = O.orderid)
WHERE O.custid = 30
ORDER BY P.productid�DESC;
CREATE OR ALTER PROC Borrar
AS
DELETE FROM P
FROM Production.Products AS P
WHERE P.productid IN(70,68,68,67,65,65,64,64,62,61,60,55,55,51,50,40,36,29,24,21,19,17,17,10,2,1)

DELETE FROM OD
FROM Production.Products AS P
	INNER JOIN Sales.OrderDetails AS OD
		ON(P.productid = OD.productid)
WHERE OD.productid IN(70,68,68,67,65,65,64,64,62,61,60,55,55,51,50,40,36,29,24,21,19,17,17,10,2,1)

DELETE FROM O
FROM Production.Products AS P
	INNER JOIN Sales.OrderDetails AS OD
		ON(P.productid = OD.productid)
	INNER JOIN Sales.Orders AS O
		ON(O.orderid = OD.orderid)
WHERE P.productid IN(70,68,68,67,65,65,64,64,62,61,60,55,55,51,50,40,36,29,24,21,19,17,17,10,2,1)

EXEC Borrar;

--2.Cree una consulta que le permita al tomador de decisi�n saber cu�les clientes han comprado el mismo producto
--m�s de 40 (inclusive) veces (40 en cantidad en cada l�nea de orden) en la misma semana.

SELECT C.companyname AS CompanyName,
       TOPN.productname AS Product,
	   YEAR(TOPN.orderdate) AS N'Year',
	   DatePART(WEEK,TOPN.orderdate) AS N'WeeK',
	   TOPN.qty AS Quantity
FROM Sales.Customers AS C
OUTER APPLY(SELECT 
             P.productname,
			 O.orderdate,
			 OD.qty
FROM Production.Products AS P
INNER JOIN Sales.OrderDetails AS OD
ON(P.productid = OD.productid)
INNER JOIN Production.Categories AS CT
ON(P.categoryid = CT.categoryid)
INNER JOIN Sales.Orders AS O 
ON(O.orderid= OD.orderid )
INNER JOIN HR.Employees AS E
ON(E.empid = O.empid)
WHERE (C.custid= 30) AND (CT.categoryid IN (2,3,7)) AND (E.empid IN(2,3,7,9)) AND (OD.qty>40)
GROUP BY P.productname,
         O.orderdate,
		 OD.qty) AS TOPN

--3. Sigas las siguientes instrucciones:
--a. Para aquellos empleados cuyas ventas hist�ricas han superado o son iguales a $ 90,000, hacer un
--reporte del TOP 2 productos m�s vendidas para cada empleado.
--b. A continuaci�n, un ejemplo de resultado y los ALIAS:SELECT TOPN.FUllName AS FullName,
       TOPN.productname AS Product,
FROM Sales.Customers AS C
OUTER APPLY(SELECT 
             CONCAT(E.firstname,' ',E.lastname) AS FUllName,  
             P.productname,
			 SUM(OD.qty*OD.unitprice) AS Amount
FROM Production.Products AS P
INNER JOIN Sales.OrderDetails AS OD
ON(P.productid = OD.productid)
INNER JOIN Production.Categories AS CT
ON(P.categoryid = CT.categoryid)
INNER JOIN Sales.Orders AS O 
ON(O.orderid= OD.orderid )
INNER JOIN HR.Employees AS E
ON(E.empid = O.empid)
WHERE (C.custid= 30) AND (CT.categoryid IN (2,3,7)) AND (E.empid IN(2,3,7,9)) 
GROUP BY P.productname,
         O.orderdate,
		 OD.qty) AS TOPN



 
