CREATE DATABASE MariaFernandaAlvaradoAstorgaExamen;

USE MariaFernandaAlvaradoAstorgaExamen;

CREATE TABLE dbo.Producto(
ProductoID INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
Precio MONEY  NOT NULL,
Descripcion NVARCHAR(100) NOT NULL
);

CREATE TABLE dbo.DetalleVenta(
DetalleVentaID INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
FacturaID INT  NOT NULL,
ProductoID INT  NOT NULL,
Cantidad SMALLINT  NOT NULL,
);

CREATE TABLE dbo.Factura(
FacturaID INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
Fecha DATETIME NOT NULL,
Clave INT  NOT NULL,
Comprobante INT  NOT NULL,
CajaID INT NOT NULL,
ClienteID INT NOT NULL,
EmpleadoID INT NOT NULL,
Descuento MONEY NOT NULL,
);

CREATE TABLE dbo.NaturalezaPersona(
TipoNaturalezaID TINYINT IDENTITY(1,1) PRIMARY KEY,
DescNaturaleza NVARCHAR(100)
);

INSERT INTO dbo.NaturalezaPersona(DescNaturaleza)
VALUES (N'CLIENTE'),
       (N'EMPLEADO');

CREATE TABLE dbo.Caja(
CajaID INT IDENTITY(1,1) PRIMARY KEY,
DescCaja NVARCHAR(100)
);

INSERT INTO dbo.Caja(DescCaja)
VALUES (N'CAJA RAPIDA'),
       (N'DISCAPACITADOS');

CREATE TABLE dbo.Persona(
PersonaID INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
TipoNaturalezaID TINYINT NOT NULL,
PrimerNombre NVARCHAR(100) NOT NULL,
PrimerApellido NVARCHAR(100) NOT NULL,
SegundoApellido NVARCHAR(100) NOT NULL,
);

ALTER TABLE dbo.DetalleVenta
ADD CONSTRAINT FK_DetalleVenta_ProductoID
FOREIGN KEY (ProductoID)
REFERENCES dbo.Producto(ProductoID);

ALTER TABLE dbo.DetalleVenta
ADD CONSTRAINT FK_DetalleVenta_FacturaID
FOREIGN KEY (FacturaID)
REFERENCES dbo.Factura(FacturaID);

ALTER TABLE dbo.Factura
ADD CONSTRAINT FK_Factura_ClienteID
FOREIGN KEY (ClienteID)
REFERENCES dbo.Persona(PersonaID);

ALTER TABLE dbo.Factura
ADD CONSTRAINT FK_Factura_EmpleadoID
FOREIGN KEY (EmpleadoID)
REFERENCES dbo.Persona(PersonaID);

ALTER TABLE dbo.Factura
ADD CONSTRAINT FK_Factura_CajaID
FOREIGN KEY (CajaID)
REFERENCES dbo.Caja(CajaID);

ALTER TABLE dbo.Persona
ADD CONSTRAINT FK_Persona_TipoPersona FOREIGN KEY (TipoNaturalezaID)
REFERENCES dbo.NaturalezaPersona (TipoNaturalezaID);


INSERT INTO dbo.Producto(Descripcion,
						 Precio)
VALUES (N'CLORO BOTELLA 900 ML', 641.19);


INSERT INTO dbo.Producto(Descripcion,
						 Precio)
VALUES (N'ACEITE SOYA', 2367.19);

SELECT *
FROM dbo.Producto;

INSERT INTO dbo.Persona(TipoNaturalezaID,
                        PrimerNombre,
						PrimerApellido,
						SegundoApellido)
VALUES (1, N'Luis', N'Bola�os', N'Alvarado');

INSERT INTO dbo.Persona(TipoNaturalezaID,
                        PrimerNombre,
						PrimerApellido,
						SegundoApellido)
VALUES (2, N'Maria', N'Alvarado', N'Astorga');

SELECT *
FROM dbo.Persona;

INSERT INTO dbo.Factura(Fecha, 
                        Clave,
						Comprobante, 
						CajaID, 
						ClienteID, 
						EmpleadoID, 
						Descuento)
VALUES ('20211007 10:30:55:300', 143, 123, 1, 1, 2, 0); 

SELECT *
FROM dbo.Caja;

SELECT *
FROM dbo.Factura;


INSERT INTO dbo.DetalleVenta(FacturaID,
							 ProductoID,
							 Cantidad)
VALUES (1, 2, 4); 

INSERT INTO dbo.DetalleVenta(FacturaID,
							 ProductoID,
							 Cantidad)
VALUES (1, 1, 3); 

SELECT *
FROM dbo.DetalleVenta;

SELECT *
FROM dbo.Factura;