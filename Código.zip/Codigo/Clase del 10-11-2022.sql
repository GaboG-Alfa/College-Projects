USE TSQLV4;

SELECT 
 o.orderid
 ,c.companyname
 ,o.orderdate
FROM Sales.Orders as o
INNER JOIN Sales.Customers AS c
ON (o.custid = c.custid); 


SELECT 
 o.orderid
 ,c.companyname
 ,o.orderdate
 ,CONCAT (e.firstname,' ', e.lastname) AS nombrecompleto 
FROM Sales.Orders as o
INNER JOIN Sales.Customers AS c
ON (o.custid = c.custid) 
INNER JOIN HR.Employees AS e
ON (o.empid = e.empid); 

SELECT CONCAT (e.firstname,' ', e.lastname) AS NombreCompleto,
DATEDIFF (YEAR,e.birthdate, GETDATE()) AS Edad 
FROM HR.Employees AS e;


SELECT CONCAT (e.firstname,' ', e.lastname) AS NombreCompleto
,DATEDIFF (YEAR,e.birthdate, GETDATE()) AS Edad
,COUNT (*) AS Cantidad 
FROM HR.Employees AS e
INNER JOIN Sales.Orders AS c
ON (c.empid = e.empid) 

GROUP BY CONCAT(e.firstname,' ', e.lastname) 
,DATEDIFF (YEAR,e.birthdate, GETDATE()) 
ORDER BY Cantidad DESC 


SELECT CONCAT (e.firstname,' ', e.lastname) AS NombreCompleto
,DATEDIFF (YEAR,e.hiredate, GETDATE()) AS A�osEnLaEmpresa
,COUNT (*) AS Cantidad 
FROM HR.Employees AS e
INNER JOIN Sales.Orders AS c
ON (c.empid = e.empid) 


SELECT TOP (4) sc.companyname
	,COUNT (*) AS Cantidad 
FROM Sales.Customers AS sc
INNER JOIN Sales.Orders AS c
ON (sc.custid = c.custid)   
GROUP BY sc.companyname
ORDER BY Cantidad DESC; 
 

 SELECT 
	sc.country, 
	COUNT (*) AS Cantidad 
FROM Sales.Customers AS sc
	INNER JOIN Sales.Orders AS c
	ON (sc.custid = c.custid)
GROUP BY sc.country	
ORDER BY Cantidad DESC; 
 
 
 SELECT 
 DATENAME (month, orderdate)
 ,COUNT (*) AS Cantidad
 FROM Sales.Customers AS sc
 INNER JOIN Sales.Orders AS c
 ON (sc.custid = c.custid)
 GROUP BY  DATENAME (month, orderdate)
 ORDER BY Cantidad DESC;