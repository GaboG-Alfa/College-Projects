USE TSQLV4

SELECT  TOP 10
          c.custid AS CustomerID,
		  c.contactname AS CustomerName,
		  c.country AS Country
		 ,Count(*) AS Quantity
		 
FROM Sales.Customers AS C
INNER JOIN Sales.Orders AS O
ON (c.custid=o.custid)
WHERE o.orderdate >= CAST('20150101' AS DATE)
GROUP BY c.custid,c.contactname,c.country
ORDER BY Quantity DESC