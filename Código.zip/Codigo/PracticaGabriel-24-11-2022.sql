USE TSQLV4;

SELECT C.categoryname,
       TOPN.productname,
	   TOPN.Amount
FROM Production.Categories AS C
OUTER APPLY(SELECT TOP (3)
             P.productname,
			 SUM(OD.qty*OD.unitprice) AS Amount
FROM Production.Products AS P
INNER JOIN Sales.OrderDetails AS OD
ON(P.productid = OD.productid)
WHERE P.categoryid=C.categoryid
GROUP BY P.productname
ORDER BY  Amount DESC) AS TOPN

--top 3 mejores clientes por suplidor basados en monto
SELECT S.contactname,
       S.companyname,
       TOPN.productname,
	   TOPN.Amount
FROM Production.Suppliers AS S
CROSS APPLY(SELECT TOP (3)
            P.productname,
			 SUM(OD.qty*OD.unitprice) AS Amount
FROM Production.Products AS P
INNER JOIN Sales.OrderDetails AS OD
ON(P.productid = OD.productid)
WHERE P.supplierid=S.supplierid
GROUP BY P.productname
ORDER BY  Amount DESC) AS TOPN

--2 Productos m�s vendidos por empleado
SELECT E.firstname,
       E.country,
       TOPN.productname,
	   TOPN.Amount
FROM HR.Employees AS E
CROSS APPLY(SELECT TOP (2)
            P.productname,
			 SUM(OD.qty*OD.unitprice) AS Amount
FROM Production.Products AS P
INNER JOIN Sales.OrderDetails AS OD
ON(P.productid = OD.productid)
INNER JOIN Sales.Orders AS O
ON(O.orderid=OD.orderid)
WHERE o.empid = E.empid
GROUP BY P.productname
ORDER BY  Amount DESC) AS TOPN

WITH MontoXOrden AS 
(SELECT O.orderid,
       O.custid,
	   O.orderdate
	   ,SUM(OD.qty * OD.unitprice) AS Amount
FROM Sales.Orders AS O
 INNER JOIN Sales.OrderDetails AS OD
 ON(O.orderid = od.orderid)
	GROUP BY O.orderid,
	         O.custid,
			 O.orderdate)

			 SELECT custid,
			 YEAR(orderdate) AS A�o,
			 MONTH(orderdate) AS Mes,
			 DAY(orderdate) AS Dia,
       orderid,
	   orderdate,
	   Amount,
	   SUM(Amount) OVER(PARTITION BY custid
	                    ORDER BY orderdate,orderid 
						ROWS BETWEEN UNBOUNDED PRECEDING
						AND CURRENT ROW) AS Acumulado
FROM MontoXOrden
ORDER BY orderdate

/*
SELECT custid,
       orderid,
	   Amount,
	   100 * (Amount / (SUM(Amount) OVER (PARTITION BY Custid))) AS PorcXCliente,
	   100 * (SUM(Amount) OVER (PARTITION BY Custid) /
	          SUM(Amount) OVER()) AS PorcTotal 
FROM MontoXOrden
*


