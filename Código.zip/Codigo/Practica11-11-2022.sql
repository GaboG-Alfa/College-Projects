/*Cantidad total de empleados*/
SELECT COUNT(*) as Cantidad
FROM HR.Employees;

/*Empleados por regiones*/
SELECT  region
       ,COUNT(*) AS Cantidad
FROM HR.Employees
GROUP BY region
ORDER BY region;
/*Empleados por ciudad*/
SELECT  city
       ,COUNT(*) AS Cantidad
FROM HR.Employees
GROUP BY city
ORDER BY city;


/*SIRVE PARA MOSTRAR DATOS AUNQUE NO HAYA UN MATCH, YA QUE CON INNER JOIN MUESTRA SOLO SI EXISTEN MATCH O REGISTROS*/
SELECT E.firstname
      ,COUNT(O.orderid) AS Cantidad
FROM HR.Employees AS E
LEFT OUTER JOIN Sales.Orders AS O
ON(E.empid = O.empid)
GROUP BY E.firstname;

/*Fecha Maxima y Minima en la que se vendio algo*/
SELECT MAX(O.orderdate) AS FechaMax
       ,MIN(O.orderdate) AS FechaMin
FROM SALES.Orders AS O;

/*Diferencia entre las ordenes*/
SELECT  E.firstname
       ,MAX(O.orderdate) AS FechaMax
       ,MIN(O.orderdate) AS FechaMin
	   ,DATEDIFF(DAY,MAX(O.orderdate), MIN(O.orderdate)) AS Diff
FROM SALES.Orders AS O
INNER JOIN HR.Employees AS E
ON (O.empid = E.empid)
GROUP BY E.firstname;

/*Cantidad de Ordenes distintas y el monto total de ordenes*/
SELECT COUNT( DISTINCT O.orderid) AS Cantidad
       ,SUM(OD.qty *OD.unitprice) AS Monto
FROM HR.Employees AS E
INNER JOIN Sales.Orders AS O
ON (E.empid = O.empid)
INNER JOIN Sales.OrderDetails AS OD
ON(O.orderid=OD.orderid);

/*Lo anterior por empleado*/
SELECT E.firstname
       ,COUNT( DISTINCT O.orderid) AS Cantidad
       ,SUM(OD.qty *OD.unitprice) AS Monto
FROM HR.Employees AS E
INNER JOIN Sales.Orders AS O
ON (E.empid = O.empid)
INNER JOIN Sales.OrderDetails AS OD
ON(O.orderid=OD.orderid)
GROUP BY E.firstname;
/*Promedio de lo que vende por orden*/
SELECT E.firstname
       ,COUNT( DISTINCT O.orderid) AS Cantidad
       ,SUM(OD.qty *OD.unitprice) AS Monto
	   ,AVG(OD.qty *OD.unitprice) AS Promedio
FROM HR.Employees AS E
INNER JOIN Sales.Orders AS O
ON (E.empid = O.empid)
INNER JOIN Sales.OrderDetails AS OD
ON(O.orderid=OD.orderid)
GROUP BY E.firstname;


/*Promedio aunque no vendan Y QUE NO SALGA LA MARCA NULL*/
SELECT E.firstname
       ,COUNT( DISTINCT O.orderid) AS Cantidad
       ,COALESCE(SUM(OD.qty *OD.unitprice),0) AS Monto
	   ,COALESCE(AVG(OD.qty *OD.unitprice),0) AS Promedio
FROM HR.Employees AS E
LEFT OUTER JOIN Sales.Orders AS O
ON (E.empid = O.empid)
LEFT OUTER JOIN Sales.OrderDetails AS OD
ON(O.orderid=OD.orderid)
GROUP BY E.firstname;
/*Empleados que no han vendido nada*/

/*Filtrar por grupos y no registros, no se puede con where, se debe utilizar el having*/

SELECT E.firstname
       ,COUNT( DISTINCT O.orderid) AS Cantidad
       ,COALESCE(SUM(OD.qty *OD.unitprice),0) AS Monto
	   ,COALESCE(AVG(OD.qty *OD.unitprice),0) AS Promedio
FROM HR.Employees AS E
INNER JOIN Sales.Orders AS O
ON (E.empid = O.empid)
INNER JOIN Sales.OrderDetails AS OD
ON(O.orderid=OD.orderid)
GROUP BY E.firstname
HAVING COUNT( DISTINCT O.orderid) >= 100;
/*NOTA: registros con where, grupos con having*/

/*Interpretar descontinuidad*/
SELECT productname
      ,CASE 
	      WHEN discontinued=0 THEN 'NO'
		  WHEN discontinued=1 THEN 'SI'
		  ELSE 'NA'
		  END discontineud
FROM Production.Products;

SELECT productname
      ,CASE 
	      WHEN unitprice BETWEEN 1 AND 0 THEN 'BARATO'
		  WHEN unitprice BETWEEN 11 AND 30 THEN 'MEDIO'
		  WHEN unitprice <30 THEN 'CARO'
		  ELSE 'NA'
		  END ValorProducto
FROM Production.Products;

/*left outer join que muestre cantidad de productos SEGUN  categoria*/

SELECT C.categoryname
      ,COUNT(P.categoryid) AS Cantidad
FROM Production.Categories AS C
     LEFT OUTER JOIN Production.Products AS P
       ON (P.categoryid = C.categoryid)
GROUP BY C.categoryname;

/*Categoria y producto*/
SELECT C.categoryname
      ,P.productname
FROM Production.Categories AS C
     LEFT OUTER JOIN Production.Products AS P
       ON (P.categoryid = C.categoryid)
GROUP BY C.categoryname, P.productname;

