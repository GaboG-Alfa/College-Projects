DROP DATABASE IF EXISTS NAE;

CREATE DATABASE NAE;

USE NAE;

CREATE TABLE Categoria(
CategoriaID SMALLINT PRIMARY KEY NOT NULL
);

CREATE SCHEMA Prod;

CREATE TABLE Prod.Categoria(
CategoriaID SMALLINT PRIMARY KEY NOT NULL
);

SELECT *
FROM TSQLV4.HR.Employees;

DROP TABLE Prod.Categoria;

DROP TABLE dbo.Categoria;

DROP TABLE Categoria;

CREATE TABLE Prod.Category(
CategoryID SMALLINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
CategoryName NVARCHAR(50) NOT NULL,
Description NVARCHAR(200) NULL DEFAULT ('')
);

INSERT INTO Prod.Category (CategoryName)
VALUES (N'Categoria 1');

SELECT *
FROM Prod.Category;

INSERT INTO Prod.Category (CategoryName,Description)
VALUES (N'Categoria 1',N'Desc de Categoria 1');

INSERT INTO Prod.Category (CategoryName,Description)
VALUES (N'Categoria 2',NULL);

SELECT *
FROM Prod.Category
WHERE Description = '';

SELECT *
FROM Prod.Category
WHERE Description IS NULL;

SELECT *
FROM Prod.Category
WHERE Description IS NULL
OR Description = '';

SELECT *
FROM Prod.Category
WHERE Description IS NOT NULL
AND Description <> N'';

INSERT INTO Prod.Category (CategoryName,Description)
VALUES (NULL,NULL);

CREATE SCHEMA Ventas;

CREATE TABLE DetalleFactura(
ProductoID INT NOT NULL,
Cantidad INT NOT NULL,
Precio NUMERIC(10,2),
SubTotal AS Precio * Cantidad
);

SELECT ProductoID
      ,Cantidad
	  ,Precio
	  ,(Precio * Cantidad) AS SubTotal
FROM dbo.DetalleFactura;

ALTER TABLE DetalleFactura
ALTER COLUMN Precio NUMERIC(12,2);