USE TSQLV4;

CREATE OR ALTER VIEW v_EstadisticaXCliente
AS
SELECT C.companyname
      ,COUNT(DISTINCT O.orderid) AS  CantidadOrdenes
	  ,SUM((OD.qty * OD.unitprice) - OD.discount) AS MontoTotal
	  ,AVG((OD.qty * OD.unitprice) - OD.discount) AS MontoPromedioPorOrden
FROM Sales.Customers AS C
  INNER JOIN Sales.Orders AS O
   ON (C.custid = O.custid)
  INNER JOIN Sales.OrderDetails AS OD
    ON (O.orderid = od.orderid)
GROUP BY C.companyname;


SELECT *
FROM v_EstadisticaXCliente;

CREATE OR ALTER PROC DevolverEstadisticas
  @CustID AS INT 
AS
BEGIN

IF @CustID IS NULL 
BEGIN
	SELECT C.companyname
		  ,COUNT(DISTINCT O.orderid) AS  CantidadOrdenes
		  ,SUM((OD.qty * OD.unitprice) - OD.discount) AS MontoTotal
		  ,AVG((OD.qty * OD.unitprice) - OD.discount) AS MontoPromedioPorOrden
	FROM Sales.Customers AS C
	  INNER JOIN Sales.Orders AS O
	   ON (C.custid = O.custid)
	  INNER JOIN Sales.OrderDetails AS OD
		ON (O.orderid = od.orderid)
	GROUP BY C.companyname;
END
ELSE
BEGIN
	SELECT C.companyname
		  ,COUNT(DISTINCT O.orderid) AS  CantidadOrdenes
		  ,SUM((OD.qty * OD.unitprice) - OD.discount) AS MontoTotal
		  ,AVG((OD.qty * OD.unitprice) - OD.discount) AS MontoPromedioPorOrden
	FROM Sales.Customers AS C
	  INNER JOIN Sales.Orders AS O
	   ON (C.custid = O.custid)
	  INNER JOIN Sales.OrderDetails AS OD
		ON (O.orderid = od.orderid)
	WHERE C.custid = @CustID
	GROUP BY C.companyname;
END
END;



EXEC DevolverEstadisticas 1;

CREATE OR ALTER PROC BorrarCategoria
	@CatID AS INT
AS
BEGIN
	DELETE FROM Production.Categories 
	WHERE categoryid = @CatID;
END;

EXEC BorrarCategoria 9;


CREATE OR ALTER PROC Test
AS
BEGIN

SELECT C.companyname
		  ,COUNT(DISTINCT O.orderid) AS  CantidadOrdenes
		  ,SUM((OD.qty * OD.unitprice) - OD.discount) AS MontoTotal
		  ,AVG((OD.qty * OD.unitprice) - OD.discount) AS MontoPromedioPorOrden
	FROM Sales.Customers AS C
	  INNER JOIN Sales.Orders AS O
	   ON (C.custid = O.custid)
	  INNER JOIN Sales.OrderDetails AS OD
		ON (O.orderid = od.orderid)
	GROUP BY C.companyname;
END;

SELECT companyname
      ,MontoTotal
FROM v_EstadisticaXCliente
ORDER BY MontoTotal DESC;

EXEC TEST;