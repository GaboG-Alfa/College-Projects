USE TSQLV4

--1. Mediante una vista, obtenga las ventas del cliente por a�o, las ventas de todo el
--a�o y las ventas totales (ver ejemplo). Para esto:
--a. Use un CTE para obtener las ventas por a�o del cliente.
--b. Lo requerido debe resolverse mediante una sola instrucci�n SQL.

CREATE OR ALTER VIEW v_VistaCliente
AS
WITH CTE AS 
(SELECT  C.contactname AS contactname
        ,YEAR(O.orderdate) AS A�o
	    ,SUM(OD.qty * OD.unitprice) AS SumVtas
FROM Sales.Customers AS C
 INNER JOIN Sales.Orders AS O
   ON(C.custid = O.custid)
 INNER JOIN Sales.OrderDetails AS OD
  ON (O.orderid = OD.orderid)
GROUP BY C.contactname,
         YEAR(O.orderdate),
		 SUM(OD.qty * OD.unitprice)
)
SELECT contactname
      ,A�o
      ,SumVtas
	  ,SUM(SumVtas)OVER (PARTITION BY A�o) AS GranTotalByAnio
	  ,SUM(SumVtas) OVER() AS GranTotal
FROM CTE;

SELECT *
FROM v_VistaCliente


--2. Mediante un procedimiento almacenado obtenga el running total (acumulado)
--de los meses de un a�o dado.
--a. El a�o debe ser pasado a procedimiento.
--b. Para simplicidad use YEAR() aunque no sea SARG. Lo que se busca es el
--uso de running.
--c. Use un CTE.
CREATE OR ALTER PROC ObtenerRunningCliente
   @Anno2 AS INT
AS
WITH CTE AS 
(SELECT YEAR(O.orderdate) AS Anno
        ,MONTH(O.orderdate) AS Mes 
	    ,SUM(OD.qty * OD.unitprice) AS SumVtas
FROM Sales.Orders AS O
 INNER JOIN Sales.OrderDetails AS OD
  ON (O.orderid = OD.orderid)
   WHERE YEAR(O.orderdate) = @Anno2 
GROUP BY YEAR(O.orderdate),
         MONTH(O.orderdate)
)
SELECT Anno
      ,Mes
      ,SumVtas
	  ,SUM(SumVtas) OVER (PARTITION BY Anno
        ORDER BY Anno ,Mes
        ROWS BETWEEN UNBOUNDED PRECEDING
        AND CURRENT ROW) AS RunningTotalByMonth
FROM CTE;

EXEC dbo.ObtenerRunningCliente 2014;