CREATE OR ALTER PROC EstadoDeCuenta
 @ClienteID AS BIGINT,
 @FechaInicio AS DATE,
 @FechaFinal AS DATE
 AS
 SELECT P.personaID AS ClienteID,
        EC.descripcion AS EstadoDeCuenta
 FROM dbo.Persona AS P
 INNER JOIN dbo.Cuenta AS C
 ON(P.PersonaID = C.PersonaID)
 INNER JOIN dbo.EstadoCuenta AS EC
 ON(C.EstadoCuentaID = EC.EstadoCuentaID)
 WHERE P.TipoPersonaID = 1
       AND P.personaID = @ClienteID;

SELECT P.personaID AS ClienteID,
        TM.descripcion AS TipoMovimiento,
		M.FechaDeMovimiento AS FechaMovimiento,
		M.monto AS Monto
FROM dbo.Persona AS P
INNER JOIN dbo.Cuenta AS C
ON(P.PersonaID = C.PersonaID)
INNER JOIN dbo.Movimiento AS M
ON(C.CuentaID = M.CuentaID)
INNER JOIN dbo.TipoMovimiento AS TM
ON(M.TipoMovimientoID = TM.TipoMovientoID)
WHERE P.personaID = @ClienteID AND
      M.FechaDeMovimiento BETWEEN @FechaInicio AND @FechaFinal;

SELECT P.PrimerNombre AS Nombre,
       COALESCE(P.SegundoNombre,'N/A') AS SegundoNombre,
	   COALESCE(P.PrimerApellido,'N/A') AS PrimerApellido,
	   COALESCE(P.SegundoApellido, 'N/A') AS SegundoApellido,
	   I.Valor AS Identificacion,
	   TI.Descripcion AS TipoIdentificacion,
	   NP.Descripcion AS NaturalezaPersona
FROM dbo.Persona AS P
INNER JOIN dbo.Identificacion AS I
ON(P.IdentificacionID = I.IdentificacionID)
INNER JOIN dbo.TipoIdentificacion AS TI
ON(I.TipoIdentificacionID = TI.TipoIdentificacionID)
INNER JOIN dbo.NaturalezaPersona AS NP
ON(P.NaturalezaPersonaID = NP.NaturalezaPersonaID)
WHERE P.personaID = @ClienteID

EXEC EstadoDeCuenta 10,'20220211','20220921'


