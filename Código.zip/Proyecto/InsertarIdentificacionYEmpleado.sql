USE ProyectoGrupo3IF4100; 
CREATE OR ALTER PROC InsertarIdentificacionYEmpleado
     @IdentificacionID AS SMALLINT,
	 @TipoIdentificacionID AS SMALLINT,
	 @FechaDeExpiracion AS DATE,
	 @Valor AS BIGINT,
	 @PersonaID AS BIGINT,
	 @IdentificadorID AS SMALLINT,
	 @PrimerNombre AS NVARCHAR(30),
	 @SegundoNombre AS NVARCHAR(30),
	 @PrimerApellido AS NVARCHAR(30),
	 @SegundoApellido AS NVARCHAR(30),
	 @TipoPersonaID AS SMALLINT
AS
BEGIN

INSERT INTO dbo.Identificacion(IdentificacionID,TipoIdentificacionID,FechaDeExpiracion,Valor) 
VALUES(@IdentificacionID,@TipoIdentificacionID,@FechaDeExpiracion,@Valor)

INSERT INTO dbo.Persona(PersonaID,IdentificacionID,PrimerNombre,SegundoNombre,PrimerApellido,SegundoApellido,NaturalezaPersonaID,TipoPersonaID) 
VALUES(@PersonaID,@IdentificadorID,@PrimerNombre,@SegundoNombre,@PrimerApellido,@SegundoApellido,1,@TipoPersonaID)

END;

EXEC InsertarIdentificacionYEmpleado 11,1,'20231209',8767544433,11,11,N'Jose',N'Antonio',N'Vega',N'Suarez',2;

