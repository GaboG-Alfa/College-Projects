/*
 * Clase que representa a un alumno
 * 
 * 
 */
package Ejercicios.Alumnos;

/**
 *
 * @author Gabriel
 * @version 13/04/2021
 */
public class Alumno {

    private final String nombre;
    private final double nota1;
    private final double nota2;

    public Alumno(String nombre, double nota1, double nota2) {
        this.nombre = nombre;
        this.nota1 = nota1;
        this.nota2 = nota2;
    }

    public double promedio() {
        double promedio;

        promedio = (nota1 + nota2) / 2;
        return promedio;
    }

}
