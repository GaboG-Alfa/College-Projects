/*
 * Clase que calcula el promedio de un curso a base de 4 alumnos
 */
package Ejercicios.Alumnos;

import Ejercicios.Alumnos.Alumno;
import java.util.ArrayList;

/**
 *
 * @author Gabriel Guzmán Alfaro
 * @version 13/14/2021
 */
public class AlumnoTest {

    public static void main(String[] args) {

        //Creación de un array de alumnos
        ArrayList<Alumno> curso = new ArrayList();

        //Promediar el curso
        double promediarCurso;

        promediarCurso = 0.0;

        //Creacion de cuatro alumnos
        Alumno alumno1 = new Alumno("Juan", 80.5, 90.34); // Promedio de Juan: 85.42
        Alumno alumno2 = new Alumno("Pedro", 75.5, 92.4); // Promedio de Pedro: 83.95
        Alumno alumno3 = new Alumno("Ana", 95.5, 84.4);   // Promedio de Ana:   89.95
        Alumno alumno4 = new Alumno("Rosa", 88.21, 94.4); // Promedio de Rosa:  91,305

        //Añadir alumnos
        curso.add(alumno1);
        curso.add(alumno2);
        curso.add(alumno3);
        curso.add(alumno4);

        //Calcular el promedio del curso
        for(Alumno alumno: curso ){
            
            promediarCurso+= alumno.promedio();
        }

        //Dividir el promedio entre la cantidad de elementos
        promediarCurso /= curso.size();

        System.out.println("El promedio del curso es: " + promediarCurso); //Promedio esperado 87.65

    }

}
