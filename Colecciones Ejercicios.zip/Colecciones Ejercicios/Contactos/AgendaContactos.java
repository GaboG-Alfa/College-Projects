/*
 * Clase que guarda las funcionalidades de una agenda
 */
package Ejercicios.Contactos;

import java.util.ArrayList;
import javax.swing.JTextField;

/**
 *
 * @author Gabriel Guzmán Alfaro
 * @version 13/04/2021
 */
public class AgendaContactos {

    private final ArrayList<Contacto> agenda = new ArrayList<>();

    /**
     * Agregar contactos a la agenda
     *
     * @param contacto
     */
    public void agregarContacto(String nombre, String telefono, String correo) {

        agenda.add(new Contacto(nombre,telefono,correo));

    }

    /**
     * Imprime todo los contactos agregados
     */
    public void verTodoContacto() {

        String mensaje;

        mensaje = "Contactos de la agenda ";

        //Iterar el texto e imprimir todos los contactos
        for (Contacto contacto : agenda) {
            mensaje += "\n Nombre: " + contacto.getNombre()
                    + " Teléfono: " + contacto.getTelefono() + " Email: " + contacto.getEmail();
        }

        System.out.println(mensaje);
    }

    /**
     * Busca un contacto por nombre
     *
     * @param nombre
     */
    public void buscarNombre(String nombre) {

        //Contador de busqueda
        int contador;

        contador = 0;

        //Recorre la agenda
        for (Contacto contacto : agenda) {

            //Selecciona el contacto esperado 
            if (contacto.getNombre().equals(nombre)) {
                contador += 1;
                System.out.println("Contacto " + nombre + " fue encontrado!");
            }
        }

        //Mensaje en caso de no encontrar el elemento
        if (contador == 0) {
            System.out.println("El contacto " + nombre + " no fue encontrado!");
        }
    }

    /**
     * Busca un contacto por índice
     *
     * @param indice
     */
    public void buscarIndice(int indice) {

        //Contador de busqueda
        int contador;

        contador = 0;

        //Recorre la agenda
        for (int i = 0; i < agenda.size(); i++) {

            //Selecciona el contacto esperado 
            if (i == indice) {
                contador += 1;
                System.out.println("Contacto " + agenda.get(i).getNombre() + " en la posición " + indice + " fue encontrado!");
            }
        }

        //Mensaje en caso de no encontrar el elemento
        if (contador == 0) {
            System.out.println("La posición " + indice + " no existe!");
        }
    }

    /**
     * Borra un contacto por nombre
     *
     * @param nombre
     */
    public void borrarContactoNombre(String nombre) {

        //Contador de busqueda
        int contador;

        contador = 0;

        //Recorre la agenda
        for (int i = 0; i < agenda.size(); i++) {

            //Selecciona el contacto por nombre y lo borra
            if (agenda.get(i).getNombre().equals(nombre)) {

                contador += 1;

                System.out.println("Contacto " + nombre + " fue borrado!");

                agenda.remove(agenda.get(i));

            }
        }

        //En caso de no encontrar el contacto
        if (contador == 0) {
            System.out.println("El contacto " + nombre + " no fue encontrado!");
        }
    }

    /**
     * Borra un contacto por índice
     *
     * @param indice
     */
    public void borrarContactoIndice(int indice) {

        //En caso de no ecnotrar el contacto
        if (indice < 0 || indice > agenda.size()) {
            System.out.println("Posición inválida!");
        }

        //Borrar el contacto de la agenda por su posición
        System.out.println("Contacto " + agenda.get(indice).getNombre() + " en la posición " + indice + " fue borrado!");

        agenda.remove(agenda.get(indice));

    }

    /**
     * Borrar todos los contactos de la agenda
     */
    public void eliminarTodos() {

            agenda.removeAll(agenda);
    }

    void agregarContacto(JTextField nombre, JTextField telefono, JTextField correo) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
