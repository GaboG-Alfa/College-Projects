/*
 * Clase que guarda la infromación de un contacto
 */
package Ejercicios.Contactos;

/**
 *
 * @author Gabriel Guzmán Alfaro
 * @version 13/04/2021
 */
public class Contacto {

    private  String nombre;
    private String telefono;
    private  String email;

    /**
     * Constructor
     *
     * @param nombre
     * @param telefono
     * @param email
     */
    public Contacto(String nombre, String telefono, String email) {
        this.nombre = nombre;
        this.telefono = telefono;
        this.email = email;
    }
    
    /**
     * Obtener el nombre del contacto
     * @return nombre 
     */
    public String getNombre() {
        return nombre;
    }
    
    /**
     * Obtener el telefono del contacto
     * @return telefono 
     */
    public String getTelefono() {
        return telefono;
    }

    /**
     * Obtener el email del contacto
     * @return email
     */
    public String getEmail() {
        return email;
    }

   

    
}
