package Ejercicios.Contactos;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import java.awt.FlowLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Menu extends JFrame {

    private JLabel menuL, nombreL, telefonoL, correoL; // Label para menu
    private JTextField nombre, telefono, correo;
    private String contacto;
    private JButton opcionA, opcionB, opcionC, opcionD, opcionE, opcionF, opcionG, exit; // Botones de mostrar y salir

    /*
    * Clase an�nima para listener, enlace:
    * 
    * http://chuwiki.chuidiang.org/index.php?title=ActionListener#:~:text=%
    * 20ActionListener%20%201%20Los%20ActionListener.%20Los%20componentes,%20...%
    * 20Este%20m%C3%A9todo%20sigue%20presentando...%20More%20
    * 
     */
    public Menu() {
        super("Agenda de contactos");

        // Instanciar la agenda de contactos
        AgendaContactos agenda = new AgendaContactos();

        setLayout(new FlowLayout(FlowLayout.LEFT, 5, 10));

        // Declaramos los objetos que estaran dentro del JFrame
        menuL = new JLabel("Pulse el botón con la opción");
        nombreL = new JLabel("Nombre del contacto:");
        nombre = new JTextField(10);
        telefonoL = new JLabel("Telefono del contacto:");
        telefono = new JTextField(10);
        correoL = new JLabel("Correo del contacto:");
        correo = new JTextField(10);
        opcionA = new JButton("Agregar contacto");
        opcionB = new JButton("Ver todos los contactos");
        opcionC = new JButton("Buscar un contacto por su nombre");
        opcionD = new JButton("Buscar un contacto por su posición");
        opcionE = new JButton("Borrar un contacto por nombre");
        opcionF = new JButton("Borrar un contacto por posición en la lista");
        opcionG = new JButton("Eliminar todos los contactos");
        exit = new JButton("Salir");

        // Agregamos los objetos en el orden deseado al JFrame
        add(menuL);
        add(nombreL);
        add(nombre);
        add(telefonoL);
        add(telefono);
        add(correoL);
        add(correo);
        add(opcionA);
        add(opcionB);
        add(opcionC);
        add(opcionD);
        add(opcionE);
        add(opcionF);
        add(opcionG);
        add(exit);

        // Programamos los Listener de cada Boton
        opcionA.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent evento) {
                
                agenda.agregarContacto(nombre.getText(),telefono.getText(),correo.getText());

            }
        });

        opcionB.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evento) {

                //Ver contactos de la lista
                agenda.verTodoContacto();
            }
        });

        opcionC.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evento) {

                contacto = JOptionPane.showInputDialog(null, "Ingrese el nombre del contacto a Buscar", "Buscar por nombre",
                        JOptionPane.INFORMATION_MESSAGE);

                //Buscar por nombre
                agenda.buscarNombre(contacto);
            }
        });

        opcionD.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evento) {

                contacto = JOptionPane.showInputDialog(null, "Ingrese la posición del contacto a buscar", "Buscar por índice",
                        JOptionPane.INFORMATION_MESSAGE);

                //Buscar por indice
                agenda.buscarIndice(Integer.parseInt(contacto));
            }
        });

        opcionE.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evento) {

                contacto = JOptionPane.showInputDialog(null, "Ingrese el nombre del contacto a borrar", "Borrar por nombre",
                        JOptionPane.INFORMATION_MESSAGE);

                //Borrar por nombre
                agenda.borrarContactoNombre(contacto);
            }
        });

        opcionF.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evento) {

                contacto = JOptionPane.showInputDialog(null, "Ingrese la posición del contacto a borrar", "Borrar por índice",
                        JOptionPane.INFORMATION_MESSAGE);

                //Borrar por indice
                agenda.borrarContactoIndice(Integer.parseInt(contacto));
            }
        });

        opcionG.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evento) {

                //Borrar todos
                agenda.eliminarTodos();

                JOptionPane.showMessageDialog(null, "La lista se vació", "Vaciar lista",
                        JOptionPane.INFORMATION_MESSAGE);

            }
        });

        exit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evento) {
                JOptionPane.showMessageDialog(null, "Saldra la aplicacion", "WARNING", JOptionPane.WARNING_MESSAGE);
                System.exit(0);
            }
        });

    }

    // Metodo main()
    public static void main(String args[]) {
        Menu listen = new Menu();
        listen.setLocationRelativeTo(null);
        listen.setSize(300, 175);
        listen.setVisible(true);
    }

}
