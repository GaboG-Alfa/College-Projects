/*
 * Clase Test triángulo que prueba el funcionamiento de un triángulo
 */
package Ejercicios.Triangulo;

import Ejercicios.Triangulo.Triangulo;
import java.util.ArrayList;

/**
 *
 * @author Gabriel Guzmán
 * @version 14/4/2021
 */
public class TrianguloTest {
    
    /**
     * Main
     * @param args 
     */
    public static void main(String[] args){
        
        //Atributo
        double promedioHipotenusas=0.0;
        double promedioAreas=0.0;
        double promedioGeneral=0.0;
        
        //Creación de los triángulos
        Triangulo triangulo1 = new Triangulo(11,12);
        Triangulo triangulo2 = new Triangulo(15,16);
        Triangulo triangulo3 = new Triangulo(20,22);
        Triangulo triangulo4 = new Triangulo(30,35);
        Triangulo triangulo5 = new Triangulo(40,45);
        
        //Creación de un array
        ArrayList<Triangulo> trianguloArray = new ArrayList<>();
        
        //Añadir triángulos
        trianguloArray.add(triangulo1);
        trianguloArray.add(triangulo2);
        trianguloArray.add(triangulo3);
        trianguloArray.add(triangulo4);
        trianguloArray.add(triangulo5);
        
        //Calcular c
        triangulo1.calcularC();
        triangulo2.calcularC();
        triangulo3.calcularC();
        triangulo4.calcularC();
        triangulo5.calcularC();
        
        //Promedio 
        for(Triangulo triangulo : trianguloArray){
            
            promedioHipotenusas+= triangulo.hipotenusa();
            promedioAreas+= triangulo.area();
        }
        
        //Promedio Hipotenusa
        promedioHipotenusas/=trianguloArray.size();
        
        //Promedio Área
        promedioAreas/=trianguloArray.size();
        
        //Promedio de promedios
        promedioGeneral=(promedioHipotenusas+promedioAreas)/2;
        
        //Imprimir los promedios
        System.out.println("Hipotenusa: "+promedioHipotenusas+" Áreas: "+promedioAreas+" Promedio de promedios: "+promedioGeneral);
        
        
        
    }
}
