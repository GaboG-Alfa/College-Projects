/*
 * La clase triángulo se encarga de representar el funcionamiento de un triángulo
 */
package Ejercicios.Triangulo;

/**
 *
 * @author Gabriel Guzmán
 * @version 14/04/2021
 */
public class Triangulo {
    
    //Atributos
    private double a;
    private double b;
    private double c;

    /**
     * Constructor
     * @param a
     * @param b
     * @param c 
     */
    public Triangulo(double a, double b) {
        this.a = a;
        this.b = b;
    }
    
    /**
     * Método para calcular c
     */
    public void calcularC (){
        
        c = Math.sqrt(Math.pow(a, 2) + Math.pow(b, 2));
    }
    
    /**
     * Obtiene el área del triángulo
     * @return area
     */
    public double area(){
        
        return (a*b)/2;
    }
    
    /**
     * Obtiene la hipotenusa del triángulo
     * @return hipotenusa 
     */
    public double hipotenusa(){
        
        return c; 
    }
    
    
}
