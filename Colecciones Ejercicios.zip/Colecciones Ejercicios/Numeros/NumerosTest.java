/*
 * Programa que hace una búsqueda de enteros dentro de un arrayList
 */
package Ejercicios.Numeros;

import java.util.ArrayList;
import java.util.Collections;

/**
 *
 * @author Gabriel Guzmán
 * @version 13/04/2021
 */
public class NumerosTest {

    public static void main(String[] args) {

        //Promedio
        Integer promedio;
        promedio = 0;

        int contador;
        contador=0;
        
        //ArrayList de integer
        ArrayList<Integer> arrayInteger = new ArrayList<>();

        Integer numero1 = (int) (Math.random() * 100);
        Integer numero2 = (int) (Math.random() * 100);
        Integer numero3 = (int) (Math.random() * 100);
        Integer numero4 = (int) (Math.random() * 100);
        Integer numero5 = (int) (Math.random() * 100);

        arrayInteger.add(numero1);
        arrayInteger.add(numero2);
        arrayInteger.add(numero3);
        arrayInteger.add(numero4);
        arrayInteger.add(numero5);

        
        //Ordenar el arreglo de menor a mayor 
        Collections.sort(arrayInteger);
        

        //Ver el array
        for(Integer numeros: arrayInteger){
            
            System.out.println("Números de array "+numeros);
        }
        
        //Recorre el array
        for (int i = 0; i < arrayInteger.size(); i++) {

            //Imprimir el menor
            if (i == 0) {
                System.out.println("Número menor: " + arrayInteger.get(i));
            }

            //Imprimir los números pares mayores a 23
            if (((arrayInteger.get(i) % 2) == 0) && (arrayInteger.get(i)>23)) {
                
                contador+=1;             
            }

            //Imprimir el menor
            if (i == 4) {
                System.out.println("Número mayor: " + arrayInteger.get(i));
            }

            //Almacenar el promedio
            promedio += arrayInteger.get(i);
        }

        //Imprimir promedio
        promedio /= arrayInteger.size();

        System.out.println("Promedio: " + promedio);
        
        System.out.println("Números pares mayores a 23: " + contador); 
    }
    
}
