/*
 * Clase que guarda un arreglo con objetos Persona
 */
package Ejercicios.Persona;

import java.util.ArrayList;

/**
 *
 * @author Gabriel Guzmán
 * @version 16/4/2021
 */
public class PersonArray {
    
    private ArrayList<Person>personArray = new ArrayList<>();

    /**
     * 
     * @param person 
     */
    public void addPerson (Person person) {
        personArray.add(person);
    } 

    public ArrayList<Person> getPersonArray() {
        return personArray;
    }
    
    
    
}
