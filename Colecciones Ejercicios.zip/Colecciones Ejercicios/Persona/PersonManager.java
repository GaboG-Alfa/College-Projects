/*
 * La clase person manager ordena el arreglo de personas por edad y nombre 
 */
package Ejercicios.Persona;

import java.util.ArrayList;
import java.util.Collections;

/**
 *
 * @author Gabriel Guzmán
 * @version 16/04/2021
 */
public class PersonManager {

    //Atributo
    private ArrayList<Person> personArray;
    private int sensorNombre;
    private int sensorEdad;

    public PersonManager(ArrayList<Person> personArray) {
        this.personArray = personArray;
        this.sensorNombre=0;
    }

    /**
     * Ordenar las personas por edad
     *
     * @return personArray
     */
    public ArrayList<Person>  ordenarPorEdad() {

        sensorEdad+=1;
        
        Collections.sort(personArray, Person.DESCENDING_COMPARATOR);
        
        if(sensorEdad%2!=0){
            Collections.sort(personArray,Person.Ascending_COMPARATOR);
        }
        
        return personArray;
    }

    /**
     * Ordenar las personas por nombre
     *
     * @return personArray
     */
    public ArrayList<Person> ordenarPorNombre() {

        sensorNombre+=1;
        
        Collections.sort(personArray);
       
        if(sensorNombre%2!=0 ){
            Collections.sort(personArray,Collections.reverseOrder());
        }
        
        return personArray;
    }
}
