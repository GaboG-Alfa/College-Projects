package Ejercicios.Persona;

import javax.swing.*;
import javax.swing.table.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;


public class TablePerson {    
     private JFrame f;
     private JButton sortId, sortName, exit;
     private JTable jt;
     private JPanel panel;
     private JScrollPane pane;
     private DefaultTableModel model;
     
     public TablePerson(){
         
         //Crear tres personas
         Person persona1 = new Person("Juan",3);
         Person persona2 = new Person("María",1);
         Person persona3 = new Person("Ana",2);
         
         //Llamar al array de personas
         PersonArray personArray = new PersonArray();
         
         personArray.addPerson(persona1);
         personArray.addPerson(persona2);
         personArray.addPerson(persona3);
         
         
         //Llamar al personManager
         PersonManager personManager = new PersonManager(personArray.getPersonArray());
         
       
         f = new JFrame();
         f.setLayout(new FlowLayout(FlowLayout.LEFT,5,10));
         f.setLocationRelativeTo(null);
         f.setSize(200,300);
         
         model = new DefaultTableModel();
         model.addColumn("ID");
         model.addColumn("Name");
         
         for(Person person:personArray.getPersonArray()){
         model.addRow(new Object[]{person.getAge(),person.getName()});
         }
         
         jt=new JTable(model);

	      panel = new JPanel();
	      panel.add(jt, BorderLayout.CENTER);
	      pane = new JScrollPane(panel);
         final Dimension d = pane.getSize();
	      d.setSize( d.width + 170, d.height + 100 );
	      pane.setSize(d);
	      pane.setPreferredSize(d);         
         
         sortId = new JButton( "Ordenar x Id" );
         sortName= new JButton( "Ordenar x Nombre" );
         exit = new JButton( "Salir" );
         
         jt.getColumnModel().getColumn(0).setMaxWidth(100);
         jt.getColumnModel().getColumn(1).setMaxWidth(300);
	      f.add( pane, BorderLayout.CENTER );
         f.add(sortId);
         f.add(sortName);
         f.add(exit);

         sortId.addActionListener(new ActionListener(){
         public void actionPerformed( ActionEvent evento ){

         model.setRowCount(0);
 
        //Añadirlo a la interfaz de forma ordenada por edad
        for(Person person: personManager.ordenarPorEdad()){
         model.addRow(new Object[]{person.getAge(),person.getName()});
         }
            
                     
         }
         });         
         
         exit.addActionListener(new ActionListener(){
         public void actionPerformed( ActionEvent evento ){
            System.exit(0);       
         }
         });
         
         sortName.addActionListener(new ActionListener(){
         public void actionPerformed( ActionEvent evento ){

         model.setRowCount(0);

        //Añadirlo a la interfaz de forma ordenada por nombre
        for(Person person: personManager.ordenarPorNombre()){
         model.addRow(new Object[]{person.getAge(),person.getName()});
         }
            
                     
         }
         });         
         exit.addActionListener(new ActionListener(){
         public void actionPerformed( ActionEvent evento ){
            System.exit(0);       
         }
         });
         
         f.setVisible(true);    
   }

   
   
   

   public static void main(String[] args) {    
     new TablePerson();    
   }    
}
