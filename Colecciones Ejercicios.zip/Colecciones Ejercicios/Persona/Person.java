/*
 * Clase que representa una persona
 */
package Ejercicios.Persona;

import java.util.Comparator;

/**
 *
 * @author Gabriel Guzmán
 * @version 14/04/2021
 */
public class Person implements Comparable{

    //Atributos
    private String name;
    private int age;

    /**
     * Obtener el nombre
     *
     * @return name
     */
    public String getName() {
        return name;
    }

    /**
     * Obtener la edad
     *
     * @return age
     */
    public int getAge() {
        return age;
    }

    /**
     * Constructor
     *
     * @param name
     * @param age
     */
    public Person(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public int compareTo(Object person) {
        Person otraPersona = (Person) person;
        //podemos hacer esto porque String implementa Comparable
        return name.compareTo(otraPersona.getName());
    }
    
    
   
      public static final Comparator<Person> DESCENDING_COMPARATOR = new Comparator<Person>() {
        // Overriding the compare method to sort the age
        @Override
        public int compare(Person p, Person p1) {
            return p.age - p1.age;
        }
    };
      
      public static final Comparator<Person> Ascending_COMPARATOR = new Comparator<Person>() {
        // Overriding the compare method to sort the age
        @Override
        public int compare(Person p, Person p1) {
            return p1.age - p.age;
        }
    };

}
