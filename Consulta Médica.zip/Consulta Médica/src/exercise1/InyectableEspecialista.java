package exercise1;

/**
 * Clase que almacena los datos de aplicar un inyectable con un especialista
 * 
 * @author Gabriel Guzm�n Alfaro
 * @version 3 de diciembre del 2020
 */
public class InyectableEspecialista extends Inyectable {

	// Definir atributos
	private final static double PORCENTAJE_ESPECIALISTA = 0.25;

	/**
	 * Constructor con par�metros
	 * 
	 * @param precioBase
	 * @param costoMedicamento
	 */
	public InyectableEspecialista(int precioBase, int costoMedicamento) {
		super(precioBase, costoMedicamento);
	}

	/**
	 * Calcula el cobro del doctor
	 * 
	 * @return cobro del doctor
	 */
	public double calcularCobroDoctor() {
		return super.getCostoMedicamento() * PORCENTAJE_ESPECIALISTA;
	}

	@Override
	public double calcularCobroServicio() {
		return super.calcularCobroServicio() + calcularCobroDoctor();
	}

	@Override
	public String toString() {
		return "Especialista: precioBase = " + super.getPrecioBase() + ", costoMedicamento = "
				+ super.getCostoMedicamento();
	}

}