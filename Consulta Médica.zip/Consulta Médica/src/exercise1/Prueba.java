package exercise1;

/**
 * Clase que prueba los diferentes tipos de atenci�n m�dica
 * 
 * @author Gabriel Guzm�n Alfaro
 * @version 3 de diciembre del 2020
 */
public class Prueba {

	/**
	 * Main que controla el programa
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		// Aplicar polimorfismo
		ServiciosContratados servicio1 = new ConsultaMedicaEspecialista(40000, 50);
		ServiciosContratados servicio2 = new ConsultaMedicaGeneral(25000, 15);
		ServiciosContratados servicio3 = new Inyectable(5000, 8200);
		ServiciosContratados servicio4 = new InyectableEspecialista(8000, 5200);
		ServiciosContratados servicio5 = new RadiografiaDentalEspecifica(15000);
		ServiciosContratados servicio6 = new RadiografiaDentalPanoramica(10000, 2);

		// Crear vector
		ServiciosContratados vectorServicios[] = { servicio1, servicio2, servicio3, servicio4, servicio5, servicio6 };

		// Agrega el vector a la factura
		Factura factura = new Factura(vectorServicios);

		// Mostrar reporte
		System.out.println("Informaci�n de los servicios" + factura.Reporte());

	}

}
