package exercise1;

/**
 * Clase que almacena la informaci�n sobre la consulta a un m�dico
 * 
 * @author Gabriel Guzm�n Alfaro
 * @version 3 de diciembre del 2020
 */
public class ConsultaMedicaGeneral extends ServiciosContratados {

	// Definir atributos
	private final static int COBRO_CUARTO_HORA = 25000;
	private final static int TIEMPO_CITA_DOCTOR_GENERAL = 15;
	private int tiempoConsulta;

	/**
	 * Constructor con par�metros
	 * 
	 * @param precioBase
	 * @param tiempoConsulta
	 */
	public ConsultaMedicaGeneral(int precioBase, int tiempoConsulta) {
		super(precioBase);
		this.tiempoConsulta = tiempoConsulta;
	}

	/**
	 * Obtiene el tiempo de consulta
	 * 
	 * @return tiempoConsulta
	 */
	public int getTiempoConsulta() {
		return tiempoConsulta;
	}

	/**
	 * Establece el tiempo de consulta
	 * 
	 * @param tiempoConsulta
	 */
	public void setTiempoConsulta(int tiempoConsulta) {
		this.tiempoConsulta = tiempoConsulta;
	}

	/**
	 * Calcula el cobro del doctor
	 * 
	 * @return el cobro del doctor
	 */
	public double calcularCobroDoctor() {
		return Math.ceil(tiempoConsulta / TIEMPO_CITA_DOCTOR_GENERAL) * COBRO_CUARTO_HORA;
	}

	@Override
	public double calcularCobroServicio() {
		return super.getPrecioBase() + calcularCobroDoctor();
	}

	@Override
	public String toString() {
		return "ConsultaMedicaGeneral: precioBase = " + super.getPrecioBase() + ", tiempoConsulta = " + tiempoConsulta;
	}
}
