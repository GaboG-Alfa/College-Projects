package exercise1;

/**
 * Clase que almacena los datos sobre aplicar un inyectable
 * 
 * @author Gabriel Guzm�n Alfaro
 * @version 3 de diciembre del 2020
 */
public class Inyectable extends ServiciosContratados {

	// Definir atributos
	private int costoMedicamento;

	/**
	 * Constructor con par�metros
	 * 
	 * @param precioBase
	 * @param costoMedicamento
	 */
	public Inyectable(int precioBase, int costoMedicamento) {
		super(precioBase);
		this.costoMedicamento = costoMedicamento;
	}

	/**
	 * Obtiene el costo del medicamento
	 * 
	 * @return costoMedicamento
	 */
	public int getCostoMedicamento() {
		return costoMedicamento;
	}

	/**
	 * Establece el costo del medicamento
	 * 
	 * @param costoMedicamento
	 */
	public void setCostoMedicamento(int costoMedicamento) {
		this.costoMedicamento = costoMedicamento;
	}

	@Override
	public double calcularCobroServicio() {
		return super.getPrecioBase() + costoMedicamento;
	}

	@Override
	public String toString() {
		return "Inyectable: precioBase = " + super.getPrecioBase() + ", costoMedicamento = " + costoMedicamento;
	}

}