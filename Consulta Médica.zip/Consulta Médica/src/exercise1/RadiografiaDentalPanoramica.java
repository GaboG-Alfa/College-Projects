package exercise1;

/**
 * Clase que almacena datos de una radiograf�a dental panor�mica
 * 
 * @author Gabriel Guzm�n Alfaro
 * @version 3 de diciembre del 2020
 */
public class RadiografiaDentalPanoramica extends RadiografiaDentalEspecifica {

	// Definir atributos
	private static final int TIPO_RADIOGRAFIA_SUPERIOR = 1;
	private static final int TIPO_RADIOGRAFIA_INFERIOR = 2;
	private static final int COSTO_RADIOGRAFIA_SUPERIOR = 20000;
	private static final int COSTO_RADIOGRAFIA_INFERIOR = 22000;
	private static final int COSTO_RADIOGRAFIA_GLOBAL = 30000;
	private int tipoRadiografia;

	/**
	 * Constructor con par�metros
	 * 
	 * @param precioBase
	 * @param tipoRadiografia
	 */
	public RadiografiaDentalPanoramica(int precioBase, int tipoRadiografia) {
		super(precioBase);
		this.tipoRadiografia = tipoRadiografia;
	}

	/**
	 * Obtiene el tipo de radiografia
	 * 
	 * @return tipoRadiografia
	 */
	public int getTipoRadiografia() {
		return tipoRadiografia;
	}

	/**
	 * Establece el tipo de radiograf�a
	 * 
	 * @param tipoRadiografia
	 */
	public void setTipoRadiografia(int tipoRadiografia) {
		this.tipoRadiografia = tipoRadiografia;
	}

	@Override
	public double calcularCobroServicio() {
		if (tipoRadiografia == TIPO_RADIOGRAFIA_INFERIOR) {
			return super.getPrecioBase() + COSTO_RADIOGRAFIA_INFERIOR;
		}
		if (tipoRadiografia == TIPO_RADIOGRAFIA_SUPERIOR) {
			return super.getPrecioBase() + COSTO_RADIOGRAFIA_SUPERIOR;
		}
		return super.getPrecioBase() + COSTO_RADIOGRAFIA_GLOBAL;
	}

	@Override
	public String toString() {
		return "RadiografiaPanor�mica: precioBase = " + super.getPrecioBase() + ", tipo de radiograf�a = "
				+ tipoRadiografia;
	}

}
