package exercise1;

/**
 * Clase que almacena la informaci�n de la factura de la consulta
 * 
 * @author Gabriel Guzm�n Alfaro
 * @version 3 de diciembre del 2020
 */
public class Factura {

	// Definir atributo
	private ServiciosContratados listaServicios[];

	/**
	 * Construcotr con par�metros
	 * 
	 * @param listaServicios
	 */
	public Factura(ServiciosContratados[] serviciosLista) {

		listaServicios = new ServiciosContratados[serviciosLista.length];

		for (int i = 0; i < listaServicios.length; i++) {
			listaServicios[i] = serviciosLista[i];
		}
	}

	/**
	 * Reporta la infromaci�n de todos los servicios
	 * 
	 * @return el reporte de la factura
	 */
	public String Reporte() {

		// Define variables
		String texto = "";
		double totalServicios = 0;
		double costoDoctor = 0;
		double medicoGeneral = 0;
		double medicoEspecialista = 0;
		double inyectableEspecialista = 0;

		// Recorre la lista
		for (int i = 0; i < listaServicios.length; i++) {

			// Suma todos los cobros de servicios de la lista
			totalServicios += listaServicios[i].calcularCobroServicio();

			// No imprime los null
			if (listaServicios != null) {

				texto = texto + " \n" + "\n" + listaServicios[i].toString() + ", Cobro del servicio: "
						+ listaServicios[i].calcularCobroServicio();

				// Instanciar para una consulta m�dica general
				if (listaServicios[i] instanceof ConsultaMedicaGeneral) {
					ConsultaMedicaGeneral general = (ConsultaMedicaGeneral) listaServicios[i];
					medicoGeneral = general.calcularCobroDoctor();

					costoDoctor += medicoGeneral;

					texto = texto + ", Cobro Doctor: " + medicoGeneral;

					continue;
				}

				// Instanciar para una consulta m�dica especialista
				if (listaServicios[i] instanceof ConsultaMedicaEspecialista) {
					ConsultaMedicaEspecialista especialista = (ConsultaMedicaEspecialista) listaServicios[i];
					medicoEspecialista = especialista.calcularCobroDoctor();

					costoDoctor += medicoEspecialista;

					texto = texto + ", Cobro Doctor: " + medicoEspecialista;

					continue;

				}

				// Instanciar para aplicar un inyectable con un especialista
				if (listaServicios[i] instanceof InyectableEspecialista) {
					InyectableEspecialista inyectable = (InyectableEspecialista) listaServicios[i];
					inyectableEspecialista = inyectable.calcularCobroDoctor();

					costoDoctor += inyectableEspecialista;

					texto = texto + ", Cobro Doctor: " + inyectableEspecialista;

					continue;

				}

			}

		}

		// Imprimir totales de los cobros de los doctores y los servicios contratados

		texto = texto + "\n\nTotal de los cobros de los doctores: " + costoDoctor
				+ "\n\n\nTotal de los servicios contratados: " + totalServicios;

		return texto;

	}

}
