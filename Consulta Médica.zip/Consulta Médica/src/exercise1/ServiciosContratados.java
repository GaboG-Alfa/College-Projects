package exercise1;

/**
 * Clase que almacena infromaci�n de servicios contratados y hereda a subclases
 * 
 * @author Gabriel Guzm�n Alfaro
 * @version 3 de diciembre del 2020
 */
public abstract class ServiciosContratados {

	// Definir atributos
	private int precioBase;

	/**
	 * Constructor con par�metros
	 * 
	 * @param precioBase
	 */
	public ServiciosContratados(int precioBase) {
		this.precioBase = precioBase;
	}

	/**
	 * Obtiene el precio base
	 * 
	 * @return precioBase
	 */
	public int getPrecioBase() {
		return precioBase;
	}

	/**
	 * Establece el precio base
	 * 
	 * @param precioBase
	 */
	public void setPrecioBase(int precioBase) {
		this.precioBase = precioBase;
	}

	/**
	 * Calcula el cobro del servicio
	 * 
	 * @return el cobro del servicio
	 */
	public abstract double calcularCobroServicio();

	@Override
	public String toString() {
		return "ServiciosContratados: precioBase=" + precioBase;
	}

}
