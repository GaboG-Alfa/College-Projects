package exercise1;

/**
 * Clase que almacena la informaci�n sobre la consulta a un especialista m�dico
 * 
 * @author Gabriel Guzm�n Alfaro
 * @version 3 de diciembre del 2020
 */
public class ConsultaMedicaEspecialista extends ConsultaMedicaGeneral {

	// Definir atributos
	private final static int COBRO_MEDIA_HORA = 40000;
	private final static int COBRO_HORA = 50000;
	private final static int HORA_MINIMA = 1;
	private final static int TIEMPO_CITA_DOCTOR_ESPECIALISTA = 30;

	/**
	 * Constructor con par�metros
	 * 
	 * @param precioBase
	 * @param tiempoConsulta
	 */
	public ConsultaMedicaEspecialista(int precioBase, int tiempoConsulta) {
		super(precioBase, tiempoConsulta);
	}

	@Override
	public double calcularCobroDoctor() {
		double tiempo = Math.ceil(super.getTiempoConsulta() / TIEMPO_CITA_DOCTOR_ESPECIALISTA);
		return (tiempo == HORA_MINIMA) ? COBRO_MEDIA_HORA : tiempo * COBRO_HORA;
	}

	@Override
	public double calcularCobroServicio() {
		return super.calcularCobroServicio();
	}

	@Override
	public String toString() {
		return "ConsultaMedicaEspecialista: precioBase = " + getPrecioBase() + ", tiempoConsulta = "
				+ getTiempoConsulta();
	}

}
