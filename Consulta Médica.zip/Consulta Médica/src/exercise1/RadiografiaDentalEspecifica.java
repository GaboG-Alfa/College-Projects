package exercise1;

/**
 * Clase que almacena informaci�n sobre una radiograf�a espec�fica
 * 
 * @author Gabriel Guzm�n Alfaro
 * @version 3 de diciembre del 2020
 */
public class RadiografiaDentalEspecifica extends ServiciosContratados {

	// Definir atributos
	private final int PRECIO_RADIOGRAFIA_ESPECIFICA = 8000;

	/**
	 * Constructor con par�metros
	 * 
	 * @param precioBase
	 */
	public RadiografiaDentalEspecifica(int precioBase) {
		super(precioBase);
	}

	@Override
	public double calcularCobroServicio() {
		return super.getPrecioBase() + PRECIO_RADIOGRAFIA_ESPECIFICA;
	}

	@Override
	public String toString() {
		return "RadiografiaEspecifica: precioBase = " + super.getPrecioBase();
	}
}