/*
 *Clase que prueba el funcionamiento de una contraseña ingresada por el usuario
 */
package Ejercicios;

import javax.swing.JOptionPane;

/**
 *
 * @author Gabriel Guzmán 
 */
public class ContrasennaTest {
    
    
    public static void main (String[] args){
        
        //Instanciar
        Contrasenna contrasennaObject = new Contrasenna();
        
        //Pide al usuario la contraseña
        String contrasenna =  JOptionPane.showInputDialog(null,"Digite la contraseña","Ingreso de contraseña",JOptionPane.INFORMATION_MESSAGE);
        
        //Manda la contraseña a validar
        contrasennaObject.validarContrasenna(contrasenna);
        
        //Imprime la contraseña   
        JOptionPane.showMessageDialog (null,contrasennaObject.getContrasennaClase(),"Contraseña", JOptionPane.INFORMATION_MESSAGE); 
        
       
    }
   
}