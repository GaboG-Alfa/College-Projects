/**
 *Clase Jugador que se encarga de recibir los atributos del jugador
 * @version 12 de septiembre 2020
 * @author Gabriel Guzm�n Alfaro
 */


public class Jugador {

   /**
    *Atributos: Son las variables del objeto
    *son privadas porque solo le pertenecen a este objeto
    */ 
   private String nombre;
   private int partidasGanadas;
   private Dado dado1;
   private Dado dado2;
   public static int id = 1;
 
   /**
    *Constructor sin p�rametros
    */    
   public Jugador() {
      this("Jugador "+id);
      id++;
   
   }
    
   
  /**
   *Constructor con p�rametro
   *@param nombre como String
   */ 
   public  Jugador(String nombre) {
      this(nombre , new Dado(), new Dado());
     
   }
   
    
   /**
    *Constructor con p�rametros
    *@param nombre como String
    *@param dado1 como Dado
    *@param dado2 como Dado
    */ 
   public  Jugador(String nombre,Dado dado1, Dado dado2) {
      this.nombre = nombre;
      this.dado1 = dado1;
      this.dado2 = dado2;
     
   }
    
    

   /**
    *@Override
    *@param nom como String
    */
   public void setNombre(String nom) {
      this.nombre = nom;
   }
    
   /**
    *@Override
    *@param part como entero
    */
   public void setPartidasGanadas(int part) {
      this.partidasGanadas = part;
   }
   
  /**
   *setDado1 establece el valor del atributo
   *@param Dado1 
   */ 
   public void setDado1(Dado dado1) {
      this.dado1=dado1;
   }
   
  /**
   *setDado2 establece el valor del atributo
   *@param dado2 
   */ 
   public void setDado2(Dado dado2) {
      this.dado2=dado2;
   }
    
   /**
    *@Override
    *@return nombre como String
    */
   public String getNombre() {
      return this.nombre;
   }
    
   /**
    *@Override
    *@return partida como entero
    */
   public int getPartidasGanadas() {
      return this.partidasGanadas;
   }
    
   /**
    *@Override
    *@return dado1
    */
   public Dado getDado1() {
      return this.dado1;
   }
    
   /**
    *@Override
    *@return dado2
    */
   public Dado getDado2() {
      return this.dado2;
   }
   
   
    
   /**
    *M�todo que retorna una cadena
    *@return partida como cadena
    */
   public String toString() {
      return "Jugador";
   }
    
}//Fin de la clase Jugador