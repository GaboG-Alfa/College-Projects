/**
 * Clase Juego que contiene el m�todo iniciarJuego con sus respectivas estructuras de control
 * necesarios para iniciar el juego
 * @version 12 de septiembre 2020
 * @author Gabriel Guzm�n Alfaro
 */

public class Juego {

   /**
    *Atributos: Son las variables del objeto
    *son privadas porque solo le pertenecen a este objeto
    */
   private GestorES gestor; 
   private Jugador jugador1;
   private Jugador jugador2;

    
   /**
    *Constructor con par�metro
    *@param gestor como GestorES
    */  
   Juego(GestorES gestor) {
      this.gestor = gestor;
      this.jugador1 = new Jugador();
      this.jugador2 = new Jugador("Gabriel");
   }
    
    
   /**
   *M�todo que se encarga de inciar el juego
   */  
   public void iniciarJuego() {
    
     //Declaraci�n de variables
      int partida = 0 ; 
      int turno = 0; 
      int suma1 = 0; 
      int suma2 = 0; 
      int total1 = 0; 
      int total2 = 0;  
      int contPierde1 = 0; 
      int contPierde2 = 0; 
      int contEmpate = 0; 
      int menuReinicio = 0; 
      int contJuegos = 0; 
      int i = 0 ;    
   
   
   
     //Mensaje de bienvenida   
      gestor.mostrarMensaje("Ha comenzado el juego!", "Bienvenido al juego de dados!"); 
   
     
      do{
       
       //Determinar el momento de reiniciar
         contJuegos = contJuegos+1;
       
       //Reiniciar las variables
         if(contJuegos > 0){
            partida = 0;  
            suma1 = 0; 
            suma2 = 0; 
            contPierde1 = 0;
            contPierde2 = 0;
            contEmpate = 0;
            menuReinicio = 0;  
            i=0 ;
            jugador1.setPartidasGanadas(0);
            jugador2.setPartidasGanadas(0);
         }
      
       //Repetir hasta que se cumplieran las 3 partidas del juego   
         for(i=0;i<3;i++){
          
            partida=partida+1;   
         
            
            //Jugador 1 tira sus dados
            jugador1.getDado1().tirarDado();
            jugador1.getDado2().tirarDado();
            
            gestor.mostrarMensaje("El JUGADOR 1 a tirado sus dados!","Lanzamiento de dados");
            
            //Mostrar el nombre del jugador 1 y el valor de los dados
             
            gestor.mostrarMensaje(jugador1.getNombre() +"\n"+ "\nDADO 1"+"\nValor: "+
                                        jugador1.getDado1().getValorDado()+"\n"+"\nDADO 2"+"\nValor: "+
                                        jugador1.getDado2().getValorDado(),"Jugador 1");
                                        
           //Resultados de suma del jugador 1
            
            suma1 = jugador1.getDado1().getValorDado()+
                    jugador1.getDado2().getValorDado();
            gestor.mostrarEntero(suma1, "Suma del turno");
            
            
            //Jugador 2 tira sus dados
            jugador2.getDado1().tirarDado();
            jugador2.getDado2().tirarDado();
            
            gestor.mostrarMensaje("El JUGADOR 2 a tirado sus dados!","Lanzamiento de dados");
            
            //Mostrar el nombre del jugador 2 y el valor de los dados
                        
            gestor.mostrarMensaje(jugador2.getNombre()+"\n"+ "\nDADO 1"+"\nValor: "+
                                        jugador2.getDado1().getValorDado()+"\n"+"\nDADO 2"+"\nValor: "+
                                        jugador2.getDado2().getValorDado(),"Jugador 2");
         
            //Resultado de la suma del jugador 2
            
            suma2 = jugador2.getDado1().getValorDado()+
                    jugador2.getDado2().getValorDado();
            gestor.mostrarEntero(suma2, "Suma del turno"); 
        
             
         
            //Mostrar el fin de cada partida
            gestor.mostrarMensaje("Partida: "+partida, "Fin de partida");
         
            //Mostrar el ganador de las partidas  o si hubo empate y contar el perdedor
             
            //Partida1 
            if((partida==1)&&(suma1>suma2)){
               jugador1.setPartidasGanadas(jugador1.getPartidasGanadas()+1);
               contPierde2=contPierde2+1;
               gestor.mostrarMensaje(jugador1.getNombre(), "Ganador de la partida 1");
            
            }
            
            if((partida==1)&&(suma1<suma2)){
               jugador2.setPartidasGanadas(jugador2.getPartidasGanadas()+1);
               contPierde1=contPierde1+1;
               gestor.mostrarMensaje(jugador2.getNombre(), "Ganador de la partida 1");
            
            }
         
          
         
            if((partida==1)&&(suma1==suma2)){
               contEmpate = contEmpate+1;
               gestor.mostrarMensaje("Empate", "Empate en la partida 1"); 
            
            }
            
            
            //Partida2
            if((partida==2)&&(suma1>suma2)){
               jugador1.setPartidasGanadas(jugador1.getPartidasGanadas()+1);
               contPierde2=contPierde2+1;
               gestor.mostrarMensaje(jugador1.getNombre(), "Ganador de la partida 2");
            
            }
            
            if((partida==2)&&(suma1<suma2)){
               jugador2.setPartidasGanadas(jugador2.getPartidasGanadas()+1);
               contPierde1=contPierde1+1;
               gestor.mostrarMensaje(jugador2.getNombre(), "Ganador de la partida 2");
            
            }
         
          
         
            if((partida==2)&&(suma1==suma2)){
               contEmpate = contEmpate+1;
               gestor.mostrarMensaje("Empate", "Empate en la partida 2"); 
            
            }
            
            //Partida 3 
            if((partida==3)&&(suma1>suma2)){
               jugador1.setPartidasGanadas(jugador1.getPartidasGanadas()+1);
               contPierde2=contPierde2+1;
               gestor.mostrarMensaje(jugador1.getNombre(), "Ganador de la partida 3");
            
            }
            
            if((partida==3)&&(suma1<suma2)){
               jugador2.setPartidasGanadas(jugador2.getPartidasGanadas()+1);
               contPierde1=contPierde1+1;
               gestor.mostrarMensaje(jugador2.getNombre(), "Ganador de la partida 3");
            
            }
         
          
         
            if((partida==3)&&(suma1==suma2)){
               contEmpate = contEmpate+1;
               gestor.mostrarMensaje("Empate", "Empate en la partida 3"); 
            
            }
            
         }//Fin del for
         
            //Gana el juego el jugador 1 si gan� m�s partidas , se muestran puntos totales
         if((jugador1.getPartidasGanadas()>jugador2.getPartidasGanadas())){
            gestor.mostrarMensaje(jugador1.getNombre()+ "\nPartidas Ganadas: "+
                                  jugador1.getPartidasGanadas()+"\nPartidas Perdidas: "+contPierde1+"\n"+
                                  "\n"+jugador2.getNombre() + "\nPartidas Ganadas: "+jugador2.getPartidasGanadas()+
                                  "\nPartidas Perdidas: " +contPierde2+"\n"+"\nPartidas Empatadas: "+contEmpate+"\n"+
                                  "\nGANADOR DEL JUEGO: "+jugador1.getNombre() ,"Resultados del juego");
         }
         
            //Gana el juego el jugador 2 si gan� m�s partidas , se muestran puntos totales
         if((jugador1.getPartidasGanadas()<jugador2.getPartidasGanadas())){
            gestor.mostrarMensaje(jugador1.getNombre()+ "\nPartidas Ganadas: "+
                                 jugador1.getPartidasGanadas()+"\nPartidas Perdidas: "+contPierde1+"\n"+"\n"+jugador2.getNombre() + "\nPartidas Ganadas: "+
                                 jugador2.getPartidasGanadas()+"\nPartidas Perdidas: " +contPierde2+ "\n"+"\nPartidas Empatadas: "+
                                 contEmpate+"\n"+"\nGANADOR DEL JUEGO: "+jugador2.getNombre() ,"Resultados del juego");
         }
         
            //Se muestra si hubo empates , se muestran puntos totales
         if((jugador1.getPartidasGanadas()==jugador2.getPartidasGanadas())){
            gestor.mostrarMensaje(jugador1.getNombre()+ "\nPartidas Ganadas: "+
                                     jugador1.getPartidasGanadas()+"\nPartidas Perdidas: "+contPierde1+"\n"+"\n"+jugador2.getNombre()+ "\nPartidas Ganadas: "+
                                     jugador2.getPartidasGanadas()+"\nPartidas Perdidas: " +contPierde2+"\n"+"\nPartidas Empatadas: "+
                                     contEmpate+"\n"+"\nJUEGO EMPATADO","Resultados del juego");
         }
         
      
         //Se solicita al usuario si desea jugar m�s                      
         menuReinicio = gestor.menuReinicio("Desea jugar de nuevo?"); 
      
      }while(menuReinicio==0);
    
   } // Fin de iniciarJuego
    
}//Fin de la clase
