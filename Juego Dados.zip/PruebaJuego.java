/**
 *Clase PruebaJuego que se encarga de dirigir el programa con el m�todo main
 * @version 12 de septiembre 2020
 * @author Gabriel Guzm�n Alfaro
 */

 /**
 *Clase principal del programa
 */
 public class PruebaJuego {
   
   /**
   *M�todo que controla el programa
   *@param args como String[]
   */
   public static void main(String []args){
       
        //Para llamar a los m�todos de la clase GestorES
        GestorES gestorES= new GestorES();
        
        
        //Creaci�n del objeto Juego para acceder a la clase juego
        Juego objetoJuego = new Juego(gestorES);

        //Se inicia el juego llamando al m�todo de iniciar juego de la clase Juego
        objetoJuego.iniciarJuego();    
    
    }//Fin del main 
    
}//Fin de la clase 