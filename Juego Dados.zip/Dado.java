import java.lang.Math;

/**
 * Clase Dado que se encarga de recibir los atributos numeroCaras y valor m�nimo
 * necesarios para calcular el valor final del dado
 * @version 12 de septiembre 2020
 * @author Gabriel Guzm�n Alfaro
 */


public class Dado {

  /**
    *Atributos: Son las variables del objeto
    *son privadas porque solo le pertenecen a este objeto
    */
    private int numeroMayor;
    private int valorDado;
    private int rand;
 
  /**
   *Metodo constructor del objeto,
   *se inicializan las variables
   */  
    public Dado () {
         numeroMayor=6;
         valorDado=0;
    }
    
   /**
    *Constructor con par�metros  
    *@param numM como entero
    *@param valDado como entero
    *@param rand como entero
    */
    public  Dado(int numM , int valDado,int rand) {
        this.numeroMayor=numM;
        this.valorDado=valDado;
        this.rand=rand;
    }
   
    
   /**
    *@Override
    *@return valorDado como entero
    */ 
    public int getValorDado() {
        return this.valorDado= this.rand;
    }
    
    /**
    *M�todo que calcula un n�mero al azar al recibir 
    *el n�mero de caras de un dado y su valor m�nimo
    *@param range como entero
    *@param variableValorMin como entero
    */  
    public void tirarDado() {
        this.rand=(int)(Math.random()*5)+1;
    }
    

   /**
    *M�todo que retorna una cadena
    *return valorDado como cadena
    */
    public String toString() {
        return "\nValor: " +valorDado ;
    }
    
}//Fin de la clase Dado