/**
 * Clase que representa la funcionalidad de un candado
 *
 * @author Gabriel Guzman
 * @version 8/4/2021
 */
package Ejercicios;

public class Candado {

    //Atributos
    private int[] combinacion;
    private boolean estado = false;

    /**
     * Constructor
     */
    public Candado() {
        this.combinacion = new int[4];
    }

    /**
     * Abre el candado
     *
     * @param validarCombinacion
     * @return boolean
     */
    public boolean abrir(int[] validarCombinacion) {

        for (int i = 0; i < combinacion.length; i++) {

            if (combinacion[i] != validarCombinacion[i]) {

                return false;
            }

        }

        return this.estado = true;
    }

    /**
     * Cierra el candado
     *
     * @return cerrar
     */
    public boolean cerrar() {

        if (estado == true) {

            return true;
        }

        return false;
    }

    public boolean estado() {

        if (estado == true) {
            return true;
        }

        return false;

    }

    /**
     * Cambia la combinacion del candado
     *
     * @param combinacionActual
     * @param nuevaCombinacion
     * @return un array
     */
    public boolean cambiarCombinacion(int[] combinacionActual, int[] nuevaCombinacion) {

        //Contador
        int cont = 0;
        int contExcepcion = 0;

        //Recorrer el arreglo
        for (int i = 0; i < combinacion.length; i++) {

            //Verifica si un solo digito es distinto para no lanzar excepción
            if (combinacionActual[i] != nuevaCombinacion[i]) {

                contExcepcion += 1;
            }

            //Verifica si un solo digito es distinto para no guardar la combinacion
            if (combinacion[i] != combinacionActual[i]) {

                cont += 1;

                return estado;

            }

            //Excepción si la combinación posee números negativos
            if (nuevaCombinacion[i] < 0) {

                throw new IllegalArgumentException("Error, la combinación posee números negativos");
            }

        }

        //Si ningun digito fue distinto hace el cambio
        if (cont == 0) {

            combinacion = nuevaCombinacion;
        }

        //Si ningun digito fue distinto lanza la excepción
        if ((contExcepcion == 0) && (nuevaCombinacion.length <= 4)) {

            throw new IllegalArgumentException("Error, la combinación actual es igual a la nueva");
        }

        //Excepción si la combinación supera los 4 digitos
        if (nuevaCombinacion.length > 4) {
            throw new IllegalArgumentException("Error, combinación fuera del límite!");
        }

        return estado;

    }

}
