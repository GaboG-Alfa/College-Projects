/*
 * Clase que prueba el funcionamiento de una contraseña ingresada por el usuario
 */
package Ejercicios;

/**
 *
 * @author Gabriel Guzmán
 */
public class CandadoTest {

    public static void main(String[] args) {
         
        //Instanciar
        Candado candado = new Candado();
        
        //Definir arreglo
        int[] combinacionVieja = new int[]{0,0,0,0};
        int[] combinacionNueva = new int[]{9,3,2,1};
        
        //Probar cambiar candado
        
        System.out.println(candado.cambiarCombinacion(combinacionVieja, combinacionNueva));
        
        
        //Probar abrir candado
        System.out.println(candado.abrir(combinacionNueva));

        //Probar cerrar candado
        System.out.println(candado.cerrar());

        //Probar estado candado
        System.out.println(candado.estado());
    }

}
