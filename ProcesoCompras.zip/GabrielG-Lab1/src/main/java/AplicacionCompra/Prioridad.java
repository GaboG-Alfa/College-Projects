/*
 * Enumeracion de las prioridades de la compra
 */
package AplicacionCompra;

/**
 *
 * @author Gabriel Guzmán Alfaro
 * @version 21/04/2021
 */
public enum Prioridad {
    
    SiguienteDia,
    De2a5Días,
    EntregaGeneral;
    
}
