/*
 *Clase que guarda información de un producto
 */
package AplicacionCompra;

/**
 *
 * @author Gabriel Guzmán
 * @version 21/04/2021
 */
public class Producto {
    
    //Atributos
    private String codigo;
    private int cantidad;
    private double peso;

    /**
     * Constructor
     * @param codigo
     * @param cantidad
     * @param peso 
     */
    public Producto(String codigo, int cantidad, double peso) {
        this.codigo = codigo;
        this.cantidad = cantidad;
        this.peso = peso;
    }
    
    
    /**
     * Obtener el peso general del producto
     * @return pesoGeneral 
     */
    public double pesoGeneral(){
        
        double pesoGeneral;
        
        pesoGeneral = cantidad * peso;
        
        return pesoGeneral;
    }

    /**
     * Obtener el codigo
     * @return codigo 
     */
    public String getCodigo() {
        return codigo;
    }

    /**
     * Obtener cantidad
     * @return cantidad 
     */
    public int getCantidad() {
        return cantidad;
    }

    /**
     * Obtener peso
     * @return peso 
     */
    public double getPeso() {
        return peso;
    }
    

    @Override
    public String toString() {
        
        return "Producto: " + " codigo = " + codigo + ", cantidad = " + cantidad + ", peso = " + peso;
    }
    
    
    
}
