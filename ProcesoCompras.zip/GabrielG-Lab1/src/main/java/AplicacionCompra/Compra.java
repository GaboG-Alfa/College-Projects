/*
 * Clase que maneja información referente a una compra
 */
package AplicacionCompra;

import java.util.TreeMap;
import java.util.Collection;
import java.util.Iterator;
import java.util.Calendar;
import java.text.SimpleDateFormat;

/**
 *
 * @author Gabriel Guzmán Alfaro
 * @version 21/04/2021
 */
public class Compra {

    //Atributos 
    private int consecutivo;
    private TreeMap<String, Producto> listaProductos;
    private Estado estado;
    private Prioridad prioridad;
    private Calendar fecha;
    private SimpleDateFormat sdf;

    /**
     * Constructor vacío
     */
    public Compra() {
    }

    /**
     * Constructor
     *
     * @param consecutivo
     * @param listaProductos
     * @param estado
     * @param prioridad
     */
    public Compra(int consecutivo, TreeMap<String, Producto> listaProductos, Estado estado, Prioridad prioridad, Calendar fecha) {
        this.consecutivo = consecutivo;
        this.listaProductos = listaProductos;
        this.estado = estado;
        this.prioridad = prioridad;
        this.fecha = fecha;
        this.sdf = new SimpleDateFormat("dd/MMMMM/yyyy hh:mm:ss");
    }

    /**
     * Obtener la lista de productos
     *
     * @return listaProductos
     */
    public TreeMap<String, Producto> getListaProductos() {
        return listaProductos;
    }

    /**
     *
     * @return estado
     */
    public Estado getEstado() {
        return estado;
    }

    /**
     *
     * @param estado
     */
    public void setEstado(Estado estado) {
        this.estado = estado;
    }

    /**
     *
     * @return prioridad
     */
    public Prioridad getPrioridad() {
        return prioridad;
    }

    /**
     *
     * @param prioridad
     */
    public void setPrioridad(Prioridad prioridad) {
        this.prioridad = prioridad;
    }

    /**
     *
     * @return consecutivo
     */
    public int getConsecutivo() {
        return consecutivo;
    }

    @Override
    public String toString() {

        //hilera
        String texto;

        texto = "";

        //Calcular el peso total
        double pesoTotal;
        pesoTotal = 0;

        //Crear coleccion 
        Collection colecccionProductos = listaProductos.values();

        //Crear iterador
        Iterator iteratorProducto = colecccionProductos.iterator();

        //iterar
        while (iteratorProducto.hasNext()) {

            pesoTotal += listaProductos.values().iterator().next().pesoGeneral();

            texto += "\n" + iteratorProducto.next().toString();
        }

        texto = texto + "\nEstado de compra: " + estado + ", Prioridad de compra: " + prioridad;

        texto = texto + ", Peso total: " + pesoTotal + ", Fecha: " + sdf.format(fecha.getTime());

        return "\nCompra #" + consecutivo + " : " + texto;
    }
     
}
