/*
 * Clase que contiene  las listas de compras
 */
package AplicacionCompra;

import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Collection;
import java.util.Comparator;
import java.util.PriorityQueue;
import java.util.LinkedList;
import java.util.TreeMap;
import java.util.Iterator;
import java.util.HashMap;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Gabriel Guzmán Alfaro
 * @version 21/04/2021
 */
public class GestionarCompras {

    // Atributos
    private Queue<Compra> procesamiento;
    private Map<Prioridad, Compra> enTransito;
    private LinkedList<Compra> entregadas;
    private Calendar fecha;
    private Comparator comparator = new Comparator<Compra>() {
        @Override
        public int compare(Compra o1, Compra o2) {

            return o1.getPrioridad().ordinal() - o2.getPrioridad().ordinal();
        }
    };
    private int contarSegundos;
    private int contarDias;
    private static int consecutivo;

    /**
     * Constructor
     */
    public GestionarCompras() {
        this.procesamiento = new PriorityQueue<Compra>(comparator);
        this.enTransito = new HashMap<>();
        this.entregadas = new LinkedList<>();
        this.fecha = GregorianCalendar.getInstance();
        this.consecutivo = 1;
        this.contarSegundos = 0;
        this.contarDias = 0;
    }

    /**
     * Insertar la compra a procesamiento
     *
     * @param listaProductos
     * @param Prioridad
     */
    public void compraProcesamiento(TreeMap<String, Producto> listaProductos, Prioridad prioridad) {

        try {
            Thread.sleep(100);
            contarSegundos += 1;
        } catch (InterruptedException ex) {
            Logger.getLogger(GestionarCompras.class.getName()).log(Level.SEVERE, null, ex);
        }

        Compra compra = new Compra(consecutivo++, listaProductos, Estado.Enprocesamiento, prioridad, fecha);

        procesamiento.add(compra);

        this.fecha.set(2021, Calendar.APRIL, 24, 3, 35, contarSegundos);
    }

    /**
     * Pasar las compras de procesamiento a en tránsito
     */
    public void compraEnTransito() {

        int cont = 0;

        cont += 1;

        try {
            Thread.sleep(100);

            contarSegundos += 5;

        } catch (InterruptedException ex) {
            Logger.getLogger(GestionarCompras.class.getName()).log(Level.SEVERE, null, ex);
        }

        //Guardar en nueva variables
        Compra compraTransito = new Compra();

        Prioridad prioridad;

        Collection coleccionCambio = procesamiento;

        Iterator<Compra> iterarCambio = coleccionCambio.iterator();

        // procesamientoCopia.poll() obtiene la cabeza de la lista y la elimina
        compraTransito = procesamiento.poll();

        prioridad = compraTransito.getPrioridad();

        //Cambiar fecha de acuerdo a la prioridad de entrega
        enTransito.put(prioridad, compraTransito);

        this.fecha.set(2021, Calendar.APRIL, 24, 5, 35, contarSegundos);
    }

    /**
     * Mandar las compras de tránsito a entregar
     */
    public void compraEntregada(int buscarConsecutivo) {

        try {
            Thread.sleep(100);

            contarSegundos += 1;

        } catch (InterruptedException ex) {
            Logger.getLogger(GestionarCompras.class.getName()).log(Level.SEVERE, null, ex);
        }

        //Iterar para recorrer la lista de compras en transito
        Set set = enTransito.entrySet();
        Iterator iterarEntrega = set.iterator();

        Compra compraEntregada = new Compra();

        while (iterarEntrega.hasNext()) {

            Map.Entry entregaHash = (Map.Entry) iterarEntrega.next();

            compraEntregada = (Compra) entregaHash.getValue();

            //Buscar la compra por número de entrega
            if (compraEntregada.getConsecutivo() == buscarConsecutivo) {

                compraEntregada.setEstado(Estado.Entregado);

                entregadas.add(compraEntregada);

                iterarEntrega.remove();

            }
        }

        //Cambiar fecha de acuerdo a la prioridad de entrega
        if (compraEntregada.getPrioridad() == Prioridad.SiguienteDia) {

            this.fecha.set(2021, Calendar.APRIL, 25, 6, 35, contarSegundos);

        } else if (compraEntregada.getPrioridad() == Prioridad.De2a5Días) {

            this.fecha.set(2021, Calendar.MAY, 1, 7, 35, contarSegundos);

        } else if (compraEntregada.getPrioridad() == Prioridad.EntregaGeneral) {

            this.fecha.set(2021, Calendar.MAY, 5, 8, 35, contarSegundos);

        }

    }

    /**
     *
     * @return procesamiento hilera
     */
    public String procesamientoToString() {

        //hilera
        String texto;

        texto = "";

        Iterator iteratorProceso = procesamiento.iterator();

        //iterar
        while (iteratorProceso.hasNext()) {
            // procesamientoCopia.poll() obtiene la cabeza de la lista y la elimina
            texto += "\n" + iteratorProceso.next().toString();
        }

        return "\nLista de Compras en procesamiento: \n" + texto;
    }

    /**
     *
     * @return hilera
     */
    public String enTransitoToString() {

        //hilera
        String texto;

        texto = "";

        Iterator<Compra> iterator = enTransito.values().iterator();
        Iterator<Prioridad> key = enTransito.keySet().iterator();

        //iterar el hash map de en tránsito
        while (iterator.hasNext() && key.hasNext()) {

            texto += "\n" + iterator.next().toString();
            key.next();
        }

        return "\nLista de Compras en tránsito: \n" + texto;

    }

    /**
     *
     * @return entregada hilera
     */
    public String entregadasToString() {

        //hilera
        String texto;

        texto = "";

        Iterator iterarEntrega = entregadas.iterator();

        while (iterarEntrega.hasNext()) {

            texto += iterarEntrega.next().toString();
        }

        return "\nLista de Compras Entregadas: \n" + texto;
    }

}
