/*
 * Clase que se encarga de probar las compras
 */
package AplicacionCompra;

import java.util.Random;
import java.util.TreeMap;

/**
 *
 * @author Gabriel Guzmán Alfaro
 * @version 21/04/2021
 */
public class CompraTest {

    /**
     * Método principal
     * @param args
     */
    public static void main(String[] args) {

        //Variables aleatorias
        String codigo;
        codigo = "";
        int cantidad;
        cantidad = 1;
        double peso;
        peso = 1;
        
        //Instanciar producto
        Producto producto;

        //Crear 7 listas de productos
        TreeMap<String, Producto> listaProductos1 = new TreeMap<>();
        TreeMap<String, Producto> listaProductos2 = new TreeMap<>();
        TreeMap<String, Producto> listaProductos3 = new TreeMap<>();
        TreeMap<String, Producto> listaProductos4 = new TreeMap<>();
        TreeMap<String, Producto> listaProductos5 = new TreeMap<>();
        TreeMap<String, Producto> listaProductos6 = new TreeMap<>();
        TreeMap<String, Producto> listaProductos7 = new TreeMap<>();

        //Crear lista compras
        GestionarCompras gestionarCompras = new GestionarCompras();

        //Crear codigo al azar con librería random 
        Random random = new Random();

        //Crear 3 productos en 7 listas
        for (int i = 0; i < 21; i++) {

            codigo = "" + (char) (random.nextInt(26) + 'a') + (int) (Math.random() * 100) + (char) (random.nextInt(26) + 'a');
            cantidad = (int) (Math.random() * 100);
            peso = (double) (Math.random() * 100);

            if (i < 3) {

                producto = new Producto(codigo, cantidad, peso);
                listaProductos1.put(codigo, producto);
                continue;
            }

            if (i < 6) {
                producto = new Producto(codigo, cantidad, peso);
                listaProductos2.put(codigo, producto);
                continue;
            }

            if (i < 9) {
                producto = new Producto(codigo, cantidad, peso);
                listaProductos3.put(codigo, producto);
                continue;
            }

            if (i < 12) {
                producto = new Producto(codigo, cantidad, peso);
                listaProductos4.put(codigo, producto);
                continue;
            }

            if (i < 15) {
                producto = new Producto(codigo, cantidad, peso);
                listaProductos5.put(codigo, producto);
                continue;
            }

            if (i < 18) {
                producto = new Producto(codigo, cantidad, peso);
                listaProductos6.put(codigo, producto);
                continue;
            }

            if (i < 21) {
                producto = new Producto(codigo, cantidad, peso);
                listaProductos7.put(codigo, producto);
                continue;
            }
        }
        
        //Mandar a procesamiento las 7 listas de productos para crear la compra
        gestionarCompras.compraProcesamiento(listaProductos1, Prioridad.SiguienteDia);
        gestionarCompras.compraProcesamiento(listaProductos2, Prioridad.EntregaGeneral);
        gestionarCompras.compraProcesamiento(listaProductos3, Prioridad.EntregaGeneral);
        gestionarCompras.compraProcesamiento(listaProductos4, Prioridad.SiguienteDia);
        gestionarCompras.compraProcesamiento(listaProductos5, Prioridad.De2a5Días);
        gestionarCompras.compraProcesamiento(listaProductos6, Prioridad.De2a5Días);
        gestionarCompras.compraProcesamiento(listaProductos7, Prioridad.De2a5Días);
     
        
        //Mostrar las lista de compras en procesamiento
        System.out.println(gestionarCompras.procesamientoToString());

        //Pasar las compras de procesamiento a tránsito 
        gestionarCompras.compraEnTransito();
       
        
        //Mostrar las compras que se encuentran en tránsito
        System.out.println(gestionarCompras.enTransitoToString());
        
        /*
        //Mostrar las compras que faltan de pasar a transitar
        System.out.println(gestionarCompras.procesamientoToString());
        
        //Llamar el método para mandar a entregar
        gestionarCompras.compraEntregada(6);
        
        //gestionarCompras.compraEntregada(4); //Probar mandar a entregar otra compra
        
        //Mostrar la lista de entregadas
        System.out.println(gestionarCompras.entregadasToString());
        
        //Mostrar las compras que faltan de pasar a entregar
        System.out.println(gestionarCompras.enTransitoToString());
        */
        
    }

}
