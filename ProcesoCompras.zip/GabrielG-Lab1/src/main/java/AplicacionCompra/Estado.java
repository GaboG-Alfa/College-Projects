/*
 * Enumeracion de los estados de la compra
 */
package AplicacionCompra;

/**
 *
 * @author Gabriel Guzmán Alfaro
 * @version 21/04/2021
 */
public enum Estado {
    
    Enprocesamiento,
    Entransito,
    Entregado;
}
