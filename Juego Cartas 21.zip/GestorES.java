import javax.swing.JOptionPane;

/**
 *GestorES: Contiene los metodos para la entrada y salida de datos por
 *medio de ventanas JOptionPane
 * @version 1 de octubre  2020
 * @author Gabriel Guzm�n Alfaro
 */

public class GestorES {

   /**
    *mostrarMensaje
    *@param mensaje como String
    *@param titulo como String
    */
   public void mostrarMensaje(String mensaje, String titulo) {
      JOptionPane.showMessageDialog(null, mensaje, titulo, 
                                    JOptionPane.INFORMATION_MESSAGE);
   }
     
    
   /**
    *solicitarValorString
    *@param mensaje como String
    *@return numero como entero
    */
   public int solicitarValorEntero(String mensaje) {
      int numero = Integer.parseInt(JOptionPane.showInputDialog(null,mensaje,
                                                                "Solicitud de informaci�n",
                                                                 JOptionPane.INFORMATION_MESSAGE));
       
      return numero; 
   }

    /** 
    *solicitarValorString
    *@param mensaje como String
    *@return hilera como String
    */
   public String solicitarValorString(String mensaje) {
      String hilera = JOptionPane.showInputDialog(null, mensaje,
                                                   "Solicitud de informaci�n", 
                                                    JOptionPane.INFORMATION_MESSAGE);
   
      return hilera;
   }

   /**
    *solicitarValorDouble
    *@param mensaje como String
    *@return numero como double
    */
   public double solicitarValorDouble(String mensaje) {
      double numero = Double.parseDouble(JOptionPane.
                                           showInputDialog(null, mensaje,
                                                           "Solicitud de informaci�n",
                                                            JOptionPane.INFORMATION_MESSAGE));
        
      return numero;
   }

    
    
   /**
    *solicitarValorBoolean
    *@param mensaje como String
    *@return hilera como String
    */
   public boolean solicitarValorBoolean(String mensaje) {
      String hilera = JOptionPane.showInputDialog(null, mensaje,
                                                     "Solicitud de informaci�n", 
                                                     JOptionPane.INFORMATION_MESSAGE);
         
      boolean hileraB = Boolean.parseBoolean(hilera);
         
      return hileraB;
   }

   /**
    *solicitarValorChar
    *@param mensaje como String
    *@return character como char
    */
   public char solicitarValorChar(String mensaje) {
      String hilera = JOptionPane.showInputDialog(null, mensaje,
                                                    "Solicitud de informaci�n",  
                                                     JOptionPane.INFORMATION_MESSAGE);
        
      char caracter = hilera.charAt(0);
        
      return caracter;
   }
    
    
   /**
    *mostrarEntero
    *@param numero como entero
    *@param titulo como String
    */
   public void mostrarEntero(int numero, String titulo) {
      JOptionPane.showMessageDialog(null,numero,titulo, 
                                      JOptionPane.INFORMATION_MESSAGE); 
   }
    
    
    
    
  /**
   *menuReinicio muestra una caja de reinicio
   *@param mensaje como String
   *@return numero como entero
   */
   public int menuReinicio(String mensaje) {
      int numero = JOptionPane.showOptionDialog(null,mensaje,"Seleccione",
                                                 JOptionPane.DEFAULT_OPTION,JOptionPane.QUESTION_MESSAGE,
                                                 null, new Object[] { "Jugar", "Salir" },"Jugar");
       
      return numero;
   }
    
    
   /**
    *toString retorna una cadena
    *@return "Gestor ES " como cadena
    */
   public String toString() {
      return " GestorES ";
   }

   

}//Fin de la clase