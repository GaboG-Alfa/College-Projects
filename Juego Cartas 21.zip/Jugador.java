/**
 *Clase Jugador que se encarga de recibir los atributos del jugador
 * @version 1 de octubre  2020
 * @author Gabriel Guzm�n Alfaro
 */


public class Jugador {

  /**
   *Atributos: Son las variables del objeto
   *son privadas porque solo le pertenecen a este objeto
   */
   private String nombre;
   private int partidasGanadas;
   private Carta carta1;
   private Carta carta2;
   public static int id=1;
  
  /**
   *Constructor sin p�rametros
   */    
   public Jugador() {
      this("Jugador "+id);
      id++;
   }
   
   
  /**
   *Constructor con p�rametro
   *@param nombre como String
   */ 
   public  Jugador(String nombre) {
      this(nombre , new Carta(), new Carta());
     
   }
   
  /**
   *Constructor con p�rametros
   *@param nombre como String
   *@param carta1 como Carta
   *@param carta2 como Carta
   */ 
   public  Jugador(String nombre,Carta carta1, Carta carta2) {
      this.nombre = nombre;
      this.carta1 = carta1;
      this.carta2 = carta2;
     
   }
   


  /**
   *setNombre establece el valor del atributo
   *@param nom como String
   */
   public void setNombre(String nom) {
      this.nombre=nom;
   }
   
   
  /**
   *setPartidasGanadas establece el valor del atributo
   *@param part como entero
   */ 
   public void setPartidasGanadas(int part) {
      this.partidasGanadas=part;
   }
   
   
  /**
   *setCarta1 establece el valor del atributo
   *@param carta1 
   */ 
   public void setCarta1(Carta carta1) {
      this.carta1=carta1;
   }
   
  /**
   *setCarta2 establece el valor del atributo
   *@param carta2 
   */ 
   public void setCarta2(Carta carta2) {
      this.carta2=carta2;
   }
   
  /**
   *getNombre establece el valor del atributo
   *@return nombre como String
   */ 
   public String getNombre() {
      return this.nombre;
   }
   
  /**
   *getPartidasGanadas obtiene  el valor del atributo
   *@return partidasGanadas como entero
   */
   public int getPartidasGanadas() {
      return this.partidasGanadas;
   }
   
   
   
  /**
   *getCarta1 obtiene  el valor del atributo
   *@return carta1
   */
   public Carta getCarta1() {
      return this.carta1;
   }
   
  /**
   *getCarta2 obtiene  el valor del atributo
   *@return carta1
   */
   public Carta getCarta2() {
      return this.carta2;
   }
      
   
  /**
   *toString retorna los atributos del objeto
   *@return partida como cadena
   */
   public String toString() {
      return "Jugador";
   }
   
   
}//Fin de la clase Jugador