/**
 * Clase Juego21 que contiene el m�todo iniciarJuego con sus respectivas estructuras de control
 * necesarios para iniciar el juego
 * @version 1 de octubre  2020
 * @author Gabriel Guzm�n Alfaro
 */

public class Juego21 {
     
    /*Atributos: Son las variables del objeto
    *son privadas porque solo le pertenecen a este objeto
    */
   public GestorES gestor;
   private Jugador jugador1, jugador2;
   
    
    /*Constructor con par�metros
    *@param gestor como GestorES
    */  
   public  Juego21(GestorES gestor) {
      this.gestor = gestor;
      this.jugador1 = new Jugador();
      this.jugador2 = new Jugador("Gabriel");
   }
    
    
    /*M�todo que se encarga de inciar el juego
    */  
   public void iniciarJuego() {
    
       //Definir variables
      int suma1; 
      int suma2; 
      int menuReinicio;
      int contarPartidas = 0; 
      int contPierde1= 0;
      int contPierde2= 0;
      int contEmpate= 0;
      String ganeJuego;
      
      
   
      
      //Dar la bienvenida al programa
      gestor.mostrarMensaje("Juego de cartas 21","Bienvenido!");
      
    
   
      //El jugador decide cu�ntas veces jugar  
      do{ 
       
      
         contarPartidas = contarPartidas+1; 
           
        
        //Crear set's de las cartas de los jugadores
         jugador1.setCarta1( repartirCarta());
         jugador1.setCarta2( repartirCarta());
         jugador2.setCarta1( repartirCarta());
         jugador2.setCarta2( repartirCarta());

      
      
        //Sumar los valores de las cartas
         suma1= obtenerValorCarta(jugador1.getCarta1().getValor())+
                                 obtenerValorCarta(jugador1.getCarta2().getValor());
                               
         suma2= obtenerValorCarta(jugador2.getCarta1().getValor())+
                                 obtenerValorCarta(jugador2.getCarta2().getValor());
                                 
                                                 
                               
                                 
        //Mostrar los datos de las cartas 
        
         //El jugador 1 muestra sus cartas
         
         gestor.mostrarMensaje("El jugador 1 muestra sus cartas","Barajar");  
         gestor.mostrarMensaje("Carta 1: "+"\n"+jugador1.getCarta1().toString()+"\n"+"\n"+
                              "Carta 2: "+"\n"+jugador1.getCarta2().toString()+"\n"+"\n"+
                              "Suma: "+suma1,jugador1.getNombre());
                                                
         gestor.mostrarMensaje("El jugador 2 muestra sus cartas","Barajar");
         gestor.mostrarMensaje("Carta 1: "+"\n"+jugador2.getCarta1().toString()+"\n"+"\n"+
                              "Carta 2: "+"\n"+jugador2.getCarta2().toString()+"\n"+"\n"+
                              "Suma: "+suma2,jugador2.getNombre());
         
         //Mostrar la cuenta de partidas                     
         gestor.mostrarMensaje("Partida: "+contarPartidas,"Partida"); 
         
         //Si gana el jugador, pierde el 2
         if(((suma1>suma2)&&(suma1<22)||(suma2>21))&&(suma1!=suma2)){
         
            jugador1.setPartidasGanadas(jugador1.getPartidasGanadas()+1);
            contPierde2 = contPierde2+1;
            gestor.mostrarMensaje(jugador1.getNombre(),"Ganador de la partida ");
          
         
         }
         
        
         //Si gana el jugador2, pierde el 1
         if(((suma2>suma1)&&(suma2<22)||(suma1>21))&&(suma2!=suma1)){
         
            jugador2.setPartidasGanadas(jugador2.getPartidasGanadas()+1); 
            contPierde1 = contPierde1+1;
            gestor.mostrarMensaje(jugador2.getNombre(),"Ganador de la partida ");
          
         
         }
         
         //En caso de que exista un empate
         if(suma1==suma2){
            contEmpate = contEmpate+1;
            gestor.mostrarMensaje("Empate","Empate en la partida ");
          
         
         }     
         
          
         //Se solicita al usuario si desea jugar m�s                      
         menuReinicio = gestor.menuReinicio("Desea jugar otra partida?");                      
                                               
      }while(menuReinicio==0); 
      
      
      //Determinar el ganador del juego
      if(jugador1.getPartidasGanadas()>jugador2.getPartidasGanadas()){ 
         ganeJuego = jugador1.getNombre();
         
      }else{
         ganeJuego = jugador2.getNombre();
      }
      
      //Determinar si el juego se empat�
      if(jugador1.getPartidasGanadas()==jugador2.getPartidasGanadas()){ 
         ganeJuego = "Empate" ;
         
      }    
       
      //Mostrar datos finales
      gestor.mostrarMensaje("Partidas Jugadas: "+contarPartidas+"\n"+"\n"+jugador1.getNombre()+
                            "\nPartidas Ganadas: "+jugador1.getPartidasGanadas()+"\nPartidas Perdidas: "+
                            contPierde1+"\n"+"\n"+jugador2.getNombre()+"\nPartidas Ganadas: "+jugador2.getPartidasGanadas()+
                            "\nPartidas Perdidas: "+contPierde2+"\n"+"\n"+"\nPartidas Empatadas: "+contEmpate+"\n"+"\n"+
                            "\nGANADOR DEL JUEGO: "+ganeJuego,"Resutados del juego 21");
        
       
   } // Fin de iniciarJuego
  
  
    /*M�todo que se encarga de barajar las cartas
    *@return carta como Carta
    */  
   public Carta repartirCarta() {
         
        //Crear objeto Carta 
      Carta carta = new Carta();
      
        //Definir variables
      String indice = "";
      String figura= "";
      int maxIndice = 13; 
      int minIndice = 1; 
      int rangeIndice = maxIndice-minIndice;
      int maxFigura = 4; 
      int minFigura = 1; 
      int rangeFigura = maxFigura-minFigura;
      int posIndice; 
      int posFigura;
    
        //Calcular valor aleatorio de indice y figura
      posIndice=(int)(Math.random()*rangeIndice)+minIndice;
      posFigura=(int)(Math.random()*rangeFigura)+minFigura;
    
        //Switch para obtener la figura 
        
      switch(posFigura){
        
         case 1: posFigura = 1;
         
            figura = "Picas";
             
            break;
        
         case 2: posFigura = 2;
         
            figura = "Diamantes";
             
            break;
        
         case 3: posFigura = 3;
         
            figura = "Tr�boles";
             
            break;
        
         case 4: posFigura = 4;
         
            figura = "Corazones";
             
            break;         
                      
      }     
       
       //Switch para obtener el �ndice
        
      switch(posIndice){
        
         case 1: posIndice = 1;
         
            indice = "A";
             
            break;
        
         case 2: posIndice = 2;
         
            indice = "2";
             
            break;
        
         case 3: posIndice = 3;
         
            indice = "3";
             
            break;
        
         case 4: posIndice = 4;
         
            indice = "4";
             
            break;
        
         case 5: posIndice = 5;
         
            indice = "5";
             
            break;
        
         case 6: posIndice = 6;
         
            indice = "6";
             
            break;
        
         case 7: posIndice = 7;
         
            indice = "7";
             
            break;
        
         case 8: posIndice = 8;
         
            indice = "8";
             
            break;
       
         case 9: posIndice = 9;
         
            indice = "9";
             
            break;
        
         case 10: posIndice = 10;
         
            indice = "10";
             
            break;
        
         case 11: posIndice = 11;
         
            indice = "J";
             
            break;
        
         case 12: posIndice = 12;
         
            indice = "K";
             
            break;
        
         case 13: posIndice = 13;
         
            indice = "Q";
             
            break;                    
                      
      }    
       
    
        //Llamar m�todos set�s de carta
        carta.setFigura(figura);
        carta.setValor(indice);
    
        //Llamar m�todos get�s de carta
        figura = carta.getFigura();
        indice = carta.getValor();
   
       
        //Se env�a el indice de la carta a obtenerValor
      this.obtenerValorCarta(indice);
   
    
      return carta;
    
   } // Fin de repartirCarta
  
  
  
    /*M�todo que se encarga de obtener el valor de la carta
    */  
   public int obtenerValorCarta(String valor) {
    
       //Definir variables
      int numero;
    
       //Inicializar variables
      numero = 0;
    
      switch(valor){
      
         case "A":
            numero = 1;
            break;
      
         case "2":
            numero = 2;
            break;
      
         case "3":
            numero = 3;
            break;
      
         case "4":
            numero = 4;
            break;
      
         case "5":
            numero = 5;
            break;
      
         case "6":
            numero = 6;
            break;
      
         case "7":
            numero = 7;
            break;
      
         case "8":
            numero = 8;
            break;
      
         case "9":
            numero = 9;
            break;
      
         case "10":
            numero = 10;
            break;
      
         case "J":
            numero = 11;
            break;
      
         case "Q":
            numero = 12;
            break;
      
         case "K":
            numero = 13;
            break;
      
      }
    
      return numero;
       
   } // Fin de obtenerValorCarta
  
  
 
    
}//Fin de la clase


