/**
 * Clase carta que se encarga de recibir los atributos figura y valor
 * necesarios para el desarrollo del programa
 * @version 1 de octubre  2020
 * @author Gabriel Guzm�n Alfaro
 */

public class Carta {

    /** 
    *Atributos: Son las variables del objeto
    *son privadas porque solo le pertenecen a este objeto
    */
   private String figura;
   private String valor;
 
   /**
   *Metodo constructor del objeto, no tiene valor de retorno
    *se llama igual a la clase
    */  
   public Carta () {
      this.figura = "";
      this.valor = "";
   }
 
 
    /**
     * Constructor con par�metros
     *@param fig como String
     *@param val como String
     */   
   public  Carta(String figura, String valor) {
      this.figura = figura;
      this.valor = valor;
   }

    
  
   /**
    *@Override
    *@param fig como String
    */
   public void setFigura(String figura) {
      this.figura = figura;
   }
    
   /*@Override
    *@param val como entero
    */
   public void setValor(String valor ) {
      this.valor = valor;
   }
 


   /**
    *@Override
    *@return figura como String
    */
   public String getFigura() {
      return this.figura;
   }
    
   /**
    *@Override
    *@return valor como String
    */
   public String getValor() {
      return this.valor;
   }
   
    
   /**
    *Imprimir con m�todo println
    *@println figura , valor como String
    */ 
   public void imprimirCarta() {
      System.out.println("La figura de la carta es " +
                         figura+" y su valor es "+valor);
   }


   /**
    *toString retorna los atributos del objeto
    *@return figura, valor como cadena
    */
   public String toString() {
      return "Figura: " + figura + "\nValor: " +valor ;
   }
    
}