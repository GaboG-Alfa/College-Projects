<----------------------------------------------->
Team integrants
    DIEGO ALFARO GONZALES   C00191
    CARLOS GUEVARA RAMIREZ  B93564
    NICOLE GARCIA LUNA      C03170
    GABRIEL GUZMAN ALFARO   C03657

<----------------------------------------------------------------------------------------------->

To run this program in netbeans

step #1.
    open project netbeans huffman_en_decode
step #2.
    at project include the javafx-sdk-16 libraries
    in Run:Module path and Complile: Class path

    and add the virtual machine options
        --module-path <path of javafx-sdk-16/lib> --add-modules=javafx.controls,javafx.fxml
    for example in Mac
    --module-path  /Users/Diego/Downloads/javafx-sdk-16/lib --add-modules=javafx.controls,javafx.fxml
    or Windows
    --module-path  c:\\Users\\NicoleGarcíaLuna\\Downloads\\javafx-sdk-16\\lib --add-modules=javafx.controls,javafx.fxml

step#3
    run huffman_en_decode project, it will complile and run ProjectRun.java
    

<----------------------------------------------------------------------------------------------->

