package test;

import controller.FXMLHandler;
import controller.grafical.MainMenu;
import javafx.application.Application;
import javafx.stage.Stage;

public class ProjectRun extends Application {
    
    @Override
    public void start(Stage stage) throws Exception {
        FXMLHandler.loadAndShowFxml(stage, new MainMenu(), "../view/MainMenu.fxml");
    }

    public static void main(String... args) {
        launch(args);
    }

}
