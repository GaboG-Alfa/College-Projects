package model;

import java.math.BigDecimal;
import java.math.RoundingMode;

import model.exceptions.CharacterRepeticionsListException;
import model.exceptions.LinkedListException;
import model.structures.BinaryNode;
import model.structures.LinkedList;

/**
* Compressor
* @author Diego Alfaro
* @author Carlos Guevara
* @author Nicole Luna
* @author Gabriel Guzman
*/

public class Compressor {

    // Atributtes

    // Constructor
    public Compressor() {
    }

    public static LinkedList<BinaryCharacter> getBinaryCharacterCodes(String fileText) {
        CharacterRepeticionsList characterRepeticionsList = //
                getCharacterRepetitions(//
                        fileText//
                );
        BinaryNode<CharacterRepetition> binaryTree = convertToTree(characterRepeticionsList);

        return getBinaryCodesOfTree(binaryTree);
    }

    public static double getCompressionPercentage(int fileTextlength, int binaryTextlenght) {
        double bitsofOrginalText = (fileTextlength * 8);
        double compressionPercentage = ((double) (//
        (double) (bitsofOrginalText - binaryTextlenght) / bitsofOrginalText//
        ) * 100);
        compressionPercentage = BigDecimal.valueOf(compressionPercentage).setScale(2, RoundingMode.HALF_UP)
                .doubleValue();
        return compressionPercentage;
    }

    /**
     * Method to count all character repetition in a text
     * @param flatText
     * @return a LinkedList with BinaryNodes containing CharacterRepetition data
     */
    public static CharacterRepeticionsList getCharacterRepetitions(String flatText) {

        CharacterRepeticionsList list = new CharacterRepeticionsList();
        for (Character character : flatText.toCharArray()) {
            try {
                //tempNode attemps to find an Equalizable node into the actual list.
                // If not found, LinkedListException is called
                BinaryNode<CharacterRepetition> tempNode = list.search(character);

                tempNode.getData().setRepetitions(//
                        tempNode.getData().getRepetitions() + 1//
                );
                tempNode.setWeight(tempNode.getData().getRepetitions());
                list.sortAcendent();

            } catch (CharacterRepeticionsListException ex) {
                //Create a new node and insert it to  node list

                BinaryNode<CharacterRepetition> newBinaryNode = //
                        new BinaryNode<>(//
                                new CharacterRepetition(character)//
                        );
                newBinaryNode.setWeight(newBinaryNode.getData().getRepetitions());
                list.insert(newBinaryNode);
            }
        }
        return list;
    }

    /**
     *
     * @param list
     */
    public static BinaryNode<CharacterRepetition> convertToTree(CharacterRepeticionsList list) {
        if (list.size() == 1) {
            try {
                return list.removeAtStart();
            } catch (Exception e) {
                System.out.println(e);
            }
        }
        try {
            BinaryNode<CharacterRepetition> temp1 = list.removeAtStart();
            BinaryNode<CharacterRepetition> temp2 = list.removeAtStart();
            list.insert(new BinaryNode<CharacterRepetition>(temp1, temp2));
        } catch (Exception e) {
            System.out.println();
        }
        return convertToTree(list);
    }

    /**
     * Recursive method to get the binary representations of the characters
     * 
     * @param tree  for stract the codes
     */
    public static LinkedList<BinaryCharacter> getBinaryCodesOfTree(BinaryNode<CharacterRepetition> tree) {
        LinkedList<BinaryCharacter> listBinaryCharacters = new LinkedList<BinaryCharacter>();
        getBinaryCodesOfTree(tree, "", listBinaryCharacters);
        listBinaryCharacters.sortAcendent();
        return listBinaryCharacters;
    }

    private static void getBinaryCodesOfTree(BinaryNode<CharacterRepetition> tree, String code,
            LinkedList<BinaryCharacter> binaryCharactersList) {

        if (tree != null) {
            getBinaryCodesOfTree(tree.getLeft(), code + "0", binaryCharactersList);
            if (tree.getLeft() == null && tree.getRight() == null) {
                binaryCharactersList.addAtEnd(//
                        new BinaryCharacter(tree.getData().getCharacter(), code)//
                );
            }
            getBinaryCodesOfTree(tree.getRight(), code + "1", binaryCharactersList);
        }

    }

    /**
     * Method to convert flat text to binary
     *
     * @param binaryCharactersList
     * @return string with the text binary
     */
    public static String convertFlatTextToBinary(//
            LinkedList<BinaryCharacter> binaryCharactersList, //
            String flatText//
    ) {

        char charTemp = ' ';
        BinaryCharacter binaryCharacterTemp = null;
        String exit = "";

        for (int i = 0; i < flatText.length(); i++) {

            charTemp = flatText.charAt(i);

            try {

                binaryCharacterTemp = binaryCharactersList.search(//
                        new BinaryCharacter(charTemp), //
                        (BinaryCharacter data, BinaryCharacter other) -> {
                            return data.getCharacter().compareTo(other.getCharacter());
                        });
                exit += binaryCharacterTemp.getBinaryCode();

            } catch (LinkedListException e) {
                System.out.println("The character not found into listCharacterBinary");
            }
        }
        return exit;
    }
}
