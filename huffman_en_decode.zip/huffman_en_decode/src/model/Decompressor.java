package model;

import model.exceptions.DecodeException;
import model.exceptions.LinkedListException;

import model.structures.LinkedList;

/**
 * Decompressor
 * @author Diego Alfaro
 * @author Carlos Guevara
 * @author Nicole Luna
 * @author Gabriel Guzman
 */
public class Decompressor {

    /**
     * This method return the text after decoding binaryCode using the binaryCharacterCodesListList as a dictionary
     * @param binaryCharacterCodesList works as a dictionary to know if a binary code is equivalent to a character.
     * @param binaryCode to decode it in a text
     * @return 
     */
    public static String decompressBinaryText(LinkedList<BinaryCharacter> binaryCharacterCodesList, String binaryText) {
        String txt = "";
        BinaryCharacter searchedCharacter;
        for (int i = 1; i <= binaryText.length(); i++) {
            try {
                // 
                searchedCharacter = binaryCharacterCodesList.search(//
                        new BinaryCharacter(//
                                binaryText.substring(0, i)//
                        ), (BinaryCharacter obj, BinaryCharacter other) -> {
                            return obj.getBinaryCode().compareTo(other.getBinaryCode());
                        });
                binaryText = binaryText.substring(i, binaryText.length());
                txt += searchedCharacter.getCharacter();
                i = 0;
            } catch (LinkedListException ex) {
                //After failing to found an equivalent BinaryCharacter it just try again
            }
        }
        return txt;
    }

    /**
     * 
     * @param textFile of the entire compressed file
     * @return binary codes of the compressed file
     * @throws DecodeException if the file no have compressed structure
     */
    public static LinkedList<BinaryCharacter> getBinaryCodesFromCompressedFileText(String textFile)
            throws DecodeException {

        LinkedList<BinaryCharacter> binaryCharacterCodesList = new LinkedList<BinaryCharacter>();

        String[] fileStructured = textFile.split("\n");
        if (fileStructured.length == 2) {
            String[] binaryTableinStrings = fileStructured[1].split(";");
            if (binaryTableinStrings.length < 1) {
                throw new DecodeException("the file no have compressed structure");
            }
            for (String tableRow : binaryTableinStrings) {
                String[] binaryCharacter = tableRow.split(",");
                if (binaryCharacter.length != 2) {
                    throw new DecodeException("the file no have compressed structure");
                }
                try {
                    binaryCharacterCodesList.addAtEnd(new BinaryCharacter(//
                            (char) Integer.parseInt(binaryCharacter[0]), //
                            binaryCharacter[1])//
                    );
                } catch (NumberFormatException e) {
                    throw new DecodeException("the file no have compressed structure");
                }
            }

        }
        return binaryCharacterCodesList;
    }

    /**
     * 
     * @param textFile of the entire compressed file
     * @return  binary text of the compressed file
     * @throws DecodeException if the file no have compressed structure
     */
    public static String getBinaryTextFromCompressedFileText(String textFile) throws DecodeException {

        String[] fileStructured = textFile.split("\n");
        if (fileStructured.length == 2) {
            for (char character : fileStructured[0].toCharArray()) {
                if (character != '1' && character != '0') {
                    throw new DecodeException("the file no have compressed structure");
                }
            }
            return fileStructured[0];
        } else {
            throw new DecodeException("the file no have compressed structure");
        }
    }

}
