package model.grafical;

import javafx.event.EventHandler;
import javafx.stage.WindowEvent;

/**
* FXMLController
* Interface to logic fxml handler
* @author Diego Alfaro
* @author Carlos Guevara
* @author Nicole Luna
* @author Gabriel Guzman
*/

public interface FXMLController {
    public void afterLoad();

    public EventHandler<WindowEvent> getCloseWindowEvent();

    public String getWindowTitle();
}