package model.exceptions;



/**
* LinkedListException
* @author Diego Alfaro
* @author Carlos Guevara
* @author Nicole Luna
* @author Gabriel Guzman
*/
public class LinkedListException extends Exception {

    /**
     * @param message
     */
    public LinkedListException(String message) {
        super("LinkedList: " + message);
    }

}
