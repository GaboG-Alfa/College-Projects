package model.structures;

import java.util.Comparator;

import model.exceptions.LinkedListException;

/**
 * LinkedList
 * @author Diego Alfaro
 * @author Carlos Guevara
 * @author Nicole Luna
 * @author Gabriel Guzman
 */
public class LinkedList<T extends Comparable<T>> {

    //Atributtes
    private Node<T> first;
    private Node<T> last;
    private int size;

    public LinkedList() {
        size = 0;
    }

    /**
     * Search generic data
     *
     * @param data
     */
    public T search(T data, Comparator<T> comparator) throws LinkedListException {
        if (first == null) {
            throw new LinkedListException("The list is empty");
        }
        for (Node<T> temp = first; temp != null; temp = temp.getNext()) {
            if (comparator != null && comparator.compare(data, temp.getData()) == 0) {
                return temp.getData();
            }
        }
        throw new LinkedListException("no found");
    }

    /**
    * Search generic data
    *
    * @param data
    */
    public T update(T data, Comparator<T> comparator) throws LinkedListException {
        if (first == null) {
            throw new LinkedListException("The list is empty");
        }

        for (Node<T> temp = first; temp != null; temp = temp.getNext()) {
            if (comparator.compare(data, temp.getData()) == 0) {
                temp.setData(data);
                return temp.getData();
            }
        }
        throw new LinkedListException("no found");
    }

    /**
     * Insert node at the start of the linked list
     *
     * @param data
     */
    public void addAtStart(T data) {
        Node<T> newNode = new Node<T>();

        newNode.setData(data);

        if (first == null) {
            first = last = newNode;
        } else {
            newNode.setNext(first);
            first = newNode;
        }
        size += 1;

    }

    /**
     * Insert node at the end of the linked list 
     *
     * @param data
     */
    public void addAtEnd(T data) {
        Node<T> newNode = new Node<T>(data);
        if (last == null) {
            first = last = newNode;
        } else {
            last.setNext(newNode);
            last = newNode;
        }
        size += 1;
    }

    /**
     * Remove a node at the start
     *
     * @return boolean
     */
    public T removeAtStart() throws LinkedListException {
        T toReturn = null;
        if (first == null)
            throw new LinkedListException("The list is empty");
        if (first == last) {
            toReturn = first.getData();
            first = last = null;
        } else {
            toReturn = first.getData();
            first = first.getNext();
        }
        size -= 1;
        return toReturn;
    }

    /**
     * Remove a node at the end
     *
     * @return boolean
     */
    public T removeAtEnd() throws LinkedListException {
        T toReturn = null;

        if (last == null)
            throw new LinkedListException("The list is empty");
        if (first == last) {
            toReturn = last.getData();
            first = last = null;
        } else {
            toReturn = last.getData();
            Node<T> temp;
            for (temp = first; temp.getNext() != last; temp = temp.getNext())
                temp.setNext(null);
            last = temp;
        }
        size -= 1;
        return toReturn;
    }

    /**
     *Order the linked list
     */
    public void sortDecendent() {
        boolean ordered = false;

        while (ordered == false) {
            ordered = true;
            for (Node<T> temp = first; temp.getNext() != null; temp = temp.getNext()) {
                if (temp.getData().compareTo(temp.getNext().getData()) < 0) {

                    T temporal = temp.getData();
                    temp.setData(temp.getNext().getData());
                    temp.getNext().setData(temporal);
                    ordered = false;

                }
            }
        }
    }

    /**
     *Order the linked list
     */
    public void sortAcendent() {
        boolean ordered = false;
        if (first == null) {
            return;
        }
        while (ordered == false) {
            ordered = true;
            for (Node<T> temp = first; temp.getNext() != null; temp = temp.getNext()) {
                if (temp.getData().compareTo(temp.getNext().getData()) > 0) {

                    T temporal = temp.getData();
                    temp.setData(temp.getNext().getData());
                    temp.getNext().setData(temporal);
                    ordered = false;
                }
            }
        }
    }

    public T get(int index) throws LinkedListException {
        if (index >= size) {
            throw new LinkedListException("index out of bounds");
        }
        if (index == 0) {
            return first.getData();
        }
        if (index == size - 1) {
            return last.getData();
        }

        Node<T> temp = first.getNext();
        int i = 1;
        while (i < index) {
            temp = temp.getNext();
            i++;
        }
        return temp.getData();

    }

    public int size() {
        return size;
    }

}
