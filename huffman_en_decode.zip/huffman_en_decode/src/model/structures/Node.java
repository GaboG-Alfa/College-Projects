/*
 * Functiong of a generic node
 */
package model.structures;

/**
 * Node
 * @author Diego Alfaro
 * @author Carlos Guevara
 * @author Nicole Luna
 * @author Gabriel Guzman
 */
public class Node<T extends Comparable<T>> implements Comparable<Node<T>> {

    //Atributtes
    private T data;
    private Node<T> next;

    /**
     * Constructor
     */
    public Node() {
    }

    /**
     * 
     * @param data 
     */
    public Node(T data) {
        this.data = data;
    }

    @Override
    public int compareTo(Node<T> o) {
        return this.data.compareTo(o.getData());
    }

    /**
     * 
     * @return data 
     */
    public T getData() {
        return data;
    }

    /**
     * 
     * @param data 
     */
    public void setData(T data) {
        this.data = data;
    }

    /**
     * 
     * @return next 
     */
    public Node<T> getNext() {
        return next;
    }

    /**
     * 
     * @param next 
     */
    public void setNext(Node<T> next) {
        this.next = next;
    }

}
