package controller.grafical;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import controller.FXMLHandler;
import controller.FileChoosersHandler;
import controller.FileStringManager;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import model.Decompressor;
import model.CompressionData;
import model.Compressor;
import model.DecompressionData;
import model.exceptions.DecodeException;
import model.grafical.FXMLController;

public class MainMenu implements Initializable, FXMLController {

    @FXML
    private Button compressFileBTN;
    @FXML
    private Button decompressFileBTN;
    @FXML
    private Button exitButton;
    @FXML
    private Label toCompressFileLB;
    @FXML
    private Label toDecompressFileLB;
    @FXML
    private Label messageLB;

    private CompressionData compression;
    private DecompressionData decompression;

    public MainMenu() {
        compression = new CompressionData();
        decompression = new DecompressionData();
    }

    /**
     * @param compression
     * @param decompression
     */
    public MainMenu(CompressionData compression, DecompressionData decompression) {
        this.compression = compression;
        this.decompression = decompression;
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {

    }

    @FXML
    private void handleLoadButtonClickAction(ActionEvent event) throws IOException {

        File file = FileChoosersHandler//
                .openFileAndGetPath(//
                        ((Stage) exitButton.getScene().getWindow()), //
                        "Select file to compress", //
                        "./src/Files/"//
                );
        if (file != null) {
            compression.setFile(file);
            toCompressFileLB.setText(file.getName());
            compressFileBTN.setDisable(false);
            compression.setTextFile(FileStringManager.loadTextFromFile(file.getPath()));
            FXMLHandler.loadAndShowFxml(//
                    new ShowTextFile(compression, decompression), //
                    "../view/ShowTextFile.fxml"//
            );
            ((Stage) exitButton.getScene().getWindow()).close();
        }
    }

    @FXML
    private void handleCompressButtonClickAction(ActionEvent event) throws IOException {
        File file = FileChoosersHandler//

                .getPathToSaveFile(//
                        ((Stage) exitButton.getScene().getWindow()), //
                        "Select path to save the compressed file", //
                        "./src/Files/"//
                );
        if (file != null) {
            compression.setBinaryCharacterCodes(//
                    Compressor.getBinaryCharacterCodes(//
                            compression.getTextFile()//
                    )//
            );
            compression.setBinaryText(//
                    Compressor.convertFlatTextToBinary(//
                            compression.getBinaryCharacterCodes(), //
                            compression.getTextFile()//
                    )//
            );
            compression.setCompressionPercentage(//
                    Compressor.getCompressionPercentage(//
                            compression.getTextFile().length(), //
                            compression.getBinaryText().length())//
            );
            FileStringManager.saveTextOnFile(file.getPath(),
                    compression.getBinaryText() + "\n" + compression.getBinaryCharacterCodesToFileString());
            FXMLHandler.loadAndShowFxml(//
                    new ShowAfterCompressData(compression, decompression), //
                    "../view/ShowAfterCompressData.fxml"//
            );
            ((Stage) exitButton.getScene().getWindow()).close();
        }

    }

    @FXML
    private void handleLoadCompressedButtonClickAction(ActionEvent event) throws IOException {
        File file = FileChoosersHandler//
                .openFileAndGetPath(//
                        ((Stage) exitButton.getScene().getWindow()), //
                        "Select file to compress", //
                        "./src/Files/"//
                );
        if (file != null) {

            try {
                String textFile = FileStringManager.loadTextFromFile(file.getPath());

                decompression.setBinaryText(//
                        Decompressor.getBinaryTextFromCompressedFileText(textFile)//
                );
                decompression.setBinaryCharacterCodes(//
                        Decompressor.getBinaryCodesFromCompressedFileText(textFile)//
                );
                toDecompressFileLB.setText(file.getName());
                decompression.setFile(file);
                decompressFileBTN.setDisable(false);
            } catch (DecodeException e) {
                messageLB.setText("This file no have a compresed file structure");
                return;
            }
            FXMLHandler.loadAndShowFxml(//
                    new ShowCompressedFile(compression, decompression), //
                    "../view/ShowCompressedFile.fxml"//
            );
            ((Stage) exitButton.getScene().getWindow()).close();
        }
    }

    @FXML
    private void handleDecompressButtonClickAction(ActionEvent event) throws IOException {
        File file = FileChoosersHandler//
                .getPathToSaveFile(//
                        ((Stage) exitButton.getScene().getWindow()), //
                        "Select path to save the decompresed file", //
                        "./src/Files/"//
                );
        if (file != null) {

            String decompresedText = Decompressor.decompressBinaryText(//
                    decompression.getBinaryCharacterCodes(), //
                    decompression.getBinaryText()//
            );
            FileStringManager.saveTextOnFile(file.getPath(), decompresedText);
            messageLB.setText("Saved file: " + file.getName());
        }

    }

    @FXML
    private void handleExitButtonClickAction(ActionEvent event) {
        ((Stage) exitButton.getScene().getWindow()).close();
    }

    @Override
    public void afterLoad() {
        if (compression.getFile() != null) {
            toCompressFileLB.setText(compression.getFile().getName());
            compressFileBTN.setDisable(false);
        }
        if (decompression.getFile() != null) {
            toDecompressFileLB.setText(decompression.getFile().getName());
            decompressFileBTN.setDisable(false);
        }
    }

    @Override
    public EventHandler<WindowEvent> getCloseWindowEvent() {
        return (WindowEvent event) -> {

        };
    }

    @Override
    public String getWindowTitle() {
        return "Huffman Algorithm";
    }

}
