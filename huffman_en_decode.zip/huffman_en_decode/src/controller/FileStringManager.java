package controller;

import java.io.File;
import java.io.FileWriter;
import java.io.FileReader;

import java.io.IOException;
import java.io.BufferedReader;
import java.io.BufferedWriter;


/**
* FileStringManager
* @author Diego Alfaro
* @author Carlos Guevara
* @author Nicole Luna
* @author Gabriel Guzman
*/
public class FileStringManager {

    private File file;
    private BufferedWriter bwOutput;
    private BufferedReader bwInput;

    /**
     * Constructor
     */
    public FileStringManager(String path) {
        this.openOrCreateFile(path);
    }

    /**
     * Define the path of the file in which we are going to work, and create it if not
     * exists
     */
    private void openOrCreateFile(String path) {

        try {
            file = new File(path);

            if (!file.exists()) {
                file.createNewFile();
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    /**
      * This method is in charge of writing our object in our file
      *
      * @param message User serializable instance
      */
    public void writeStringInFile(String string) {

        try {
            bwOutput = new BufferedWriter(new FileWriter(this.file));
            if (bwOutput != null) {
                bwOutput.write(string);
                bwOutput.close();
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    /**
     *
     * @return Returns the message read in our file
     * @throws IOException
     * @throws ClassNotFoundException
     */
    public String readFile() throws IOException {
        try {
            bwInput = new BufferedReader(new FileReader(this.file));
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
        String line = null;
        String nextLine = null;

        String exit = "";

        line = bwInput.readLine();

        do {
            if (line != null) {
                exit += line;
                nextLine = bwInput.readLine();
                if (nextLine != null) {
                    exit += "\n";
                }
                line = nextLine;
            }
        } while (line != null);
        bwInput.close();
        return exit;
    }

    /**
    * Method to load Text From File
    */
    public static String loadTextFromFile(String path) {

        FileStringManager fileManager = new FileStringManager(path);
        String fileText = "";
        try {
            fileText = fileManager.readFile();
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
        return fileText;
    }

    /**
    * Method to save Text From File
    */
    public static void saveTextOnFile(String path, String text) {
        FileStringManager fileManager = new FileStringManager(path);

        fileManager.writeStringInFile(text);

    }

}
