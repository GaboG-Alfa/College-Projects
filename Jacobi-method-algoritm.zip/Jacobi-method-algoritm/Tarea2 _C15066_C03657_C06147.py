#Version 1.0
#Estudiantes
#Joseph Mora Cubero C15066
#Gabriel Guzmán Alfaro C03657
#Alexander Quesada JImenez C06147
import numpy as np 
 
def jacobi(matrix, b, xo, N, tol): 
    k = 1 
    x = [] 
    while k <= N: 
        for i in range(len(matrix)): 
            sumParcial = 0 
            for j in range(len(matrix)): 
                if j != i: 
                    sumParcial += matrix[i][j] * xo[j] 
            x_i = (-1 / matrix[i][i]) * (sumParcial - b[i]) 
            x.append(x_i) 
 
        error = np.linalg.norm(np.array(x) - np.array(xo), np.inf) 
        print('\nx_' + str(k), x) 
        print('Error', error) 
 
        if error < tol: 
            print('\nNúmero de iteraciones necesarias:', k) 
            print('Vector solución:', x) 
            print('\n\n\n')
            break 
 
        k += 1 
        xo = x 
        x = [] 
 
# Ejemplo de uso 1 
matrix = [[2, 1, 0], 
          [3, 7, 1], 
          [1,-1,5]] 
b = [1,-1,0] 
xo = [0, 0, 0] 
N = 9 
tol = 1e-3 
 
jacobi(matrix, b, xo, N, tol) 
 
# Ejemplo de uso 2 
matrix = [[10, 1, 2], 
          [4, 6, -1], 
          [-2,3,8]] 
b = [3,9,51] 
xo = [0, 0, 0] 
N = 16 
tol = 1e-5 
 
jacobi(matrix, b, xo, N, tol) 
 
# Ejemplo de uso 3 
matrix = [[10, -1, 2, 0], 
          [-1, 11, -3,3,], 
          [2,-1,10,-1], 
          [0,3,-1,8]] 
b = [6,25,-11,15] 
xo = [0, 0, 0,0] 
N = 18 
tol = 1e-5 
 
jacobi(matrix, b, xo, N, tol)