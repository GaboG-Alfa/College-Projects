package com.example.ejerciciosecc4poo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import java.lang.Math.sqrt

class MainActivity : AppCompatActivity() {

    private fun comprobar(n:Int, fn: (Int)->Boolean):Boolean{
        return fn(n)
    }

    override fun onCreate(savedInstanceState : Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val par : Int = 4
        val impar: Int= 3

        val primo :Int =1
        val noPrimo: Int = 9
        val guay : Int = 15
        val noGuay : Int = 8

        val funcionPar = { x:Int-> x%2==0 }
        val funcionPrimo = {x:Int-> // función que retorna un booleano
            var primo = true
            for (i in 2..x / 2) { // bucle sobre un rango
                if (x % i == 0) { // no es número primo
                    primo = false
                    break // sale del bucle
                }
            }
             primo // true o false
          }


        println("El número $par es par? respuesta: ${comprobar(par,funcionPar)}")
        println("El número $impar es par ? respuesta ${comprobar(impar,funcionPar)}")
        println("El número $primo es primo ? respuesta ${comprobar(primo,funcionPrimo)}")
        println("El número $noPrimo es primo ? respuesta ${comprobar(noPrimo,funcionPrimo)}")

    }
}