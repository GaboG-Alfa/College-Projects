/*
 * Clase que controla todas las view
 */
package Controller;

import Main.ContactosMVC_FX;
import Model.Listas;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Gabriel Guzmán Alfaro
 * @verison 06/05/2021
 */
public class ContactoController implements Initializable {

    //Atributos
    private Listas modelListas;

    @FXML
    private Button agregar;
    @FXML
    private Button mostrar;
    @FXML
    private Button salir;
    @FXML
    private Button ver;
    @FXML
    private Button atrasConsulta;
    @FXML
    private TextField txtCedula;
    @FXML
    private TextField txtApellido1;
    @FXML
    private TextField txtApellido2;
    @FXML
    private TextField txtNombre;
    @FXML
    private TextField txtEmail;
    @FXML
    private TextField txtTelefono;
    @FXML
    private TextArea textConsulta;

    @FXML
    public void handleButtonClick(ActionEvent event) {

        if (event.getSource() == agregar) {

            modelListas.agregarContacto(txtCedula.getText(), txtApellido1.getText(), txtApellido2.getText(),
                    txtNombre.getText(), txtEmail.getText(), txtTelefono.getText());
            return;
        }

        if (event.getSource() == mostrar) {

            consultar();
            return;
        }

        if (event.getSource() == salir) {
            modelListas.escribirArchivo();
            System.exit(0);
        }

    }

    @FXML
    public void showConsulta(ActionEvent event) throws IOException {

        if (event.getSource() == ver) {
            textConsulta.appendText(modelListas.toString());
            return;
        }

        if (event.getSource() == atrasConsulta) {
            Stage stage = (Stage) this.atrasConsulta.getScene().getWindow();
            stage.close();
        }

    }

    /**
     * Initializes the controller
     *
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        if(modelListas == null){
            modelListas = new Listas();
            try {
            
                modelListas.leer();
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }
    }

    public void setModelListas(Listas modelListas) {
        this.modelListas = modelListas;

    }

    public Listas getModelListas() {
      return modelListas;
    }

    /**
     * Abre la ventana de consulta
     */
    public void consultar() {
        try {
            Stage stage = new Stage();
            stage.setTitle("Consulta de la lista de contactos");
            Parent root = null;
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/View/Consulta.fxml"));
            root = loader.load();
            ((ContactoController) loader.getController()).setModelListas(this.modelListas);
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        } catch (IOException ex) {
            Logger.getLogger(ContactosMVC_FX.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

}
