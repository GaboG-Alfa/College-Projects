/*
 * Clase que se encarga de guardar la información de las listas 
 */
package Model;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author Gabriel Guzmán Alfaro
 * @version 06/05/2021
 */
public class Listas {

    //Atributos
    private ArrayList<Contactos> contactoList;
    private BufferedReader lector;

    /**
     * Constructor
     */
    public Listas() {
        contactoList = new ArrayList<Contactos>();
    }

    /**
     *
     * @param cedula
     * @param apellido1
     * @param apellido2
     * @param nombre
     * @param email
     * @param telefono
     */
    public void agregarContacto(String cedula, String apellido1, String apellido2, String nombre, String email, String telefono) {

        contactoList.add(new Contactos(cedula, apellido1, apellido2, nombre, email, telefono));

    }

    /**
     * Escribir Archivo
     */
    public void escribirArchivo() {

        try {
            escribir();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

    }

    /**
     * open a target file to start the edition
     *
     * @param nombreArchivo
     * @throws FileNotFoundException throws a exception when no found file
     */
    public void leer() throws FileNotFoundException, IOException {
        File archivo = null;
        FileReader fr = null;
        BufferedReader br = null;

        try {
            archivo = new File("Contactos.txt");
            fr = new FileReader(archivo);
            br = new BufferedReader(fr);

            String linea = br.readLine();
            String[] datos = linea.split(", ");
            while (linea != null) {
                this.agregarContacto(datos[0], datos[1], datos[2], datos[3], datos[4], datos[5]);
                linea = br.readLine();
            }
            fr.close();
            new File("Contactos.txt").delete();
        } catch (IOException e) {
            System.out.println(e.getMessage());
        } 
    }

    private void escribir() {
        try {

            BufferedWriter bw = new BufferedWriter(new FileWriter("Contactos.txt"));

            for (Contactos contacto : contactoList) {
                bw.write(contacto.getCedula() + " , " + contacto.getApellido1() + " , " + contacto.getApellido2() + " , " + contacto.getNombre()
                        + " , " + contacto.getEmail() + " , " + contacto.getTelefono() + "\r\n");
            }

            bw.close();
        } catch (Exception ex) {

            ex.fillInStackTrace();
        }
    }

    
    @Override
    public String toString() {
        String salida = "";
        for( Contactos contacto : contactoList ){
            salida += contacto.toString()+"\n";
        }
      return salida;
    }

    public boolean isEmpty() {
        return contactoList.isEmpty();
    }

    

}
