package Model;

/**
 *
 * @author Gabriel Guzmán Alfaro
 * @version 1/05/2021
 */
public class Contactos {

    // Define attributes
    private String cedula;
    private String apellido1;
    private String apellido2;
    private String nombre;
    private String email;
    private String telefono;

    /**
     * Constructor without parameters
     */
    public Contactos() {

    }

    /**
     * 
     * @param cedula
     * @param apellido1
     * @param apellido2
     * @param nombre
     * @param email
     * @param telefono 
     */
    public Contactos(String cedula, String apellido1, String apellido2, String nombre, String email, String telefono) {
        this.cedula = cedula;
        this.apellido1 = apellido1;
        this.apellido2 = apellido2;
        this.nombre = nombre;
        this.email = email;
        this.telefono = telefono;
    }

    /**
     * 
     * @return cedula 
     */
    public String getCedula() {
        return cedula;
    }

    /**
     * 
     * @param cedula 
     */
    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    /**
     * 
     * @return apellido1
     */
    public String getApellido1() {
        return apellido1;
    }

    /**
     * 
     * @param apellido1 
     */
    public void setApellido1(String apellido1) {
        this.apellido1 = apellido1;
    }

    /**
     * 
     * @return apellido2 
     */
    public String getApellido2() {
        return apellido2;
    }

    /**
     * 
     * @param apellido2 
     */
    public void setApellido2(String apellido2) {
        this.apellido2 = apellido2;
    }

    /**
     * 
     * @return nombre 
     */
    public String getNombre() {
        return nombre;
    }
    
    /**
     * 
     * @param nombre 
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * 
     * @return email 
     */
    public String getEmail() {
        return email;
    }

    /**
     * 
     * @param email 
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * 
     * @return telefono 
     */
    public String getTelefono() {
        return telefono;
    }

    /**
     * 
     * @param telefono 
     */
    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    @Override
    public String toString() {
        return "Asistente{" + "cedula=" + cedula + ", apellido1=" + apellido1 + ", apellido2=" + apellido2 + ", nombre=" + nombre + ", email=" + email + ", telefono=" + telefono + '}';
    }

}
