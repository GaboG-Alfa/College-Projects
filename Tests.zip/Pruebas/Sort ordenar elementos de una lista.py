lst = [5, 3, 1, 2, 4]
print(lst)

lst.sort ()
print(lst) # salida: [1, 2, 3, 4, 5
