#Programa en el cual se ingresen las notas de una serie de estudiantes de un curso. Pide informacon y dice si aprobo, tiene que ir a ampliacion o si reprobo
menu=input("Menu: \n a) Digitar un nuevo estudiante \n b) Terminar el programa \n: ")
#Inicializar algunas variables
suma=0
cont=0
#Comenzar el ciclo
while menu=="a":
    cont=cont+1
    #Condición en el if para reiniciar la variable suma
    if cont>0:70
        suma=0
    carnee=input("Digite el carné del estudiante: ")
    nombre=input("Digite el nombre del estudiante: ")
    #Condición del for para preguntar el valor de las cuatro notas
    for i in range(1,5):
        nota=int(input("Digite la nota del estudiante: "))
        suma=suma+nota
    promedio=suma/4
    if promedio<57.5:
        condicion="reprobado"
    if promedio>57.5 and promedio<67.5:
        condicion="ampliación"
    if promedio>=67.5:
        condicion="aprobado"
    print("Estudiante: ",nombre,"\n Carné: ",carnee,"\n Promedio: ",promedio,"\n Condición: ",condicion)
    menu=input("Menu: \n a) Digitar un nuevo estudiante \n b) Terminar el programa \n: ") 
#Salir si la opción del menú es b
if menu=="b":
    print("Gracias por usar nuestro programa!!!") 
      
