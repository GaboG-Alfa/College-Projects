# paso 1
beatles= []
print("Paso 1:", beatles)

# paso 2
beatles.append("Jhon Lennon")
beatles.append("Paul McCartney")
beatles.append("George Harrison")
print("Paso 2:", beatles)

# paso 3
stu=input("Agregue el nombre de Stu Sutcliffe: ")
pete=input("Agregue el nombre de Pete Best: ")
beatles.append(stu)
beatles.append(pete)
print("Paso 3:", beatles)

# etapa 4
beatles.remove(stu)
beatles.remove(pete)
print("Paso 4:", beatles)

# paso 5
ring="Ringo Starr"
beatles.insert(0,ring)
print("Paso 5:", beatles)


# probando la longitud de la lista
print("Los Fab", len(beatles))
