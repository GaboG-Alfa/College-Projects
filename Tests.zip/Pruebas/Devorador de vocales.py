﻿palabraSinVocal = ""
vocales=("a","e","i","o","u","A","E","I","O","U")
userWord=input("Ingrese una palabra: ")


for letra in userWord:
	if letra not in vocales:
	    palabraSinVocal=palabraSinVocal+letra
	    palabraSinVocal=palabraSinVocal.upper()

print(palabraSinVocal)

