﻿def mensaje(que, numero):
    print("Ingresa", que, "número", numero)

mensaje("teléfono", 11)
mensaje("precio", 5)
mensaje("número", "número")