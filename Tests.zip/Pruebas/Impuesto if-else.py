ingreso=float(input("Ingrese el ingreso anual: "))


if ingreso < 85528 :
    impuesto=(ingreso*0.18)-556.2
else:
   impuesto=14839.2+(((ingreso*0.18)-556.2)*0.32)/85528

impuesto=round(impuesto, 0)
print("El impuesto es: ", impuesto, "pesos")

