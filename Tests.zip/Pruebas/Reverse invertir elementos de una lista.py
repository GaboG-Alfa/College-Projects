Python 3.8.3 (tags/v3.8.3:6f8c832, May 13 2020, 22:20:19) [MSC v.1925 32 bit (Intel)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> lst = [5, 3, 1, 2, 4]
print(lst)
    
lst.reverse()
print (lst) # salida: [4, 2, 1, 3, 5]