print("Welcome to the program that recomend you the hours that you should sleep per day according with your age!")

ask=int(input("Input 1 if you want to continue or  2 if you want to exit: "))

while ask==1:
    name=input("Input your name: ")
    age=int(input("Input your age: "))

    if age >= 0 and age<12:
        message= name+": You should sleep between 9 and 11 hours per day "
        print(message)
        ask=int(input("Input 1 if you want to continue or 2 if you want to exit: "))
    else:
        if age >=12 and age<=64:
            message= name+": You should sleep between 7 and 9 hours per day "
            print(message)
            ask=int(input("Input 1 if you want to continue or 2 if you  to exit: "))
        else:
            if age >64:
                message= name+": You should sleep between 7 and 8 hours per day "
                print(message)
                ask=int(input("Input 1 if you want to continue or 2 if you want to exit: "))
            else:
                message=name+": Invalid age"
                print(message)
                ask=int(input("Input 1 if you want to continue or 2 if you want to exit: "))
                