﻿import time

for i in range(1,6):
    print(i,"Mississippi")
time.sleep (1)

print("¡Listo o no, ahí voy!")
