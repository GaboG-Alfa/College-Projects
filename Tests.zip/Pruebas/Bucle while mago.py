﻿numeroSecreto = 777

print(
"""
+==================================+
| Bienvenido a mi juego, muggle!   |
| Introduce un número entero       |
| y adivina qué número he          |
| elegido para ti.                 |
| Entonces,                        |      
+==================================+
""")

numeroInput=int(input("¿Cuál es el número secreto?: "))
while numeroInput != numeroSecreto:
    print("¡Ja, ja! ¡Estás atrapado en mi ciclo!")
    numeroInput=int(input("¿Cuál es el número secreto?: "))
    
    
    
if numeroInput==numeroSecreto:
    print("¡Bien hecho, muggle! Eres libre ahora")
    