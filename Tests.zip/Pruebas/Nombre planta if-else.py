planta=input("Ingrese el nombre de la planta: ") 
if planta=="Espatifilo":
    print("Si, ¡El Espatifilo es la mejor planta de todos los tiempos!")
elif planta=="espatifilo":
    print("No, ¡quiero un gran Espatifilo!")
else:
   print("¡Espatifilo!" "¡No",planta,"!")
