print("Bienvenido al programa que determina la categoría de su triángulo")
a=int(input("Ingrese una medida: "))
b=int(input("Ingrese una segunda medida: "))
c=int(input("Ingrese una tercera medida: "))
if a==b and b==c and a==c:
    print("Su triángulo es equilátero")

if (a==b and c!=a and  c!=b) or a==c and b!=a and b!=c  :
   print("Su triángulo es iscóceles")

if  a!=b and a!=c and b!=c: 
    print("Su triángulo es escaleno")
