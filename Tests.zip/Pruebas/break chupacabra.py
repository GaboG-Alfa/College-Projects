palabra=input("Ingrese una palabra: ")
while palabra!="chupacabra":
    palabra=input("Ingrese una palabra: ")
    if palabra=="chupacabra":
        print("¡Has dejado el ciclo con éxito")
        break
