﻿miLista = [10, 8, 6, 4, 2]
nuevaLista = miLista [:3]
print(nuevaLista)

miLista = [10, 8, 6, 4, 2]
nuevaLista = miLista[3:]
print(nuevaLista)