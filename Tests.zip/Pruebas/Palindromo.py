print("Bienvenido al programa que se encarga de determinar si su número es palindromo!!")
a=" "
while a!="exit":
    a=input("Ingrese un número o exit para salir: ")
    anumb=int(a)
    b=int(input("Ingrese el segundo número: "))
    c=int(input("Ingrese el tercer número: "))
    d=int(input("Ingrese el cuarto número: "))
    e=int(input("Ingrese el quinto número: "))
    if anumb==e and b==d:
        print("Su número ",anumb,b,c,d,e," es palindromo!")
    else:
        print("Su número ",anumb,b,c,d,e ," no es palindromo!")
a=input("Ingrese un número o exit para salir: ")