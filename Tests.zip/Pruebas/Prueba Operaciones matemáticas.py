from tkinter import messagebox
#Digitar un número a para realizar cálculos
a=float(input("Digite un número a: "))
#Digitar un número b para realizar cálculos
b=float(input("Digite un número b: "))
#Mostrar el resultado de la suma de a y b
messagebox.showinfo("Suma: ",a+b)
#Mostrar el resultado de la resta de a y b
messagebox.showinfo("Resta: ",a-b)
#Mostrar el resultado de la multiplicación de a y b
messagebox.showinfo("Multiplicación: ",a*b)
#Mostrar el resultado de la división de a y b
messagebox.showinfo("División : ",a/b)
