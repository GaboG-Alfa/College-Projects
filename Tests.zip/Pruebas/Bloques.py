blocks = int(input("Cuantos bloques tiene?: "))
necessaryBlocks: int = int(1)
height = int(0)
while blocks >= necessaryBlocks:
    height = height + int(1)
    blocks = blocks - necessaryBlocks
    necessaryBlocks = necessaryBlocks + int(1)
print("La altura de la piramide es de: " + str(height))
