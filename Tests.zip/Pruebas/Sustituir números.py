﻿listaSombrero = [1, 2, 3, 4, 5] # Esta es una lista existente de números ocultos en el sombrero.
#Paso 1 solicitar un digito al uusuario para sustituirlo por el número de en medio
listaSombrero[2]=int(input("Ingrese un número: "))
#Paso 2 eliminar el último elemento de la lista
del listaSombrero[4]

# Paso 3: escribe aquí una línea de código que imprima la longitud de la lista existente.
print("Longitud de la lista del sombrero es: ",len(listaSombrero))

print(listaSombrero)