package Ejercicio3;

/**
 * 
 * @author Gabriel Guzm�n Alfaro
 * @version 09/11/2020
 */
public class BooksList {

	// Define attributes
	private Book bookList[];

	/**
	 * Constructor without parameters
	 */
	public BooksList() {

		this.bookList = new Book[10];
	}

	/**
	 * Constructor with parameter
	 * 
	 * @param bookList
	 */
	public BooksList(Book bookList[]) {

		this.bookList = bookList;

	}

	/**
	 * Print the list of books
	 * 
	 * @return listBooks
	 */
	public String printList() {

		String listBooks = "";
		for (int i = 0; i < bookList.length; i++) {
			if (bookList[i] != null) {
				listBooks = listBooks + " \n" + "\n" + bookList[i].information() + "\nTime of loan: "
						+ bookList[i].loan();
			}
		}
		return listBooks;
	}

	/**
	 * Return the quantity of books in the shelf
	 * 
	 * @return bookList[i] or null
	 */
	public int quantityBooks(int shelf) {

		int n = 0;

		for (int i = 0; i < bookList.length; i++) {

			if (bookList[i] instanceof ShelfBooks) {

				ShelfBooks shelfBooks = (ShelfBooks) bookList[i];

				if (shelf == shelfBooks.getNumberShelf()) {
					n = n + 1;
				}

			}

		}

		return n;
	}

}
