package Ejercicio3;

/**
 * Test the books classes and controls the program
 * 
 * @author Gabriel Guzm�n Alfaro
 * @version 9/11/2020
 */
public class TestBooks {

	/**
	 * Controls the program
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		// Create a list
		Book listOfBooks[] = new Book[10];

		// Create book instances
		Book roomBooks = new RoomBooks("It", "Stephen King", "6th", 500, "Horror");
		Book roomBooks2 = new RoomBooks("Star Wars", "George Walton", "10th", 4000, "Comic");
		Book shelfBooks = new ShelfBooks("The petite prince", "Antoine de Saint", "9th", 300, 10, false);
		Book shelfBooks2 = new ShelfBooks("Aura", "Carlos Fuentes", "1st", 0, 10, false);
		Book shelfBooks3 = new ShelfBooks("The Odisey", "Homero", "3th", 700, 3, false);
		Book shelfBooks4 = new ShelfBooks("Don Quijote", "Miguel de Cervantes", "2nd", 1000, 3, true);

		// Create news paper instances
		RareNewsPaper rareNewsPaper = new RareNewsPaper("Unknow", 00001, 1710);
		NewsPaper newsPaper = new NewsPaper("New York Printing", 1300, 1950, null);
		NewsPaper newsPaper2 = new NewsPaper("Washington Printing", 2500, 1999, null);
		NewsPaper newsPaper3 = new NewsPaper(rareNewsPaper.getPrintingName(), rareNewsPaper.getId(),
				rareNewsPaper.getYear(), rareNewsPaper);

		// Insert instances in the List
		listOfBooks[0] = roomBooks;
		listOfBooks[1] = roomBooks2;
		listOfBooks[2] = shelfBooks;
		listOfBooks[3] = shelfBooks2;
		listOfBooks[4] = shelfBooks3;
		listOfBooks[5] = shelfBooks4;

		// Create book list instance
		BooksList bookList = new BooksList(listOfBooks);

		// Found the number of books in a shelf

		System.out.println("Number of books in this shelf: " + bookList.quantityBooks(10));

		// Print the books

		System.out.println(bookList.printList());

		// Print the news paper
		System.out.println("\n Year less 1980 \n" + newsPaper.information() + "\nTime of loan: \n"
				+ newsPaper.computeNewsPaperLoan());
		System.out.println("\n Year exceed 1980 \n" + newsPaper2.information() + "\nTime of loan: \n"
				+ newsPaper2.computeNewsPaperLoan());
		System.out.println("\nLimted news paper edition\n" + newsPaper3.information() + "\nTime of loan: \n"
				+ newsPaper3.computeNewsPaperLoan());

	}

}