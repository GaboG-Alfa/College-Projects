package Ejercicio3;

/**
 * Interface to compute the news paper loan
 * 
 * @author Gabriel Guzm�n Alfaro
 * @version 09/11/2020
 */
public interface NewsPaperLoan {

	// Compute the time of the news paper loan
	public abstract String computeNewsPaperLoan();

}
