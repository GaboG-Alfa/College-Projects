package Ejercicio3;

/**
 * Book class saves a room books data
 *
 * @author Gabriel Guzm�n Alfaro
 * @version 9/11/2020
 */
public class RoomBooks extends Book {

	// Define attributes
	private String roomName;

	/**
	 * Constructor without parameters
	 */
	public RoomBooks() {

	}

	/**
	 * Constructor with parameters
	 *
	 * @param name
	 * @param author
	 * @param edition
	 * @param numberPages
	 * @param roomName
	 */
	public RoomBooks(String name, String author, String edition, int numberPages, String roomName) {
		super(name, author, edition, numberPages);
		this.roomName = roomName;
	}

	/**
	 * Set the room name
	 *
	 * @param roomName
	 */
	public void setRoomName(String roomName) {
		this.roomName = roomName;
	}

	/**
	 * Get the room name
	 *
	 * @return roomName
	 */
	public String getRoomName() {
		return roomName;
	}

	/**
	 * 
	 * @return the time of the loan
	 */
	@Override
	public String loan() {

		// Define variables
		int time;

		// Define the time to loan
		time = (1 + super.getNumberPages()) / 100;

		// Test if the time exceed the limit
		if (time > 30) {

			return "You have exceeded the maximum number of days, the book will only be loaned 30 days";
		}

		return "Your book will be loaned for: " + time + " days";
	}

	/**
	 * Print the book type
	 * 
	 * @return type
	 */
	public String information() {

		return "Type: room book " + ", Name: " + super.getName() + ", Author: " + super.getAuthor() + ", Edition: "
				+ super.getEdition() + ", Number of pages: " + super.getNumberPages() + ", Room Name: " + roomName;
	}

	@Override
	public String toString() {
		return "Type: room book " + "\nName: " + super.getName() + "\nAuthor: " + super.getAuthor() + "\nEdition: "
				+ super.getEdition() + "\nNumber of pages: " + super.getNumberPages() + "\nRoom Name: " + roomName;
	}

}
