package Ejercicio2;

/**
 * Historical news paper with limited edition
 *
 * @author Gabriel Guzm�n Alfaro
 * @version 09/11/2020
 */
public class RareNewsPaper {

	// Define attributes
	private String printingName;
	private int id;
	private int year;

	/**
	 * Constructor without parameters
	 */
	public RareNewsPaper() {

	}

	/**
	 * Constructor with parameters
	 *
	 * @param printingName
	 * @param id
	 * @param year
	 */
	public RareNewsPaper(String printingName, int id, int year) {
		this.printingName = printingName;
		this.id = id;
		this.year = year;
	}

	/**
	 * Set the news paper printing name
	 * 
	 * @param printingName
	 */
	public void setPrintingName(String printingName) {
		this.printingName = printingName;
	}

	/**
	 * Set the news paper id name
	 * 
	 * @param id
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * Set the news paper year
	 * 
	 * @param year
	 */
	public void setYear(int year) {
		this.year = year;
	}

	/**
	 * Get the news paper printing name
	 * 
	 * @return printingName
	 */
	public String getPrintingName() {
		return printingName;
	}

	/**
	 * Get the news paper id
	 * 
	 * @return
	 */
	public int getId() {
		return id;
	}

	/**
	 * Get the news paper year
	 * 
	 * @return year
	 */
	public int getYear() {
		return year;
	}

	@Override
	public String toString() {
		return "\nPrinting Name: " + printingName + "\nYear: " + year + "\nId: " + id;
	}
}
