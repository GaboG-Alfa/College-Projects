package Ejercicio2;

/**
 * Class NewsPaper saves all data about a news paper
 *
 * @author Gabriel Guzm�n Alfaro
 * @version 09/11/2020
 */
public class NewsPaper implements NewsPaperLoan {

	// Define attributes
	private String printingName;
	private int id;
	private int year;
	private RareNewsPaper limited;

	/**
	 * Constructor without parameters
	 */
	public NewsPaper() {

	}

	/**
	 * Constructor with parameters
	 *
	 * @param printingName
	 * @param id
	 * @param year
	 * @param limited
	 */
	public NewsPaper(String printingName, int id, int year, RareNewsPaper limited) {
		this.printingName = printingName;
		this.id = id;
		this.year = year;
		this.limited = limited;
	}

	/**
	 * Set the news paper printing name
	 * 
	 * @param printingName
	 */
	public void setPrintingName(String printingName) {
		this.printingName = printingName;
	}

	/**
	 * Set the news paper id name
	 * 
	 * @param id
	 */
	public void setId(int id) {
		this.id = id;
	}

	/**
	 * Set the news paper year
	 * 
	 * @param year
	 */
	public void setYear(int year) {
		this.year = year;
	}

	/**
	 * Set if the edition of news paper is limited
	 * 
	 * @param limited
	 */
	public void setLimited(RareNewsPaper limited) {
		this.limited = limited;
	}

	/**
	 * Get the news paper printing name
	 * 
	 * @return printingName
	 */
	public String getPrintingName() {
		return printingName;
	}

	/**
	 * Get the news paper id
	 * 
	 * @return
	 */
	public int getId() {
		return id;
	}

	/**
	 * Get the news paper year
	 * 
	 * @return year
	 */
	public int getYear() {
		return year;
	}

	/**
	 * Get if the edition of news paper is limited
	 * 
	 * @return limited
	 */
	public RareNewsPaper getLimited() {
		return limited;
	}

	@Override
	public String computeNewsPaperLoan() {

		if ((year < 1980) && (limited == null)) {

			return "Your news paper is able to loan for 2 days";
		}

		if (limited != null) {

			return "Your news paper is able to loan for 2 hours";
		}

		return "Your news paper is able to loan for 4 days";
	}

	/**
	 * Print the type
	 * 
	 * @return type
	 */
	public String information() {

		return "Type: news paper " + ", Printing Name: " + printingName + ", Id: " + id + ", Year: " + year;
	}

	@Override
	public String toString() {
		return "Type: news paper " + "\nPrinting Name: " + printingName + "\nId: " + id + "\nYear: " + year;
	}

}
