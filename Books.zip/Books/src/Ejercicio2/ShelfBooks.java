package Ejercicio2;

/**
 * Book class saves a shelf books data
 *
 * @author Gabriel Guzm�n Alfaro
 * @version 9/11/2020
 */
public class ShelfBooks extends Book {

	// Define attributes
	private int numberShelf;
	private boolean extra;

	/**
	 * Constructor without parameters
	 */
	public ShelfBooks() {

	}

	/**
	 * Constructor with parameters
	 *
	 * @param name
	 * @param author
	 * @param edition
	 * @param numberPages
	 * @param numberShelf
	 * @param extra
	 */
	public ShelfBooks(String name, String author, String edition, int numberPages, int numberShelf, boolean extra) {
		super(name, author, edition, numberPages);
		this.numberShelf = numberShelf;
		this.extra = extra;
	}

	/**
	 * Set the book number shelf
	 *
	 * @param numberShelf
	 */
	public void setNumberShelf(int numberShelf) {
		this.numberShelf = numberShelf;
	}

	/**
	 * Set if the book is able to extra loan
	 *
	 * @param extra
	 */
	public void setExtra(boolean extra) {
		this.extra = extra;
	}

	/**
	 * Get the book number shelf
	 *
	 * @return number shelf
	 */
	public int getNumberShelf() {
		return numberShelf;
	}

	/**
	 * Get if the book is able to extra loan
	 *
	 * @return extra
	 */
	public boolean getExtra() {
		return extra;
	}

	/**
	 *
	 * @return the time of the loan
	 */
	@Override
	public String loan() {

		// Define variables
		int time;

		// Define the time to loan
		time = super.getNumberPages() / 100;

		// Test if the time is 0
		if (time == 0) {

			return "Your book be loaned for 1 hour";
		}

		// Test if the time exceed the limit
		if (time > 6) {

			return "You have exceeded the maximum number of hours, the book will only be loaned 6 hours";
		}

		// Test if the loan have an extraordinary
		if (extra == true && time > 6) {

			time = 24;

			return "Congrats you have an extraordinary!! \nYour book will be loaned for: " + time + " hours";
		}

		return "Your book will be loaned for: " + time + " hours";
	}

	/**
	 * Print the book type
	 * 
	 * @return type
	 */
	public String information() {

		return "Type: shelf book " + ", Name: " + super.getName() + ", Author: " + super.getAuthor() + ", Edition: "
				+ super.getEdition() + ", Number of pages: " + super.getNumberPages() + ", Number of shelf: "
				+ numberShelf + ", The book is able to extra loan?: " + extra;
	}

	@Override
	public String toString() {
		return "Type: shelf book " + "\nName: " + super.getName() + "\nAuthor: " + super.getAuthor() + "\nEdition: "
				+ super.getEdition() + "\nNumber of pages: " + super.getNumberPages() + "\nNumber of shelf: "
				+ numberShelf + "\nThe book is able to extra loan?: " + extra;
	}

}
