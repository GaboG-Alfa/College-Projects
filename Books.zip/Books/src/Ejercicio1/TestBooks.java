package Ejercicio1;

/**
 * Test the books classes and controls the program
 * 
 * @author Gabriel Guzm�n Alfaro
 * @version 9/11/2020
 */
public class TestBooks {

	/**
	 * Controls the program
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		// Create instances
		RoomBooks roomBooks = new RoomBooks("It", "Stephen King", "6th", 500, "Horror");
		RoomBooks roomBooks2 = new RoomBooks("Star Wars", "George Walton", "10th", 4000, "Comic");
		ShelfBooks shelfBooks = new ShelfBooks("The petite prince", "Antoine de Saint", "9th", 300, 10, false);
		ShelfBooks shelfBooks2 = new ShelfBooks("Aura", "Carlos Fuentes", "1st", 0, 3, false);
		ShelfBooks shelfBooks3 = new ShelfBooks("The Odisey", "Homero", "3th", 700, 3, false);
		ShelfBooks shelfBooks4 = new ShelfBooks("Don Quijote", "Miguel de Cervantes", "2nd", 1000, 3, true);

		// Print the methods
		System.out.println("Time less 30 days\n" + roomBooks.information() + "\nTime of loan \n" + roomBooks.loan());
		System.out.println(
				"\nTime exceed 30 days\n" + roomBooks2.information() + "\nTime of loan \n" + roomBooks2.loan());
		System.out
				.println("\nTime less 6 hours\n" + shelfBooks.information() + "\nTime of loan \n" + shelfBooks.loan());
		System.out.println(
				"\nTime equals 0 hours\n" + shelfBooks2.information() + "\nTime of loan \n" + shelfBooks2.loan());
		System.out.println(
				"\nTime exceed 6 hours\n" + shelfBooks3.information() + "\nTime of loan \n" + shelfBooks3.loan());
		System.out.println("\nTime exceed 6 hours with extraordinary\n" + shelfBooks4.information()
				+ "\nTime of loan \n" + shelfBooks4.loan());

	}

}
