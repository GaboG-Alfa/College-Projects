package Ejercicio1;

/**
 * Book class saves a book data
 * 
 * @author Gabriel Guzm�n Alfaro
 * @version 9/11/2020
 */
public class Book {
	// Define attributes
	private String name;
	private String author;
	private String edition;
	private int numberPages;

	/**
	 * Constructor without parameters
	 */
	public Book() {

	}

	/**
	 * Constructor with parameters
	 * 
	 * @param name
	 * @param author
	 * @param edition
	 * @param numberPages
	 */
	public Book(String name, String author, String edition, int numberPages) {
		this.name = name;
		this.author = author;
		this.edition = edition;
		this.numberPages = numberPages;
	}

	/**
	 * Set the book name
	 * 
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Set the book author
	 * 
	 * @param author
	 */
	public void setAuthor(String author) {
		this.author = author;
	}

	public void setEdition(String edition) {
		this.edition = edition;
	}

	/**
	 * Set the book number of pages
	 * 
	 * @param numberPages
	 */
	public void setNumberPages(int numberPages) {
		this.numberPages = numberPages;
	}

	/**
	 * Get the book name
	 * 
	 * @return name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Get the book author
	 * 
	 * @return author
	 */
	public String getAuthor() {
		return author;
	}

	/**
	 * Get the book edition
	 * 
	 * @return edition
	 */
	public String getEdition() {
		return edition;
	}

	/**
	 * Get the book number of pages
	 * 
	 * @return numberPages
	 */
	public int getNumberPages() {
		return numberPages;
	}

	@Override
	public String toString() {
		return "Book" + "name: " + name + ", author: " + author + ", edition: " + edition + ", numberPages: "
				+ numberPages;
	}

}
