package Ejercicio4;

/**
 * Test the figures shapes and controls the program
 * 
 * @author Gabriel Guzm�n Alfaro
 * @version 9/11/2020
 */
public class TestFigures {

	/**
	 * Controls the program
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		// Create shape instances
		Figures rhomb = new Rhomb("Rhomb", 15, 30, 20);
		Figures trapeze = new Trapeze("Trapeze", 5, 10, 15, 6, 8);
		Figures cube = new Cube("Cube", 8, 6);
		Figures cylinder = new Cylinder("Cylinder", 8, 16);

		// Create figure list instance
		FiguresList figuresList = new FiguresList();

		// Call methods
		rhomb.computeArea();

		// Insert figures
		figuresList.insert(rhomb);
		figuresList.insert(trapeze);
		figuresList.insert(cube);
		figuresList.insert(cylinder);

		// Print the figures
		System.out.println(figuresList.printList());

	}

}