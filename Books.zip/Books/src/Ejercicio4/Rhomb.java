package Ejercicio4;

/**
 * @author Gabriel Guzm�n
 * @version 09/11/2020
 */
public class Rhomb extends Figures {

	// Define attributes
	private int minorDiagonal;
	private int majorDiagonal;
	private int side;

	/**
	 * Constructor without parameters
	 */
	public Rhomb() {

	}

	/**
	 * Constructor with parameters
	 * 
	 * @param name
	 * @param minorDiagonal
	 * @param majorDiagonal
	 * @param leftSide
	 * @param rightSide
	 */
	public Rhomb(String name, int minorDiagonal, int majorDiagonal, int side) {
		super(name);
		this.minorDiagonal = minorDiagonal;
		this.majorDiagonal = majorDiagonal;
		this.side = side;
	}

	/**
	 * Set the minor diagonal
	 * 
	 * @param minorDiagonal
	 */
	public void setMinorDiagonal(int minorDiagonal) {
		this.minorDiagonal = minorDiagonal;
	}

	/**
	 * Set the major diagonal
	 * 
	 * @param majorDiagonal
	 */
	public void setMajorDiagonal(int majorDiagonal) {
		this.majorDiagonal = majorDiagonal;
	}

	/**
	 * Set the rhomb side
	 * 
	 * @param side
	 */
	public void setSide(int side) {
		this.side = side;
	}

	/**
	 * Get the minor diagonal
	 * 
	 * @return minorDiagonal
	 */
	public int getMinorDiagonal() {
		return minorDiagonal;
	}

	/**
	 * Get the major diagonal
	 * 
	 * @return majorDiagonal
	 */
	public int getMajorDiagonal() {
		return majorDiagonal;
	}

	/**
	 * Get the rhomb side
	 * 
	 * @return side
	 */
	public int getSide() {
		return side;
	}

	/**
	 * This method computes the perimeter
	 */
	public int computePerimeter() {
		int perimeter;
		perimeter = 4 * side;
		return perimeter;
	}

	/**
	 * @Override
	 */
	public int computeArea() {

		int area;
		area = (minorDiagonal * majorDiagonal) / 2;

		return area;
	}

	/**
	 * @Override
	 */
	public String toString() {
		return "Name: " + super.getName() + "\nSide: " + side + "\nArea: " + computeArea() + "\nPerimeter: "
				+ computePerimeter();
	}

}