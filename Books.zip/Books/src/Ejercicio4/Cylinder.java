package Ejercicio4;

/**
 * @author Gabriel Guzm�n
 * @version 09/11/2020
 */
public class Cylinder extends Figures {

	// Define attributes
	private int radio;
	private int height;

	/**
	 * Constructor without parameters
	 */
	public Cylinder() {

	}

	/**
	 * Constructor with parameters
	 * 
	 * @param name
	 * @param minorBase
	 * @param majorBase
	 * @param leftSide
	 */
	public Cylinder(String name, int radio, int height) {
		super(name);
		this.radio = radio;
		this.height = height;
	}

	/**
	 * Set the radio
	 * 
	 * @param radio
	 */
	public void setRadio(int radio) {
		this.radio = radio;
	}

	/**
	 * Set the height
	 * 
	 * @param height
	 */
	public void setHeight(int height) {
		this.height = height;
	}

	/**
	 * Get the radio
	 * 
	 * @return radio
	 */
	public int getRadio() {
		return radio;
	}

	/**
	 * Get the height
	 * 
	 * @return height
	 */
	public int getHeight() {
		return height;
	}

	/**
	 * This method computes the volume
	 */
	public int computeVolume() {
		double volume;
		volume = 3.14 * (radio ^ 2) * height;
		return (int) volume;
	}

	/**
	 * @Override
	 */
	public int computeArea() {

		double area;
		area = (2 * 3.14) * (radio * (height + radio));

		return (int) area;
	}

	/**
	 * @Override
	 */
	public String toString() {
		return "Name: " + super.getName() + "\nRadio: " + radio + "\nHeight: " + height + "\nArea: " + computeArea()
				+ "\nVolume: " + computeVolume();
	}

}