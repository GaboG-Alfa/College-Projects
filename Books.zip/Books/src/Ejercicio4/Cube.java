package Ejercicio4;

/**
 * @author Gabriel Guzm�n
 * @version 09/11/2020
 */
public class Cube extends Figures {

	// Define attributes
	private int side;
	private int numberOfSides;

	/**
	 * Constructor without parameters
	 */
	public Cube() {

	}

	/**
	 * Constructor with parameters
	 * 
	 * @param name
	 * @param side
	 * @param numberOfSides
	 */
	public Cube(String name, int side, int numberOfSides) {
		super(name);
		this.side = side;
		this.numberOfSides = numberOfSides;
	}

	/**
	 * Set the cube side
	 * 
	 * @param side
	 */
	public void setSide(int side) {
		this.side = side;
	}

	/**
	 * Set the cube number of sides
	 * 
	 * @param numberOfSides
	 */
	public void setnumberOfSides(int numberOfSides) {
		this.numberOfSides = numberOfSides;
	}

	/**
	 * Get the cube side
	 * 
	 * @return side
	 */
	public int getSide() {
		return side;
	}

	/**
	 * Get the cube number of sides
	 * 
	 * @return numberOfSide
	 */
	public int getNumberOfSides() {
		return numberOfSides;
	}

	/**
	 * @Override
	 */
	public int computeVolume() {
		int compute;
		compute = side ^ 3;
		return compute;
	}

	/**
	 * @Override
	 */
	public int computeArea() {

		int area;
		area = numberOfSides * (side ^ 2);

		return area;
	}

	/**
	 * @Override
	 */
	public String toString() {
		return "Name: " + super.getName() + "\nSide: " + side + "\nNumber of sides" + numberOfSides + "\nArea: "
				+ computeArea() + "\nVolume: " + computeVolume();
	}

}
