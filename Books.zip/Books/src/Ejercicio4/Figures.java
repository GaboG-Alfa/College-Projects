package Ejercicio4;

/**
 * @author Gabriel Guzm�n
 * @version 09/11/2020
 */
public abstract class Figures {

	// Define
	private String name;

	/**
	 * Constructor without parameters
	 */
	public Figures() {

	}

	/**
	 * Constructor with parameters
	 * 
	 * @param name
	 */
	public Figures(String name) {
		this.name = name;
	}

	/**
	 * Set the figure name
	 * 
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Get the figure name
	 * 
	 * @return
	 */
	public String getName() {
		return name;
	}

	/**
	 * Return all attributes
	 */
	public String toString() {
		return "Name: " + name;
	}

	/**
	 * Abstract methods
	 */
	public abstract int computeArea();;

}