package Ejercicio4;

/**
 * @author Gabriel Guzm�n
 * @version 09/11/2020
 */
public class Trapeze extends Figures {

	// Define attributes
	private int minorBase;
	private int majorBase;
	private int height;
	private int leftSide;
	private int rightSide;

	/**
	 * Constructor without parameters
	 */
	public Trapeze() {

	}

	/**
	 * Constructor with parameters
	 * 
	 * @param name
	 * @param minorBase
	 * @param majorBase
	 * @param leftSide
	 * @param rightSide
	 */
	public Trapeze(String name, int minorBase, int majorBase, int height, int leftSide, int rightSide) {
		super(name);
		this.minorBase = minorBase;
		this.majorBase = majorBase;
		this.height = height;
		this.leftSide = leftSide;
		this.rightSide = rightSide;
	}

	/**
	 * Set the minor base
	 * 
	 * @param minorBase
	 */
	public void setMinorBase(int minorBase) {
		this.minorBase = minorBase;

	}

	/**
	 * Set the major base
	 * 
	 * @param majorBase
	 */
	public void setMajorBase(int majorBase) {
		this.majorBase = majorBase;

	}

	/**
	 * Set the trapeze height
	 * 
	 * @param height
	 */
	public void setHeight(int height) {
		this.height = height;
	}

	/**
	 * Set the trapeze left side
	 * 
	 * @param leftSide
	 */
	public void setLeftSide(int leftSide) {

	}

	/**
	 * Set the trapeze right side
	 * 
	 * @param leftSide
	 */
	public void setRightSide(int rightSide) {

	}

	/**
	 * Get the minor base
	 * 
	 * @return minorBase
	 */
	public int getetMinorBase() {
		return minorBase;

	}

	/**
	 * Get the major base
	 * 
	 * @return majorBase
	 */
	public int getMajorBase() {
		return majorBase;

	}

	/**
	 * Get the trapeze height
	 * 
	 * @return height
	 */
	public int getHeight() {
		return height;
	}

	/**
	 * Get the left side
	 * 
	 * @return leftSide
	 */
	public int getLeftSide() {
		return leftSide;
	}

	/**
	 * Get the right side
	 * 
	 * @return rightSide
	 */
	public int getRightSide() {
		return rightSide;
	}

	/**
	 * This method compute the perimeter
	 */
	public int computePerimeter() {
		int perimeter;
		perimeter = minorBase + majorBase + leftSide + rightSide;
		return perimeter;
	}

	/**
	 * @Override
	 */
	public int computeArea() {

		int area;
		area = ((minorBase + majorBase) * height) / 2;

		return area;
	}

	/**
	 * @Override
	 */
	public String toString() {
		return "Name: " + super.getName() + "\nHeight: " + height + "\nLeft Side: " + leftSide + "\nRight Side: "
				+ rightSide + "\nArea: " + computeArea() + "\nVolume: " + computePerimeter();
	}

}