package Ejercicio4;

/**
 * 
 * @author Gabriel Guzm�n Alfaro
 * @version 09/11/2020
 */
public class FiguresList {

	// Define attributes
	private Figures figureList[];
	private int index = 0;

	/**
	 * Constructor without parameters
	 */
	public FiguresList() {

		this.figureList = new Figures[10];
	}

	/**
	 * Print the list of books
	 * 
	 * @return listBooks
	 */
	public String printList() {

		String listFigures = "";
		for (int i = 0; i < figureList.length; i++) {
			if (figureList[i] != null) {
				listFigures = listFigures + " \n" + "\n" + figureList[i].toString();
			}
		}
		return listFigures;
	}

	/**
	 * Add a figure as a stack
	 * 
	 * @param figure
	 * @param position
	 */
	public void insert(Figures figure) {
		figureList[index] = figure;
		index = index + 1;

	}
}
