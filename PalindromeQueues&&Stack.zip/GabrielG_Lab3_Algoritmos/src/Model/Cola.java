package Model;

/**
 * 
 * @author Gabriel Guzmán Alfaro
 * @version 20/05/2021 
 */
public class Cola {
    
    //Atributo
    NodoCola front;
    NodoCola reer;
    int size;
    int max;
    
    /**
     * Constructor
     * @param tamano 
     */
    public Cola(){
        
        front = reer = null;
        size = 0;
        this.max = 0;
    }
    
    /**
     * 
     * @return primero
     */
    public boolean isEmpty() {
        return front == null;
    }
    
    /**
     * Inserta el dato
     * @param dato 
     */
    public void enqueue(char dato){
         
        NodoCola nuevo = new NodoCola();
        nuevo.setDato(dato);
        if (front==null) {
            
            front = nuevo;
            
        } else {
            reer.setSiguiente(nuevo);
        }
        reer = nuevo;
        size++;
    }
    
    /**
     * Extrae el primer elemento
     * @return tmp
     */
    public char dequeue() throws ColaException {
        
        if(front==null){
            throw new ColaException("La cola está vacía");
        }
        
        char tmp = front.getDato();
        front = front.getSiguiente();
        
        
        size--;
        return tmp;
        
    }
    
    /**
     * 
     * @return primero.getDato()
     */
    public char front() throws ColaException {
        
        if(front==null){
            throw new ColaException("La cola está vacía");
        }
        
        return front.getDato();
        
    }
    
    /**
     * Retorna el tamaño de la cola
     * @return tamano 
     */
    public int size() {
        return size;
        
    }
    
}
