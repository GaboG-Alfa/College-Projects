/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Cola;
import Model.ColaException;
import Model.Pila;
import Model.PilaException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Gabriel Guzmán Alfaro
 * @version 20/05/2021
 */
public class Palindromo {

    //Atributos 
    private Pila pila;
    private Cola cola;

    /**
     * Constructor
     */
    public Palindromo() {

        pila = new Pila();
        cola = new Cola();
    }

    public void ingreso(String palabra) throws ColaException {
        
        pila=new Pila();
        cola = new Cola();
        
        palabra = palabra.toLowerCase();

        for (int i = 0; i < palabra.length(); i++) {

            if (palabra.charAt(i) != ' ') {
                pila.push(palabra.charAt(i));
                cola.enqueue(palabra.charAt(i));

            }

        }

    }

    /**
     * Hacer palindromo
     *
     * @param palabra
     * @return hilera
     */
    public boolean isPalindromo() {

        while (!pila.isEmpty()) {

            try {
                if (pila.pop() != cola.dequeue()) {

                    return false;
                }
            } catch (ColaException ex) {
                Logger.getLogger(Palindromo.class.getName()).log(Level.SEVERE, null, ex);
            } catch (PilaException ex) {
                Logger.getLogger(Palindromo.class.getName()).log(Level.SEVERE, null, ex);
            }

        }

        return true;

    }

}
