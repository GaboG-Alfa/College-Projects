package View;

import Controller.Palindromo;
import Model.ColaException;
import javax.swing.JFrame;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import java.awt.FlowLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.util.logging.Level;
import java.util.logging.Logger;

public class PalindromoTest extends JFrame {

    private String palabra;
    private Palindromo palindromo;
    private boolean evaluar = false;
    private JButton opcionA, exit; // Botones de mostrar y salir

    public PalindromoTest(){
        super("Palindromo");

        setLayout(new FlowLayout(FlowLayout.LEFT, 5, 10));

        opcionA = new JButton("Ingresar otra palabra");

        exit = new JButton("Salir");
        add(opcionA);
        add(exit);

        //Instanciar balanceo
        palindromo = new Palindromo();

        palabra = JOptionPane.showInputDialog(null, "Ingrese la palabra: ", "Palabra a preguntar",
                JOptionPane.INFORMATION_MESSAGE);

        try {
            palindromo.ingreso(palabra);
        } catch (ColaException ex) {
            Logger.getLogger(PalindromoTest.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        evaluar= palindromo.isPalindromo();

        JOptionPane.showMessageDialog(null, "Es palindormo? : " + evaluar, "Resultados del balanceo de fórmula", JOptionPane.INFORMATION_MESSAGE);

        // Programamos los Listener de cada Boton
        opcionA.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent evento) {
                
                
                palabra = JOptionPane.showInputDialog(null, "Ingrese la palabra: ", "Palabra a preguntar",
                        JOptionPane.INFORMATION_MESSAGE);

                try {
                    palindromo.ingreso(palabra);
                } catch (ColaException ex) {
                    Logger.getLogger(PalindromoTest.class.getName()).log(Level.SEVERE, null, ex);
                }

                evaluar= palindromo.isPalindromo();
               
                JOptionPane.showMessageDialog(null, "Es palindormo? : " + evaluar, "Resultados del balanceo de fórmula", JOptionPane.INFORMATION_MESSAGE);

            }

        });

        exit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evento) {
                JOptionPane.showMessageDialog(null, "Saldra de la aplicacion", "WARNING", JOptionPane.WARNING_MESSAGE);
                System.exit(0);
            }
        });

    }

    // Metodo main()
    public static void main(String args[]) {
        PalindromoTest listen = new PalindromoTest();
        listen.setLocationRelativeTo(null);
        listen.setSize(300, 175);
        listen.setVisible(true);
    }

}
