﻿using DA;
using Datos;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BL
{
    public class PacienteBL
    {
        private PacienteDA pacienteDA;
        public PacienteBL()
        {
            pacienteDA = new PacienteDA();

        }

        public DataTable obtenerPacientes()
        {
            return pacienteDA.obtenerPacientes();
        }

        public Paciente obtenerPaciente(string cedula)
        {
            Paciente paciente = pacienteDA.buscarPaciente(cedula);
            return paciente;
        }

        public bool agregarPaciente(Paciente paciente)
        {
            if (paciente.Cedula == "")
            {
                throw new Exception("La cédula es requerida");
            }

            if (paciente.Nombre == "")
            {
                throw new Exception("El nombre es requerido");
            }

            if (paciente.Apellidos == "")
            {
                throw new Exception("Los apellidos son requeridos");
            }
            if (paciente.FechaNacimiento == null)
            {
                throw new Exception("La fecha de nacimiento es requerida");
            }

            if (paciente.Direccion == "")
            {
                throw new Exception("La direccion es requerida");
            }

            if (paciente.Telefono == "" ) {
                throw new Exception("El número de teléfono es requerido");
            }

            if (paciente.Email == "")
            {
                throw new Exception("El correo electrónico es requerido");
            }

            if (paciente.TipoSangre == "")
            {
                throw new Exception("El tipo de sangre es requerido");
            }

            if (paciente.Alergias == "")
            {
                throw new Exception("Las alergias son requeridas");
            }

            Paciente pacienteExistente = obtenerPaciente(paciente.Cedula);
            if (pacienteExistente == null)
            {

                return pacienteDA.agregarPaciente(paciente);

            }

            return pacienteDA.editarPaciente(paciente);
        }

        public bool eliminarPaciente(string cedula)
        {
            bool eliminado = pacienteDA.eliminarPaciente(cedula);
            if (!eliminado)
            {

              throw new Exception("El paciente no pudo ser eliminado");

            }
            return eliminado;
        }

    }
}
