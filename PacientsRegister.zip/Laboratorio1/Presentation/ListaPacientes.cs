﻿using BL;
using Datos;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Presentation
{
    public partial class ListaPacientes : Form
    {
        private PacienteBL pacienteBL;
        private MostrarPacienteBuscado pacienteBuscadoForm = new MostrarPacienteBuscado();
        public ListaPacientes()
        {
            InitializeComponent();
            pacienteBL = new PacienteBL();
        }

        private void ListaPacientes_Load(object sender, EventArgs e)
        {
            pacientesDataGridView.DataSource = pacienteBL.obtenerPacientes();
            llenarTabla();

        }

        private void AgregarButton_Click(object sender, EventArgs e)
        {
            RegistroPaciente registroEmpleadoForm = new RegistroPaciente(this, null);
            registroEmpleadoForm.Show();

        }

        private void pacientesDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow row = pacientesDataGridView.Rows[e.RowIndex];
            if (e.ColumnIndex == pacientesDataGridView.Columns["Borrar"].Index)
            {
                string cedula = row.Cells[0].Value.ToString();
                try
                {
                    pacienteBL.eliminarPaciente(cedula);
                    llenarTabla();
                }
                catch (Exception error)
                {

                    MessageBox.Show(error.Message);

                }
            }

            if (e.ColumnIndex == pacientesDataGridView.Columns["Editar"].Index)
            {
                string cedula = row.Cells[0].Value.ToString();
                string nombre = row.Cells[1].Value.ToString();
                string apellidos = row.Cells[2].Value.ToString();
                DateTime fechaNacimiento = DateTime.Parse(row.Cells[3].Value.ToString());
                string direccion = row.Cells[4].Value.ToString();
                string telefono = row.Cells[5].Value.ToString();
                string email = row.Cells[6].Value.ToString();
                string tipoSangre = row.Cells[7].Value.ToString();
                string alergias = row.Cells[8].Value.ToString();
                Paciente paciente = new Paciente(cedula, nombre, apellidos, fechaNacimiento, direccion, telefono, email, tipoSangre, alergias);


                RegistroPaciente registroPacienteForm = new RegistroPaciente(this, paciente);
                registroPacienteForm.Show();


            }
        }

        public void llenarTabla()
        {

            pacientesDataGridView.DataSource = null;
            pacientesDataGridView.Columns.Clear();
            pacientesDataGridView.DataSource = pacienteBL.obtenerPacientes();

            //Botón eliminar
            DataGridViewButtonColumn columnaBorrar = new DataGridViewButtonColumn();
            columnaBorrar.Name = "Borrar";
            columnaBorrar.Text = "Borrar";
            columnaBorrar.UseColumnTextForButtonValue = true;
            pacientesDataGridView.Columns.Add(columnaBorrar);

            //Botón editar
            DataGridViewButtonColumn columnaEditar = new DataGridViewButtonColumn();
            columnaEditar.Name = "Editar";
            columnaEditar.Text = "Editar";
            columnaEditar.UseColumnTextForButtonValue = true;
            pacientesDataGridView.Columns.Add(columnaEditar);
        }

        private void buscarPacienteTextBox_TextChanged(object sender, EventArgs e)
        {
        }

        private void buscarPacienteButton_Click(object sender, EventArgs e)
        {
            string cedula = buscarPacienteTextBox.Text;
            Paciente paciente = pacienteBL.obtenerPaciente(cedula);
            if (paciente != null)
            {
                mostrarPacienteBuscado(paciente);
            }
            else
            {
                MessageBox.Show("No se encontró ningún paciente con esa cédula.");
            }
        }

        private void mostrarPacienteBuscado(Paciente paciente)
        {
            pacienteBuscadoForm.mostrarPaciente(paciente);
            pacienteBuscadoForm.ShowDialog(); 
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}    
