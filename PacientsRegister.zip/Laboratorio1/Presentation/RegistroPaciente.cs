﻿using BL;
using Datos;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Presentation
{
    public partial class RegistroPaciente : Form
    {
        private ListaPacientes pacientesForm;
        private Paciente paciente;
        private PacienteBL pacienteBL;  
        public RegistroPaciente(ListaPacientes listaPaciente,Paciente paciente)
        {
            this.pacientesForm= listaPaciente;
            this.paciente = paciente;
            pacienteBL=new PacienteBL();
            InitializeComponent();
        }

        private void RegistroPaciente_Load(object sender, EventArgs e)
        {

            if (paciente != null)
            {
                cedulaTextBox.Enabled = false;
                cedulaTextBox.Text = paciente.Cedula;
                nombreTextBox.Text = paciente.Nombre;
                apellidosTextBox.Text = paciente.Apellidos;
                fechaNacimientoCalendar.SelectionStart = paciente.FechaNacimiento;
                fechaNacimientoCalendar.SelectionEnd = paciente.FechaNacimiento;
                direccionTextBox.Text = paciente.Direccion;
                telefonoTextBox.Text = paciente.Telefono;
                correoElectronicoTextBox.Text = paciente.Email;
                tipoSangreComboBox.Text= paciente.TipoSangre;
                alergiasTextBox.Text = paciente.Alergias;
            }


        }

        private void guardarButton_Click(object sender, EventArgs e)
        {
            try
            {
                guardar();
                pacientesForm.llenarTabla();
                Close();
            }
            catch (Exception error)
            {

                MessageBox.Show(error.Message);

            }
        }

        private void guardar()
        {
            string cedula = cedulaTextBox.Text;
            string nombre = nombreTextBox.Text;
            string apellidos = apellidosTextBox.Text;
            DateTime fechaNacimiento = fechaNacimientoCalendar.SelectionStart;
            string direccion = direccionTextBox.Text;
            string telefono = telefonoTextBox.Text;
            string email = correoElectronicoTextBox.Text;
            string tipoSangre = tipoSangreComboBox.Text;
            string alergias = alergiasTextBox.Text;
            Paciente paciente = new Paciente(cedula, nombre, apellidos, fechaNacimiento,direccion,telefono,email,tipoSangre,alergias);
            pacienteBL.agregarPaciente(paciente);

        }
    }
}
