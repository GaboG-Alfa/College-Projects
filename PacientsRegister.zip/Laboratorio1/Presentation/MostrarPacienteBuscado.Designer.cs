﻿namespace Presentation
{
    partial class MostrarPacienteBuscado
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MostrarPacienteBuscado));
            this.mostrarPacienteDataGridView = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.acpetarButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.mostrarPacienteDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // mostrarPacienteDataGridView
            // 
            this.mostrarPacienteDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.mostrarPacienteDataGridView.Location = new System.Drawing.Point(15, 36);
            this.mostrarPacienteDataGridView.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.mostrarPacienteDataGridView.Name = "mostrarPacienteDataGridView";
            this.mostrarPacienteDataGridView.Size = new System.Drawing.Size(672, 310);
            this.mostrarPacienteDataGridView.TabIndex = 0;
            this.mostrarPacienteDataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.mostrarPacienteDataGridView_CellContentClick);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(627, 786);
            this.button1.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(138, 42);
            this.button1.TabIndex = 1;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // acpetarButton
            // 
            this.acpetarButton.Location = new System.Drawing.Point(294, 355);
            this.acpetarButton.Name = "acpetarButton";
            this.acpetarButton.Size = new System.Drawing.Size(106, 35);
            this.acpetarButton.TabIndex = 2;
            this.acpetarButton.Text = "Aceptar";
            this.acpetarButton.UseVisualStyleBackColor = true;
            this.acpetarButton.Click += new System.EventHandler(this.acpetarButton_Click);
            // 
            // MostrarPacienteBuscado
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(702, 395);
            this.Controls.Add(this.acpetarButton);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.mostrarPacienteDataGridView);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.Name = "MostrarPacienteBuscado";
            this.Text = "MostarPacienteBuscado";
            this.Load += new System.EventHandler(this.MostrarPacienteBuscado_Load);
            ((System.ComponentModel.ISupportInitialize)(this.mostrarPacienteDataGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView mostrarPacienteDataGridView;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button acpetarButton;
    }
}