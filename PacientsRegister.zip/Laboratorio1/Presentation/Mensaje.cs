﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Presentation
{
    public partial class Mensaje : Form
    {
        private string mensaje;
        public Mensaje(string mensaje)
        {
            InitializeComponent();
            this.mensaje = mensaje;
        
        }

        private void Mensaje_Load(object sender, EventArgs e)
        {
            mensajeLabel.Text = mensaje;
        }

        private void aceptarButton_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
