﻿namespace Presentation
{
    partial class ListaPacientes
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ListaPacientes));
            this.pacientesDataGridView = new System.Windows.Forms.DataGridView();
            this.AgregarButton = new System.Windows.Forms.Button();
            this.buscarPacienteTextBox = new System.Windows.Forms.TextBox();
            this.buscarPacienteButton = new System.Windows.Forms.Button();
            this.instruccionLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pacientesDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // pacientesDataGridView
            // 
            this.pacientesDataGridView.AllowUserToOrderColumns = true;
            this.pacientesDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.pacientesDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.pacientesDataGridView.Location = new System.Drawing.Point(15, 134);
            this.pacientesDataGridView.Margin = new System.Windows.Forms.Padding(6);
            this.pacientesDataGridView.Name = "pacientesDataGridView";
            this.pacientesDataGridView.Size = new System.Drawing.Size(769, 415);
            this.pacientesDataGridView.TabIndex = 0;
            this.pacientesDataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.pacientesDataGridView_CellContentClick);
            // 
            // AgregarButton
            // 
            this.AgregarButton.Location = new System.Drawing.Point(680, 38);
            this.AgregarButton.Margin = new System.Windows.Forms.Padding(6);
            this.AgregarButton.Name = "AgregarButton";
            this.AgregarButton.Size = new System.Drawing.Size(105, 38);
            this.AgregarButton.TabIndex = 1;
            this.AgregarButton.Text = "Agregar";
            this.AgregarButton.UseVisualStyleBackColor = true;
            this.AgregarButton.Click += new System.EventHandler(this.AgregarButton_Click);
            // 
            // buscarPacienteTextBox
            // 
            this.buscarPacienteTextBox.Location = new System.Drawing.Point(44, 48);
            this.buscarPacienteTextBox.Margin = new System.Windows.Forms.Padding(2);
            this.buscarPacienteTextBox.Name = "buscarPacienteTextBox";
            this.buscarPacienteTextBox.Size = new System.Drawing.Size(275, 29);
            this.buscarPacienteTextBox.TabIndex = 2;
            this.buscarPacienteTextBox.TextChanged += new System.EventHandler(this.buscarPacienteTextBox_TextChanged);
            // 
            // buscarPacienteButton
            // 
            this.buscarPacienteButton.Location = new System.Drawing.Point(325, 46);
            this.buscarPacienteButton.Margin = new System.Windows.Forms.Padding(2);
            this.buscarPacienteButton.Name = "buscarPacienteButton";
            this.buscarPacienteButton.Size = new System.Drawing.Size(97, 36);
            this.buscarPacienteButton.TabIndex = 3;
            this.buscarPacienteButton.Text = "Buscar";
            this.buscarPacienteButton.UseVisualStyleBackColor = true;
            this.buscarPacienteButton.Click += new System.EventHandler(this.buscarPacienteButton_Click);
            // 
            // instruccionLabel
            // 
            this.instruccionLabel.AutoSize = true;
            this.instruccionLabel.Location = new System.Drawing.Point(28, 9);
            this.instruccionLabel.Name = "instruccionLabel";
            this.instruccionLabel.Size = new System.Drawing.Size(443, 24);
            this.instruccionLabel.TabIndex = 4;
            this.instruccionLabel.Text = "Busque un paciente por su número de cédula aquí:";
            this.instruccionLabel.Click += new System.EventHandler(this.label1_Click);
            // 
            // ListaPacientes
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(813, 564);
            this.Controls.Add(this.instruccionLabel);
            this.Controls.Add(this.buscarPacienteButton);
            this.Controls.Add(this.buscarPacienteTextBox);
            this.Controls.Add(this.AgregarButton);
            this.Controls.Add(this.pacientesDataGridView);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "ListaPacientes";
            this.Text = "Pacientes";
            this.Load += new System.EventHandler(this.ListaPacientes_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pacientesDataGridView)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView pacientesDataGridView;
        private System.Windows.Forms.Button AgregarButton;
        private System.Windows.Forms.TextBox buscarPacienteTextBox;
        private System.Windows.Forms.Button buscarPacienteButton;
        private System.Windows.Forms.Label instruccionLabel;
    }
}

