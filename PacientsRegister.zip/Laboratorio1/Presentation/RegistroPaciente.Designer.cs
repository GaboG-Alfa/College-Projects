﻿namespace Presentation
{
    partial class RegistroPaciente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(RegistroPaciente));
            this.cedulaLabel = new System.Windows.Forms.Label();
            this.nombreLabel = new System.Windows.Forms.Label();
            this.apellidosLabel = new System.Windows.Forms.Label();
            this.fechaNacimientoLabel = new System.Windows.Forms.Label();
            this.direccionLabel = new System.Windows.Forms.Label();
            this.telefonoLabel = new System.Windows.Forms.Label();
            this.correoElectronicoLabel = new System.Windows.Forms.Label();
            this.tipoSangreLabel = new System.Windows.Forms.Label();
            this.alergiasLabel = new System.Windows.Forms.Label();
            this.cedulaTextBox = new System.Windows.Forms.TextBox();
            this.nombreTextBox = new System.Windows.Forms.TextBox();
            this.apellidosTextBox = new System.Windows.Forms.TextBox();
            this.fechaNacimientoCalendar = new System.Windows.Forms.MonthCalendar();
            this.direccionTextBox = new System.Windows.Forms.TextBox();
            this.telefonoTextBox = new System.Windows.Forms.TextBox();
            this.correoElectronicoTextBox = new System.Windows.Forms.TextBox();
            this.alergiasTextBox = new System.Windows.Forms.TextBox();
            this.tipoSangreComboBox = new System.Windows.Forms.ComboBox();
            this.guardarButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // cedulaLabel
            // 
            this.cedulaLabel.AutoSize = true;
            this.cedulaLabel.Location = new System.Drawing.Point(35, 39);
            this.cedulaLabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.cedulaLabel.Name = "cedulaLabel";
            this.cedulaLabel.Size = new System.Drawing.Size(75, 24);
            this.cedulaLabel.TabIndex = 0;
            this.cedulaLabel.Text = "Cédula:";
            // 
            // nombreLabel
            // 
            this.nombreLabel.AutoSize = true;
            this.nombreLabel.Location = new System.Drawing.Point(35, 88);
            this.nombreLabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.nombreLabel.Name = "nombreLabel";
            this.nombreLabel.Size = new System.Drawing.Size(84, 24);
            this.nombreLabel.TabIndex = 1;
            this.nombreLabel.Text = "Nombre:";
            // 
            // apellidosLabel
            // 
            this.apellidosLabel.AutoSize = true;
            this.apellidosLabel.Location = new System.Drawing.Point(35, 138);
            this.apellidosLabel.Name = "apellidosLabel";
            this.apellidosLabel.Size = new System.Drawing.Size(93, 24);
            this.apellidosLabel.TabIndex = 2;
            this.apellidosLabel.Text = "Apellidos:";
            // 
            // fechaNacimientoLabel
            // 
            this.fechaNacimientoLabel.AutoSize = true;
            this.fechaNacimientoLabel.Location = new System.Drawing.Point(35, 187);
            this.fechaNacimientoLabel.Name = "fechaNacimientoLabel";
            this.fechaNacimientoLabel.Size = new System.Drawing.Size(196, 24);
            this.fechaNacimientoLabel.TabIndex = 3;
            this.fechaNacimientoLabel.Text = "Fecha de Nacimiento:";
            // 
            // direccionLabel
            // 
            this.direccionLabel.AutoSize = true;
            this.direccionLabel.Location = new System.Drawing.Point(45, 429);
            this.direccionLabel.Name = "direccionLabel";
            this.direccionLabel.Size = new System.Drawing.Size(95, 24);
            this.direccionLabel.TabIndex = 4;
            this.direccionLabel.Text = "Dirección:";
            // 
            // telefonoLabel
            // 
            this.telefonoLabel.AutoSize = true;
            this.telefonoLabel.Location = new System.Drawing.Point(45, 493);
            this.telefonoLabel.Name = "telefonoLabel";
            this.telefonoLabel.Size = new System.Drawing.Size(90, 24);
            this.telefonoLabel.TabIndex = 5;
            this.telefonoLabel.Text = "Teléfono:";
            // 
            // correoElectronicoLabel
            // 
            this.correoElectronicoLabel.AutoSize = true;
            this.correoElectronicoLabel.Location = new System.Drawing.Point(45, 544);
            this.correoElectronicoLabel.Name = "correoElectronicoLabel";
            this.correoElectronicoLabel.Size = new System.Drawing.Size(173, 24);
            this.correoElectronicoLabel.TabIndex = 6;
            this.correoElectronicoLabel.Text = "Correo Electrónico:";
            // 
            // tipoSangreLabel
            // 
            this.tipoSangreLabel.AutoSize = true;
            this.tipoSangreLabel.Location = new System.Drawing.Point(45, 603);
            this.tipoSangreLabel.Name = "tipoSangreLabel";
            this.tipoSangreLabel.Size = new System.Drawing.Size(146, 24);
            this.tipoSangreLabel.TabIndex = 7;
            this.tipoSangreLabel.Text = "Tipo de Sangre:";
            // 
            // alergiasLabel
            // 
            this.alergiasLabel.AutoSize = true;
            this.alergiasLabel.Location = new System.Drawing.Point(45, 648);
            this.alergiasLabel.Name = "alergiasLabel";
            this.alergiasLabel.Size = new System.Drawing.Size(83, 24);
            this.alergiasLabel.TabIndex = 8;
            this.alergiasLabel.Text = "Alergias:";
            // 
            // cedulaTextBox
            // 
            this.cedulaTextBox.Location = new System.Drawing.Point(120, 39);
            this.cedulaTextBox.Name = "cedulaTextBox";
            this.cedulaTextBox.Size = new System.Drawing.Size(254, 29);
            this.cedulaTextBox.TabIndex = 9;
            // 
            // nombreTextBox
            // 
            this.nombreTextBox.Location = new System.Drawing.Point(120, 91);
            this.nombreTextBox.Name = "nombreTextBox";
            this.nombreTextBox.Size = new System.Drawing.Size(254, 29);
            this.nombreTextBox.TabIndex = 10;
            // 
            // apellidosTextBox
            // 
            this.apellidosTextBox.Location = new System.Drawing.Point(134, 141);
            this.apellidosTextBox.Name = "apellidosTextBox";
            this.apellidosTextBox.Size = new System.Drawing.Size(240, 29);
            this.apellidosTextBox.TabIndex = 11;
            // 
            // fechaNacimientoCalendar
            // 
            this.fechaNacimientoCalendar.Location = new System.Drawing.Point(218, 231);
            this.fechaNacimientoCalendar.Name = "fechaNacimientoCalendar";
            this.fechaNacimientoCalendar.TabIndex = 12;
            // 
            // direccionTextBox
            // 
            this.direccionTextBox.Location = new System.Drawing.Point(146, 429);
            this.direccionTextBox.Name = "direccionTextBox";
            this.direccionTextBox.Size = new System.Drawing.Size(364, 29);
            this.direccionTextBox.TabIndex = 13;
            // 
            // telefonoTextBox
            // 
            this.telefonoTextBox.Location = new System.Drawing.Point(146, 490);
            this.telefonoTextBox.Name = "telefonoTextBox";
            this.telefonoTextBox.Size = new System.Drawing.Size(376, 29);
            this.telefonoTextBox.TabIndex = 14;
            // 
            // correoElectronicoTextBox
            // 
            this.correoElectronicoTextBox.Location = new System.Drawing.Point(224, 544);
            this.correoElectronicoTextBox.Name = "correoElectronicoTextBox";
            this.correoElectronicoTextBox.Size = new System.Drawing.Size(303, 29);
            this.correoElectronicoTextBox.TabIndex = 15;
            // 
            // alergiasTextBox
            // 
            this.alergiasTextBox.Location = new System.Drawing.Point(134, 645);
            this.alergiasTextBox.Name = "alergiasTextBox";
            this.alergiasTextBox.Size = new System.Drawing.Size(371, 29);
            this.alergiasTextBox.TabIndex = 16;
            // 
            // tipoSangreComboBox
            // 
            this.tipoSangreComboBox.FormattingEnabled = true;
            this.tipoSangreComboBox.Items.AddRange(new object[] {
            "A+",
            "O+",
            "B+",
            "AB+",
            "A-",
            "O-",
            "B-",
            "AB-"});
            this.tipoSangreComboBox.Location = new System.Drawing.Point(197, 600);
            this.tipoSangreComboBox.Name = "tipoSangreComboBox";
            this.tipoSangreComboBox.Size = new System.Drawing.Size(339, 32);
            this.tipoSangreComboBox.TabIndex = 17;
            // 
            // guardarButton
            // 
            this.guardarButton.Location = new System.Drawing.Point(559, 253);
            this.guardarButton.Name = "guardarButton";
            this.guardarButton.Size = new System.Drawing.Size(114, 33);
            this.guardarButton.TabIndex = 18;
            this.guardarButton.Text = "Guardar";
            this.guardarButton.UseVisualStyleBackColor = true;
            this.guardarButton.Click += new System.EventHandler(this.guardarButton_Click);
            // 
            // RegistroPaciente
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(707, 710);
            this.Controls.Add(this.guardarButton);
            this.Controls.Add(this.tipoSangreComboBox);
            this.Controls.Add(this.alergiasTextBox);
            this.Controls.Add(this.correoElectronicoTextBox);
            this.Controls.Add(this.telefonoTextBox);
            this.Controls.Add(this.direccionTextBox);
            this.Controls.Add(this.fechaNacimientoCalendar);
            this.Controls.Add(this.apellidosTextBox);
            this.Controls.Add(this.nombreTextBox);
            this.Controls.Add(this.cedulaTextBox);
            this.Controls.Add(this.alergiasLabel);
            this.Controls.Add(this.tipoSangreLabel);
            this.Controls.Add(this.correoElectronicoLabel);
            this.Controls.Add(this.telefonoLabel);
            this.Controls.Add(this.direccionLabel);
            this.Controls.Add(this.fechaNacimientoLabel);
            this.Controls.Add(this.apellidosLabel);
            this.Controls.Add(this.nombreLabel);
            this.Controls.Add(this.cedulaLabel);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "RegistroPaciente";
            this.Text = "RegistroPaciente";
            this.Load += new System.EventHandler(this.RegistroPaciente_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label cedulaLabel;
        private System.Windows.Forms.Label nombreLabel;
        private System.Windows.Forms.Label apellidosLabel;
        private System.Windows.Forms.Label fechaNacimientoLabel;
        private System.Windows.Forms.Label direccionLabel;
        private System.Windows.Forms.Label telefonoLabel;
        private System.Windows.Forms.Label correoElectronicoLabel;
        private System.Windows.Forms.Label tipoSangreLabel;
        private System.Windows.Forms.Label alergiasLabel;
        private System.Windows.Forms.TextBox cedulaTextBox;
        private System.Windows.Forms.TextBox nombreTextBox;
        private System.Windows.Forms.TextBox apellidosTextBox;
        private System.Windows.Forms.MonthCalendar fechaNacimientoCalendar;
        private System.Windows.Forms.TextBox direccionTextBox;
        private System.Windows.Forms.TextBox telefonoTextBox;
        private System.Windows.Forms.TextBox correoElectronicoTextBox;
        private System.Windows.Forms.TextBox alergiasTextBox;
        private System.Windows.Forms.ComboBox tipoSangreComboBox;
        private System.Windows.Forms.Button guardarButton;
    }
}