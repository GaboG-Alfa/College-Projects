﻿using BL;
using Datos;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Presentation
{
    public partial class MostrarPacienteBuscado : Form
    {
        private PacienteBL pacienteBL = new PacienteBL();
        private string cedula;
        public MostrarPacienteBuscado()
        {
            InitializeComponent();
        }

        private void mostrarPacienteDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
        }

        public void setCedula(string cedula) {

            this.cedula = cedula;
        }

        private void MostrarPacienteBuscado_Load(object sender, EventArgs e)
        {

        }

        public void mostrarPaciente(Paciente paciente)
        {
            DataTable dataTable = new DataTable();
            dataTable.Columns.Add("Cedula");
            dataTable.Columns.Add("Nombre");
            dataTable.Columns.Add("Apellidos");
            dataTable.Columns.Add("FechaNacimiento");
            dataTable.Columns.Add("Direccion");
            dataTable.Columns.Add("Telefono");
            dataTable.Columns.Add("Email");
            dataTable.Columns.Add("TipoSangre");
            dataTable.Columns.Add("Alergias");

            DataRow row = dataTable.NewRow();
            row["Cedula"] = paciente.Cedula;
            row["Nombre"] = paciente.Nombre;
            row["Apellidos"] = paciente.Apellidos;
            row["FechaNacimiento"] = paciente.FechaNacimiento;
            row["Direccion"] = paciente.Direccion;
            row["Telefono"] = paciente.Telefono;
            row["Email"] = paciente.Email;
            row["TipoSangre"] = paciente.TipoSangre;
            row["Alergias"] = paciente.Alergias;
            dataTable.Rows.Add(row);

            mostrarPacienteDataGridView.DataSource = dataTable;
        }

        private void acpetarButton_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
