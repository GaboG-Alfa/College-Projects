﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Datos;

namespace DA
{
    public class PacienteDA
    {
        private SqlConnection conexionSql;
        public PacienteDA()
        {
            conexionSql = new SqlConnection("server=DESKTOP-391E3G3\\SQLEXPRESS; database=Laboratorio1; integrated security=true");
        }

        public DataTable obtenerPacientes()
        {
            DataTable dataTable = new DataTable();
            try
            {
                conexionSql.Open();
                string query = "SELECT p.Cedula, p.Nombre, p.Apellidos, p.FechaNacimiento, p.Direccion, p.Telefono, p.Email, pa.TipoSangre, pa.Alergias\r\nFROM Persona p\r\nINNER JOIN Paciente pa ON p.Cedula = pa.Cedula;";
                SqlCommand comando = new SqlCommand(query, conexionSql);
                SqlDataReader reader = comando.ExecuteReader();
                dataTable.Load(reader);
            }
            catch (Exception error)
            {
                Console.WriteLine(error.Message);
            }
            conexionSql.Close();
            return dataTable;
        }

        public Paciente buscarPaciente(string cedula)
        {
            Paciente paciente = null; 

            try
            {
                conexionSql.Open();
                string query = "SELECT * FROM Laboratorio1.dbo.Persona\r\nINNER JOIN Paciente ON Paciente.Cedula = Laboratorio1.dbo.Persona.Cedula\r\nWHERE Laboratorio1.dbo.Persona.Cedula = @cedula;";
                SqlCommand comando = new SqlCommand(query, conexionSql);
                comando.Parameters.AddWithValue("@cedula", cedula);
                SqlDataReader reader = comando.ExecuteReader();

                
                if (reader.HasRows)
                {
                    
                    reader.Read();

                    paciente = new Paciente();
                    paciente.Cedula = reader["Cedula"].ToString();
                    paciente.Nombre = reader["Nombre"].ToString();
                    paciente.Apellidos = reader["Apellidos"].ToString();
                    paciente.FechaNacimiento = Convert.ToDateTime(reader["FechaNacimiento"]);
                    paciente.Direccion = reader["Direccion"].ToString();
                    paciente.Telefono = reader["Telefono"].ToString();
                    paciente.Email = reader["Email"].ToString();
                    paciente.TipoSangre = reader["TipoSangre"].ToString();
                    paciente.Alergias = reader["Alergias"].ToString();
                }

               
                reader.Close();
            }
            catch (Exception error)
            {
                Console.WriteLine(error.Message);
            }
            finally
            {
                
                if (conexionSql.State == ConnectionState.Open)
                {
                    conexionSql.Close();
                }
            }

            return paciente;
        }

        public bool agregarPaciente(Paciente paciente)
        {
            int filasAgregadas = 0;
            try
            {
                conexionSql.Open();
                string query = "INSERT INTO Persona (Cedula, Nombre, Apellidos, FechaNacimiento, Direccion, Telefono, Email)\r\nVALUES (@cedula, @nombre, @apellidos, @fechaNacimiento,@direccion,@telefono,@email);\r\n\r\nINSERT INTO Paciente (Cedula, TipoSangre, Alergias)\r\nSELECT p.Cedula, @tipoSangre,@alergias \r\nFROM Persona p\r\nWHERE p.Cedula = @cedula;";
                SqlCommand comando = new SqlCommand(query, conexionSql);
                comando.Parameters.AddWithValue("@cedula", paciente.Cedula);
                comando.Parameters.AddWithValue("@nombre", paciente.Nombre);
                comando.Parameters.AddWithValue("@apellidos", paciente.Apellidos);
                comando.Parameters.AddWithValue("@fechaNacimiento", paciente.FechaNacimiento);
                comando.Parameters.AddWithValue("@direccion",paciente.Direccion);
                comando.Parameters.AddWithValue("@telefono", paciente.Telefono);
                comando.Parameters.AddWithValue("@email", paciente.Email);
                comando.Parameters.AddWithValue("@tipoSangre", paciente.TipoSangre);
                comando.Parameters.AddWithValue("@alergias", paciente.Alergias);

                filasAgregadas = comando.ExecuteNonQuery();

            }
            catch (Exception error)
            {

                Console.WriteLine(error.Message);
            }
            conexionSql.Close();
            return filasAgregadas > 0;
        }

        public bool eliminarPaciente(string cedula)
        {
            int filasEliminadas = 0;

            try
            {
                conexionSql.Open();
                string query = "DELETE FROM Paciente\r\nWHERE Cedula IN (SELECT Cedula FROM Persona WHERE Cedula = @cedula);\r\n\r\nDELETE FROM Persona\r\nWHERE Cedula = @cedula;";
                SqlCommand comando = new SqlCommand(query, conexionSql);
                comando.Parameters.AddWithValue("@cedula", cedula);
                filasEliminadas = comando.ExecuteNonQuery();

            }
            catch (Exception error)
            {
                Console.WriteLine(error.Message);
            }

            conexionSql.Close();
            return filasEliminadas > 0;
        }

        public bool editarPaciente(Paciente paciente)
        {

            int filasActualizadas = 0;
            try
            {
                conexionSql.Open();
                string query = "Update Persona SET Nombre = @nombre,Apellidos = @apellidos,FechaNacimiento = @fechaNacimiento,Direccion = @direccion, Telefono = @telefono , Email = @email WHERE Cedula = @cedula; UPDATE Paciente\r\nSET TipoSangre = @tipoSangre,\r\n    Alergias = @alergias\r\nFROM Paciente pa\r\nINNER JOIN Persona p ON p.Cedula = pa.Cedula\r\nWHERE p.Cedula = @cedula;";
                SqlCommand comando = new SqlCommand(query, conexionSql);
                comando.Parameters.AddWithValue("@cedula", paciente.Cedula);
                comando.Parameters.AddWithValue("@nombre", paciente.Nombre);
                comando.Parameters.AddWithValue("@apellidos", paciente.Apellidos);
                comando.Parameters.AddWithValue("@fechaNacimiento", paciente.FechaNacimiento);
                comando.Parameters.AddWithValue("@direccion", paciente.Direccion);
                comando.Parameters.AddWithValue("@telefono", paciente.Telefono);
                comando.Parameters.AddWithValue("@email", paciente.Email);
                comando.Parameters.AddWithValue("@tipoSangre", paciente.TipoSangre);
                comando.Parameters.AddWithValue("@alergias", paciente.Alergias);
                filasActualizadas = comando.ExecuteNonQuery();
            }
            catch (Exception error)
            {
                Console.WriteLine(error.Message);
            }

            conexionSql.Close();

            return filasActualizadas > 0;

        }
    }
}
