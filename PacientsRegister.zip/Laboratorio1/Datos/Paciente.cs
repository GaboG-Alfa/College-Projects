﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Datos
{
    public class Paciente:Persona
    {
        public string TipoSangre { get; set; }
        public string Alergias { get; set; }

        public Paciente()
        {
        }
        public Paciente(string cedula,string nombre, string apellidos, DateTime fechaNacimiento, string direccion, string telefono, string email,string tipoSangre,string alergias) : base(cedula,nombre,apellidos,fechaNacimiento,direccion,telefono,email)
        {
        
            TipoSangre = tipoSangre;
            Alergias = alergias;

        }
    }
}
