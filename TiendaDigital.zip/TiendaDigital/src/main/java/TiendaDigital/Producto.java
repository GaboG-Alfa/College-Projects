package TiendaDigital;

/**
 * Clase que guarda información del producto
 */

/**
 *
 * @author Gabriel Guzmán Alfaro
 * @author Issac Brenes
 */
public class Producto {
    //Iniciar variables

    private String code;
    private double precio;
    private String nombre;
    private double cantidad;
    private double subTotal;

    /**
     * Constructor sin parametros
     */
    public Producto() {
        code = "";
    }//Fin constructor vac�o

    /**
     * Constructor
     *
     * @param code
     * @param precio
     * @param nombre
     * @param cantidad
     * @param subTotal
     */
    public Producto(String code, double precio, String nombre, double cantidad, double subTotal) {
        this.subTotal = subTotal;
        this.code = code;
        this.precio = precio;
        this.nombre = nombre;
        this.cantidad = cantidad;
    }//Fin constructor lleno 

    /**
     *
     * @param code
     */
    public void setCode(String code) {
        this.code = code;
    }

    /**
     *
     * @param precio
     */
    public void setPrecio(double precio) {
        this.precio = precio;
    }

    /**
     *
     * @param nombre
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     *
     * @param cantidad
     */
    public void setCantidad(double cantidad) {
        this.cantidad = cantidad;
    }

    /**
     *
     * @param subTotal
     */
    public void setSubTotal(double subTotal) {
        this.subTotal = subTotal;
    }

    /**
     *
     * @return code
     */
    public String getCode() {
        return code;
    }

    /**
     *
     * @return precio
     */
    public double getPrecio() {
        return precio;
    }

    /**
     *
     * @return nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     *
     * @return cantidad
     */
    public double getCantidad() {
        return cantidad;
    }

    /**
     *
     * @param precio
     * @param cantidad
     * @return subtotal
     */
    public double subTotalProducto(double precio, double cantidad) {
        subTotal = precio * cantidad;
        return subTotal;
    }

    /**
     *
     * @return hilera
     */
    public String toString() {
        return "Código: " + code + "        Título: " + nombre + "\n Cantidad: " + cantidad + "         Precio: " + precio + " colones.\n SubTotal: " + subTotal + ".\n***************************\n";
    }
}
