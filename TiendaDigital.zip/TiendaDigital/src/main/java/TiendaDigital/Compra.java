package TiendaDigital;

/**
 * Clase que almacena información sobre una compra
 */

/**
 *
 * @author Gabriel Guzmán Alfaro
 * @author Issac Brenes
 */
public class Compra {
    //Iniciar variables

    private String cliente;
    private String apellido;
    private int ident;
    private double iva;
    private double sumaSub;
    private double totalDeCompra;
    //Se crean objetos respectivos a cada producto
    private Producto producto1 = new Producto();
    private Producto producto2 = new Producto();
    private Producto producto3 = new Producto();
    private Producto producto4 = new Producto();
    private Producto producto5 = new Producto();
    //Constante necesaria para dar el valor de vacio a los productos en uno de los m�todos
    private final String CODIGO_VACIO = "";

    //Crear constructo vacio
    public Compra() {
    }//Fin constructor vacio 

    /**
     * Constructor
     *
     * @param cliente
     * @param apellido
     * @param ident
     * @param iva
     * @param sumaSub
     * @param totalDeCompra
     */
    public Compra(String cliente, String apellido, int ident, double iva, double sumaSub, double totalDeCompra) {
        this.cliente = cliente;
        this.apellido = apellido;
        this.ident = ident;
        this.iva = iva;
        this.sumaSub = sumaSub;
        this.totalDeCompra = totalDeCompra;
    }//Fin constructor lleno

    /**
     *
     * @param cliente
     */
    public void setCliente(String cliente) {
        this.cliente = cliente;
    }

    /**
     *
     * @param apellido
     */
    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    /**
     *
     * @param ident
     */
    public void setIdent(int ident) {
        this.ident = ident;
    }

    /**
     *
     * @param iva
     */
    public void setIva(double iva) {
        this.iva = iva;
    }

    /**
     *
     * @return cliente
     */
    public String getCliente() {
        return cliente;
    }

    /**
     *
     * @return apellido
     */
    public String getApellido() {
        return apellido;
    }

    /**
     *
     * @return ident
     */
    public int getIdent() {
        return ident;
    }

    /**
     *
     * @return iva
     */
    public double getIva() {
        return iva;
    }

    /**
     * Sumar subtotales
     *
     * @param sumaSub
     * @param subTotal
     * @return sumaSub
     */
    public double sumaSub(double sumaSub, double subTotal) {
        sumaSub = sumaSub + subTotal;
        return sumaSub;
    }

    /**
     *
     * @param sumaSub
     * @return iva
     */
    public double iva(double sumaSub) {
        this.iva = sumaSub * 0.13;
        return iva;
    }

    /**
     *
     * @param sumaSub
     * @param iva
     * @return totalDeCompra
     */
    public double totalDeCompra(double sumaSub, double iva) {
        this.totalDeCompra = sumaSub + iva;
        return totalDeCompra;
    }

    /**
     *
     * @return hilera
     */
    public String toString() {
        return "Nombre del cliente: " + cliente + " " + apellido + ".               Identificación: " + ident + ".";
    }

    /**
     * Se encarga de agregar un libro
     *
     * @param code
     * @param precio
     * @param nombre
     * @param cantidad
     * @param subTotal
     */
    public void agregarLibro(String code, double precio, String nombre, double cantidad, double subTotal) {
        if (producto1.getCode().equals(CODIGO_VACIO)) {
            producto1.setCode(code);
            producto1.setPrecio(precio);
            producto1.setNombre(nombre);
            producto1.setCantidad(cantidad);
            producto1.setSubTotal(subTotal);
        }//Fin if1
        else {
            if (producto2.getCode().equals(CODIGO_VACIO)) {
                producto2.setCode(code);
                producto2.setPrecio(precio);
                producto2.setNombre(nombre);
                producto2.setCantidad(cantidad);
                producto2.setSubTotal(subTotal);
            }//Fin if2
            else {
                if (producto3.getCode().equals(CODIGO_VACIO)) {
                    producto3.setCode(code);
                    producto3.setPrecio(precio);
                    producto3.setNombre(nombre);
                    producto3.setCantidad(cantidad);
                    producto3.setSubTotal(subTotal);
                }//Fin if3
                else {
                    if (producto4.getCode().equals(CODIGO_VACIO)) {
                        producto4.setCode(code);
                        producto4.setPrecio(precio);
                        producto4.setNombre(nombre);
                        producto4.setCantidad(cantidad);
                        producto4.setSubTotal(subTotal);
                    }//Fin if4
                    else {
                        if (producto5.getCode().equals(CODIGO_VACIO)) {
                            producto5.setCode(code);
                            producto5.setPrecio(precio);
                            producto5.setNombre(nombre);
                            producto5.setCantidad(cantidad);
                            producto5.setSubTotal(subTotal);
                        }//Fin if5
                    }//Fin else 5
                }//Fin else 4
            }//Fin else 3
        }//Fin else 2
    }//Fin else 1

    /**
     * Retorna los productos que se van ingresando
     *
     * @return hilera
     */
    public String mostrarDatos() {
        String hilera = "";
        if (producto1.getCode().equals(CODIGO_VACIO) == false) {
            hilera += producto1;
        }//Fin if 
        if (producto2.getCode().equals(CODIGO_VACIO) == false) {
            hilera += producto2;
        }//Fin if 
        if (producto3.getCode().equals(CODIGO_VACIO) == false) {
            hilera += producto3;
        }//Fin if 
        if (producto4.getCode().equals(CODIGO_VACIO) == false) {
            hilera += producto4;
        }//Fin if 
        if (producto5.getCode().equals(CODIGO_VACIO) == false) {
            hilera += producto5;
        }//Fin if 
        return hilera;
    }//Fin mostrar datos

    /**
     * Elimina un libro
     *
     * @param code
     * @param nombre
     * @param cantidad
     * @param precio
     * @param subTotal
     * @param sumaSub
     * @return
     */
    public double eliminarLibro(String code, String nombre, double cantidad, double precio, double subTotal, double sumaSub) {
        if (code.equals(producto1.getCode()) == true) {
            sumaSub = sumaSub - subTotal;
            code = "";
            nombre = "";
            cantidad = 0;
            precio = 0;
            subTotal = 0;
            producto1.setCode(code);
            producto1.setPrecio(precio);
            producto1.setNombre(nombre);
            producto1.setCantidad(cantidad);
            producto1.setSubTotal(subTotal);
        }//fin if producto 1
        if (code.equals(producto2.getCode()) == true) {
            sumaSub = sumaSub - subTotal;
            code = "";
            nombre = "";
            cantidad = 0;
            precio = 0;
            subTotal = 0;
            producto2.setCode(code);
            producto2.setPrecio(precio);
            producto2.setNombre(nombre);
            producto2.setCantidad(cantidad);
            producto2.setSubTotal(subTotal);
        }//fin if producto 2
        if (code.equals(producto3.getCode()) == true) {
            sumaSub = sumaSub - subTotal;
            code = "";
            nombre = "";
            cantidad = 0;
            precio = 0;
            subTotal = 0;
            producto3.setCode(code);
            producto3.setPrecio(precio);
            producto3.setNombre(nombre);
            producto3.setCantidad(cantidad);
            producto3.setSubTotal(subTotal);
        }//fin if producto 3
        if (code.equals(producto4.getCode()) == true) {
            sumaSub = sumaSub - subTotal;
            code = "";
            nombre = "";
            cantidad = 0;
            precio = 0;
            subTotal = 0;
            producto4.setCode(code);
            producto4.setPrecio(precio);
            producto4.setNombre(nombre);
            producto4.setCantidad(cantidad);
            producto4.setSubTotal(subTotal);
        }//fin if producto 4
        if (code.equals(producto5.getCode()) == true) {
            sumaSub = sumaSub - subTotal;
            code = "";
            nombre = "";
            cantidad = 0;
            precio = 0;
            subTotal = 0;
            producto5.setCode(code);
            producto5.setPrecio(precio);
            producto5.setNombre(nombre);
            producto5.setCantidad(cantidad);
            producto5.setSubTotal(subTotal);
        }//fin if producto 5
        return sumaSub;
    }

    /**
     * Reinicia los productos
     *
     * @param code
     * @param nombre
     * @param precio
     * @param cantidad
     * @param subTotal
     */
    public void reinicio(String code, String nombre, double precio, double cantidad, double subTotal) {
        code = "";
        nombre = "";
        cantidad = 0;
        precio = 0;
        subTotal = 0;
        producto1.setCode(code);
        producto1.setPrecio(precio);
        producto1.setNombre(nombre);
        producto1.setCantidad(cantidad);
        producto1.setSubTotal(subTotal);
        producto2.setCode(code);
        producto2.setPrecio(precio);
        producto2.setNombre(nombre);
        producto2.setCantidad(cantidad);
        producto2.setSubTotal(subTotal);
        producto3.setCode(code);
        producto3.setPrecio(precio);
        producto3.setNombre(nombre);
        producto3.setCantidad(cantidad);
        producto3.setSubTotal(subTotal);
        producto4.setCode(code);
        producto4.setPrecio(precio);
        producto4.setNombre(nombre);
        producto4.setCantidad(cantidad);
        producto4.setSubTotal(subTotal);
        producto5.setCode(code);
        producto5.setPrecio(precio);
        producto5.setNombre(nombre);
        producto5.setCantidad(cantidad);
        producto5.setSubTotal(subTotal);
    }

}//Fin clase Compra
