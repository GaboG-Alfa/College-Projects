package TiendaDigital;

/**
 * Clase que se encarga de gestionar la interfaz
 */
import javax.swing.JOptionPane;

/**
 *
 * @author Gabriel Guzmán
 * @author Issac Brenes
 */
public class GestorES {

    /**
     *
     * @param mensaje
     * @param titulo
     * @return
     */
    public String solicitarString(String mensaje, String titulo) {
        String hilera = JOptionPane.showInputDialog(null, mensaje, titulo, JOptionPane.INFORMATION_MESSAGE);
        return hilera;
    }

    /**
     *
     * @param mensaje
     * @param titulo
     * @return
     */
    public double solicitarDouble(String mensaje, String titulo) {
        double numero = Double.parseDouble(JOptionPane.showInputDialog(null, mensaje, titulo, JOptionPane.INFORMATION_MESSAGE));
        return numero;
    }

    /**
     *
     * @param mensaje
     * @param titulo
     * @return
     */
    public int solicitarInt(String mensaje, String titulo) {
        int numero = Integer.parseInt(JOptionPane.showInputDialog(null, mensaje, titulo, JOptionPane.INFORMATION_MESSAGE));
        return numero;
    }

    /**
     *
     * @param mensaje
     * @param titulo
     * @return
     */
    public char solicitarChar(String mensaje, String titulo) {
        String hilera = JOptionPane.showInputDialog(null, mensaje, titulo, JOptionPane.INFORMATION_MESSAGE);
        char caracter = hilera.charAt(0);
        return caracter;
    }

    /**
     *
     * @param mensaje
     * @param titulo
     */
    public void desplegarString(String mensaje, String titulo) {
        JOptionPane.showMessageDialog(null, mensaje, titulo, JOptionPane.INFORMATION_MESSAGE);
    }

    /**
     * Muestra mensaje de finalización
     */
    public void finalizar() {
        JOptionPane.showMessageDialog(null, "Gracias por usar nuestro programa", "Hasta luego!", JOptionPane.INFORMATION_MESSAGE);
        System.exit(0);
    }

}//Fin de la clase
