package TiendaDigital;

/**
 * Programa que permite hacer una compra de un listado de libros para determinar
 * el costo total a pagar.
 */

/**
 *
 * @author Gabriel Guzmán Alfaro
 * @author Issac Brenes
 *
 */
public class Menu {//Inicio de la clase menú.

    public static void main(String[] args) {//Inicio del main.
        //Creaciónn de objetos.
        GestorES gestorES = new GestorES();
        Producto objetoProducto = new Producto();
        Compra objetoCompra = new Compra();

        //Declaraci�n e inicialización de variables
        int opcionMenuu, ident, contProducto = 0, contMenuu = 0;
        String cliente, apellido, nombre = " ", mostrarCompra = "", code = "", hilera;
        char opcionSubMenuu;
        boolean seguir = true;
        boolean seguir1 = true;
        double iva = 0, subTotal = 0, precio = 0, cantidad = 0, totalDeCompra = 0, sumaSub = 0;

        do {//Ciclo que le permite volver al usuario al menú principal las veces que lo desee.
            contMenuu += 1;
            //Reinicio de variables para realizar el programa las veces que se desee.
            if (contMenuu > 0) {
                code = "";
                iva = 0;
                subTotal = 0;
                precio = 0;
                cantidad = 0;
                totalDeCompra = 0;
                sumaSub = 0;
                mostrarCompra = "";
                nombre = "";
                contProducto = 0;
                seguir1 = true;
                objetoCompra.reinicio(code, nombre, precio, cantidad, subTotal);
            }//fin if reinicio 
            //Bienvenidad y solicitud de camino a seguir del usuario
            opcionMenuu = gestorES.solicitarInt("¡Bienvenido a la libreria digital GASSACMARKET! \n 1. Iniciar una compra. \n 2. Salir.", "¡Hola!");
            //Inicio del primer Swithc
            switch (opcionMenuu) {
                case 1://Iniciar compra
                    //Solicitud de datos del cliente
                    cliente = gestorES.solicitarString("Digite el nombre del cliente.", "Datos del cliente.");
                    apellido = gestorES.solicitarString("Digite el apellido del cliente.", "Datos del cliente.");
                    ident = gestorES.solicitarInt("Ingrese el número de cédula del cliente.", "Datos del cliente.");

                    //Set�s y get�s de las variables cliente, apellido e ident
                    objetoCompra.setCliente(cliente);
                    objetoCompra.setApellido(apellido);
                    objetoCompra.setIdent(ident);
                    cliente = objetoCompra.getCliente();
                    apellido = objetoCompra.getApellido();
                    ident = objetoCompra.getIdent();

                    do {//Ciclo repetitivo que le permite al usuario hacer con total libertad su compra el el subMen�.
                        //Consulta al usuario sobre lo que desea realizar en el subMen�
                        opcionSubMenuu = gestorES.solicitarChar("Seleccione la acción que desea realizar: \na) Agregar un producto. \nb) Eliminar un producto. \nc) Mostrar compra. \nd) Finalizar compra. \ne) Regresar al menú principal (se perderá la información de la compra).", "Menú de compra.");

                        //Switch basado en la opci�n ingresada por el usuario en el subMen�.
                        switch (opcionSubMenuu) {
                            case 'a':
                            case 'A'://Ingreso de un nuevo libro.
                                contProducto += 1;//Contador que le impide al usuario ingresar m�s de 5 productos debido a la exclusividad de la tienda.
                                if (contProducto < 6) {//Principio del if que supervisa que no se ingresen m�s de 5 libros a compra. 
                                    //Solicitud del código del producto que desea ingrear 
                                    code = gestorES.solicitarString("Digite el código del producto que desea agregar:\n \nCódigo: 101,   Titulo: 100 años soledad (García Márquez),   Precio: 6250 colones. \nCódigo: 102,   Titulo: Lord of Rings(JR.Tolkien),   Precio: 5500 colones. \nCódigo: 103,   Titulo: Pedro Páramo(Juan Rulfo),    Precio:3500 colones, \nCódigo: 104.   Titulo: CYBER STORM (Matthew Matter),   Precio:3000 colones.  \nCódigo: 105,   Titulo: The Silent Patient (Alex Michaelides),   Precio:4500 colones. \nCódigo: 106,   Titulo: IT (Stephen King),   Precio: 7000 colones. \nCódigo: 107,   Titulo:Crónica de una muerte anunciada(García Marquez),   Precio:3500 colones.\nCódigo: 108,   Titulo:100 poemas de amor y una canci�n desesperada(Pablo Neruda).   Precio:2000 colones. \nCódigo: 109,   Titulo: La odiesa(Homero),    Precio: 6000 colones.  \nCódigo: 110,   Titulo: MAUS(Art Spiegelman),   Precio: 6000 colones. ", "Agregar Libro");
                                    while ((code.equals("101") == false) && (code.equals("102") == false) && (code.equals("103") == false) && (code.equals("104") == false) && (code.equals("105") == false) && (code.equals("106") == false) && (code.equals("107") == false) && (code.equals("108") == false) && (code.equals("109") == false) && (code.equals("110") == false)) {//Alerta y petición de ingreso de código, en caso de haber ingresado un código incorrecto.
                                        code = gestorES.solicitarString("El código ingresado es incorrecto, por favor digite uno nuevo.\n Digite el código del producto que desea agregar:\n \ncódigo: 101   Titulo: 100 años soledad (Garc�a M�rquez)   Precio: 6250 colones \ncódigo: 102   Titulo: Lord of Rings(JR.Tolkien)   Precio: 5500 colones \ncódigo: 103   Titulo: Pedro P�ramo(Juan Rulfo)    Precio:3500 colones \ncódigo: 104   Titulo: CYBER STORM (Matthew Matter)   Precio:3000  \ncódigo: 105   Titulo: The Silent Patient (Alex Michaelides)   Precio:4500 \ncódigo: 106   Titulo: IT (Stephen King)   Precio: 7000 \ncódigo: 107   Titulo:Cr�nica de una muerte anunciada(Garc�a Marquez)   Precio:3500 \ncódigo: 108   Titulo:100 poemas de amor y una canci�n desesperada(Pablo Neruda)   Precio:2000 colones \ncódigo: 109   Titulo: La odiesa(Homero)    Precio: 6000 colones  \ncódigo: 110   Titulo: MAUS(Art Spiegelman)   Precio: 6000 colones ", "ERROR!");
                                    }//Fin while
                                    //if�s anidados que según el código ingresado por el usuario asigna un precio y un nombre a dicho código
                                    if (code.equals("101")) {
                                        nombre = "100 años soledad (García Márquez).";
                                        precio = 6250;
                                    }//Fin if 1
                                    else {
                                        if (code.equals("102")) {
                                            nombre = "Lord of Rings(JR.Tolkien).";
                                            precio = 5500;
                                        }//Fin if 2
                                        else {
                                            if (code.equals("103")) {
                                                nombre = "Pedro P�ramo(Juan Rulfo).";
                                                precio = 3500;
                                            }//Fin if 3
                                            else {
                                                if (code.equals("104")) {
                                                    nombre = "CYBER STORM (Matthew Matter).";
                                                    precio = 3000;
                                                }//Fin if 4
                                                else {
                                                    if (code.equals("105")) {
                                                        nombre = "The Silent Patient (Alex Michaelides).";
                                                        precio = 4500;
                                                    }//Fin if 5
                                                    else {
                                                        if (code.equals("106")) {
                                                            nombre = "IT (Stephen King).";
                                                            precio = 7000;
                                                        }//Fin if 6
                                                        else {
                                                            if (code.equals("107")) {
                                                                nombre = "Crónica de una muerte anunciada(García Marquez).";
                                                                precio = 3500;
                                                            }//Fin if 7
                                                            else {
                                                                if (code.equals("108")) {
                                                                    nombre = "100 poemas de amor y una canción desesperada(Pablo Neruda).";
                                                                    precio = 2000;
                                                                }//Fin if 8
                                                                else {
                                                                    if (code.equals("109")) {
                                                                        nombre = "La odiesa(Homero).";
                                                                        precio = 6000;
                                                                    }//Fin if 9
                                                                    else {
                                                                        if (code.equals("110")) {
                                                                            nombre = "MAUS(Art Spiegelman).";
                                                                            precio = 6000;
                                                                        }//Fin if 10
                                                                    }//fin else 9
                                                                }//Fin else 8
                                                            }//Fin else 7
                                                        }//Fin else 6
                                                    }//Fin else 5
                                                }//fin else 4
                                            }//Fin else 3
                                        }//Fin else 2
                                    }//Fin else 1
                                    //Fin de asignación de nombre y precio según el código.

                                    //Solicitud de la cantidad de libros que desea comprar.                         
                                    cantidad = gestorES.solicitarInt("Ingrese la cantidad que desea comprar de este libro, recuerde no ingresar más de 3 o números negativos.", "Cantidad de libros.");
                                    do {//Ciclo que repite un mensaje de error hasta que el usuario digite una cantidad correcta.
                                        if ((cantidad < 0) || (cantidad > 3)) {
                                            cantidad = gestorES.solicitarInt("*Usted ha ingresado una cantidad inválida, recuerde no ingresar cantidad negativas o mayores que 3, por favor digite una nueva.*\nIngrese la cantidad que desea comprar de este libro, recuerde no ingresar m�s de 3 o n�meros negativos.", "Error!");
                                        }//Fin if cantidad incorrecta
                                    } while ((cantidad < 0) || (cantidad > 3));

                                    //validaci�n de que el producto fue a�adido con exito.
                                    if (cantidad <= 3) {
                                        gestorES.desplegarString("El libro se ha agregado correctamente.", "Agregado.");
                                        //Calcular el subtotal de la compra
                                        subTotal = objetoProducto.subTotalProducto(precio, cantidad);
                                        //Calcular la suma subtotal de compra        
                                        sumaSub = objetoCompra.sumaSub(sumaSub, subTotal);
                                        //calcular el iva de la compra
                                        iva = objetoCompra.iva(sumaSub);
                                        //Calcular la compra final        
                                        totalDeCompra = objetoCompra.totalDeCompra(sumaSub, iva);
                                        //Creaci�n de una variable que contiene la información de los productos ingresados 
                                        mostrarCompra = mostrarCompra + "\n" + objetoCompra.mostrarDatos();
                                    }// fin if de cantidad válida
                                }//Fin if contProducto 
                                //if que no le permite al usuario ingresar más de 5 productos y le muestra un mensaje señalandoselo
                                if (contProducto > 5) {
                                    gestorES.desplegarString("Ha ingresado 5 libros diferentes , si desea a�adir otro, elimine uno de los libros o realize m�s de una compra.", "Vuelva a ingresar.");
                                }//Fin if 
                                //Guardado del objeto 1 en producto y compra 
                                objetoCompra.agregarLibro(code, precio, nombre, cantidad, subTotal);
                                break;//break del case A.

                            case 'b':
                            case 'B'://Eliminar un producto de la compra.
                                if (mostrarCompra == "") {//Si aún no se han ingresado productos aparece el mensaje correspondiente
                                    gestorES.desplegarString("No se han añadido libros a la compra.", "Vuelva a ingresar.");
                                }//Fin if caso de que no hayan productoa
                                else {//Si ya se han ingresado productos.
                                    seguir1 = true;//Se le da un valor de verdadero a seguir 1 para poder continuar con el programa y no devolverse al men� inicial 
                                    hilera = objetoCompra.mostrarDatos();//Se crea una variable llamada hilera que guarda lo ingresado en el m�todo de la clase compra, llamado mostrarDatos
                                    //Se solicita el código del producto que desea realizar.
                                    code = gestorES.solicitarString("Digite el código del libro que desea eliminar de su compra: \n" + hilera, "Eliminar producto.");
                                    //mediante el método eliminar Libro eliminamos un libro ingresado y calculamos el nuevo subTotal para poder aplicarle el cambio al precio final
                                    sumaSub = objetoCompra.eliminarLibro(code, nombre, cantidad, precio, subTotal, sumaSub);
                                    iva = objetoCompra.iva(sumaSub);//Calculamos el iva con el nuevo subtotal para realizar correctamente el cambio de dinero
                                    totalDeCompra = objetoCompra.totalDeCompra(sumaSub, iva);//Y calculamos el total con el nuevo subtotal y el nuevo iva que se gener� debido a la extracci�n del producto.

                                    //preemos que el usuario intente ingresar un producto más y así aumente el contador mediante los siguientes ifs anidados.
                                    if (contProducto == 7) {//Si el usuario intenta ingresar dos productos más después de sobrepasar el límite
                                        contProducto = contProducto - 3;
                                    } else {
                                        if (contProducto == 6) {//Si el usuario intenta ingresar un producto más depués de sobrepasar el límite 
                                            contProducto = contProducto - 2;
                                        } else {
                                            contProducto = contProducto - 1;//Si el usuario no intenta sobrepasar el límite se quita solo un valor al contador para as� permitir sustiturlo por un nuevo producto
                                        }//Fin else 3
                                    }//Fin else 2
                                }//Fin else 1
                                break;//Break case 'B'

                            case 'c':
                            case 'C'://Mostar estado de compra hasta ese momento 
                                if (mostrarCompra == "") {//Si aún no se han ingresado productos aparece el mensaje correspondiente
                                    gestorES.desplegarString("No se han añadido libros a la compra.", "Vuelva a ingresar.");
                                }//fin if 
                                else {//si se han ingresado productos
                                    seguir1 = true;//Se le da un valor de verdadero a seguir1 para poder continuar con el programa
                                    //se muestran la compra hasta el momento 
                                    gestorES.desplegarString(objetoCompra.toString() + "\n\nLibros agregados: \n" + objetoCompra.mostrarDatos() + "\nTotal sin el I.V.A: " + sumaSub + " colones.\nI.V.A: " + iva + " colones.\nTotal a pagar: " + totalDeCompra + " colones.", "Compra.");
                                }//fin else
                                break;//break case C

                            case 'd':
                            case 'D'://Finalizar compra
                                if (mostrarCompra == "") {//Si aún no se han ingresado productos aparece el mensaje correspondiente
                                    gestorES.desplegarString("No se han añadido libros a la compra.", "Vuelva a ingresar.");
                                }//Fin if 
                                else {
                                    seguir1 = true;
                                    //se muestra un mensaje que confirma la compra y los datos de la misma
                                    gestorES.desplegarString("LA COMPRA HA SIDO ALMACENADA Y REALIZADA CORRECTAMENTE. \n\n" + objetoCompra.toString() + "\n\nLibros agregados: \n" + objetoCompra.mostrarDatos() + "\nTotal sin el I.V.A: " + sumaSub + " colones.\nI.V.A: " + iva + " colones.\nTotal a pagar: " + totalDeCompra + " colones.", "Compra");
                                }//Fin else 
                                break;//Fin break case 'D'
                            case 'e':
                            case 'E'://volver al sub menú 
                                seguir1 = false; //le damos un valor de falso para que se termine el ciclo do y volvamos al men� principal         
                                break;//break case 'E'

                            default://En caso de ser ingresada una opci�n inv�lida 
                                gestorES.desplegarString("Usted ha ingresado una opción inválida, por favor digite una nueva.", "Error");
                                break;//break default
                        }//fin switch2
                    } while (seguir1 == true);//Fin segundo do
                    break;//break case 1
                case 2://Finalizar 
                    gestorES.desplegarString("¡Gracias, por preferir nuestra libreria digital!", "Vuelva pronto.");//despedida
                    seguir = false;//se le da un valor de falso a seguir para terminar el segundo do 
                    break;//break case 2

                default://en caso de opci�n incorrecta
                    gestorES.desplegarString("Usted ha ingresado una opción inválida, por favor digite una nueva. ", "Error.");
                    break;//break default    
            }//Fin switch 2
        } while (seguir == true);//Fin primer do
    } //Fin Main
} //Fin Class.
