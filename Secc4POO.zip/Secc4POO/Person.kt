package com.example.poo

import android.annotation.SuppressLint

open class Person(var name: String = "Anonimo", var passport: String? = null, var height: Float) {

    var alive: Boolean = true

    @SuppressLint("NotConstructor")
    fun Person(){
        this.name = "Juan"
        this.passport = "A123984"
    }

    fun die(){
        alive = false
    }

    fun checkPolice(fn:(Float)->Boolean):Boolean{
        return fn(this.height)
    }
}

class Athlete(name:String,passport:String?,var sport:String): Person(name, passport, 1.62f){

}