package com.example.poo

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import kotlin.properties.Delegates

typealias aliasObjeto = SubClasses.Anidada
typealias aliasDato = MutableMap<Int,ArrayList<String>>
typealias aliasFuncion = (a:Int, b:Int) -> Int

class MainActivity : AppCompatActivity() {

    //private lateinit var pok :Pokemon
    object fernanda{
        var apodo = "fer"

        fun saludo(){println("Hola,me llaman $apodo")}
    }

    private fun String.noSpaces(): String{
        return this.replace("","")
    }

    private fun IntArray.show(){
        print("(")
        for(i in this) print("$i")
        println(")")
    }

    private fun calculadora(n1:Int, n2:Int, fn: (Int,Int)->Int):Int{
        return fn(n1,n2)
    }

    private fun suma(x:Int,y:Int):Int{return x+y}
    private fun resta(x:Int,y:Int):Int{return x-y}
    private fun multiplica(x:Int,y:Int):Int{return x*y}
    private fun divide(x:Int,y:Int):Int{return x/y}


    private fun inColombia(h:Float):Boolean{
        return h>=1.6f
    }

    private fun inSpain(h:Float):Boolean{
        return h>=1.65f
    }

    private fun Person.checkPolice(fn:(Float)->Boolean):Boolean{
        return fn(height)
    }

    private fun recorrerArray(array:IntArray,fn:(Int) -> Unit){
        for(i in array)
            fn(i)
    }

    private fun value_try(a: Int, b:Int){
        var res =
        try {
            println("División 5/0 = ${a / b}")
            a/b
        }catch(e:Exception){
            println("Vamos a manejar este error")

            "Divisón no permitida"
        }
    }

    private lateinit var cadena :String
    private var resi by Delegates.notNull<Boolean>()

    class IllegalPasswordException(message:String): Exception(message)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var usuario = "soy yo"
        println("${usuario} (${usuario.length}) - ${usuario.noSpaces()} (${usuario.noSpaces().length})")

        var array1: Array<Int> = arrayOf(5,4,3,2,1)
        var array2= IntArray(3)
        array2[0] = 10
        array2[1] = 20
        array2[2] = 30
        println("array2: "); array2.show()


        var array3: IntArray = intArrayOf(1,2,3,4,5)

        println("array3: "); array3.show()

        println("La suma de 80 y 20 es ${calculadora(80,20,::suma)}")

        var funcion = {x:Int, y: Int -> x+y}
        println("La suma de 80 y 20 con variable es ${calculadora(80,20,funcion)}")

        funcion = {x:Int, y: Int -> x-y}
        println("La resta de 50 y 10 con variable es ${calculadora(50,10,funcion)}")

        println("La suma de 80 y 20 con lamba es ${calculadora(80,20) { x: Int, y: Int -> x + y }}")
        println("La resta de 50 y 10 con lamba es ${calculadora(50,10) { x: Int, y: Int -> x - y }}")
        println("La potencia de 2 elevada a la 5 con lamba es ${calculadora(2,5
        ) { x, y ->
            var valor = 1
            for (i in 1..y) valor *= x

            valor
        }
        }")

        var array4=IntArray(10){5}
        println("array4: "); array4.show()
        var array5=IntArray(10){it}
        println("array5: "); array5.show();
        var array6=IntArray(10){it*2}
        println("array6: "); array6.show();

        var array7 = IntArray(10) {i-> i * 3}
        println("array7: "); array7.show()


        var suma = 0
        recorrerArray(array7){
            suma+= it
        }



        println("La suma de todos los elementos del array 7 es ${suma}")

        var num: Int = 0
        var jota: Person = Person("Jota","A23453456",1.62f)

        if(jota.checkPolice (::inColombia)) println("${jota.name} puede ser policía en Colombia")
        if(jota.checkPolice (::inSpain)) println("${jota.name} puede ser policía en España")


        println(jota.alive)
        println(jota.name)
        println(jota.passport)

        /*
        var anonimo:Person = Person()
        anonimo.Person()
        println(anonimo.alive)
        println(anonimo.name)
        println(anonimo.passport)
        */

        jota.die()
        jota.height= 1.8f
        jota.passport = "C23484"

        jota.let{
            it.die()
            it.height = 1.8f
            it.passport = "C234874"
        }

        var jose = Person("Jose","LP23451",1.4f).apply{
            this.die()
            height = 1.9f
            passport = "D989832"
        }.also{
            it.alive=true
        }

        var maria = Person("María","R892033",1.7f).run{
           this.height = 1.9f
           this.passport = "D98021"

           "María es muy alta"
        }

        var marta = Person("Marta","Df3451",1.7f).run{
            this.height = 1.5f
            this.passport = "S12341"

            "Marta no es muy alta"
        }

        var pais:String? = "Rusia"
        pais = pais?.uppercase() ?: "Desconocido"
        println(pais)

        var ciudad : String? = null
        ciudad = ciudad?.uppercase() ?: "Desconocida"
        println(ciudad)

        var residente: Boolean

        println(jota.alive)

        /*
        var pikachu:Pokemon = Pokemon()
        println(pikachu.getName())
        println(pikachu.getAttackPower())
        pikachu.setLife(30f)
        println(pikachu.getLife())
       */

        var ani = SubClasses.Anidada()
        println(ani.presentar())

        var inn = SubClasses().Interna()
        println(inn.presentar())

        var anidada = aliasObjeto()
        println(anidada.presentar())

        var saludos:aliasDato= mutableMapOf()
        saludos[0] = arrayListOf("Hola","Adiós")
        saludos[1] = arrayListOf("Hi","Bye")

        for((id,palabras) in saludos)
            println("$id, $palabras")

        val calle : String by lazy {"Nueva"}

        var direccion = "$pais - $ciudad - $calle"
        println(direccion)

        var pele :Athlete = Athlete("Pelé","C813465","Futbol")

        println(pele.alive)
        println(pele.name)
        println(pele.passport)
        println(pele.sport)

        pele.die()
        println(pele.alive)

        println(fernanda.saludo())
        fernanda.apodo = "SuperFer"
        println(fernanda.saludo())

        var sol: star = star("Sol",696340f,"vía lactea")
        println(sol)

        var (name_star2,radius_star2,galaxy2) = star("Sol2",68759f,"Vía Láctea")
        println("Datos Star2 Desestructurados $name_star2, $radius_star2, $galaxy2")

        var (name_star3,radius_star3) = star("Sol3",68759f,"Vía Láctea")
        println("Datos Star3 Desestructurados $name_star3, $radius_star3")

        var (name_star4,_,galaxy4) = star("Sol4",62323f,"Vía Láctea")
        println("Datos Star4 Desestructurados $name_star4, $galaxy4")

        var componente = star("Sol5",320940f,"Vía Láctea")
        println("Datos Star5 con Componentes: ${componente.component1()} ${componente.component2()} ${componente.component3()}")

        var betelgeuse : star = star("Betelgeuse",617100000f,"Orión")
        betelgeuse.alive = false
        println(betelgeuse.alive)

        var nueva: star = star()
        println(nueva)

        var hoy: dias = dias.LUNES
        var semana: Array<dias> = dias.values()
        for(i in semana) println(i)

        println(dias.valueOf("MIÉRCOLES"))
        println(hoy.name)
        println(hoy.ordinal)

        println(hoy.saludo())
        println(hoy.laboral)
        println(hoy.jornada)

        hoy = dias.DOMINGO

        /*
        *Null Pointer Exception
        *Arithmetic Exception
        * Security Exception
        *ArrayIndexOutOfBoundException
        */


        var res1 = value_try(10,2)
        println(res1)
        var res2 = value_try(10,0)
        println(res2)

        var password:String = "1234"
        if (password.length < 6){
            throw IllegalPasswordException("Password muy corta")
        }
        else println("Password segura")

        try {
            println("División 5/0 = ${5 / 0}")
        }catch(e:Exception){
            println("Vamos a manejar este error")
        }finally{
            println("Pase lo que pase vamos a hacer cositas")
        }

        }

    /*
       fun createNewPokemon(v:View){
           var etName: findViewById<EditText>(R.id.etName)
           var etAttackPower = findViewById<EditText>(R.id.etAttackPower)

           pok = Pokemon()

           if(!etName.text.isNullOrEmpty() && !etAttackPower.text.toString().toFloat())
              pok.Pokemon(etName.text.toString,etAttackPower.text.toString().toFloat())

           var ivPokemon = findViewById<ImageView>(R.id.ivPokemon)
           ivPokemon.setImageResource(R.mipmap.pokemon)

           var tvPokemon = findviewById<TextView>(R.Id.tvPokemon)
           loadDataPokemon(tvPokemon, pok)
       }



       private fun loadDataPokemon(tv:TextView,p:Pokemon){
           var description: String = ""

           description += p.getName() + " ("
           description += "AP: " + p.getAttackPower().toInt()
           description += "-L: " + p.getLife().toInt() + ")"

           tv.text = description
       }
     */
}
