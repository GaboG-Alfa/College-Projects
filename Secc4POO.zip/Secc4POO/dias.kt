package com.example.poo

enum class dias (val laboral:Boolean, val jornada:Int) {
    LUNES(true,8),MARTES(true,8),MIÉRCOLES(true,5),JUEVES(true,8),VIERNES(true,4),SÁBADO(false,0),DOMINGO(false,0);

    fun saludo():String{
        when(this){
            LUNES -> return "empezando con alegría!!"
            MARTES -> return "ya queda menos!!"
            MIÉRCOLES -> return "sabías que los miércoles son los días más productivos?"
            JUEVES -> return "esta noche es jueves!"
            VIERNES -> return "hoy es viernes y el cuerpo lo sabe!"
            else -> return "a quemar el findeee!"
        }
    }
}