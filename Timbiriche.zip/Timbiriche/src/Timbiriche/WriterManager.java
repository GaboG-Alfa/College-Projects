package Timbiriche;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.File;
import java.io.IOException;

/**
 * WriterManager class, this class is the manager of the write the file
 * structuring this.
 * 
 * @author Diego Alfaro
 * @author Nicole Garcia
 * @author Gabriel Guzman
 * @version 1 December 2020
 */

public class WriterManager {

	// Define attributes
	private BufferedWriter writer;

	/**
	 * Open a target file to start the edition
	 * 
	 * @param fileName a name of the file to open
	 * @throws IOException throws a exception when no found file
	 */
	public void open(String fileName) throws IOException {
		new File(fileName).delete();
		writer = new BufferedWriter(new FileWriter(fileName));
	}

	/**
	 * This method write the file structuring the data of the players
	 * 
	 * @param playerList playerlist with players data
	 * @throws IOException throws an exception when have an unknow error
	 */
	public void write(PlayerList playerList) throws IOException {
		writer.write(playerList.toFileString() + "\n");
	}

	/**
	 * Close a target file to end the edition
	 * 
	 * @throws IOException If there is a problem in the closed it returns an
	 *                     exception
	 */
	public void close() throws IOException {
		writer.close();
	}
}
