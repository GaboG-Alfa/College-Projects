package Timbiriche;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

/**
 * ReaderManager class, this class is the manager of the read program the file.
 * 
 * @author Diego Alfaro
 * @author Nicole Garcia
 * @author Gabriel Guzman
 * @version 1 December 2020
 */
public class ReaderManager {

	// Define attributes
	private BufferedReader reader;

	/**
	 * open a target file to start the edition
	 * 
	 * @param fileName a name of the file to open
	 * @throws FileNotFoundException throws a exception when no found file
	 */
	public void open(String fileName) throws FileNotFoundException {
		reader = new BufferedReader(new FileReader(fileName));
	}

	/**
	 * This method reads the file understanding the structure in it
	 * 
	 * @throws IOException throws an exception when have an unknow error
	 */
	public Player[] read() throws IOException {
		String line = reader.readLine();
		Player playerList[];
		String data[];
		String playerData[];
		if (line != null) {// when have no records return "null"
			data = line.split("-");// The file.TXT for understand the dash "-"
			playerList = new Player[data.length];
			for (int i = 0; i < data.length; i++) {
				playerData = data[i].split("_");
				playerList[i] = new Player();
				playerList[i].setId(playerData[0]);
				playerList[i].setName(playerData[1]);
				playerList[i].setGameIdentifier(playerData[2].charAt(0));
				playerList[i].addPoints(Double.parseDouble(playerData[3]));
			}
		} else {
			return null;
		}
		return playerList;
	}

	/**
	 * Close a target file to end the edition
	 * 
	 * @throws IOException If there is a problem in the closed it returns an
	 *                     exception
	 */
	public void close() throws IOException {
		reader.close();
	}

}
