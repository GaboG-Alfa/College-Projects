package Timbiriche;

/**
 * Border class, stores information about a border of a Square
 * 
 * @author Diego Alfaro
 * @author Nicole Garcia
 * @author Gabriel Guzman
 * @version 1 December 2020
 */

public class Border extends Shape {

	/**
	 * Define Marked border
	 * 
	 * @param isMarked is a boolean state
	 */
	public Border(boolean isMarked) {
		super(isMarked);
	}

	@Override
	public String toString() {
		return "Borde: esta marcado: " + super.getIsMarked();
	}

}
