package Timbiriche;

/**
 * Game class that starts the game
 * 
 * @author Diego Alfaro
 * @author Nicole Garcia
 * @author Gabriel Guzman
 * @version 1 December 2020
 */

public class Game {

	// Define attributes
	private int noMarkedSquares;
	private PlayerList playerList;
	private Board board;
	private GameHelper gameHelper;
	private Player currentPlayerOne;
	private Player currentPlayerTwo;
	private ReaderManager reader;
	private WriterManager writer;

	/**
	 * Constructor without parameters
	 */
	public Game() {
		playerList = new PlayerList();
		gameHelper = new GameHelper();
		reader = new ReaderManager();
		writer = new WriterManager();
	}

	/**
	 * Execute all logic forDevelops the game
	 */
	public void startGame() {
		try {
			reader.open("PlayerList.txt");
			playerList.setPlayerList(reader.read());
			reader.close();
		} catch (Exception e) {

		}
		// Welcome: the program begins with a window that show a welcome
		// of the game, the authors names and Input options.
		gameHelper.initialMessage();

		char mainMenu;
		do {
			mainMenu = gameHelper.showMenu("\nInicio:\n a) Jugar\n b) Ver Puntaje de los jugadores\n c) Salir\n", 'a',
					'b', 'c');
			switch (mainMenu) {
			case 'a':
				byte rowsSize = IO.requestByteWithLimit("\nValores: min 2, max 10 \nIngrese el tamano de las filas: ",
						2, 10);
				IO.printFiftySpaces();
				byte colsSize = IO
						.requestByteWithLimit("\nValores: min 2, max 10 \nIngrese el tamano de las columnas: ", 2, 10);
				IO.printFiftySpaces();

				// Operation for created the board
				noMarkedSquares = rowsSize * colsSize;
				board = new Board(rowsSize, colsSize);

				// Request for menu the game mode
				char mode = gameHelper.showMenu(
						"Elija el modo del videojuego:\n a) Dos jugadores\n b) contra Computadora\n c) Salir al menu principal",
						'a', 'b', 'c');
				IO.printFiftySpaces();

				// Switch for menu the game mode
				switch (mode) {
				case 'a':
					// Select the players
					IO.showMessage("Seleccione la informacion del primer jugador");
					currentPlayerOne = gameHelper.selectNewPlayerOrExisting(playerList);
					IO.printFiftySpaces();
					IO.showMessage("Seleccione la informacion del segundo jugador");
					currentPlayerTwo = gameHelper.selectNewPlayerOrExisting(playerList);
					IO.printFiftySpaces();
					play(mode);
					gameHelper.endGameMessage(board, currentPlayerOne, currentPlayerTwo);
					playerList.insertion(currentPlayerOne);
					playerList.insertion(currentPlayerTwo);
					break;
				case 'b':
					// Select the player one
					currentPlayerOne = gameHelper.selectNewPlayerOrExisting(playerList);
					currentPlayerTwo = new Player("0", "la consola", 'C');

					// Choose the difficulty of game1
					char modeDifficulty = ' ';
					modeDifficulty = gameHelper.showMenu(
							"\nElija la modalidad del juego: \na) Facil, b) Medio, c) Dificil \n", 'a', 'b', 'c');

					IO.printFiftySpaces();
					// Start the game
					play(mode, modeDifficulty);
					IO.wait(3500);
					gameHelper.endGameMessage(board, currentPlayerOne, currentPlayerTwo);
					playerList.insertion(currentPlayerOne);

					break;
				case 'c':
					break;
				}
				break;
			case 'b':
				// Show player score if the list is not empty
				if (!playerList.isEmpty()) {
					IO.showMessage("\nPuntaje de los jugadores:\n" + playerList.printPlayerList() + "\n");
					IO.wait(3500);
				} else {
					IO.showMessage("\nNo hay Jugadores registrados\n");
					IO.wait(2500);
				}
				break;
			case 'c':
				// End the game
				try {
					writer.open("PlayerList.txt");
					writer.write(playerList);
					writer.close();
				} catch (Exception e) {

				}
				IO.showMessage("Gracias por jugar!");
				break;
			}
		} while (mainMenu != 'c');
	}

	private void play(char mode) {
		play(mode, ' ');
	}

	/**
	 * Method that Develops the mode(PvP and PvM)in case of PvM the difficult easy,
	 * medium, hard
	 * 
	 * @param mode       Player vs Player and Player vs Machine
	 * @param difficulty a to easy, b to medium, c to hard
	 */
	private void play(char mode, char difficulty) {

		// Define in a random way the order of players
		int i = (int) (Math.random() * 2) + 1;

		// While squaresNoMarked
		while (noMarkedSquares > 0) {
			if (i % 2 != 0) {
				// Turn player 1
				IO.showBoardBeforeTurn(board, currentPlayerOne);
				SquareUbication temp = gameHelper.requestSquareUbication(board, currentPlayerOne);
				byte whichBorder = gameHelper.requestWhichBorder(board, temp.getRow(), temp.getCol());

				// Complete squares
				switch (board.markBorder(temp.getRow(), temp.getCol(), whichBorder,
						currentPlayerOne.getGameIdentifier())) {
				case 1:
					i++;
					break;
				case 2:
					noMarkedSquares -= 1;
					break;
				case 3:
					noMarkedSquares -= 2;
					break;
				}
				IO.printFiftySpaces();
				IO.showBoardAfterTurn(board, currentPlayerOne);
				IO.wait(3500);
				IO.printFiftySpaces();

			} else if (i % 2 == 0) {
				byte rowOfSquare = -1;
				byte colOfSquare = -1;
				byte whichBorder = -1;

				// Develops player vs player
				if (mode == 'a') {
					// turn player 2
					IO.showBoardBeforeTurn(board, currentPlayerTwo);
					SquareUbication temp = gameHelper.requestSquareUbication(board, currentPlayerOne);
					rowOfSquare = temp.getRow();
					colOfSquare = temp.getCol();
					whichBorder = gameHelper.requestWhichBorder(board, rowOfSquare, colOfSquare);

					IO.printFiftySpaces();

					// Develops player vs machine
				} else if (mode == 'b') {

					// Develops easy mode
					if (difficulty == 'a') {

						SquareUbication temp = gameHelper.getSquareUbicationToEasyMode(board);
						rowOfSquare = temp.getRow();
						colOfSquare = temp.getCol();
						whichBorder = gameHelper.getRandomBorderToEasyMode(board, rowOfSquare, colOfSquare);
					}

					// Develops medium mode
					if (difficulty == 'b') {
						SquareUbication temp = gameHelper.getSquareUbicationToMediumMode(board, noMarkedSquares);
						rowOfSquare = temp.getRow();
						colOfSquare = temp.getCol();
						int cont = 0;
						whichBorder = gameHelper.getRandomBorderToMediumMode(board, rowOfSquare, colOfSquare, cont);
					}

					// Hard mode
					if (difficulty == 'c') {
						boolean found = false;
						// Valid if a square have 3 borders marked for mark and win the square
						for (byte row = 0; row < board.getRowsSize(); row++) {
							for (byte col = 0; col < board.getColsSize(); col++) {
								if (board.howManyBordersHaveMarkedThisSquare(row, col) == 3) {
									for (int j = 1; j <= 4; j++) {
										if (board.isMarkableBorder(row, col, (byte) j)) {
											rowOfSquare = row;
											colOfSquare = col;
											whichBorder = (byte) j;
											found = true;
											break;
										}
									}
								}

								if (found) {
									break;
								}
							}
							if (found) {
								break;
							}
						}

						// If the square doesn´t have 3 borders marked , the difficult is less and
						// change to medium
						if (!found) {
							SquareUbication temp = gameHelper.getSquareUbicationToMediumMode(board, noMarkedSquares);
							rowOfSquare = temp.getRow();
							colOfSquare = temp.getCol();
							int cont = 0;
							whichBorder = gameHelper.getRandomBorderToMediumMode(board, rowOfSquare, colOfSquare, cont);
						}
					}
				}

				// Complete squares
				switch (board.markBorder(rowOfSquare, colOfSquare, whichBorder, currentPlayerTwo.getGameIdentifier())) {
				case 1:
					i++;
					break;
				case 2:
					noMarkedSquares -= 1;
					break;
				case 3:
					noMarkedSquares -= 2;
					break;
				}
				IO.printFiftySpaces();
				IO.showBoardAfterTurn(board, currentPlayerTwo);
				IO.wait(3500);
				IO.printFiftySpaces();
			}
		}
	}
}
