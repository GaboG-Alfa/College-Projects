package Timbiriche;

/**
 * TestTimbiriche class proof the game
 * 
 * @author Diego Alfaro
 * @author Nicole Garcia
 * @author Gabriel Guzman
 * @version 1 December 2020
 */

public class TestTimbiriche {
	/**
	 * Main controls the program
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		// Create instance
		Game gameObject = new Game();
		gameObject.startGame();
	}
}
