package Timbiriche;

/**
 * SquareUbication class store a location of a square
 * 
 * @author Diego Alfaro
 * @author Nicole Garcia
 * @author Gabriel Guzman
 * @version 1 December 2020
 */

public class SquareUbication {

	// Define attributes
	private byte row;
	private byte col;

	/**
	 * Set a row and col in the square
	 * 
	 * @param row
	 * @param col
	 */
	public SquareUbication(byte row, byte col) {
		this.row = row;
		this.col = col;
	}

	/**
	 * @return the col
	 */
	public byte getCol() {
		return col;
	}

	/**
	 * @return the row
	 */
	public byte getRow() {
		return row;
	}
}