Diego Alfaro Gonzáles  Carné: C00191
Nicole García Luna     Carné: C03170
Gabriel Guzmán Alfaro  Carné: C03657