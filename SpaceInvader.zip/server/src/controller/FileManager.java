package controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

/**
 *
 * @author DIEGO ALFARO GONZÁLES
 * @author NICOLE GARCÍA LUNA
 * @author GABRIEL GUZMÁN ALFARO
 * @version 11/07/2021
 */
public class FileManager {

    private File file;
    private ObjectOutputStream bwOutput;
    private ObjectInputStream bwInput;

    /**
     * Constructor
     */
    public FileManager(String path) {
        this.openOrCreateFile(path);
    }

    /**
     * Define the path of the file in which we are going to work, and create it if not
     * exists
     * @param path 
     */
    private void openOrCreateFile(String path) {
        try {
            file = new File(path);

            if (!file.exists()) {
                file.createNewFile();
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    /**
      * This method is in charge of writing our object in our file
      *
      * @param message User serializable instance
      */
    public void writeObject(Object object) {

        try {
            bwOutput = new ObjectOutputStream(new FileOutputStream(this.file));
            bwOutput.flush();
            if (bwOutput != null) {
                bwOutput.writeObject(object);
                bwOutput.close();
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    /**
     * Function to read object of properties file
     * @return Returns the message read in our file
     * @throws IOException
     * @throws ClassNotFoundException
     */
    public Object readObject() {
        try {
            bwInput = new ObjectInputStream(new FileInputStream(this.file));
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
        Object object = null;

        if (bwInput != null) {
            try {
                object = bwInput.readObject();
                bwInput.close();
            } catch (ClassNotFoundException | IOException e) {
                System.out.println(e.getMessage());
            }
            return object;
        }
        return null;
    }

}
