package controller;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * This program accepts single player. The server listens on port 5777.
 * @author DIEGO ALFARO GONZÁLES
 * @author NICOLE GARCÍA LUNA
 * @author GABRIEL GUZMÁN ALFARO
 * @version 11/07/2021
 */
public class ServerSocketThread {

    // Atributtes
    private ServerSocket server;
    private Socket conection;
    private ObjectInputStream in;
    private ObjectOutputStream out;

    /**
     * Constructor
     *
     * @param port listens on port 5777
     */
    public ServerSocketThread(String port) {
        try {
            server = new ServerSocket(Integer.parseInt(port));
        } catch (Exception e) {
            System.out.println(e.getMessage() + "\n\n\n" + e);
        }
    }

    /**
     * Method to accept the Connection
     */
    public void acceptConection() {
        try {
            conection = server.accept();
        } catch (Exception e) {
            System.out.println(e.getMessage() + "\n\n\n" + e);
        }
    }

    /**
     * Method to open the streams
     */
    public void openStreams() {
        try {
            in = new ObjectInputStream(conection.getInputStream());
            out = new ObjectOutputStream(conection.getOutputStream());
            out.flush();
        } catch (Exception e) {
            System.out.println(e.getMessage() + "\n\n\n" + e);
        }
    }

    /**
     * Method to close the streams
     */
    public void closeStreams() {
        try {
            in.close();
            out.close();
            conection.close();
            out.flush();
        } catch (Exception e) {
            System.err.println(e);
        }
    }

    /**
     * Method to receive data
     *
     * @return the received data
     */
    public Object receiveData() {

        Object object = null;

        try {
            object = (Object) in.readObject();
        } catch (Exception e) {
            // System.out.println(e);
            System.exit(0);
        }
        return object;
    }

    /**
     * Method to send the data
     *
     * @param object . Data to send
     */
    public void sendData(Object object) {
        try {
            out.writeObject(object);
        } catch (Exception e) {
            System.out.println(e.getMessage() + "\n\n\n" + e);
        }
    }

}
