package model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * This class contains as an attribute an ArrayList where the players are stored
 * 

 * @author DIEGO ALFARO GONZALES
 * @author NICOLE GARCIA LUNA
 * @author GABRIEL GUZMAN ALFARO
 * @version 11/07/2021
 */
public class UsersList implements Serializable {

    // Atribute
    private List<User> userList;

    // Constructor
    public UsersList() {
        userList = new ArrayList<User>();
    }

    /**
     * Constructor
     * 
     * @param userList
     */
    public UsersList(ArrayList<User> userList) {
        this.userList = userList;
    }

    /**
     * Method to add the user in the userList
     * 
     * @param user
     */
    public void add(User user) {
        userList.add(user);
    }

    /**
     * Method to search for a user in the userList
     * 
     * @param user to search
     * @return returns the user found or null if not found
     */
    public User search(User user) {
        Collections.sort(userList);
        int index = Collections.binarySearch(userList, user);
        return index >= 0 ? userList.get(index) : null;
    }

    /**
     * Method to update a user within the userList
     * 
     * @param user
     */
    public void update(User user) {
        userList.set(userList.indexOf(search(user)), user);
        Collections.sort(userList);
    }

    /**
     * Method to get ArrayList Sorted By Score
     * 
     * @return Hash Map Sorted By Score
     */
    public List<User> getArrayListSortedByScore() {
        userList.sort(new Comparator<User>() {
            @Override
            public int compare(User user, User other) {
                return -1 * ((Integer) user.getLastScore()).compareTo(other.getLastScore());
            }
        });
        List<User> temp = new ArrayList<User>();

        for (User user : userList) {
            if (userList.indexOf(user) >= 10) {
                break;
            }
            temp.add(new User(user.getUserName(), user.getLastScore()));
        }
        Collections.sort(userList);

        return temp;
    }

}
