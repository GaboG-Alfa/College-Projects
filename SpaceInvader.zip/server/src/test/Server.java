package test;

import java.util.ArrayList;

import controller.FileManager;
import model.User;
import model.UsersList;
import model.serverComunication.Request;
import model.specs.Enemies;
import model.specs.Explosion;
import model.specs.ExtraEnemy;
import model.specs.GameContext;
import model.specs.Shot;
import model.specs.Universe;
import controller.ServerSocketThread;

/**
 * Class that contains data of file and user list with a default user
 * @author DIEGO ALFARO GONZALES
 * @author NICOLE GARCIA LUNA
 * @author GABRIEL GUZMAN ALFARO
 * @version 11/07/2021
 */
public class Server {

    /**
     * Method with the server socket
     * @param args 
     */
    public static void main(String... args) {

        ServerSocketThread server = new ServerSocketThread("5777");
        System.out.println("Server: listening");
        server.acceptConection();
        server.openStreams();
        FileManager fileManager = new FileManager("Properties.src");
        UsersList usersList = null;
        Object response = null;
        Request request = null;
        User currectUser = null;
        // A FileManager object is created and the file "Properties.src" is opened or
        // created

        // the information that is inside the file is read
        usersList = (UsersList) fileManager.readObject();
        while (true) {
            User temp = null;
            if (usersList == null) {
                usersList = new UsersList();
            }

            // the information of the request sent by the client is received
            request = (Request) server.receiveData();

            if (request == null) {
                continue;
            }

            /**
            * If the player logs in, it checks if the username
            * and password are correct. If the player wants to register, check that the
            * username they entered does not currently exist in the list of players there
            * are.
            *
            *  request object that contains the user information (username, password)
            *                and the type of request that is (login or log up).
            * returns the response according to the given request.
            */
            response = null;
            switch (request.getType()) {

            case LOG_IN:
                // Search for the username entered in the list of players that already exist
                temp = usersList.search(new User(((User) request.getData()).getUserName()));

                /**
                 * if the username exists in the player list, then the password is checked to be
                 * the same as that of the found user. If the entered password is the same as
                 * the user's password, the session is successful.
                 */
                if (temp != null && temp.getPassword().equals(((User) request.getData()).getPassword())) {
                    response = "Loged in";
                    currectUser = new User(temp);
                    currectUser.setInGameScore(0);
                } else {
                    // si el nombre de usuario o la constraseña son incorrectos
                    response = "Loged fail, user or pass";
                }
                temp = null;
                break;
            case LOG_UP:
                temp = null;
                // Search for the username entered in the list of players that already exist
                temp = usersList.search(new User(((User) request.getData()).getUserName()));

                // if username already exists then it cannot be registered
                if (temp != null) {
                    response = "Log up fail, the user exist";
                    break;
                }

                // if the username does not exist then the player is added to the player list
                // with their respective information
                usersList.add(
                        new User(((User) request.getData()).getUserName(), ((User) request.getData()).getPassword()));
                fileManager.writeObject(usersList);
                response = "Successfully registered";
                temp = null;
                break;
            case GAME_SPECIFICATIONS:
                ArrayList<String> enemiesImagesPath = new ArrayList<String>();
                enemiesImagesPath.add("/image/Enemy0.png");
                enemiesImagesPath.add("/image/Enemy1.png");
                enemiesImagesPath.add("/image/Enemy2.png");

                ArrayList<Integer> enemiesScore = new ArrayList<Integer>();
                enemiesScore.add(40);
                enemiesScore.add(20);
                enemiesScore.add(10);

                ArrayList<String> universeImagesPath = new ArrayList<String>();
                universeImagesPath.add("/image/star.png");
                universeImagesPath.add("/image/star1.png");
                universeImagesPath.add("/image/star2.png");
                universeImagesPath.add("/image/star3.png");
                universeImagesPath.add("/image/star4.png");
                universeImagesPath.add("/image/star5.png");
                int commonElementSize = 48;
                response = new GameContext(
                        //explosion specs
                        new Explosion(commonElementSize, 3, 3, 30, "/image/Exploding.png"),
                        //player specs
                        new model.specs.Player(//
                        commonElementSize, new Shot(10, -10, "80DEEA"), 10, 1, //
                                "/image/Player.png", //
                                150),
                        //enemies specs
                        new Enemies(//
                                10, 75, enemiesImagesPath, commonElementSize, 1, 10, //
                                new Shot(10, 10, "FFEBEE"), 1, 3, 10, //
                                enemiesScore, 500, 2500),
                        //extra enemy specs
                        new ExtraEnemy(//
                                500, 2000, commonElementSize, 25, 10, new Shot(10, 10, "E1BEE7"), //
                                "/image/Enemy3.png", 3, 80, 150), //
                        new Universe(universeImagesPath, 2), "212121");
                break;

            case POST_USERSCORE:
                currectUser.setInGameScore(currectUser.getInGameScore() + (Integer) request.getData());
                break;
            case GET_USERSCORE:
                response = currectUser.getInGameScore();
                break;

            case GET_BESTSSCORES:
                response = (ArrayList<User>) usersList.getArrayListSortedByScore();
                break;

            case POST_SCOREWIN:
                if (currectUser.getLastScore() < (int) request.getData()) {
                    currectUser.setLastScore((int) request.getData());
                }
                currectUser.setInGameScore(0);
                usersList.update(currectUser);
                fileManager.writeObject(usersList);
                break;

            case CLOSE_SERVER:
                response = "serverClose";
                break;

            default:
                response = "Request not valid";
                break;
            }

            // the response is sent to the client
            if (response != null && response.getClass().getName() == "String") {
                if (response.equals("serverClose")) {
                    break;
                }
            }
            if (response != null) {
                server.sendData(response);
            }
            response = null;
        }

        // write the object in the file "Properties.src"
        fileManager.writeObject(usersList);
        server.closeStreams();
    }
}
