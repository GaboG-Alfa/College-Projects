<----------------------------------------------->
Team integrants
    DIEGO ALFARO GONZALES   C00191
    NICOLE GARCIA LUNA      C03170
    GABRIEL GUZMAN ALFARO   C03657

<----------------------------------------------------------------------------------------------->

To run this program in netbeans

step #1.
    open project netbeans client
    open project netbeans client
step #2.
    at project client include the javafx-sdk-16 libraries
    in Run:Module path and Complile: Class path

    and add the virtual machine options
        --module-path <path of javafx-sdk-16/lib> --add-modules=javafx.controls,javafx.fxml
    for example in Mac
    --module-path  /Users/Diego/Downloads/javafx-sdk-16/lib --add-modules=javafx.controls,javafx.fxml
    or Windows
    --module-path  c:\\Users\\NicoleGarcíaLuna\\Downloads\\javafx-sdk-16\\lib --add-modules=javafx.controls,javafx.fxml

step#3
    run a server project it will complile and run Server.java
    
    when Server is listening

    run a client project it will complile and run ClientGUI.java

<----------------------------------------------------------------------------------------------->

