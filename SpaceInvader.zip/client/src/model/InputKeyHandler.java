package model;

import javafx.event.EventHandler;
import javafx.scene.input.KeyEvent;

/**
 *
 * @author DIEGO ALFARO GONZÁLES
 * @author NICOLE GARCÍA LUNA
 * @author GABRIEL GUZMÁN ALFARO
 * @version 11/07/2021
 */
public class InputKeyHandler {
    
    //Atributes
    private int axisX;
    private boolean shot;
    private KeyReleased keyReleased;
    private KeyPressed keyPressed;

    /**
     * Function is manage the events of SpaceShip controlls when keys are released 
     */
    class KeyReleased implements EventHandler<KeyEvent> {
        @Override
        public void handle(KeyEvent e) {
            switch (e.getCode()) {
            case LEFT:
                axisX = 0;
                break;

            case RIGHT:
                axisX = 0;
                break;

            case SPACE:
                shot = false;
                break;
            default:
                break;
            }

        }

    }

    /**
     * Function is manage the events of SpaceShip controlls when keys are pushed 
     */
    class KeyPressed implements EventHandler<KeyEvent> {
        @Override
        public void handle(KeyEvent e) {
            switch (e.getCode()) {
            case LEFT:
                axisX = -1;
                break;

            case RIGHT:
                axisX = 1;
                break;
            case SPACE:
                shot = true;
                break;

            default:
                break;
            }

        }

    }

    /**
     * Function is input key events 
     */
    public InputKeyHandler() {
        shot = false;
        axisX = 0;
        keyPressed = new KeyPressed();
        keyReleased = new KeyReleased();
    }

    /**
     * @return the axisX
     */
    public int getAxisX() {
        return axisX;
    }

    /**
     * @param axisX the axisX to set
     */
    public void setAxisX(int axisX) {
        this.axisX = axisX;
    }

    /**
     * @return the shot
     */
    public boolean getShot() {
        return shot;
    }

    /**
     * @return the keyReleased
     */
    public KeyReleased getKeyReleased() {
        return keyReleased;
    }

    /**
     * @return the keyPressed
     */
    public KeyPressed getKeyPressed() {
        return keyPressed;
    }

}
