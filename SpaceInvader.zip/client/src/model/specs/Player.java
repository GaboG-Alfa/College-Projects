package model.specs;

import java.io.Serializable;

/**
 *
 * @author DIEGO ALFARO GONZÁLES
 * @author NICOLE GARCÍA LUNA
 * @author GABRIEL GUZMÁN ALFARO
 * @version 11/07/2021
 */
public class Player implements Serializable {
    private int size;
    private Shot shot;
    private int speed;
    private int maxBulletsInScreen;
    private String imagePath; ///image/Ship.png
    private int spawningSteps;

    /**
     * @param size
     * @param shot
     * @param speed
     * @param maxBulletsInScreen
     */
    public Player(int size, Shot shot, int speed, int maxBulletsInScreen, String imagePath, int spawningSteps) {
        this.size = size;
        this.shot = shot;
        this.speed = speed;
        this.maxBulletsInScreen = maxBulletsInScreen;
        this.imagePath = imagePath;
        this.spawningSteps = spawningSteps;
    }

    /**
     * @return the size
     */
    public int getSize() {
        return size;
    }

    /**
     * @return the shot
     */
    public Shot getShot() {
        return shot;
    }

    /**
     * @return the speed
     */
    public int getSpeed() {
        return speed;
    }

    /**
     * @return the maxBulletsInScreen
     */
    public int getMaxBulletsInScreen() {
        return maxBulletsInScreen;
    }

    /**
     * @return the imagePath
     */
    public String getImagePath() {
        return imagePath;
    }

    /**
     * @return the spawningSteps
     */
    public int getSpawningSteps() {
        return spawningSteps;
    }

}
