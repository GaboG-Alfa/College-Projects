package model.specs;

import java.io.Serializable;
import java.util.List;

/**
 *
 * @author DIEGO ALFARO GONZÁLES
 * @author NICOLE GARCÍA LUNA
 * @author GABRIEL GUZMÁN ALFARO
 * @version 11/07/2021
 */
public class Universe implements Serializable {
    private List<String> imagePaths;
    private int speed;

    /**
     * @param imagePaths
     * @param speed
     */
    public Universe(List<String> imagePaths, int speed) {
        this.imagePaths = imagePaths;
        this.speed = speed;
    }

    /**
     * @return the imagePaths
     */
    public List<String> getImagePaths() {
        return imagePaths;
    }

    /**
     * @return the speed
     */
    public int getSpeed() {
        return speed;
    }

}
