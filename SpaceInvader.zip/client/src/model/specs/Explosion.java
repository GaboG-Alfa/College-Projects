package model.specs;

import java.io.Serializable;


/**
 *
 * @author DIEGO ALFARO GONZÁLES
 * @author NICOLE GARCÍA LUNA
 * @author GABRIEL GUZMÁN ALFARO
 * @version 11/07/2021
 */

public class Explosion implements Serializable {

    //Attributes
    private int size;
    private int rows;
    private int cols;
    private int steps;
    private String imagepath;

    /**
     * @param size
     * @param rows
     * @param cols
     * @param steps
     */

    public Explosion(int size, int rows, int cols, int steps, String imagepath) {
        this.size = size;
        this.rows = rows;
        this.cols = cols;
        this.steps = steps;
        this.imagepath = imagepath;
    }

    /**
     * @return the size
     */
    public int getSize() {
        return size;
    }

    /**
     * @return the rows
     */
    public int getRows() {
        return rows;
    }

    /**
     * @return the cols
     */
    public int getCols() {
        return cols;
    }

    /**
     * @return the steps
     */
    public int getSteps() {
        return steps;
    }

    /**
     * @return the imagepath
     */
    public String getImagepath() {
        return imagepath;
    }

}
