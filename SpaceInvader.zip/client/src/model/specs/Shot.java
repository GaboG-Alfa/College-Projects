package model.specs;

import java.io.Serializable;

/**
 *
 * @author DIEGO ALFARO GONZÁLES
 * @author NICOLE GARCÍA LUNA
 * @author GABRIEL GUZMÁN ALFARO
 * @version 11/07/2021
 */
public class Shot implements Serializable {
    
    //Attributes
    private int size; // 25
    private int speed; // 25
    private String colorHex; // 

    /**
     * @param size
     * @param speed
     * @param colorHex
     */
    public Shot(int size, int speed, String colorHex) {
        this.size = size;
        this.speed = speed;
        this.colorHex = colorHex;
    }

    /**
     * @return the colorHex
     */
    public String getColorHex() {
        return colorHex;
    }

    /**
     * @return the size
     */
    public int getSize() {
        return size;
    }

    /**
     * @return the speed
     */
    public int getSpeed() {
        return speed;
    }
}
