package model.specs;

import java.io.Serializable;
import java.util.List;
/**
 *
 * @author DIEGO ALFARO GONZÁLES
 * @author NICOLE GARCÍA LUNA
 * @author GABRIEL GUZMÁN ALFARO
 * @version 11/07/2021
 */
public class Enemies implements Serializable {
    
    //Atributtes
    private int minTimeBetweenShots_milis;//500
    private int maxTimeBetweenShots_milis;//2500
    private int gapBetweenEnemies_px;//= 10
    private int gapBetweenEnemiesAndTop_px;// = 75
    private List<String> imagesPaths;//=/image/Ship.png
    private int size;//48
    private int speedX;//=1
    private int speedY;//=5
    private Shot shot;
    private int maxBulletsOnScreen;//=1
    private int enemyRows;//=3
    private int enemyPerRow;//10
    private List<Integer> enemiesScores;//=/image/Ship.png

    /**
     * @return the size
     */
    public int getSize() {
        return size;
    }

    /**
     * @param gapBetweenEnemies_px
     * @param gapBetweenEnemiesAndTop_px
     * @param imagesPaths
     * @param size
     * @param speedX
     * @param speedY
     * @param shot
     * @param maxShotsOnScreen
     * @param enemyRows
     * @param enemyPerRow
     * @param enemiesScores
     */
    public Enemies(//
            int gapBetweenEnemies_px, int gapBetweenEnemiesAndTop_px, //
            List<String> imagesPaths, int size, int speedX, int speedY, //
            Shot shot, int maxBulletsOnScreen, int enemyRows, //
            int enemyPerRow, List<Integer> enemiesScores, //
            int minTimeBetweenShots_milis, int maxTimeBetweenShots_milis//
    ) {
        this.gapBetweenEnemies_px = gapBetweenEnemies_px;
        this.gapBetweenEnemiesAndTop_px = gapBetweenEnemiesAndTop_px;
        this.imagesPaths = imagesPaths;
        this.size = size;
        this.speedX = speedX;
        this.speedY = speedY;
        this.shot = shot;
        this.maxBulletsOnScreen = maxBulletsOnScreen;
        this.enemyRows = enemyRows;
        this.enemyPerRow = enemyPerRow;
        this.enemiesScores = enemiesScores;
        this.minTimeBetweenShots_milis = minTimeBetweenShots_milis;
        this.maxTimeBetweenShots_milis = maxTimeBetweenShots_milis;
    }

    /**
     * @return the gapBetweenEnemies_px
     */
    public int getGapBetweenEnemies_px() {
        return gapBetweenEnemies_px;
    }

    /**
     * @return the gapBetweenEnemiesAndTop_px
     */
    public int getGapBetweenEnemiesAndTop_px() {
        return gapBetweenEnemiesAndTop_px;
    }

    /**
     * @return the imagesPaths
     */
    public List<String> getImagesPaths() {
        return imagesPaths;
    }

    /**
     * @return the speedX
     */
    public int getSpeedX() {
        return speedX;
    }

    /**
     * @return the speedY
     */
    public int getSpeedY() {
        return speedY;
    }

    /**
     * @return the shot
     */
    public Shot getShot() {
        return shot;
    }

    /**
     * @return the maxShotsOnScreen
     */
    public int getMaxBulletsOnScreen() {
        return maxBulletsOnScreen;
    }

    /**
     * @return the enemyRows
     */
    public int getEnemyRows() {
        return enemyRows;
    }

    /**
     * @return the enemyPerRow
     */
    public int getEnemyPerRow() {
        return enemyPerRow;
    }

    /**
     * @return the enemiesScores
     */
    public List<Integer> getEnemiesScores() {
        return enemiesScores;
    }

    /**
     * @return the maxTimeBetweenShots_milis
     */
    public int getMaxTimeBetweenShots_milis() {
        return maxTimeBetweenShots_milis;
    }

    /**
     * @return the minTimeBetweenShots_milis
     */
    public int getMinTimeBetweenShots_milis() {
        return minTimeBetweenShots_milis;
    }

}
