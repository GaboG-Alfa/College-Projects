package model.specs;

import java.io.Serializable;

/**
 *
 * @author DIEGO ALFARO GONZÁLES
 * @author NICOLE GARCÍA LUNA
 * @author GABRIEL GUZMÁN ALFARO
 * @version 11/07/2021
 */
public class GameContext implements Serializable {
    private int paneWidth;
    private int paneHeight;
    private Explosion explosion;
    private Player player;
    private Enemies enemies;
    private ExtraEnemy extraEnemy;
    private Universe universe;
    private String backGroundColor_hex;

    /**
     * @param explosion
     * @param player
     * @param enemies
     * @param extraEnemy
     * @param universe
     */
    public GameContext(//
            Explosion explosion, Player player, Enemies enemies, //
            ExtraEnemy extraEnemy, Universe universe, String backGroundColor_hex //
    ) {
        this.explosion = explosion;
        this.player = player;
        this.enemies = enemies;
        this.extraEnemy = extraEnemy;
        this.universe = universe;
        this.backGroundColor_hex = backGroundColor_hex;
    }

    /**
     * Constructor
     */
    public GameContext() {

    }

    /**
     * @return the paneWidth
     */
    public int getPaneWidth() {
        return paneWidth;
    }

    /**
     * @return the paneHeight
     */
    public int getPaneHeight() {
        return paneHeight;
    }

    /**
     * @return the explosion
     */
    public Explosion getExplosion() {
        return explosion;
    }

    /**
     * @return the player
     */
    public Player getPlayer() {
        return player;
    }

    /**
     * @return the enemies
     */
    public Enemies getEnemies() {
        return enemies;
    }

    /**
     * @return the extraEnemy
     */
    public ExtraEnemy getExtraEnemy() {
        return extraEnemy;
    }

    /**
     * @return the universe
     */
    public Universe getUniverse() {
        return universe;
    }

    /**
     * @param paneWidth the paneWidth to set
     */
    public void setPaneWidth(int paneWidth) {
        this.paneWidth = paneWidth;
    }

    /**
     * @param paneHeight the paneHeight to set
     */
    public void setPaneHeight(int paneHeight) {
        this.paneHeight = paneHeight;
    }

    /**
     * @return the backGroundColor_hex
     */
    public String getBackGroundColor_hex() {
        return backGroundColor_hex;
    }

}
