package model.specs;

import java.io.Serializable;

/**
 *
 * @author DIEGO ALFARO GONZÁLES
 * @author NICOLE GARCÍA LUNA
 * @author GABRIEL GUZMÁN ALFARO
 * @version 11/07/2021
 */
public class ExtraEnemy implements Serializable {
    private int minTimeBetweenAparicions_milis;//500
    private int maxTimeBetweenAparicions_milis;//2500
    private int size;//48
    private int yPostiton; // 25
    private int initialXPostiton; // 10
    private Shot shot; // 25 
    private String imagePath; ///image/Enemy4.png
    private int speedX; // 2
    private int minScore; // 80
    private int maxScore; // 150

    /**
     * @param minTimeBetweenAparicions_milis
     * @param maxTimeBetweenAparicions_milis
     * @param size
     * @param yPostiton
     * @param initialXPostiton
     * @param shot
     * @param imagePath
     * @param speedX
     * @param minScore
     * @param maxScore
     */
    public ExtraEnemy(//
            int minTimeBetweenAparicions_milis, int maxTimeBetweenAparicions_milis, //
            int size, int yPostiton, int initialXPostiton, Shot shot, //
            String imagePath, int speedX, int minScore, int maxScore//
    ) {
        this.minTimeBetweenAparicions_milis = minTimeBetweenAparicions_milis;
        this.maxTimeBetweenAparicions_milis = maxTimeBetweenAparicions_milis;
        this.size = size;
        this.yPostiton = yPostiton;
        this.initialXPostiton = initialXPostiton;
        this.shot = shot;
        this.imagePath = imagePath;
        this.speedX = speedX;
        this.minScore = minScore;
        this.maxScore = maxScore;
    }

    /**
     * @return the minTimeBetweenAparicions_milis
     */
    public int getMinTimeBetweenAparicions_milis() {
        return minTimeBetweenAparicions_milis;
    }

    /**
     * @return the maxTimeBetweenAparicions_milis
     */
    public int getMaxTimeBetweenAparicions_milis() {
        return maxTimeBetweenAparicions_milis;
    }

    /**
     * @return the size
     */
    public int getSize() {
        return size;
    }

    /**
     * @return the yPostiton
     */
    public int getYPostiton() {
        return yPostiton;
    }

    /**
     * @return the initialXPostiton
     */
    public int getInitialXPostiton() {
        return initialXPostiton;
    }

    /**
     * @return the shot
     */
    public Shot getShot() {
        return shot;
    }

    /**
     * @return the imagePath
     */
    public String getImagePath() {
        return imagePath;
    }

    /**
     * @return the speedX
     */
    public int getSpeedX() {
        return speedX;
    }

    /**
     * @return the minScore
     */
    public int getMinScore() {
        return minScore;
    }

    /**
     * @return the maxScore
     */
    public int getMaxScore() {
        return maxScore;
    }

}
