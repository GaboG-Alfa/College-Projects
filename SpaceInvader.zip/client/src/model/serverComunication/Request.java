package model.serverComunication;

import java.io.Serializable;

/**
 * Class that contains the information of the player, username, password and the
 * type of request that is requested (login or log up)
 * @author DIEGO ALFARO GONZÁLES
 * @author NICOLE GARCÍA LUNA
 * @author GABRIEL GUZMÁN ALFARO
 * @version 11/07/2021
 */
public class Request implements Serializable {

    /**
     * To find out what type of request is
     */
    public enum type {
        LOG_IN, LOG_UP, GAME_SPECIFICATIONS, POST_USERSCORE, GET_USERSCORE, GET_BESTSSCORES, POST_SCOREWIN,  CLOSE_SERVER;
    }

    // Atributtes
    private Object data;
    
    private type type;

    // Constructor
    public Request(Request.type type) {
        this.type = type;
    }

    /**
     * Constructor
     *
     * @param data      of the request
     * @param type     of the request
     */
    public Request(Object data, Request.type type) {
        this.data = data;
        this.type = type;
    }

    /**
     *
     * @return the type of request
     */
    public type getType() {
        return type;
    }

    /**
     * @return the data
     */
    public Object getData() {
        return data;
    }

    /**
     * @param data the data to set
     */
    public void setData(Object data) {
        this.data = data;
    }

    /**
     * To set the type of request
     *
     * @param type of request
     */
    public void setType(type type) {
        this.type = type;
    }

}
