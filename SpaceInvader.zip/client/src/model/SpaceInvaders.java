package model;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import controller.grafical.InGame;
import controller.serverComunications.ConnectionHandler;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.TextAlignment;
import javafx.util.Duration;
import model.grafical.Bullet;
import model.grafical.Enemy;
import model.grafical.Player;

import model.grafical.Universe;
import model.specs.GameContext;

/**
 *
 * @author DIEGO ALFARO GONZÁLES
 * @author NICOLE GARCÍA LUNA
 * @author GABRIEL GUZMÁN ALFARO
 * @version 11/07/2021
 */
public class SpaceInvaders {

    //Atributes
    private GameContext gameContext;
    private InputKeyHandler inputKH;
    private List<Image> enemyImages;
    private List<Image> universeImages;

    private boolean gameOver = false;
    private boolean won = false;

    private Player player;
    private ArrayList<ArrayList<Bullet>> bullets;
    private List<Universe> univ;
    private ArrayList<ArrayList<Enemy>> enemies;
    private Random rand;
    private Timeline timeline;
    private Thread extraEnemyCrafterThread;
    private Thread enemyShootsThread;
    private ConnectionHandler connectionHandler;
    private InGame inGameController;

    /**
     * Constructor
     * @param gameContext
     * @param inputKH
     * @param connectionHandler
     * @param inGame 
     */
    public SpaceInvaders(GameContext gameContext, InputKeyHandler inputKH, ConnectionHandler connectionHandler,
            InGame inGame) {
        rand = new Random();
        univ = new ArrayList<>();

        universeImages = new ArrayList<>();

        enemyImages = new ArrayList<>();

        bullets = new ArrayList<ArrayList<Bullet>>();
        bullets.add(new ArrayList<Bullet>());
        bullets.add(new ArrayList<Bullet>());

        enemies = new ArrayList<ArrayList<Enemy>>();
        for (int i = 0; i < gameContext.getEnemies().getEnemyRows() + 1; i++) {
            enemies.add(new ArrayList<Enemy>());
        }
        this.gameContext = gameContext;
        this.inputKH = inputKH;
        this.connectionHandler = connectionHandler;
        this.inGameController = inGame;
        setup();
    }

    /**
     * Function is add objects in the panel
     */
    public void setup() {

        for (String imagepath : gameContext.getEnemies().getImagesPaths()) {
            enemyImages.add(new Image(imagepath));
        }
        enemyImages.add(new Image(gameContext.getExtraEnemy().getImagePath()));

        //add Enemies
        for (int i = 0; i < gameContext.getEnemies().getEnemyRows(); i++) {
            ArrayList<Enemy> enemieRow = enemies.get(i);
            for (int j = 0; j < gameContext.getEnemies().getEnemyPerRow(); j++) {
                enemieRow.add(new Enemy(
                        //positionX
                        (gameContext.getEnemies().getSize() + //
                                gameContext.getEnemies().getGapBetweenEnemies_px()) * j,
                        //positionY
                        (gameContext.getEnemies().getGapBetweenEnemiesAndTop_px()//
                                + (//
                                (gameContext.getPlayer().getSize() + //
                                        gameContext.getEnemies().getGapBetweenEnemies_px()) * i)//
                        ),
                        //size
                        gameContext.getPlayer().getSize(),
                        //shot info; size,speed,color
                        gameContext.getEnemies().getShot().getSize(),
                        gameContext.getEnemies().getShot().getSpeed() - i * 2,
                        Color.web("0x" + gameContext.getEnemies().getShot().getColorHex()),
                        //image
                        enemyImages.get(i),
                        //speedY, speedX, explosion, initialDirection 1 = rigth
                        gameContext.getEnemies().getSpeedY(), //
                        gameContext.getEnemies().getSpeedX(), //
                        gameContext.getExplosion(), 1));
            }
        }

        for (String imagepath : gameContext.getUniverse().getImagePaths()) {
            universeImages.add(new Image(imagepath));
        }

        //add player
        player = new Player(
                //x position
                (gameContext.getPaneWidth() - gameContext.getPlayer().getSize()) / 2,
                //y positon
                gameContext.getPaneHeight() - gameContext.getPlayer().getSize(),
                //size
                gameContext.getPlayer().getSize(),
                //shot info; size 10 ,speed -10, color hexadecimal
                gameContext.getPlayer().getShot().getSize(), //
                gameContext.getPlayer().getShot().getSpeed(), //
                Color.web("0x" + gameContext.getPlayer().getShot().getColorHex()),
                new Image(gameContext.getPlayer().getImagePath()), //
                gameContext.getExplosion(), gameContext.getPlayer().getSpawningSteps()//
        );
    }

    /**
     * Actualizate the graphics of the game
     * @param graphicsContext 
     */
    public void start(GraphicsContext graphicsContext) {
        //set and start thread in charge of actualizate de graphics of the game
        //with a infinite cycle and 30 milis between each execution
        timeline = new Timeline(//
                new KeyFrame(//
                        Duration.millis(55), //
                        e -> run(graphicsContext)//
                )//
        );
        timeline.setCycleCount(Timeline.INDEFINITE);
        timeline.play();

        //set and start thread in charge of create a extra enemy in the alatorian time
        extraEnemyCrafterThread = new Thread(new ExtraEnemyCrafter());
        //set and start thread in charge of enemy Bullets in the alatorian time
        enemyShootsThread = new Thread(new EnemyBullets());
        extraEnemyCrafterThread.start();
        enemyShootsThread.start();

    }

    /**
     * This method return the distance between two point in a plain catersian
     * @param x1
     * @param y1
     * @param x2
     * @param y2
     * @return 
     */
    public static int distance(int x1, int y1, int x2, int y2) {
        return (int) Math.sqrt(Math.pow((x1 - x2), 2) + Math.pow((y1 - y2), 2));
    }

    /**
     * Run Graphics actualization
     * @param graphicsContext 
     */
    private void run(GraphicsContext graphicsContext) {

        graphicsContext.setFill(Color.web("0X" + gameContext.getBackGroundColor_hex(), 1.0));
        graphicsContext.fillRect(0, 0, gameContext.getPaneWidth(), gameContext.getPaneHeight());

        if (gameOver) {

            graphicsContext.setFont(Font.font(35));
            graphicsContext.setFill(Color.YELLOW);
            connectionHandler.requestGetUserScore();
            graphicsContext.fillText(//
                    "Game Over \n Your Score is: " + (int) connectionHandler.getResponse() //
                            + " \n Press space to go to Menu",
                    gameContext.getPaneWidth() / 2, gameContext.getPaneHeight() / 2.5//
            );
            if (inputKH.getShot()) {
                timeline.stop();
                extraEnemyCrafterThread.interrupt();
                enemyShootsThread.interrupt();
                inGameController.showMenu(connectionHandler);
            }
            return;
        }

        if (won) {
            graphicsContext.setFont(Font.font(35));
            graphicsContext.setFill(Color.YELLOW);
            connectionHandler.requestGetUserScore();
            int tempScoreStore = (int) connectionHandler.getResponse();
            graphicsContext.fillText(//
                    "Congratulations you win!\n Your Score is: " + tempScoreStore//
                            + " \n Press space to go to Menu",
                    gameContext.getPaneWidth() / 2, gameContext.getPaneHeight() / 2.5//
            );
            if (inputKH.getShot()) {
                connectionHandler.requestPostScoreWin(tempScoreStore);
                inGameController.showMenu(connectionHandler);
                extraEnemyCrafterThread.interrupt();
                enemyShootsThread.interrupt();
                timeline.stop();
            }
            return;
        }

        if (rand.nextInt(20) < 2) {
            univ.add(//
                    new Universe(//
                            gameContext.getPaneWidth(), //
                            gameContext.getUniverse().getSpeed(), //
                            universeImages.get(//
                                    rand.nextInt(universeImages.size())//
                            )//
                    )//
            );
        }

        for (int i = 0; i < univ.size(); i++) {
            if (univ.get(i).getPositionY() > gameContext.getPaneHeight()) {
                univ.remove(i);
            }
        }

        for (Universe e : univ) {
            e.update();
            e.draw(graphicsContext);
        }

        graphicsContext.setTextAlign(TextAlignment.CENTER);
        graphicsContext.setFont(Font.font(20));
        graphicsContext.setFill(Color.WHITE);
        connectionHandler.requestGetUserScore();
        graphicsContext.fillText("Score: " + (int) connectionHandler.getResponse(), 60, 20);

        graphicsContext.drawImage(new Image("/image/Heart.png"), 145, 0, 30, 30);
        graphicsContext.setTextAlign(TextAlignment.CENTER);
        graphicsContext.setFont(Font.font(20));
        graphicsContext.setFill(Color.WHITE);
        graphicsContext.fillText("x" + player.getLives(), 180, 20);

        if (!player.isDestroyed() && !player.isExploding() && inputKH.getAxisX() != 0
                && player.isAtLimit(gameContext.getPaneWidth()) != 0) {
            if (player.isAtLimit(gameContext.getPaneWidth()) != inputKH.getAxisX())
                player.setPositionX(//
                        player.getPositionX() + (inputKH.getAxisX()//
                                * gameContext.getPlayer().getSpeed()));
        } else {
            player.setPositionX(//
                    player.getPositionX() + //
                            (inputKH.getAxisX() * gameContext.getPlayer().getSpeed()));
        }
        player.update();
        player.draw(graphicsContext);

        if (inputKH.getShot()) {
            if (bullets.get(0).size() < gameContext.getPlayer().getMaxBulletsInScreen() && !player.isDestroyed()
                    && !player.isExploding()) {
                bullets.get(0).add(player.shoot());
            }
        }

        for (int i = 0; i < bullets.size(); i++) {
            for (int j = 0; j < bullets.get(i).size(); j++) {
                Bullet bullet = bullets.get(i).get(j);
                if (bullet.isRemove()) {
                    bullets.get(i).remove(bullet);
                    continue;
                }
                bullet.update(gameContext.getPaneHeight());
                bullet.draw(graphicsContext);
            }
        }

        for (int i = 0; i < bullets.get(0).size(); i++) {
            Bullet bullet = bullets.get(0).get(i);
            for (ArrayList<Enemy> enemyRow : enemies) {
                for (Enemy enemy : enemyRow) {
                    if (bullet.colide(enemy) && !enemy.isExploding()) {
                        addScore(enemies.indexOf(enemyRow));
                        enemy.explode();
                        bullet.setRemove(true);
                    }
                }
            }
        }

        boolean enemiesChangeDirection = false;

        for (int i = 0; i <= gameContext.getEnemies().getEnemyRows(); i++) {
            for (int j = 0; j < enemies.get(i).size(); j++) {
                Enemy enemy = enemies.get(i).get(j);
                if (enemy.isDestroyed()) {
                    enemies.get(i).remove(enemy);
                    continue;
                }
                enemy.update();
                enemy.draw(graphicsContext);
                if (!enemiesChangeDirection && i != gameContext.getEnemies().getEnemyRows()) {
                    enemiesChangeDirection = enemy.isAtLimit(//
                            gameContext.getPaneWidth(), //
                            gameContext.getPaneHeight(), //
                            player.getSize()//
                    );
                } else {
                    enemy.update();
                }
                if (player.colide(enemy) && !player.isExploding()) {
                    player.explode();
                    gameOver = true;
                }
            }
        }

        if (enemiesChangeDirection == true) {
            enemiesChangeDirection = false;
            for (int i = 0; i < gameContext.getEnemies().getEnemyRows(); i++) {
                ArrayList<Enemy> enemyRow = enemies.get(i);
                for (Enemy enemy : enemyRow) {
                    enemy.changeDirection();
                    enemy.stepDown();
                }
            }
        }

        for (int i = 0; i < bullets.get(1).size(); i++) {
            Bullet bullet = bullets.get(1).get(i);
            if (bullet.colide(player) && !player.isExploding() && !player.isSpawning()) {
                player.setLives(player.getLives() - 1);
                player.explode();
                bullet.setRemove(true);
            }
        }

        if (enemies.get(gameContext.getEnemies().getEnemyRows()).size() != 0) {
            Enemy enemy = (Enemy) enemies.get(gameContext.getEnemies().getEnemyRows()).get(0);
            enemy.update();
            enemy.draw(graphicsContext);
            if (enemy.isAtLimit(gameContext.getPaneWidth(), //
                    gameContext.getPaneHeight(), //
                    player.getSize())//
            ) {
                enemies.get(gameContext.getEnemies().getEnemyRows()).remove(enemy);
            }
        }

        won = true;
        for (int i = 0; i < gameContext.getEnemies().getEnemyRows(); i++) {
            if (enemies.get(i).size() != 0) {
                won = false;
            }
        }

        for (int i = 0; i <= gameContext.getEnemies().getEnemyRows(); i++) {
            for (int j = 0; j < enemies.get(i).size(); j++) {
                Enemy enemy = enemies.get(i).get(j);
                if (enemy.getPositionY() + enemy.getSize() > gameContext.getPaneHeight() - player.getSize()) {
                    gameOver = true;
                    break;
                }
            }
            if (gameOver) {
                break;
            }
        }
        if (gameOver) {
            return;
        }

        gameOver = player.getLives() == 0;

    }

    /**
     * Function is to add an extra alien 
     */
    private void addExtraAlien() {
        int initialDirection = rand.nextInt(2) == 1 ? -1 : 1;
        int initialPositionX = (//
        initialDirection == -1 ? //
                gameContext.getPaneWidth() //
                        - gameContext.getExtraEnemy().getSize() //
                        - gameContext.getExtraEnemy().getInitialXPostiton()
                : //
                gameContext.getExtraEnemy().getInitialXPostiton()//
        );

        enemies.get(gameContext.getEnemies().getEnemyRows()).add(//
                new Enemy(//
                        initialPositionX, //
                        gameContext.getExtraEnemy().getYPostiton(), //
                        gameContext.getExtraEnemy().getSize(),
                        //shotZize, Bulletspeed
                        gameContext.getExtraEnemy().getShot().getSize(),
                        gameContext.getExtraEnemy().getShot().getSpeed(),
                        //shotColor in hex 
                        Color.web("0x" + gameContext.getExtraEnemy().getShot().getColorHex()),
                        //image
                        enemyImages.get(gameContext.getEnemies().getEnemyRows()),
                        //speedY, speedX, explosion, initialDirection
                        0, gameContext.getExtraEnemy().getSpeedX(), gameContext.getExplosion(), initialDirection//
                )//
        );
    }

    /**
     * Function is add scores when an alien is exterminated
     * @param alienRow 
     */
    private void addScore(int alienRow) {

        switch (alienRow) {
        case 0:
            connectionHandler.requestPostUserScore(40);
            break;
        case 1:
            connectionHandler.requestPostUserScore(20);
            break;
        case 2:
            connectionHandler.requestPostUserScore(10);
            break;
        case 3:
            connectionHandler.requestPostUserScore(//
                    randomValueBetween(//
                            gameContext.getExtraEnemy().getMinScore(), //
                            gameContext.getExtraEnemy().getMaxScore()//
                    )//
            );
            break;
        }

    }

    /**
     * Function class is craft an extraEnemy
     */
    class ExtraEnemyCrafter implements Runnable {
        @Override
        public void run() {
            while (true) {
                try {
                    Thread.sleep(//
                            randomValueBetween(//
                                    gameContext.getExtraEnemy().getMinTimeBetweenAparicions_milis(), //
                                    gameContext.getExtraEnemy().getMaxTimeBetweenAparicions_milis()//
                            )//
                    );
                } catch (Exception e) {
                }
                if (enemies.get(gameContext.getEnemies().getEnemyRows()).size() == 0)
                    addExtraAlien();
            }
        }

    }

    class EnemyBullets implements Runnable {
        @Override
        public void run() {
            while (true) {
                try {
                    Thread.sleep(//
                            randomValueBetween(//
                                    gameContext.getEnemies().getMinTimeBetweenShots_milis(), //
                                    gameContext.getEnemies().getMaxTimeBetweenShots_milis()//
                            )//
                    );
                } catch (Exception e) {
                }
                if (bullets.get(1).size() < gameContext.getEnemies().getMaxBulletsOnScreen()) {
                    int randRow = rand.nextInt(4);
                    if (enemies.get(randRow).size() != 0) {
                        bullets.get(1).add(//
                                enemies.get(randRow).get(//
                                        rand.nextInt(//
                                                enemies.get(randRow).size()//
                                        ) //
                                ).shoot()//
                        );
                    }
                }
            }
        }

    }

    public void stop() {
        if(won){
            connectionHandler.requestGetUserScore();
            int tempScoreStore = (int) connectionHandler.getResponse();
            connectionHandler.requestPostScoreWin(tempScoreStore);
        }
        extraEnemyCrafterThread.interrupt();
        enemyShootsThread.interrupt();
        timeline.stop();
    }

    public int randomValueBetween(int min, int max) {
        double randNumber = rand.nextDouble();

        double result = (max - min) * randNumber;
        return min + (int) result;
    }
}
