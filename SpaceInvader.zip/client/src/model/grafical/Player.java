package model.grafical;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import model.specs.Explosion;

/**
 * Method that contains the characteristics of the player
 * 
 * @author DIEGO ALFARO GONZALES
 * @author NICOLE GARCIA LUNA
 * @author GABRIEL GUZMAN ALFARO
 * @version 11/07/2021
 */
public class Player extends Ship {

    // Atributtes
    private int lives;
    private boolean spawning;
    private int spawn_step;
    private int spawningSteps;

    /**
     * Constructor
     * 
     * @param positionX     position in X
     * @param positionY     position in Y
     * @param size          size of the player
     * @param shotSize      size of the shot
     * @param shotSpeed     Speed of the shot
     * @param shotcolor     color of the shot
     * @param image         image of the player
     * @param explosion     explosion of the player
     * @param spawningSteps of the player
     */
    public Player(//
            int positionX, int positionY, int size, int shotSize, //
            int shotSpeed, Color shotcolor, Image image, Explosion explosion, int spawningSteps//
    ) {

        super(positionX, positionY, size, shotSize, //
                shotSpeed, shotcolor, image, explosion);
        lives = 3;
        spawn_step = spawningSteps;
    }

    /**
     * Method that indicates whether the player's ship is on the edge
     * 
     * @param gamePaneWidth
     * @return int representation to 1 right , -1 to left or 0 to nothing
     */
    public int isAtLimit(int gamePaneWidth) {
        if (!super.isDestroyed() && !super.isExploding()) {
            if (super.getPositionX() + super.getSize() > gamePaneWidth) {
                return 1;
            }
            if (super.getPositionX() < 0) {
                return -1;
            }
        }
        return 0;
    }

    /**
     * Method to update the player's ship according to context
     */
    public void update() {
        if (!spawning) {
            if (super.isExploding()) {
                super.setExplosion_step(super.getExplosion_step() + 1);
                super.setExploding(super.getExplosion_step() < super.getExplosion().getSteps());
                super.setDestroyed(!super.isExploding());
            }
            if (super.isDestroyed()) {
                spawn();
                super.setDestroyed(false);
            }
        } else {
            spawn_step++;
            spawning = spawn_step < spawningSteps;
        }
    }

    /**
     * Method to draw the player's ship
     */
    public void draw(GraphicsContext graphicsContext) {
        if (spawning) {
            if (spawn_step % 5 == 0) {
                graphicsContext.drawImage(//
                        super.getImage(), //
                        this.getPositionX(), //
                        this.getPositionY(), //
                        this.getSize(), //
                        this.getSize()//
                );
            }
        } else {
            super.draw(graphicsContext);
        }
    }

    /**
     * @return the lives
     */
    public int getLives() {
        return lives;
    }

    /**
     * @param lives the lives to set
     */
    public void setLives(int lives) {
        this.lives = lives;
    }

    /**
     * @return the spawning
     */
    public boolean isSpawning() {
        return spawning;
    }

    /**
     * @param spawning the spawning to set
     */
    public void setSpawning(boolean spawning) {
        this.spawning = spawning;
    }

    /**
     * Method to spawn the player
     */
    public void spawn() {
        this.spawning = true;
        spawn_step = -1;
    }

    public Bullet shoot() {
        return new PlayerBullet(//
                super.getPositionX() + (super.getSize() / 2) - super.getShotSize() / 2, //
                super.getPositionY() - super.getShotSize(), super.getShotSize(), super.getShotSpeed(),
                super.getShotcolor()//
        );
    }
}
