package model.grafical;

import java.util.Random;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;

/**
 * Class of the environment (Universe)
 * 
 * @author DIEGO ALFARO GONZALES
 * @author NICOLE GARCIA LUNA
 * @author GABRIEL GUZMAN ALFARO
 * @version 11/07/2021
 */
public class Universe {

    // Atributtes
    private int positionX;
    private int positionY;
    private int size;
    private double scale;
    private int speed;
    private Image image;
    private Random rand = new Random();

    /**
     * Constructor
     * 
     * @param paneWidth is the pane Width
     * @param speed     universe element speed
     * @param image     universe element image
     */
    public Universe(int paneWidth, int speed, Image image) {
        this.speed = speed;
        this.image = image;
        positionX = rand.nextInt(paneWidth);
        positionY = 0;
        size = rand.nextInt(24) + 8;

        scale = rand.nextFloat();
        if (scale < 0)
            scale *= -1;
        if (scale > 0.5)
            scale = 0.5;
    }

    /**
     * To draw the universe element
     * 
     * @param graphicsContext
     */
    public void draw(GraphicsContext graphicsContext) {
        graphicsContext.drawImage(image, positionX, positionY, //
                (int) (size * scale), (int) (size * scale));
    }

    /**
     * Method to update the universe element
     */
    public void update() {
        if (scale > 0.8)
            scale -= 0.01;
        if (scale < 0.1)
            scale += 0.01;
        positionY += speed;
    }

    /**
     * @return the positionY
     */
    public int getPositionY() {
        return positionY;
    }
}