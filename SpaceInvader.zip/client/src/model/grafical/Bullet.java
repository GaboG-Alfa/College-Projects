package model.grafical;

import javafx.scene.canvas.GraphicsContext;

public interface Bullet {
    public void update(int paneWidth);

    public void draw(GraphicsContext graphicsContext);

    public boolean colide(Ship ship);

    public boolean isRemove();

    public void setRemove(boolean remove);
}
