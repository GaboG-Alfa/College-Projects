package model.grafical;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import model.SpaceInvaders;
import model.specs.Explosion;

/**
 * Class that contains the attributes of the ship (of the enemy or player) such
 * as the position, size, shot, image of the ship and how it is destroyed.
 * 
 * @author DIEGO ALFARO GONZALES
 * @author NICOLE GARCIA LUNA
 * @author GABRIEL GUZMAN ALFARO
 * @version 11/07/2021
 */
public class Ship {

    // Atributes
    private int positionX;
    private int positionY;
    private int size;
    private int shotSize;
    private int shotSpeed;
    private Color shotcolor;
    private Image image;
    private boolean exploding;
    private boolean destroyed;
    private int explosion_step;
    private Explosion explosion;

    /**
     * Constructor
     * 
     * @param positionX position in X
     * @param positionY position in Y
     * @param size      size of the ship
     * @param shotSize  size of the shot
     * @param shotSpeed Speed of the shot
     * @param shotcolor color of the shot
     * @param image     image of the ship
     * @param explosion explosion of the ship
     */
    public Ship(//
            int positionX, int positionY, int size, int shotSize, //
            int shotSpeed, Color shotcolor, Image image, Explosion explosion//
    ) {
        this.positionX = positionX;
        this.positionY = positionY;
        this.size = size;
        this.shotSize = shotSize;
        this.shotSpeed = shotSpeed;
        this.shotcolor = shotcolor;
        this.image = image;
        this.explosion = explosion;
        explosion_step = explosion.getSteps();
    }

    /**
     * @return the exploding of the ship
     */
    public boolean isExploding() {
        return exploding;
    }

    /**
     * @param exploding the exploding to set
     */
    public void setExploding(boolean exploding) {
        this.exploding = exploding;
    }

    /**
     * @return return true if the ship is destroyed or false if not
     */
    public boolean isDestroyed() {
        return destroyed;
    }

    /**
     * @param destroyed the destroyed to set
     */
    public void setDestroyed(boolean destroyed) {
        this.destroyed = destroyed;
    }

    /**
     * @return the shotSpeed
     */
    public int getShotSpeed() {
        return shotSpeed;
    }

    /**
     * @param shotSpeed the shotSpeed to set
     */
    public void setShotSpeed(int shotSpeed) {
        this.shotSpeed = shotSpeed;
    }

    /**
     * @return the positionX
     */
    public int getPositionX() {
        return positionX;
    }

    /**
     * @param positionX the positionX to set
     */
    public void setPositionX(int positionX) {
        this.positionX = positionX;
    }

    /**
     * @return the positionY
     */
    public int getPositionY() {
        return positionY;
    }

    /**
     * @param positionY the positionY to set
     */
    public void setPositionY(int positionY) {
        this.positionY = positionY;
    }

    /**
     * @return the size
     */
    public int getSize() {
        return size;
    }

    /**
     * @param size the size to set
     */
    public void setSize(int size) {
        this.size = size;
    }

    /**
     * @return the image
     */
    public Image getImage() {
        return image;
    }

    /**
     * @return the shotSize
     */
    public int getShotSize() {
        return shotSize;
    }

    /**
     * @return the shotcolor
     */
    public Color getShotcolor() {
        return shotcolor;
    }

    /**
     * @return the explosion_step
     */
    public int getExplosion_step() {
        return explosion_step;
    }

    /**
     * @param explosion_step the explosion_step to set
     */
    public void setExplosion_step(int explosion_step) {
        this.explosion_step = explosion_step;
    }

    /**
     * @return the explosion
     */
    public Explosion getExplosion() {
        return explosion;
    }
    
    /**
     * Method to update if the ship is exploding, if it is not exploding leave it
     * normal.
     */
    public void update() {
        if (exploding) {
            explosion_step++;
        }
        destroyed = explosion_step > explosion.getSteps();
    }
    

    /**
     * Method to draw based on context (whether it is exploding or not).
     * 
     * @param graphicsContext
     */
    public void draw(GraphicsContext graphicsContext) {
        if (exploding) {
            graphicsContext.drawImage(//
                    new Image(explosion.getImagepath()), //
                    this.explosion_step % explosion.getCols() * explosion.getSize(), //

                    (this.explosion_step / explosion.getRows()) //
                            * explosion.getSize() + 1,
                    explosion.getSize(), //
                    explosion.getSize(), //
                    this.positionX, //
                    this.positionY, //
                    this.size, //
                    this.size//
            );
        } else {
            graphicsContext.drawImage(//
                    this.image, //
                    this.positionX, //
                    this.positionY, //
                    this.size, //
                    this.size//
            );
        }

    }

    /**
     * Verify is a this element is colliding with another
     * 
     * @param other the ship
     * @return true or false
     */
    public boolean colide(Ship other) {
        int distance = SpaceInvaders.distance(//
                this.positionX + this.size / 2, //
                this.positionY + size / 2, //
                other.getPositionX() + other.getSize() / 2, //
                other.getPositionY() + other.getSize() / 2//
        );
        return distance < other.getSize() / 2 + this.size / 2;
    }

    /**
     * Method in case the ship explodes
     */
    public void explode() {
        exploding = true;
        explosion_step = -1;
    }

}
