package model.grafical;

import javafx.scene.image.Image;
import javafx.scene.paint.Color;
import model.specs.Explosion;

/**
 * Class that contains the methods for the characteristics of an enemy, speed,
 * direction, position and shot that takes.
 * 
 * @author DIEGO ALFARO GONZALES
 * @author NICOLE GARCIA LUNA
 * @author GABRIEL GUZMAN ALFARO
 * @version 11/07/2021
 */
public class Enemy extends Ship {

    // Atributtes
    private float speedX;
    private int speedY;
    private int direction; // left -1, rigth 1;

    /**
     * Constructor
     * @param positionX position in X
     * @param positionY position in Y
     * @param size size of the enemy
     * @param shotSize size of the shot
     * @param shotSpeed Speed of the shot
     * @param shotcolor color of the shot
     * @param image image of the enemy
     * @param speedY speed in X
     * @param speedX speed in Y
     * @param explosion explosion of the enemy
     * @param initialDirection initial Direction of the enemy
     */
    public Enemy(//
            int positionX, int positionY, int size, int shotSize, //
            int shotSpeed, Color shotcolor, Image image, int speedY, //
            int speedX, Explosion explosion, int initialDirection//
    ) {

        super(positionX, positionY, size, shotSize, shotSpeed, //
                shotcolor, image, explosion);

        this.speedY = speedY;
        this.speedX = speedX;
        direction = initialDirection;
    }

    /**
     * Method to identify if the enemy is on the edge of the panel
     * 
     * @param gamePaneWidth  is the game panel width
     * @param gamePaneHeight is the game Pane Height
     * @param playerHeight   is the player Height
     * @return true if the enemy is on the edge of the panel
     */
    public boolean isAtLimit(int gamePaneWidth, int gamePaneHeight, int playerHeight) {
        if (!super.isDestroyed() && !super.isExploding()) {
            if (direction == 1)
                super.setPositionX((int) (super.getPositionX() + speedX));
            if (direction == -1)
                super.setPositionX((int) (super.getPositionX() - speedX));

            if ((super.getPositionX() + super.getSize()) > gamePaneWidth) {
                return true;
            }
            if (super.getPositionX() <= 0) {
                return true;
            }

        }
        if (super.getPositionY() + (super.getSize() / 2) > (gamePaneHeight - playerHeight)) {
            super.setDestroyed(true);
        }
        return false;
    }

    /**
     * Method to change Direction the enemy
     */
    public void changeDirection() {
        if (direction == 1) {
            direction = -1;
            return;
        }
        if (direction == -1)
            direction = 1;
    }

    /**
     * Method to step Down to the enemy
     */
    public void stepDown() {
        if (direction == 1)
            super.setPositionX(super.getPositionX() + 2);
        if (direction == -1)
            super.setPositionX(super.getPositionX() - 2);
        speedX = (float) (speedX + 0.25);
        super.setPositionY(super.getPositionY() + speedY);
    }

    public Bullet shoot() {
        return new EnemyBullet(//
                super.getPositionX() + (super.getSize() / 2) - super.getShotSize() / 2, //
                super.getPositionY() + super.getSize() + super.getShotSize(), super.getShotSize(), super.getShotSpeed(),
                super.getShotcolor()//
        );
    }


}