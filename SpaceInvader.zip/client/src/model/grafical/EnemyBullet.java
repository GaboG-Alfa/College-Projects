package model.grafical;

import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import model.SpaceInvaders;

public class EnemyBullet implements Bullet {

    private boolean remove;

    private int positionX;
    private int positionY;
    private int size;
    private int speed;
    private Color color;

    /**
     * @param positionX
     * @param positionZ
     */
    public EnemyBullet(int positionX, int positionY, int size, int speed, Color color) {
        this.positionX = positionX;
        this.positionY = positionY;
        this.size = size;
        this.speed = speed;
        this.color = color;
    }

    /**
     * @return the remove
     */
    public boolean isRemove() {
        return remove;
    }

    /**
     * @param remove the remove to set
     */
    public void setRemove(boolean remove) {
        this.remove = remove;
    }

    /**
     * @return the positionX
     */
    public int getPositionX() {
        return positionX;
    }

    /**
     * @param positionX the positionX to set
     */
    public void setPositionX(int positionX) {
        this.positionX = positionX;
    }

    /**
     * @return the positionY
     */
    public int getPositionY() {
        return positionY;
    }

    /**
     * @param positionY the positionY to set
     */
    public void setPositionY(int positionY) {
        this.positionY = positionY;
    }

    /**
     * @return the size
     */
    public int getSize() {
        return size;
    }

    /**
     * @param size the size to set
     */
    public void setSize(int size) {
        this.size = size;
    }

    /**
     * @return the speed
     */
    public int getSpeed() {
        return speed;
    }

    /**
     * @param speed the speed to set
     */
    public void setSpeed(int speed) {
        this.speed = speed;
    }

    public void update(int paneHeight) {
        if (positionY + (size / 2) > paneHeight){
            remove = true;
        }
            positionY += speed;
    }

    public void draw(GraphicsContext graphicsContext) {
        graphicsContext.setFill(color);
        graphicsContext.fillOval(positionX, positionY, size, size);
    }

    public boolean colide(Ship ship) {
        int distance = SpaceInvaders.distance(//
                this.positionX + size / 2, //
                this.positionY + size / 2, //
                ship.getPositionX() + ship.getSize() / 2, //
                ship.getPositionY() + ship.getSize() / 2//
        );
        return distance < ship.getSize() / 2 + this.size / 2;
    }

}
