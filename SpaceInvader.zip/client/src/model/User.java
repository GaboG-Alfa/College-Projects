package model;

import java.io.Serializable;

/**
 *
 * @author DIEGO ALFARO GONZÁLES
 * @author NICOLE GARCÍA LUNA
 * @author GABRIEL GUZMÁN ALFARO
 * @version 11/07/2021
 */
public class User implements Comparable<User>, Serializable {

    // Atributtes
    private String userName;
    private String password;
    private int lastScore;
    private int inGameScore;

    @Override
    public int compareTo(User player) {
        // compare the username
        return userName.compareTo(player.getUserName());
    }

    /**
     * Constructor
     */
    public User() {
    }

    // Constructor
    public User(User other) {
        this.userName = other.userName;
        this.password = other.password;
        this.lastScore = other.lastScore;
        this.inGameScore = other.inGameScore;
    }

    /**
     * Constructor
     * 
     * @param userName of the player
     */
    public User(String userName) {
        this.userName = userName;
        this.lastScore = 0;
        this.inGameScore = 0;
    }

    /**
     * Constructor
     *
     * @param userName of the player
     * @param password of the player
     */
    public User(String userName, String password) {
        this.userName = userName;
        this.password = password;
        this.lastScore = 0;
        this.inGameScore = 0;

    }

    /**
     * Constructor
     * @param userName
     * @param lastScore
     */
    public User(String userName, int lastScore) {
        this.userName = userName;
        this.lastScore = lastScore;
    }

    /**
     * @return the inGameScore
     */
    public int getInGameScore() {
        return inGameScore;
    }

    /**
     * @param inGameScore the inGameScore to set
     */
    public void setInGameScore(int inGameScore) {
        this.inGameScore = inGameScore;
    }

    /**
     * to set the password of the player
     * 
     * @param password of the player
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * to set the score of the player
     * 
     * @param score of the player
     */
    public void setLastScore(int lastScore) {
        this.lastScore = lastScore;
    }

    /**
     * to set username of the player
     * 
     * @param userName of the player
     */
    public void setUserName(String userName) {
        this.userName = userName;
    }

    /**
     * 
     * @return the password of the player
     */
    public String getPassword() {
        return password;
    }

    /**
     * 
     * @return socre of the player
     */
    public int getLastScore() {
        return lastScore;
    }

    /**
     * 
     * @return username of the player
     */
    public String getUserName() {
        return userName;
    }

}
