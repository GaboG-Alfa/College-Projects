package model;
/**
 * Interface to logic fxml handler
 */
/**
 *
 * @author DIEGO ALFARO GONZÁLES
 * @author NICOLE GARCÍA LUNA
 * @author GABRIEL GUZMÁN ALFARO
 * @version 11/07/2021
 */
public interface FXMLController {
    public void afterLoad();
}
