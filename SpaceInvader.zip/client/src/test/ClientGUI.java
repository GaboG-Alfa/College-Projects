package test;

import controller.FXMLHandler;
import controller.grafical.LogIn;
import controller.serverComunications.ConnectionHandler;
import javafx.application.Application;
import javafx.stage.Stage;

/**
 *
 * @author DIEGO ALFARO GONZÁLES
 * @author NICOLE GARCÍA LUNA
 * @author GABRIEL GUZMÁN ALFARO
 * @version 11/07/2021
 */
public class ClientGUI extends Application {

    @Override
    public void start(Stage stage) throws Exception {

        ConnectionHandler connectionHandler = new ConnectionHandler();
        connectionHandler.openConexion();

        FXMLHandler.loadAndShowFxml(//
                LogIn::closeWindowEvent, //
                new LogIn(connectionHandler), //
                "/view/LogIn.fxml", //
                "Space invaders"//
        );
    }

    public static void main(String[] args) {
        launch(args);
    }

}
