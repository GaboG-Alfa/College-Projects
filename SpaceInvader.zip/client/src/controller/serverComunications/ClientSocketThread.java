package controller.serverComunications;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

/**
 * ClientSocketThread, stay in localhost and port 5777
 * 
 * @author DIEGO ALFARO GONZALES
 * @author NICOLE GARCIA LUNA
 * @author GABRIEL GUZMAN ALFARO

 * @version 11/07/2021
 */
public class ClientSocketThread {

   // Atributtes
   private Socket conection;
   private ObjectInputStream in;
   private ObjectOutputStream out;

   /**
    * Constructor
    *
    * @param serverIp is localhost
    * @param port     is 5777
    */
   public ClientSocketThread(String serverIp, String port) {
      try {
         conection = new Socket(serverIp, Integer.parseInt(port));

      } catch (Exception e) {
         if (e.getMessage().equals("Connection refused")) {
            System.out.println(e.getMessage() + " is posible that the server is no listening... check it out");
            System.exit(0);

         }
         System.out.println(e.getMessage() + "\n\n\n" + e);
      }

   }

   /**
    * Method to open the streams
    */
   public void openStreams() {
      try {
         out = new ObjectOutputStream(conection.getOutputStream());
         out.flush();
         in = new ObjectInputStream(conection.getInputStream());
      } catch (Exception e) {
         System.out.println(e.getMessage() + "\n\n\n" + e);
      }
   }

   /**
    * Method to close the streams
    */
   public void closeStreams() {
      try {
         in.close();
         out.close();
         conection.close();
      } catch (Exception e) {
         System.out.println(e.getMessage() + "\n\n\n" + e);
      }
   }

   /**
    * Method to receive data
    *
    * @return the received data
    */
   public Object receiveData() {

      Object object = null;

      try {
         object = in.readObject();
      } catch (Exception e) {
         System.out.println(e.getMessage() + "\n\n\n" + e);
      }
      return object;
   }

   /**
    * Method to send the data
    *
    * @param object . Data to send
    */
   public void sendData(Object object) {
      try {
         out.writeObject(((Object) object));
      } catch (Exception e) {
         System.out.println(e.getMessage() + "\n\n\n" + e);
      }
   }

}

