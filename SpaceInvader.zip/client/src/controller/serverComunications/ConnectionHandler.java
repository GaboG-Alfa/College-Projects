package controller.serverComunications;

import model.User;
import model.serverComunication.Request;

/**
 * Class to Handle Connection
 * 
 * @author DIEGO ALFARO GONZALES
 * @author NICOLE GARCIA LUNA
 * @author GABRIEL GUZMAN ALFARO
 * @version 11/07/2021
 */
public class ConnectionHandler {

    // Atributtes
    ClientSocketThread clientSocketThread;

    /**
     * Constructor
     */
    public ConnectionHandler() {
        clientSocketThread = new ClientSocketThread("localhost", "5777");
    }

    /**
     * Method to request log in
     * 
     * @param userName username to the player
     * @param password password to the player
     */
    public void requestLogIn(String userName, String password) {
        clientSocketThread.sendData(new Request(new User(userName, password), Request.type.LOG_IN));
    }

    /**
     * Method to request sign up
     * 
     * @param userName username to the player
     * @param password password to the player
     */
    public void requestSignUp(String userName, String password) {
        clientSocketThread.sendData(new Request(new User(userName, password), Request.type.LOG_UP));
    }

    /**
     * Method to request game specifications
     */
    public void requestGameSpecifications() {
        clientSocketThread.sendData(new Request(Request.type.GAME_SPECIFICATIONS));
    }

    /**
     * Method to request post user score
     * 
     * @param score player score
     */
    public void requestPostUserScore(Integer score) {
        clientSocketThread.sendData(new Request(score, Request.type.POST_USERSCORE));
    }

    /**
     * Method to request get user score
     * 
     */
    public void requestGetUserScore() {
        clientSocketThread.sendData(new Request(Request.type.GET_USERSCORE));
    }

    /**
     * Method to request get best scores
     * 
     */
    public void requestGetBestScores() {
        clientSocketThread.sendData(new Request(Request.type.GET_BESTSSCORES));
    }

    /**
     * Method to request Post Score Win
     * 
     * @param score player score
     */
    public void requestPostScoreWin(int score) {
        clientSocketThread.sendData(new Request(score, Request.type.POST_SCOREWIN));
    }

    /**
     * Method to request Close Server
     * 
     */
    public void requestCloseServer() {
        clientSocketThread.sendData(new Request(Request.type.CLOSE_SERVER));
    }

    /**
     * Method to get the response
     * 
     * @return the Object
     */
    public Object getResponse() {
        return clientSocketThread.receiveData();
    }

    /**
     * Method to open connection
     */
    public void openConexion() {
        clientSocketThread.openStreams();
    }

    /**
     * Method to close connection
     */
    public void closeConexion() {
        clientSocketThread.closeStreams();
    }
}