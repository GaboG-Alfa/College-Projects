package controller.serverComunications;

/**
 * Class to verify that the information only contains numbers
 * 
 * @author DIEGO ALFARO GONZÁLES
 * @author NICOLE GARCÍA LUNA
 * @author GABRIEL GUZMÁN ALFARO
 * @version 11/07/2021
 */
public class Validate {

  /**
   * Verify of contains number
   * 
   * @param string
   * @return true if the string only have numbers
   */
  public static boolean onlyContainsNumbers(String string) {
    boolean OnlyHaveNumbers = false;
    for (int i = 0; i < string.length(); i++) {
      if (Character.isDigit(string.charAt(i))) {
        OnlyHaveNumbers = true;
      } else {
        OnlyHaveNumbers = false;
      }
    }
    return OnlyHaveNumbers;
  }
}
