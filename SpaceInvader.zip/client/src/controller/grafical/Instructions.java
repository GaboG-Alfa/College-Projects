package controller.grafical;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import controller.FXMLHandler;
import controller.serverComunications.ConnectionHandler;
import model.FXMLController;

/**
 *
 * @author DIEGO ALFARO GONZÁLES
 * @author NICOLE GARCÍA LUNA
 * @author GABRIEL GUZMÁN ALFARO
 * @version 11/07/2021
 */
public class Instructions implements Initializable, FXMLController {

    // private static testView controller;

    @FXML
    private Button backButton;

    private ConnectionHandler connectionHandler;

    public Instructions(ConnectionHandler connectionHandler) {
        this.connectionHandler = connectionHandler;
    }

    @FXML
    private void handleBackButtonClickAction(ActionEvent event) {
        FXMLHandler.loadAndShowFxml(//
                Menu::closeWindowEvent, //
                new Menu(connectionHandler), //
                "/view/Menu.fxml", //
                "Space invaders"//
        );
        ((Stage) backButton.getScene().getWindow()).close();
    }

    /**
     * Close window
     * @param event
     */
    public static void closeWindowEvent(WindowEvent event) {
        System.exit(0);
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {

    }

    /**
     * Empty
     */
    public void afterLoad() {

    }

}
