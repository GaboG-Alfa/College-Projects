package controller.grafical;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import controller.FXMLHandler;
import controller.serverComunications.ConnectionHandler;
import model.FXMLController;
import model.User;

/**
 *
 * @author DIEGO ALFARO GONZÁLES
 * @author NICOLE GARCÍA LUNA
 * @author GABRIEL GUZMÁN ALFARO
 * @version 11/07/2021
 */
public class BestsScores implements Initializable, FXMLController {

    // private static testView controller;

    @FXML
    private Button backButton;
    @FXML
    private TableView<toShowUser> tableView;
    @FXML
    private TableColumn<toShowUser, Integer> numberC1;
    @FXML
    private TableColumn<toShowUser, String> userNameC;
    @FXML
    private TableColumn<toShowUser, Integer> scoreC;

    private ConnectionHandler connectionHandler;

    /**
     * Constructor
     * @param connectionHandler 
     */
    public BestsScores(ConnectionHandler connectionHandler) {
        this.connectionHandler = connectionHandler;
    }

    @FXML
    private void handleBackButtonClickAction(ActionEvent event) {
        FXMLHandler.loadAndShowFxml(//
                Menu::closeWindowEvent, //
                new Menu(connectionHandler), //
                "/view/Menu.fxml", //
                "Space invaders"//
        );
        ((Stage) backButton.getScene().getWindow()).close();
    }

    /**
     * Close the window
     * @param event
     */
    public static void closeWindowEvent(WindowEvent event) {
        System.exit(0);
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        numberC1.setCellValueFactory(new PropertyValueFactory<>("number"));
        userNameC.setCellValueFactory(new PropertyValueFactory<>("userName"));
        scoreC.setCellValueFactory(new PropertyValueFactory<>("lastScore"));
    }

    /**
     * After load fxml file this method will be executed
     */
    public void afterLoad() {
        connectionHandler.requestGetBestScores();
        ArrayList<User> userList  = ((ArrayList<User>)connectionHandler.getResponse());
        ArrayList<toShowUser> toShow = new ArrayList<toShowUser>() ;
        for( User user : userList ){
            toShow.add(new toShowUser(userList.indexOf(user)+1,user));
        }
        
        for( toShowUser user :  toShow ){
            tableView.getItems().add(user);
        }
    }


    /**
     * InnerBestsScores
     */
    public class toShowUser extends User {
        int number;

        public toShowUser(int number, User user) {
            super(user);
            this.number = number;
        }

        /**
         * @return the number
         */
        public int getNumber() {
            return number;
        }
    }

}
