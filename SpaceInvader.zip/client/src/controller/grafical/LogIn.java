package controller.grafical;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import controller.FXMLHandler;
import controller.serverComunications.ConnectionHandler;
import model.FXMLController;

/**
 *
 * @author DIEGO ALFARO GONZÁLES
 * @author NICOLE GARCÍA LUNA
 * @author GABRIEL GUZMÁN ALFARO
 * @version 11/07/2021
 */
public class LogIn implements Initializable, FXMLController {

    // private static testView controller;

    @FXML
    private Button exitButton;
    @FXML
    private TextField userNameTF;
    @FXML
    private TextField passwordTF;
    @FXML
    private Label messageLB;

    private ConnectionHandler connectionHandler;

    /**
     * Constructor
     * @param connectionHandler 
     */
    public LogIn(ConnectionHandler connectionHandler) {
        this.connectionHandler = connectionHandler;
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {

    }

    @FXML
    private void handleLogInClickAction(ActionEvent event) throws IOException {

        if (userNameTF.getText().equals("") && passwordTF.getText().equals("")) {
            messageLB.setText("Empty Spaces!!!");
            return;
        }
        if (userNameTF.getText().equals("")) {
            messageLB.setText("Empty Username!!!");
            return;//this line avoid that the this method keep running
        }

        if (passwordTF.getText().equals("")) {
            messageLB.setText("Empty Password!!");
            return;//this line avoid that the this method keep running
        }

        connectionHandler.requestLogIn(userNameTF.getText(), passwordTF.getText());
        // "Loged fail, user or pass" "Loged in"
        String response = (String) connectionHandler.getResponse();
        if (response == null) {
            System.out.println("critical server error");
            System.exit(0);
        }
        if (response.equals("Loged in")) {

            FXMLHandler.loadAndShowFxml(//
                    Menu::closeWindowEvent, //
                    new Menu(connectionHandler), //
                    "/view/Menu.fxml", //
                    "Space invaders"//
            );

            ((Stage) exitButton.getScene().getWindow()).close();

        } else if (response.equals("Loged fail, user or pass")) {
            messageLB.setText("Loged fail, user or password is incorrect");
        }

    }

    @FXML
    private void handleSignUpClickAction(ActionEvent event) throws IOException {

        FXMLHandler.loadAndShowFxml(//
                SignUp::closeWindowEvent, //
                new SignUp(connectionHandler), //
                "/view/SignUp.fxml", //
                "Space invaders"//
        );

        ((Stage) exitButton.getScene().getWindow()).close();
    }

    /**
     * Close window
     * @param event
     */
    public static void closeWindowEvent(WindowEvent event) {
        System.exit(0);
    }

    @FXML
    private void handleExitButtonClickAction(ActionEvent event) {
        ((Stage) exitButton.getScene().getWindow()).close();
        System.exit(0);
    }

    /**
     * Empty
     */
    public void afterLoad() {

    }

}
