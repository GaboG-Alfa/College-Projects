package controller.grafical;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import controller.FXMLHandler;
import controller.serverComunications.ConnectionHandler;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import model.FXMLController;
import model.InputKeyHandler;
import model.SpaceInvaders;
import model.specs.GameContext;

/**
 *
 * @author DIEGO ALFARO GONZÁLES
 * @author NICOLE GARCÍA LUNA
 * @author GABRIEL GUZMÁN ALFARO
 * @version 11/07/2021
 */
public class InGame implements Initializable, FXMLController {

    // private static testView controller;
    @FXML
    private Button backButton;
    @FXML
    private Label messageLB;
    @FXML
    private Pane gameP;
    @FXML
    private Canvas mainCanvas;

    private SpaceInvaders game;
    private GameContext gameContext;
    private GraphicsContext graphicsContext;

    private ConnectionHandler connectionHandler;
    private InputKeyHandler inputKH;

    /**
     * Constructor
     * @param connectionHandler
     * @param inputKH
     */
    public InGame(ConnectionHandler connectionHandler, InputKeyHandler inputKH) {
        this.connectionHandler = connectionHandler;
        this.inputKH = inputKH;
    }

    /**
     * After load fxml file this method will be executed
     */
    public void afterLoad() {
        connectionHandler.requestGameSpecifications();
        gameContext = (GameContext) connectionHandler.getResponse();
        if (gameContext == null) {
            System.out.println("critical server error");
            System.exit(0);
        }

        gameContext.setPaneHeight((int) mainCanvas.getHeight());
        gameContext.setPaneWidth((int) mainCanvas.getWidth());

        game = new SpaceInvaders(gameContext, inputKH, connectionHandler, this);
        game.start(graphicsContext);
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        graphicsContext = mainCanvas.getGraphicsContext2D();
        // gameContext.getInputKeyHandler().setAxisXLimits((int)mainCanvas.getWidth()/2);
    }

    @FXML
    private void handleBackButtonClickAction(ActionEvent event) throws IOException {
        game.stop();
        showMenu(connectionHandler);
    }

    /**
     * Show menu and close the stage
     * @param connectionHandler 
     */
    public void showMenu(ConnectionHandler connectionHandler) {
        FXMLHandler.loadAndShowFxml(//
                Menu::closeWindowEvent, //
                new Menu(connectionHandler), //
                "/view/Menu.fxml", //
                "Space invaders"//
        );
        ((Stage) this.backButton.getScene().getWindow()).close();
    }

    /**
     *
     * @param event
     */
    public static void closeWindowEvent(WindowEvent event) {
        System.exit(0);
    }
}
