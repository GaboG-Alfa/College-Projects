package controller.grafical;

import java.net.URL;
import java.util.ResourceBundle;

import controller.FXMLHandler;
import controller.serverComunications.ConnectionHandler;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import model.FXMLController;

/**
 *
 * @author DIEGO ALFARO GONZÁLES
 * @author NICOLE GARCÍA LUNA
 * @author GABRIEL GUZMÁN ALFARO
 * @version 11/07/2021
 */
public class SignUp implements Initializable, FXMLController {

    // private static testView controller;
    @FXML
    private Button backButton;
    @FXML
    private TextField userNameTF;
    @FXML
    private TextField passwordTF;
    @FXML
    private TextField confirmTF;
    @FXML
    private Label messageLB;

    private ConnectionHandler connectionHandler;

    /**
     * Constructor
     */
    public SignUp () {
     
    }

    /**
     * Constructor
     * @param connectionHandler 
     */
    public SignUp(ConnectionHandler connectionHandler) {
        this.connectionHandler = connectionHandler;
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {

    }

    @FXML
    private void handleSignUpButtonClickAction(ActionEvent event) {

        if (!passwordTF.getText().equals(confirmTF.getText())) {
            messageLB.setText("Incorrect Password and Confirm!!!");
            return;
        }

        if (userNameTF.getText().equals("") && //
                !passwordTF.getText().equals("") && //
                !confirmTF.getText().equals("")//
        ) {
            messageLB.setText("Empty Username!!!");
            return;
        }

        if (passwordTF.getText().equals("") && //
                confirmTF.getText().equals("") && //
                !userNameTF.getText().equals("")//
        ) {
            messageLB.setText("Empty Password and Confirm!!!");
            return;
        }

        if (userNameTF.getText().equals("") && //
                passwordTF.getText().equals("") && //
                confirmTF.getText().equals("")//
        ) {
            messageLB.setText("Empty Spaces!!!");
            return;
        }

        // "Successfully registered"
        // "Log up fail, the user exist"
        connectionHandler.requestSignUp(userNameTF.getText(), passwordTF.getText());
        String response = (String) connectionHandler.getResponse();

        if (response == null) {
            System.out.println("critical server error");
            System.exit(0);
        }
        if (response.equals("Successfully registered")) {
            showLogIn();
            ((Stage) this.backButton.getScene().getWindow()).close();
        } else if (response.equals("Log up fail, the user exist")) {
            messageLB.setText("Log up fail,the user alrready exist");
            return;
        }

    }

    @FXML
    private void handleBackButtonClickAction(ActionEvent event) {
        showLogIn();
        ((Stage) this.backButton.getScene().getWindow()).close();
    }

    /**
     * Show the log in
     */
    private void showLogIn() {
        FXMLHandler.loadAndShowFxml(//
                LogIn::closeWindowEvent, //
                new LogIn(connectionHandler), //
                "/view/LogIn.fxml", //
                "Space invaders"//
        );
    }

    /**
    * Close the window event
    * @param event
    */
    public static void closeWindowEvent(WindowEvent event) {
        System.exit(0);
    }

    public void afterLoad() {

    }

}
