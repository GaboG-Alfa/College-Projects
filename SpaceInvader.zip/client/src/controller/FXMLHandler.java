package controller;

import java.io.IOException;

import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import model.FXMLController;

/**
 *
 * @author DIEGO ALFARO GONZALES
 * @author NICOLE GARCIA LUNA
 * @author GABRIEL GUZMAN ALFARO
 * @version 11/07/2021
 */
public class FXMLHandler {

    /**
     * Function is loadAndShowFxml
     * @param stage
     * @param closeWindowEvent
     * @param keyPressedHandler
     * @param keyReleaceHandler
     * @param controller
     * @param path
     * @param title
     * @return controller
     */
    public static Object loadAndShowFxml(//
            Stage stage, EventHandler<WindowEvent> closeWindowEvent, //
            EventHandler<KeyEvent> keyPressedHandler, EventHandler<KeyEvent> keyReleaceHandler, //
            FXMLController controller, String path, String title//
    ) {

        Parent root = null;
        FXMLLoader loader = new FXMLLoader(FXMLHandler.class.getResource(path));
        if (controller != null) {
            loader.setController(controller);
        }
        try {
            root = loader.load();
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
        if (stage == null) {
            stage = new Stage();
        }
        Scene scene = new Scene(root);
        if (keyPressedHandler != null) {
            scene.setOnKeyPressed(keyPressedHandler);
        }
        if (keyReleaceHandler != null) {
            scene.setOnKeyReleased(keyReleaceHandler);
        }
        stage.setTitle(title);
        stage.setScene(scene);
        stage.setAlwaysOnTop(false);
        controller = loader.getController();
        controller.afterLoad();
        if (closeWindowEvent != null) {
            stage.getScene().getWindow().addEventHandler(WindowEvent.WINDOW_CLOSE_REQUEST, closeWindowEvent);
        }
        stage.show();

        return controller;
    }

    /**
     * Function is loadAndShowFxml recursive
     * @param closeWindowEvent
     * @param keyPressedHandler
     * @param keyReleaceHandler
     * @param controller
     * @param path
     * @param title
     * @return loadAndShowFxml
     */
    public static Object loadAndShowFxml(//
            EventHandler<WindowEvent> closeWindowEvent, //
            EventHandler<KeyEvent> keyPressedHandler, //
            EventHandler<KeyEvent> keyReleaceHandler, //
            FXMLController controller, String path, String title//
    ) {
        return loadAndShowFxml(//
                null, //
                closeWindowEvent, //
                keyPressedHandler, //
                keyReleaceHandler, //
                controller, path, title);
    }

    /**
     * Function is loadAndShowFxml recursive
     * @param closeWindowEvent
     * @param controller
     * @param path
     * @param title
     * @return loadAndShowFxml
     */
    public static Object loadAndShowFxml(//
            EventHandler<WindowEvent> closeWindowEvent, //
            FXMLController controller, String path, String title//
    ) {
        return loadAndShowFxml(null, closeWindowEvent, null, null, controller, path, title);
    }

    /**
     * Function is loadAndShowFxml recursive
     * @param controller
     * @param path
     * @param title
     * @return loadAndShowFxml
     */
    public static Object loadAndShowFxml(FXMLController controller, String path, String title) {
        return loadAndShowFxml(null, null, null, null, //
                controller, path, title);
    }

    /**
     * Function is loadAndShowFxml recursive
     * @param path
     * @param title
     * @return loadAndShowFxml
     */
    public static Object loadAndShowFxml(String path, String title) {
        return loadAndShowFxml(null, path, title);
    }

    /**
     * Function is loadAndShowFxml recursive
     * @param stage
     * @param controller
     * @param path
     * @param title
     * @return loadAndShowFxml
     */
    public static Object loadAndShowFxml(//
            Stage stage, //
            FXMLController controller, String path, String title) {
        return loadAndShowFxml(stage, null, null, null, //
                controller, path, title);
    }

}
