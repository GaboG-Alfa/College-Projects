package com.example.tarea2kotlin2022

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class CoheteNasa : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var cuentaRegresiva:Int = 10

        do{
            cuentaRegresiva--

            println("Cuenta Regresiva $cuentaRegresiva")

            if(cuentaRegresiva==0) println("Despegue!!!!!")

        }while(cuentaRegresiva!=0)

    }


}