package com.example.ejercicio3seccion2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class Platos : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var platos:Array<String> = arrayOf("pie de limón","chifrijo","arroz cantonés","pollo con papas fritas")

        for (i in platos)
            println(i)

    }
}