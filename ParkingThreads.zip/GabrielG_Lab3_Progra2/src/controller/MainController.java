package controller;

import model.CarMaker;
import model.PakingTimeController;
import model.Parking;
import view.ParkingReport;

/**
 * 
 * @author Gabriel Guzmán Alfaro
 * @version 23/05/2021
 */
public class MainController {
  
  /**
   * Constructor
   */  
  public MainController () {
    Parking parking = new Parking(9,1);
    CarMaker carMaker = new CarMaker(parking);
    PakingTimeController pakingTimeController = new PakingTimeController(parking);
    ParkingReport parkingReport = new ParkingReport(parking);
    Thread tpakingTimeController = new Thread(pakingTimeController);
    tpakingTimeController.start();
    Thread tparkingReport = new Thread(parkingReport);
    tparkingReport.start();
    Thread tcarMaker = new Thread(carMaker);
    tcarMaker.start();
  }

  /**
   * 
   * @param min
   * @param max
   * @return random 
   */
  public static int getAleatoryNumberBetween(int min, int max) {
    return (int) Math.floor(Math.random() * (max - min + 1) + min);
  }

  /**
   * 
   * @param seconds 
   */
  public static void sleep(int seconds) {
    try {
      Thread.sleep(seconds * 500);
    } catch (Exception e) {
      ParkingReport.showException(e);
    }
  }
}
