package test;

import controller.MainController;

/**
 * 
 * @author Gabriel Guzmán Alfaro
 * @version 23/05/2021
 */
public class Main {
  public static void main(String[] args) {
    new MainController();
  }
}
