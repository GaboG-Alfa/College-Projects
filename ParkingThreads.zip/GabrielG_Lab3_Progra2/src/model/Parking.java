package model;

import java.util.ArrayList;
import java.util.List;

/**
 * 
 * @author Gabriel Guzmán Alfaro
 * @version 23/05/2021
 */
public class Parking {
  
  //Atributtes  
  private List<Space> spaces;
  private boolean isOpen;

  /**
   * 
   * @param able
   * @param outOfFunctioning 
   */
  public Parking(int able, int outOfFunctioning) {
    this.spaces = new ArrayList<Space>();
    for (int i = 0; i < able; i++) {
      spaces.add(new Space(SpaceCondition.Able));
    }
    for (int i = 0; i < outOfFunctioning; i++) {
      spaces.add(new Space(SpaceCondition.OutOfFunctioning));
    }
    isOpen = true;
  }

  /**
   * 
   * @param index
   * @param carToAdd 
   */
  public void entryCar(int index, Car carToAdd) {
    spaces.set(index, new Space(SpaceCondition.Full, carToAdd));
  }

  /**
   * 
   * @return space index 
   */
  public int searchAbleSpace() {
    for (Space space : spaces) {
      if (space.getConditions() == SpaceCondition.Able) {
        return spaces.indexOf(space);
      }
    }
    return -1;
  }

  /**
   * 
   * @param index 
   */
  public void takeOutCar(int index) {
    spaces.set(index, new Space(SpaceCondition.Able));
  }

  /**
   * 
   * @return isOpen 
   */
  public boolean isOpen() {
    return isOpen;
  }

  /**
   * Control the open
   */
  public void open() {
    isOpen = true;
  }

  /**
   * Control the close
   */
  public void close() {
    isOpen = false;
  }

  /**
   * Control the parking
   */
  public void showParking() {
    String exit = "Parking: \n\t status: " + isOpen;
    for (Space space : spaces) {
      exit += "\n\t\tspace: " + space.getConditions();
      if (space.getConditions() == SpaceCondition.Full) {
        exit += " by car: " + space.getCar().getId();
      }
    }
    System.out.println(exit);
  }

}
