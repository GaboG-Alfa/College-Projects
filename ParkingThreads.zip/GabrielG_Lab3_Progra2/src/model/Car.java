/*
 * Clase que se encarga de guardar la información de un carro
 */
package model;

import controller.MainController;
import view.ParkingReport;

/**
 *
 * @author Gabriel Guzmán Alfaro
 * @version 23/05/2021
 */
public class Car implements Runnable {

  //Atributos
  private int id;
  private Parking parking;
  private int timeInParking;
  private Object monitor = new Object();;

  private static int consecutiveId = 1;

  /**
   * 
   * @param parking
   * @param timeInParking 
   */
  public Car(Parking parking, int timeInParking) {
    id = consecutiveId;
    consecutiveId++;
    this.timeInParking = timeInParking;
    this.parking = parking;
  }

  /**
   * 
   * @return id 
   */
  public int getId() {
    return id;
  }

  /**
   * Run
   */
  public void run() {
    ParkingReport.showQueue(id);
    if (!parking.isOpen()) {
      ParkingReport.parkingClosed(id);
      return;
    }
    int index;
    do {
      index = parking.searchAbleSpace();
      if (index == -1) {
        synchronized (monitor) {
          try {
            ParkingReport.parkingFull();
            monitor.wait();
          } catch (Exception e) {
            ParkingReport.showException(e);
          }
        }
      }
    } while (index == -1);

    parking.entryCar(index, this);
    ParkingReport.showParkingInput(id);
    MainController.sleep(timeInParking);
    parking.takeOutCar(index);
    synchronized (monitor) {
      monitor.notifyAll();
    }
  }

}
