/*
 * Clase que se encarga de almacenar información de un espacio
 */
package model;

/**
 *
 * @author Gabriel Guzmán  Alfaro
 * @version 23/05/2021
 */
public class Space {

    //Atributtes
    private SpaceCondition conditions;
    private Car car;

    /**
     *
     * @param conditions
     * @param car
     */
    public Space(SpaceCondition conditions) {
        this.conditions = conditions;
    }

    /**
    *
    * @param conditions
    * @param car
    */
    public Space(SpaceCondition conditions, Car car) {
        this.conditions = conditions;
        this.car = car;
    }

    /**
     *
     * @return car
     */
    public Car getCar() {
        return car;
    }

    /**
     *
     * @param car
     */
    public void setCar(Car car) {
        this.car = car;
    }

    /**
     *
     * @param conditions
     */
    public void setConditions(SpaceCondition conditions) {
        this.conditions = conditions;
    }

    /**
     *
     * @return conditions
     */
    public SpaceCondition getConditions() {
        return conditions;
    }

}
