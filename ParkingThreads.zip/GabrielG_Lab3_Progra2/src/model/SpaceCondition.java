/*
 * Class with enums
 */
package model;

/**
 *
 * @author Gabriel Guzmán Alfaro
 * @version 23/05/2021
 */
public enum SpaceCondition {
    Able, Full, OutOfFunctioning;
}
