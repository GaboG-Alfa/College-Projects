package model;

import controller.MainController;

/**
 * 
 * @author Gabriel Guzmán Alfaro
 * @version 23/05/2021
 */
public class PakingTimeController implements Runnable {
  private Parking parking;

  /**
   * 
   * @param parking 
   */
  public PakingTimeController(Parking parking) {
    this.parking = parking;
  }

  @Override
  public void run() {
    while (true) {
      parking.open();
      synchronized (parking) {
        parking.notifyAll();
      }
      MainController.sleep(120);
      parking.close();
      MainController.sleep(30);
    }
  }

}
