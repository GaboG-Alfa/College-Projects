package model;

import controller.MainController;
import view.ParkingReport;

/**
 * 
 * @author Gabriel Guzmán Alfaro
 * @version 23/05/2021
 */
public class CarMaker implements Runnable {
  
  //Atributtes
  private Parking parking;

  /**
   * 
   * @param parking 
   */
  public CarMaker(Parking parking) {
    this.parking = parking;
  }

  @Override
  public void run() {
    while (true) {
      while (parking.isOpen()) {
        Car car = new Car(parking, MainController.getAleatoryNumberBetween(20, 40));
        Thread tC = new Thread(car);
        tC.start();
        MainController.sleep(MainController.getAleatoryNumberBetween(2, 5));
        
      }
      while (!parking.isOpen()) {
        synchronized (parking) {
          try {
            parking.wait();
          } catch (Exception e) {
            ParkingReport.showException(e);
          }
        }
      }
    }
  }

}
