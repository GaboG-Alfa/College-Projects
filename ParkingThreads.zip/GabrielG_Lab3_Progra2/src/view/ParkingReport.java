package view;

import controller.MainController;
import model.Parking;
import model.SpaceCondition;
/*
 * Class with messages
 */

/**
 *
 * @author Gabriel Guzmán Alfaro
 * @version 23/05/2021
 */
public class ParkingReport implements Runnable{
    private Parking parking;
    public ParkingReport (Parking parking) {
     this.parking = parking;
    }

    @Override
    public void run() {
        while (true) {
            MainController.sleep(5);
            parking.showParking();
        }
    }
    /**
     *
     * @param carList
     */
    public static void showQueue(int id) {

        System.out.println("\nCar in queue... " + " The car " + id + " is waiting....");
    }

    /**
     *
     * @param e
     */
    public static void showException(Exception e) {

        System.out.println("Error wait: " + e);
    }

    /**
     * Print the parking input message
     */
    public static void showParkingInput(int id) {

        System.out.println("\nThe car " + id + "----->entry at a space");

    }

    /**
     * Full parking message
     */
    public static void parkingFull() {
        System.out.println("Parking full! Wait to found a empty space....");
    }
        /**
     * Full parking message
     */
    public static void parkingClosed(int id) {
        System.out.println("The car:" + id +" encontro el parqueo cerrado procede a retirarse");
    }




    /**
     * Show space state
     * @param state
     */
    public static void showSpaceCondition(int count, SpaceCondition spaceCondition) {

        System.out.println("The sapce " + count + " is " + spaceCondition);

    }

}
