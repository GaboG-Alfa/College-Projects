/*
 *Clase que guarda información de un nodo para ubicarse en la lista
 */
package ListaEnlazadaSimplePersona;

/**
 *
 * @author Gabriel Guzmán Alfaro
 * @version 29/04/201
 */
public class Nodo {
    
    //Atributos
    private Persona persona;
    private Nodo siguiente;

    /**
     * Constructor
     */
    public Nodo() {
    }
    
    /**
     * Constructor
     * @param persona
     * @param siguiente 
     */
    public Nodo(Persona persona, Nodo siguiente) {
        this.persona = persona;
        this.siguiente = siguiente;
    }

    /**
     * 
     * @return persona 
     */
    public Persona getPersona() {
        return persona;
    }

    /**
     * 
     * @param persona 
     */
    public void setPersona(Persona persona) {
        this.persona = persona;
    }

    /**
     * 
     * @return siguiente 
     */
    public Nodo getSiguiente() {
        return siguiente;
    }

    /**
     * 
     * @param siguiente 
     */
    public void setSiguiente(Nodo siguiente) {
        this.siguiente = siguiente;
    }
       
    
}
