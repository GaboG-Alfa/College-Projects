/*
 *Clase que guarda información de la clase lista persona
 */
package ListaEnlazadaSimplePersona;

/**
 *
 * @author Gabriel Guzmán
 * @version 29/04/2021
 */
public class ListaPersona {

    //Atributo
    private Nodo primero;
    private Nodo ultimo;

    /**
     * Agregar persona al inicio de la lista con punteros
     *
     * @param persona
     */
    private  void insertarInicio(Persona persona) {

        //Por punteros
        Nodo nuevo = new Nodo();

        nuevo.setPersona(persona);

        if(primero == null){
         
            primero = ultimo = nuevo;
            
        }else{
            
            nuevo.setSiguiente(primero);
            
            primero = nuevo;
        }
       
        
    }

    /**
     * Agregar persona al final de la lista con punteros
     *
     * @param dato
     */
    private void insertarFinal(Persona persona) {

        //Por punteros
        Nodo nuevo = new Nodo();

        nuevo.setPersona(persona);

        if (ultimo == null) {

            primero = ultimo = nuevo;

        } else {

            ultimo.setSiguiente(nuevo);
            ultimo = nuevo;
        }
    }

    /**
     * Agregar persona de forma ordenada por cédula en la lista
     *
     * @param persona
     */
    public boolean insertarOrdenamiento(Persona persona) {
        
        //Validar antes de ingresar
        if(consultar(persona.getCedula())!=null){
            
            if(persona.getCedula()== (consultar(persona.getCedula()).getCedula()))
            throw new IllegalArgumentException("Error, la persona ya ha sido ingresada ");
            
        }

        if (primero == null) {

            insertarInicio(persona);

            return true;
        }

        if (persona.getCedula() < primero.getPersona().getCedula()) {

            insertarInicio(persona);

            return true;
        }

        if (persona.getCedula() > ultimo.getPersona().getCedula()) {

            insertarFinal(persona);

            return true;
        }

        for (Nodo temp = primero; temp != ultimo; temp = temp.getSiguiente()) {

            if (persona.getCedula() < temp.getSiguiente().getPersona().getCedula()) {

                //Por punteros
                Nodo nuevo = new Nodo();

                nuevo.setPersona(persona);

                nuevo.setSiguiente(temp.getSiguiente());
                temp.setSiguiente(nuevo);

                return true;

            }

        }

        return true;
    }

    /**
     * Consultar una persona por cédula
     *
     * @param cedula
     */
    public Persona consultar(int cedula) {

        if (primero == null) {

            return null;
        }

        for (Nodo temp = primero; temp != null; temp = temp.getSiguiente()) {

            if (cedula == temp.getPersona().getCedula()) {
                return temp.getPersona();
            }
        }

        return null;
    }

    /**
     * Eliminar una persona al inicio
     *
     * @return boolean
     */
    public boolean eliminarInicio() {

        if (primero == null) {

            return false;
        }

        if (primero == ultimo) {
            primero = ultimo = null;
        } else {

            primero = primero.getSiguiente();
        }

        return true;

    }

    /**
     *
     * @return boolean
     */
    public boolean eliminarFinal() {
        if (ultimo == null) {
            return false;
        }
        if (ultimo == primero) {
            primero = ultimo = null;
        } else {
            Nodo temp = primero;
            while (temp.getSiguiente() != ultimo) {
                temp = temp.getSiguiente();
            }
            if (temp.getSiguiente() == ultimo) {
                temp.setSiguiente(null);
                ultimo = temp;
            }
        }
        return true;
    }

    /**
     * Elimina una persona por cedula
     *
     * @param cedula
     * @return boolean
     */
    public boolean eliminarPersona(int cedula) {

        if (primero == null) {

            return false;

        }

        if (primero.getPersona().getCedula() == cedula) {

            this.eliminarInicio();

            return true;

        } else if (ultimo.getPersona().getCedula() == cedula) {

            this.eliminarFinal();

            return true;

        } else {

            Nodo temp;

            temp = primero;

            while (temp.getSiguiente() != null) {

                if (temp.getSiguiente().getPersona().getCedula() == cedula) {

                    temp.setSiguiente(temp.getSiguiente().getSiguiente());

                    return true;
                }

                temp = temp.getSiguiente();
            }

        }

        return false;
    }

    /**
     *
     * @return hilera
     */
    public String imprimirListaPersona() {

        String salida = "";

        for (Nodo temp = primero; temp != null; temp = temp.getSiguiente()) {

            salida += "\n" + temp.getPersona().toString();
        }

        return salida;
    }

}
