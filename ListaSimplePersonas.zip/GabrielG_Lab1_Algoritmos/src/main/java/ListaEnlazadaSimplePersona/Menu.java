package ListaEnlazadaSimplePersona;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import java.awt.FlowLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Menu extends JFrame {

    private JLabel menuL, cedulaL, nombreL, apellidoL, edadL; // Label para menu
    private JTextField menu,cedula, nombre, apellido, edad;
    private String persona;
    private JButton opcionA, opcionB, opcionC, opcionD, exit; // Botones de mostrar y salir

    /*
    * Clase an�nima para listener, enlace:
    * 
    * http://chuwiki.chuidiang.org/index.php?title=ActionListener#:~:text=%
    * 20ActionListener%20%201%20Los%20ActionListener.%20Los%20componentes,%20...%
    * 20Este%20m%C3%A9todo%20sigue%20presentando...%20More%20
    * 
     */
    public Menu() {
        super("Lista de personas");

        setLayout(new FlowLayout(FlowLayout.LEFT, 5, 10));
        
        //Instanciar la lista de personas
        
        ListaPersona listaPersona = new ListaPersona();

        // Declaramos los objetos que estaran dentro del JFrame
        menuL = new JLabel("Pulse el botón con la opción");
        menu = new JTextField(10);
        cedulaL = new JLabel("Cédula de la persona:");
        cedula = new JTextField(10);
        nombreL = new JLabel("Nombre de la persona:");
        nombre = new JTextField(10);
        apellidoL = new JLabel("Apellido de la persona:");
        apellido = new JTextField(10);
        edadL = new JLabel("Edad de la persona:");
        edad = new JTextField(10);
        opcionA = new JButton("Insertar persona");
        opcionB = new JButton("Eliminar persona");
        opcionC = new JButton("Consultar persona");
        opcionD = new JButton("Mostrar la lista de personas");
        exit = new JButton("Salir");

        // Agregamos los objetos en el orden deseado al JFrame
        add(menuL);
        add(cedulaL);
        add(cedula);
        add(nombreL);
        add(nombre);
        add(apellidoL);
        add(apellido);
        add(edadL);
        add(edad);
        add(opcionA);
        add(opcionB);
        add(opcionC);
        add(opcionD);

        add(exit);

        // Programamos los Listener de cada Boton
        opcionA.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent evento) {
                
               Persona persona = new Persona(Integer.parseInt(cedula.getText()),nombre.getText(),apellido.getText(),Integer.parseInt(edad.getText()));

               listaPersona.insertarOrdenamiento(persona);
            }
        });

        opcionB.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evento) {

                persona = JOptionPane.showInputDialog(null, "Ingrese la cédula de la persona a eliminar", "Eliminar por cédula",
                        JOptionPane.INFORMATION_MESSAGE);
                
                //Eliminar persona de la lista
                listaPersona.eliminarPersona(Integer.parseInt(persona));
            }
        });

        opcionC.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evento) {
                
                //Variable temporal
                Persona resultadoConsulta; 

                persona = JOptionPane.showInputDialog(null, "Ingrese la cédula de la persona a consultar", "Consultar por cédula",
                        JOptionPane.INFORMATION_MESSAGE);
                
                //Consultar persona en la lista
               resultadoConsulta = listaPersona.consultar(Integer.parseInt(persona));
               
               //Validar si no se encontró la persona
               if(resultadoConsulta!=null){
                   
                   System.out.println("\nConsultar: "+resultadoConsulta.toString());
               }else{
                   
                   throw new IllegalArgumentException("Error, la persona no se encontró en la lista");
               }
                
            }
        });

        opcionD.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evento) {

               System.out.println("\nLista de personas: "+listaPersona.imprimirListaPersona());
            }
        });

        exit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evento) {
                JOptionPane.showMessageDialog(null, "Saldra la aplicacion", "WARNING", JOptionPane.WARNING_MESSAGE);
                System.exit(0);
            }
        });

    }

    // Metodo main()
    public static void main(String args[]) {
        Menu listen = new Menu();
        listen.setLocationRelativeTo(null);
        listen.setSize(300, 175);
        listen.setVisible(true);
    }

}
