/*
 * Clase que se encarga de guardar información de una persona 
 */
package ListaEnlazadaSimplePersona;

/**
 *
 * @author Gabriel
 * @version 29/04/2021
 */
public class Persona {
    
    //Atributos 
    private int cedula;
    private String nombre;
    private String apellido;
    private int edad;

    /**
     * Constructor
     */
    public Persona() {
    }

    /**
     * Constructor
     * @param cedula
     * @param nombre
     * @param apellido
     * @param edad 
     */
    public Persona(int cedula, String nombre, String apellido, int edad) {
        this.cedula = cedula;
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
    }
    
    

    /**
     * 
     * @return cedula 
     */
    public int getCedula() {
        return cedula;
    }
 
    /**
     * 
     * @param cedula 
     */
    public void setCedula(int cedula) {
        this.cedula = cedula;
    }

    /**
     * 
     * @return apellido 
     */
    public String getApellido() {
        return apellido;
    }

    /**
     * 
     * @param apellido 
     */
    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    /**
     * 
     * @return edad 
     */
    public int getEdad() {
        return edad;
    }

    /**
     * 
     * @param edad 
     */
    public void setEdad(int edad) {
        this.edad = edad;
    }

    @Override
    public String toString() {
        return "Persona: " + "Cédula = " + cedula + ", nombre = " + nombre + ", apellido = " + apellido + ", edad = " + edad;
    }
    
    
    
    
}
