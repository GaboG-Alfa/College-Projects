package Patrones;
//Esta es la clase llamada Componente Concreto a la cual
//se le pueden agregar nuevas funcionalidades o decoradores
//Implementa la interfaz Component (Sellable)
public class Helado implements Sellable {

    private String descripcion;
    private int precio;

    public Helado() {
    }

    public Helado(String descripcion, int precio) {
        this.descripcion = descripcion;
        this.precio = precio;
    }

    @Override
    public String getDescription() {
        return descripcion;
    }

    @Override
    public int getPrice() {
        return precio;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

}