package Patrones;

public class SalsaDeRon extends HeladoDecorator {

    private final int PRICE = 2500;
    private final String DESCRIPTION = "Salsa de Ron";

    public SalsaDeRon(Sellable sellable) {
        super(sellable);
    }

    @Override
    public int getPrice() {
        return getSellable().getPrice() + PRICE;
    }

    @Override
    public String getDescription() {
        return getSellable().getDescription() + ", " + DESCRIPTION;
    }
}
