package Patrones;


public class DecoratorDemo {

    public static void main(String[] args) {
        //Se instancia el Helado (Componente Concreto) de tipo interfaz Component
        Sellable helado1 = new Helado("Toppings de  Helado de Vainilla: ", 10000);
        
        //El decorador (que puede ser AirCondition, SalsaDeRon o SiropeDeChocolate)
        //recibe como parametro un objeto de tipo Component(Sellable)
        //
        helado1 = new Almendras(helado1);
        helado1 = new SalsaDeRon(helado1);
        helado1 =  new SiropeDeChocolate(helado1); 
        
        
        Sellable helado2 = new Helado("Toppings de  Helado de   Menta: ", 20000);
        
        //El decorador (que puede ser AirCondition, SalsaDeRon o SiropeDeChocolate)
        //recibe como parametro un objeto de tipo Component(Sellable)
        //
        helado2 = new Almendras(helado2);
        helado2 = new SalsaDeRon(helado2);
        helado2 =  new SiropeDeChocolate(helado2); 
        helado2 = new TortitasDeArroz(helado2);
        
        
        System.out.println("Helado 1:\n" + helado1.getDescription() + "\nPrice: " + helado1.getPrice() + "\n\n");
        System.out.println("Helado 2:\n" + helado2.getDescription() + "\nPrice: " + helado2.getPrice() + "\n\n");
    }
}
