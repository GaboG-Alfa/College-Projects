package Patrones;
//Esta es una clase llamada Decorador Concreto
//Para nuestros efectos el aire acondicionado es un accesorio que se puede
//Sellable (vender, vendible) con el automovil
public class Almendras extends HeladoDecorator {

    private final int PRICE = 1000;
    private final String DESCRIPTION = "Almendras";

    public Almendras(Sellable sellable) {
        super(sellable);
    }

    @Override
    public int getPrice() {
        return getSellable().getPrice() + PRICE;
    }

    @Override
    public String getDescription() {
        return getSellable().getDescription() + ", " + DESCRIPTION;
    }
}
