package Patrones;

public class SiropeDeChocolate extends HeladoDecorator {

    private final int PRICE = 600;
    private final String DESCRIPTION = "Sirope de Chocolate";

    public SiropeDeChocolate(Sellable sellable) {
        super(sellable);
    }

    @Override
    public int getPrice() {
        return getSellable().getPrice() + PRICE;
    }

    @Override
    public String getDescription() {
        return getSellable().getDescription() + ", " + DESCRIPTION;
    }
}
