package Patrones;
//Esta es la clase/intefaz llamada Component
//El patr�n Decorator en Java permite agregar nuevas funcionalidades a las clases
// sin modificar su estructura.
//El concepto de este patr�n es agregar de forma din�mica nuevo comportamiento
// o funcionalidades al componente concreto.

public interface Sellable {

    public String getDescription();

    public int getPrice();
}
