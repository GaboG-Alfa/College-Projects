package Patrones;

public class TortitasDeArroz extends HeladoDecorator {

    private final int PRICE = 600;
    private final String DESCRIPTION = "Tortitas de Arroz";

    public TortitasDeArroz(Sellable sellable) {
        super(sellable);
    }

    @Override
    public int getPrice() {
        return getSellable().getPrice() + PRICE;
    }

    @Override
    public String getDescription() {
        return getSellable().getDescription() + ", " + DESCRIPTION;
    }
}
