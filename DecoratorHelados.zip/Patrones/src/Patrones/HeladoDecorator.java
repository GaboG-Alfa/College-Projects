package Patrones;
/*Esta es la clase llamada Decorador
  Es abstracta e implementa el componente (Sellable), se explica asi:
   Entonces, si se tiene una clase abstracta e implementa una interfaz con ella,
   tiene dos opciones para los m�todos de la interfaz:
    a. Implementarlos en la clase abstracta o,
    b. Se dejan abstractos, pero luego algunos de sus hijos m�s concretos necesitan implementarlos,
    que en este caso son los decoradores (MP3_Player, etc...)
*/
public abstract class HeladoDecorator implements Sellable {

    private final Sellable sellable;

    public HeladoDecorator(Sellable sellable) {
        this.sellable = sellable;
    }

    public Sellable getSellable() {
        return sellable;
    }
}
