/*
 * Clase que guarda la información de un evento
 */
package Model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author Gabriel Guzmán Alfaro
 * @version 06/05/2021
 */
public class Evento {
    
    //Atributos
    private String codigo;
    private int cantidad;
    private ObservableList<Asistente> asistenteList;

    /**
     * Contructor
     */
    public Evento() {
        
       this.asistenteList = FXCollections.observableArrayList();;
    }

    /**
     *  
     * @param codigo
     * @param cantidad
     * @param asistenteList 
     */
    public Evento(String codigo, int cantidad, ObservableList<Asistente> asistenteList) {
        this.codigo = codigo;
        this.cantidad = cantidad;
        this.asistenteList = asistenteList;
    }


    /**
     * 
     * @return constructor 
     */
    public String getCodigo() {
        return codigo;
    }

    /**
     * 
     * @param codigo 
     */
    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    /**
     * 
     * @return contador 
     */
    public int getCantidad() {
        return cantidad;
    }

    /**
     * 
     * @param contador 
     */
    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    @Override
    public String toString() {
        
        String mensaje;
        
        mensaje = "codigo=" + codigo + ", cantidad de asistentes=" + cantidad+"\n\nLista de asistentes :";
        
        for(Asistente asistente: asistenteList){
            
            mensaje+=asistente.toString();
            
        }
        
        return mensaje;
    }
    
}
