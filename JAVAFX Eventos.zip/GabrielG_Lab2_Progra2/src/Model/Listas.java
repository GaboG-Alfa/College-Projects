/*
 * Clase que se encarga de guardar la información de las listas 
 */
package Model;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author Gabriel Guzmán Alfaro
 * @version 06/05/2021
 */
public class Listas {

    //Atributos
    private ArrayList<Asistente> asistenteList;
    private ObservableList<Evento> eventoList;
    private BufferedReader lector;
    private int cantidad;

    /**
     * Constructor
     */
    public Listas() {

        asistenteList = new ArrayList();
        eventoList = FXCollections.observableArrayList();
    }

    /**
     *
     * @return asistenteList
     */
    public ArrayList<Asistente> getAsistenteList() {
        return asistenteList;
    }

    /**
     * 
     * @return eventoList
     */
    public ObservableList<Evento> getEventoList() {
        return eventoList;
    }
    
    /**
     *
     * @param asistente
     */
    public void agregarAsistente(int cedula, String nombreYape, int telefono) {

        cantidad += 1;

        asistenteList.add(new Asistente(cantidad, cedula, nombreYape, telefono));

    }

    /**
     *
     * @param asistente
     */
    public void agregarEventos(String codigo, int cantidad, ObservableList<Asistente> asistenteList) {

        eventoList.add(new Evento(codigo, cantidad, asistenteList));
    }
    
    /**
     * 
     * @param codigo
     * @return 
     */
    public boolean siEventoExiste(String codigo){
        
        for(Evento evento: eventoList ){
            
            if(evento.getCodigo().equals(codigo)){
                return true;
            }
        }
        
        
        return false;
    }
    
    /**
     * 
     * @param codigo
     * @return 
     */
    public boolean siLengthMenor7(String codigo){
        
            if(codigo.length()<7){
                return true;
            }
        
        return false;
    }

    /**
     * Abre el archivo 1
     */
    public void manipularArchivo1() {

        try {
            open("ListaAsistentes#1.txt");
        } catch (Exception e) {

        }

    }

    /**
     * Abre el archivo 2
     */
    public void manipularArchivo2() {

        try {
            open("ListaAsistentes#2.txt");
        } catch (Exception e) {

        }

    }

    /**
     * Abre el archivo 3
     */
    public void manipularArchivo3() {

        try {
            open("ListaAsistentes#3.txt");
        } catch (Exception e) {

        }

    }

    /**
     * open a target file to start the edition
     *
     * @param nombreArchivo
     * @throws FileNotFoundException throws a exception when no found file
     */
    public void open(String nombreArchivo) throws FileNotFoundException, IOException {
        lector = new BufferedReader(new FileReader(nombreArchivo));
        String linea;
        linea = "";

        try {
            linea = lector.readLine();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        String dato[];
        String asistenteDato[];
        if (linea != null) {// cuando no está vació
            dato = linea.split("-");// Lee los asitentes separados por un "-"

            for (int i = 0; i < dato.length; i++) {

                asistenteDato = dato[i].split(","); //Lee cada variable separada por ","

                if (asistenteDato == null) {

                    throw new IllegalArgumentException("Error, el archivo está vacío");
                }

                agregarAsistente(Integer.parseInt(asistenteDato[0]), asistenteDato[1], Integer.parseInt(asistenteDato[2]));
            }

        }

        cerrar();
    }

    /**
     * Cierra el archivo que se abrió para manipular
     *
     * @throws IOException si hay un problema retorna una excepción
     */
    public void cerrar() throws IOException {
        lector.close();
    }

    /**
     *
     * @return cantidad
     */
    public int getCantidad() {
        return cantidad;
    }

    /**
     * Imprime todos los asistentes del evento
     */
    public String verEventos() {

        String mensaje;

        mensaje = "";

        //Iterar el texto e imprimir todos los asistentes pero del archivo
        for (Evento evento : eventoList) {
            mensaje += evento.toString();
        }

        return mensaje;
    }

    /**
     * Imprime todos los asistentes del evento
     */
    public String verListas() {

        String mensaje;

        mensaje = "Lista de asistentes al nuevo evento";

        //Iterar el texto e imprimir todos los asistentes pero del archivo
        for (Asistente asistente : asistenteList) {
            mensaje += asistente.toString();
        }

        return mensaje;
    }

}
