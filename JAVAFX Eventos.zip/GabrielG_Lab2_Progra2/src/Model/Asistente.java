package Model;

/**
 *
 * @author Gabriel Guzmán Alfaro
 * @version 1/05/2021
 */
public class Asistente {

    // Define attributes
    private int consecutivo;
    private int cedula;
    private String nombreYape;
    private int telefono;

    /**
     * Constructor without parameters
     */
    public Asistente() {

    }

    /**
     *
     * @param cedula
     * @param nombre
     * @param telefono
     */
    public Asistente(int consecutivo,int cedula, String nombreYape, int telefono) {
        this.cedula = cedula;
        this.nombreYape = nombreYape;
        this.telefono = telefono;
        this.consecutivo = consecutivo;
    }

    /**
     *
     * @return cedula
     */
    public int getCedula() {
        return cedula;
    }

    /**
     *
     * @param cedula
     */
    public void setCedula(int cedula) {
        this.cedula = cedula;
    }

    /**
     *
     * @return nombreYape
     */
    public String getNombre() {
        return nombreYape;
    }

    /**
     *
     * @param nombreYape
     */
    public void setNombre(String nombreYape) {
        this.nombreYape = nombreYape;
    }

    /**
     *
     * @return telefono
     */
    public int getTelefono() {
        return telefono;
    }

    /**
     *
     * @param telefono
     */
    public void setTelefono(int telefono) {
        this.telefono = telefono;
    }

    @Override
    public String toString() {
        return "\n\nAsistente #"+consecutivo+": "+"cedula=" + cedula + ", nombre=" + nombreYape + ", telefono=" + telefono;
    }

}
