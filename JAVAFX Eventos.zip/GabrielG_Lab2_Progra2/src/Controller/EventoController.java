/*
 * Clase que controla todas las view
 */
package Controller;

import Main.EventoMVC_FX;
import Model.Asistente;
import Model.Listas;
import View.MensajesSecundarios;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Gabriel Guzmán Alfaro
 * @verison 06/05/2021
 */
public class EventoController implements Initializable {

    //Atributos
    private EventoMVC_FX modelMain;
    private Listas modelArreglos1;
    private Listas modelArreglos2;
    private Listas modelArreglos3;
    private MensajesSecundarios modelMensajes;
    private ObservableList<Asistente> asistenteList1;
    private ObservableList<Asistente> asistenteList2;
    private ObservableList<Asistente> asistenteList3;
    private static int contadorCargar1;
    private static int contadorCargar2;
    private static int contadorCargar3;
    private static int contadorEventos;
    private static int cantidad1;
    private static int cantidad2;
    private static int cantidad3;
    private static String codigo1 = "";
    private static String codigo2 = "";
    private static String codigo3 = "";
    private static String codigoEvento1;
    private static String codigoEvento2;
    private static String codigoEvento3;

    @FXML
    private Button agregar;
    @FXML
    private Button consultar;
    @FXML
    private Button salir;
    @FXML
    private TextField txtCodigo;
    @FXML
    private Button selectLista1;
    @FXML
    private Button selectLista2;
    @FXML
    private Button selectLista3;
    @FXML
    private Button ver;
    @FXML
    private Button verNueva;
    @FXML
    private TextArea textConsulta;
    @FXML
    private TextArea textNueva;
    @FXML
    private Button atrasLista;
    @FXML
    private Button atrasConsulta;
    @FXML
    private Button atrasListaPrint;

    @FXML
    public void handleButtonClick(ActionEvent event) {

        //Botón agregar
        if (event.getSource() == agregar) {

            contadorEventos += 1;

            if (contadorEventos == 1) {

                codigo1 = txtCodigo.getText();

                if (codigo1.length() < 7) {

                    modelMensajes.lenghtIncorrecto();

                } else {

                    modelMain.selectlista();
                }
            }

            if (contadorEventos == 2) {

                codigo2 = txtCodigo.getText();

                if (codigo2.length() < 7) {

                    modelMensajes.lenghtIncorrecto();

                } else if ((codigo2.equals(codigo1))) {

                    modelMensajes.codigoRepetido();

                } else {

                    modelMain.selectlista();
                }
            }

            if (contadorEventos == 3) {

                codigo3 = txtCodigo.getText();

                if (codigo3.length() < 7) {

                    modelMensajes.lenghtIncorrecto();

                } else if ((codigo3.equals(codigo2)) || (codigo2.equals(codigo1))) {

                    modelMensajes.codigoRepetido();

                } else {

                    modelMain.selectlista();
                }
            }

        }//Fin botón agregar

        //Botón consultar
        if (event.getSource() == consultar) {

            modelMain.consultar();

        }//Fin botón consultar 

        //Botón salir
        if (event.getSource() == salir) {
            System.exit(0);

        }//Fin botón salir 

    }

    @FXML
    public void controlesLista(ActionEvent event) {

        //Muestra la lista 1
        if (event.getSource() == selectLista1) {

            contadorCargar1 += 1;

            //Abrir archivo1
            modelArreglos1.manipularArchivo1();

            modelMensajes.mensajeExito();

            //Determinar código de evento 1
            if (contadorEventos == 1) {

                codigoEvento1 = codigo1;

            } else if (contadorEventos == 2) {

                codigoEvento1 = codigo2;

            } else if (contadorEventos == 3) {

                codigoEvento1 = codigo3;
            }

            modelMain.listaPrint();
        }

        //Muestra la lista 2
        if (event.getSource() == selectLista2) {

            contadorCargar2 += 1;

            //Abrir archivo 2
            modelArreglos2.manipularArchivo2();

            modelMensajes.mensajeExito();

            //Determinar código evento 2
            if (contadorEventos == 1) {

                codigoEvento2 = codigo1;

            } else if (contadorEventos == 2) {

                codigoEvento2 = codigo2;

            } else if (contadorEventos == 3) {

                codigoEvento2 = codigo3;
            }

            modelMain.listaPrint();
        }

        //Muestra la lista 3
        if (event.getSource() == selectLista3) {

            contadorCargar3 += 1;

            //Abrir archivo 3
            modelArreglos3.manipularArchivo3();

            modelMensajes.mensajeExito();

            //Determinar código de evento 3
            if (contadorEventos == 1) {

                codigoEvento3 = codigo1;

            } else if (contadorEventos == 2) {

                codigoEvento3 = codigo2;

            } else if (contadorEventos == 3) {

                codigoEvento3 = codigo3;
            }

            modelMain.listaPrint();
        }

        //Ir atrás 
        Stage stage = (Stage) this.atrasLista.getScene().getWindow();
        stage.close();

    }

    @FXML
    public void mostrarNuevo(ActionEvent event) {

        //Mostrar la lista a agregar
        if (event.getSource() == verNueva) {

            String mensaje = "";

            if (contadorCargar1 == 1) {

                modelArreglos1.manipularArchivo1();

                mensaje = modelArreglos1.verListas();
            }

            if (contadorCargar2 == 1) {

                modelArreglos2.manipularArchivo2();

                mensaje = modelArreglos2.verListas();

            }

            if (contadorCargar3 == 1) {

                modelArreglos3.manipularArchivo3();

                mensaje = modelArreglos3.verListas();

            }

            textNueva.appendText(mensaje);

        }

        //Ir atrás
        if (event.getSource() == atrasListaPrint) {

            Stage stage = (Stage) this.atrasListaPrint.getScene().getWindow();
            stage.close();

        }

    }

    @FXML
    public void showConsulta(ActionEvent event) {

        if (event.getSource() == ver) {

            String mensaje = "Consulta: ";

            //Archivo 1
            if (contadorCargar1 == 1) {

                modelArreglos1.manipularArchivo1();

                for (Asistente asistente : modelArreglos1.getAsistenteList()) {

                    cantidad1 += 1;

                    asistenteList1.add(asistente);
                }

                if (!(modelArreglos1.siEventoExiste(codigoEvento1)) && !(modelArreglos1.siEventoExiste(codigoEvento1))) {

                    modelArreglos1.agregarEventos(codigoEvento1, cantidad1, asistenteList1);

                }

                mensaje += "\n\nEvento con lista #1: " + modelArreglos1.verEventos();

            }//Fin archivo 1

            //Archivo 2
            if (contadorCargar2 == 1) {

                modelArreglos2.manipularArchivo2();

                for (Asistente asistente : modelArreglos2.getAsistenteList()) {

                    cantidad2 += 1;

                    asistenteList2.add(asistente);
                }

                if (!(modelArreglos2.siEventoExiste(codigoEvento2)) && !(modelArreglos2.siLengthMenor7(codigoEvento2))) {

                    modelArreglos2.agregarEventos(codigoEvento2, cantidad2, asistenteList2);

                }

                mensaje += "\n\nEvento con lista #2: " + modelArreglos2.verEventos();

            }//Fin archivo 2

            //Archivo 3
            if (contadorCargar3 == 1) {

                modelArreglos3.manipularArchivo3();

                for (Asistente asistente : modelArreglos3.getAsistenteList()) {

                    cantidad3 += 1;

                    asistenteList3.add(asistente);
                }

                if (!(modelArreglos3.siEventoExiste(codigoEvento3)) && !(modelArreglos3.siLengthMenor7(codigoEvento3))) {

                    modelArreglos3.agregarEventos(codigoEvento3, cantidad3, asistenteList3);

                }

                mensaje += "\n\nEvento con lista #3: " + modelArreglos3.verEventos();

            }

            textConsulta.appendText(mensaje);

        }//Fin archivo 3

        if (event.getSource() == atrasConsulta) {

            Stage stage = (Stage) this.atrasConsulta.getScene().getWindow();
            stage.close();
        }

    }

    /**
     * Initializes the controller cla
     *
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        modelMain = new EventoMVC_FX();
        modelArreglos1 = new Listas();
        modelArreglos2 = new Listas();
        modelArreglos3 = new Listas();
        modelMensajes = new MensajesSecundarios();
        asistenteList1 = FXCollections.observableArrayList();
        asistenteList2 = FXCollections.observableArrayList();
        asistenteList3 = FXCollections.observableArrayList();
    }

}
