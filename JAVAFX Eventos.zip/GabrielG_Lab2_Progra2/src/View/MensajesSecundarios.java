/*
 * Clase que imprime por interfaz JOptionPane mensajes secundarios del programa
 */
package View;

import javax.swing.JOptionPane;

/**
 *
 * @author Gabriel Guzmán Alfaro
 * @verison 06/05/2021
 */
public class MensajesSecundarios {
    
    /**
     * Imprimir el mensaje de carga exitosa del archivo
     */
    public void mensajeExito(){
        
        JOptionPane.showMessageDialog(null, "Archivo cargado con éxito!","Notificación",JOptionPane.INFORMATION_MESSAGE);
    }
    
    /**
     * Imprimir el mensaje de error de evento
     */
    public void mensajeErrorEvento(){
        
        JOptionPane.showMessageDialog(null, "Ese evento no existe!","Error",JOptionPane.INFORMATION_MESSAGE);
    }
    
    /**
     * Imprimir el error de código repetido
     */
    public void codigoRepetido(){
        
        JOptionPane.showMessageDialog(null, "El código ya fue ingresado!","Error",JOptionPane.INFORMATION_MESSAGE);
    }
    
    /**
     * Imprimir el error
     */
    public void lenghtIncorrecto(){
        
        JOptionPane.showMessageDialog(null, "El código es menor de 7 caracteres!","Error",JOptionPane.INFORMATION_MESSAGE);
    }
    
}
