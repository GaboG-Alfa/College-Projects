/*
 * CLase que se encarga de ejecutar las ventanas
 */
package Main;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author Gabriel Guzmán Alfaro
 * @version 06/05/2021
 */
public class EventoMVC_FX extends Application {

    @Override
    public void start(Stage stage) throws Exception {
        stage.setTitle("Event Managers");
        Parent root = FXMLLoader.load(getClass().getResource("/View/Evento.fxml"));
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    /**
     * Abre la ventana de selección de listas
     */
    public void selectlista() {

        try {
            Stage stage = new Stage();
            stage.setTitle("Lista de asistentes en los archivos");
            Parent root;
            root = FXMLLoader.load(getClass().getResource("/View/Lista.fxml"));
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        } catch (IOException ex) {
            Logger.getLogger(EventoMVC_FX.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
   
    /**
     * Abre la ventana de consulta 
     */
   public void consultar(){
       
       try {
            Stage stage = new Stage();
            stage.setTitle("Consulta de la lista de asistentes al evento");
            Parent root;
            root = FXMLLoader.load(getClass().getResource("/View/Consulta.fxml"));
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        } catch (IOException ex) {
            Logger.getLogger(EventoMVC_FX.class.getName()).log(Level.SEVERE, null, ex);
        }
       
   }
   
    /**
     * Abre la ventana de la lista a agregar
     */
    public void listaPrint(){
       
       try {
            Stage stage = new Stage();
            stage.setTitle("Lista a incorporar al nuevo evento");
            Parent root;
            root = FXMLLoader.load(getClass().getResource("/View/ListaPrint.fxml"));
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();
        } catch (IOException ex) {
            Logger.getLogger(EventoMVC_FX.class.getName()).log(Level.SEVERE, null, ex);
        }
       
   }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

}
