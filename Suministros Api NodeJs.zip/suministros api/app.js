const express = require("express");
const { v4 } = require("uuid");
const fs = require("fs");
const { sumistro, requisicion, orden } = require("./schemas");

const app = express();
app.use(express.json());
const port = 3000;

app.post("/api/suministros", (req, res) => {
  const { value, error } = sumistro.validate(req.body);
  if (error) {
    res.status(400).json(error);
  } else {
    value.codigo = v4();
    value.movimientos = [];
    const data = JSON.parse(fs.readFileSync("./data.json"));
    data.suministros.push(value);
    fs.writeFileSync("./data.json", JSON.stringify(data));
    res.json(value);
  }
});

app.get("/api/suministros", (req, res) => {
  const data = JSON.parse(fs.readFileSync("./data.json"));
  res.json(data.suministros);
});

app.put("/api/suministros/:id", (req, res) => {
  const value = req.body;
  if (!value.nombre) {
    res.json(error);
  } else {
    const data = JSON.parse(fs.readFileSync("./data.json"));
    const index = data.suministros.findIndex(
      (el) => el.codigo === req.params.id
    );
    if (index >= 0) {
      data.suministros[index].nombre = value.nombre;
      fs.writeFileSync("./data.json", JSON.stringify(data));
      res.json(value);
    } else {
      res.status(404).send("Id not found");
    }
  }
});

app.delete("/api/suministros/:id", (req, res) => {
  const data = JSON.parse(fs.readFileSync("./data.json"));
  const index = data.suministros.findIndex((el) => el.codigo === req.params.id);
  if (index >= 0) {
    const deleted = data.suministros.splice(index, 1);
    for (let movimiento of deleted[0].movimientos) {
      if (movimiento.tipo === 1) {
        const ordenIndex = data.ordenesdecompra.findIndex(
          (el) => el.codigo === movimiento.codigo
        );
        data.ordenesdecompra.splice(ordenIndex, 1);
      } else if (movimiento.tipo === 2) {
        const requisicionIndex = data.requisiciones.findIndex(
          (el) => el.codigo === movimiento.codigo
        );
        data.requisiciones.splice(requisicionIndex, 1);
      }
    }
    fs.writeFileSync("./data.json", JSON.stringify(data));
    res.json(data.suministros);
  } else {
    res.status(404).send("Id not found");
  }
});

app.post("/api/requisiciones", (req, res) => {
  const { value, error } = requisicion.validate(req.body);
  if (error) {
    res.json(error);
  } else {
    value.fecha = new Date();
    value.codigo = v4();
    const data = JSON.parse(fs.readFileSync("./data.json"));
    data.requisiciones.push(value);
    for (let suministro of value.listaSuministros) {
      const index = data.suministros.findIndex(
        (subEl) => subEl.codigo === suministro.codigo
      );
      if (index < 0) {
        res.status(404).send(`suministro ID ${suministro.codigo} not found`);
        return;
      }
      if (suministro.cantidad > data.suministros[index].cantidad) {
        res.send(`quantity of ${suministro.codigo} exceds current stock`);
        return;
      }
      data.suministros[index].movimientos.push({
        tipo: 2,
        codigo: value.codigo,
        cantidad: suministro.cantidad,
      });
      data.suministros[index].cantidad -= suministro.cantidad;
    }
    fs.writeFileSync("./data.json", JSON.stringify(data));
    res.json(value);
  }
});

app.get("/api/requisiciones", (req, res) => {
  const data = JSON.parse(fs.readFileSync("./data.json"));
  res.json(data.requisiciones);
});

app.post("/api/ordenesdecompra", (req, res) => {
  const { value, error } = orden.validate(req.body);
  if (error) {
    res.json(error);
  } else {
    value.fecha = new Date();
    value.codigo = v4();
    const data = JSON.parse(fs.readFileSync("./data.json"));
    data.ordenesdecompra.push(value);
    for (let orden of value.listaSuministros) {
      const index = data.suministros.findIndex(
        (subEl) => subEl.codigo === orden.codigo
      );
      if (index < 0) {
        res.send(`suministro ID ${orden.codigo} not found`);
        return;
      }
      data.suministros[index].movimientos.push({
        tipo: 1,
        codigo: value.codigo,
        cantidad: orden.cantidad,
      });
      data.suministros[index].cantidad += orden.cantidad;
    }
    fs.writeFileSync("./data.json", JSON.stringify(data));
    res.json(value);
  }
});

app.get("/api/ordenesdecompra", (req, res) => {
  const data = JSON.parse(fs.readFileSync("./data.json"));
  res.json(data.ordenesdecompra);
});

app.listen(port, () => {
  console.log(`Example app listening at http://localhost:${port}`);
});
