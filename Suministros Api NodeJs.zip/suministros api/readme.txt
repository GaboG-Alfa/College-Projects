----------> Run suministros api

1#Step: Ctrl+shift+p
2#Step: npm install -> if is an error with node modules package, delete and enter this node command
3#Step: node app.js