const Joi = require("joi");

const sumistro = Joi.object({
  codigo: Joi.string(),
  nombre: Joi.string().required(),
  cantidad: Joi.number().min(0).required(),
  movimientos: Joi.array().items(
    Joi.object({
      tipo: Joi.number(),
      codigo: Joi.string(),
      cantidad: Joi.number().min(0),
    })
  ),
});

const requisicion = Joi.object({
  codigo: Joi.string(),
  fecha: Joi.date(),
  listaSuministros: Joi.array()
    .items(
      Joi.object({
        codigo: Joi.string().required(),
        cantidad: Joi.number().min(0).required(),
      })
    )
    .required(),
});

const orden = Joi.object({
  codigo: Joi.string(),
  fecha: Joi.date(),
  listaSuministros: Joi.array()
    .items(
      Joi.object({
        codigo: Joi.string().required(),
        cantidad: Joi.number().min(0).required(),
      })
    )
    .required(),
});

module.exports = {
  sumistro,
  requisicion,
  orden,
};
