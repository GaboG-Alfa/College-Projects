package view;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import java.awt.FlowLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import model.Persona;
import controller.ProcesosVacunacion;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.ColaPrioridadException;
import model.PersonaException;

/**
 * 
 * @author Gabriel Gzumán Alfaro
 * @version 7/06/2021
 */
public class Menu extends JFrame {

    private JLabel textoL; // Label para menu
    private JTextField datoL;
    private String buscar,nombre,cedula,edad,vacuna,dosis;
    private JButton opcionA, opcionB, opcionC, opcionD, opcionE, opcionF, opcionG,opcionH,opcionI,exit; // Botones de mostrar y salir
    private Persona persona;
    private ProcesosVacunacion procesos;
    
    /*
    * Clase an�nima para listener, enlace:
    * 
    * http://chuwiki.chuidiang.org/index.php?title=ActionListener#:~:text=%
    * 20ActionListener%20%201%20Los%20ActionListener.%20Los%20componentes,%20...%
    * 20Este%20m%C3%A9todo%20sigue%20presentando...%20More%20
    * 
     */
    public Menu() {
        super("Vacunación");

        setLayout(new FlowLayout(FlowLayout.LEFT, 5, 10));

        // Declaramos los objetos que estaran dentro del JFrame
        opcionA = new JButton("Agregar nueva persona");
        opcionB = new JButton("Mostrar siguiente persona en la cola de vacunación");
        opcionC = new JButton("Mostrar cantidad de personas en la cola de vacunación");
        opcionD = new JButton("Buscar persona en la lista de vacunados y agregarlo a la cola de vacunación");
        opcionE = new JButton("Mostrar total de personas vacunadas por tipo de vacuna y total general");
        opcionF = new JButton("Mostrar lista de personas con vacunas pendientes:");
        opcionG = new JButton("Mostrar la lista de todas las personas registradas en orden ascendente:");
        opcionH = new JButton("Mostrar la lista de todas las personas registradas en orden descendente:");
        opcionI= new JButton("Promedio de edad de las personas vacunadas (método recursivo)");
        
        exit = new JButton("Salir");

        // Agregamos los objetos en el orden deseado al JFrame
        add(opcionA);
        add(opcionB);
        add(opcionC);
        add(opcionD);
        add(opcionE);
        add(opcionF);
        add(opcionG);
        add(opcionH);
        add(opcionI);
        add(exit);
        
        
        try {
            //Objeto de procesos
            procesos= new ProcesosVacunacion();
        } catch (ColaPrioridadException ex) {
            JOptionPane.showMessageDialog(null, "Error: "+ex, "Error",  
                            JOptionPane.INFORMATION_MESSAGE);
        }
      

        // Programamos los Listener de cada Boton
        opcionA.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent evento) {

                    boolean verificaCola=false;
                    boolean verificaLista=false;
                    
                    cedula= JOptionPane.showInputDialog(null, "Cédula: ", "Ingrese la cédula de la persona",
                            JOptionPane.INFORMATION_MESSAGE);
                    
                    verificaCola=procesos.verificarPersonaCola(Integer.parseInt(cedula));
                    
                    verificaLista=procesos.verificarPersonaCola(Integer.parseInt(cedula));
                    
                    //Se verifica las colas
                    if(verificaCola==false|| verificaLista==false){
                        nombre= JOptionPane.showInputDialog(null,"Nombre: ", "Ingrese el nombre de la persona",
                                JOptionPane.INFORMATION_MESSAGE);
                        edad= JOptionPane.showInputDialog(null,"Edad: ", "Ingrese la edad de la persona",
                                JOptionPane.INFORMATION_MESSAGE);
                        vacuna= JOptionPane.showInputDialog(null,"Vacuna (Escoja -> Vacuna 1 , Vacuna2, Vacuna3): ", "Ingrese la vacuna de la persona",
                                JOptionPane.INFORMATION_MESSAGE);
                        
                        dosis=vacuna;
                        
                        try {
                            persona= new Persona(Integer.parseInt(cedula),nombre,Integer.parseInt(edad),Integer.parseInt(vacuna),Integer.parseInt(dosis));
                        } catch (PersonaException ex) {
                            JOptionPane.showMessageDialog(null, "Error: "+ex, "Error",  
                            JOptionPane.INFORMATION_MESSAGE);
                        }
                        
                        try {
                            procesos.agregarPersonaACola(persona);
                        } catch (PersonaException ex) {
                            JOptionPane.showMessageDialog(null, "Error: "+ex, "Error",  
                            JOptionPane.INFORMATION_MESSAGE);
                        }
                    
                    }else{
                        
                         JOptionPane.showMessageDialog(null, "Persona ya registrada: ", "No se puede volver a registrar",  
                            JOptionPane.INFORMATION_MESSAGE);
                        
                    }
                
            }

        });

        
        opcionB.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evento) {

                try {
                    JOptionPane.showMessageDialog(null, "Siguiente persona en vacunación: " + procesos.mostrarSiguientePersonaVacunacion(), "Tamaño de la lista",
                            JOptionPane.INFORMATION_MESSAGE);
                } catch (ColaPrioridadException ex) {
                      JOptionPane.showMessageDialog(null, "Error: "+ex, "Error",  
                            JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });

      
        opcionC.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evento) {

                JOptionPane.showMessageDialog(null, "Cantidad de personas en cola de vacunación: " + procesos.cantidadEnCola(), "Faltan de vacunarse",
                            JOptionPane.INFORMATION_MESSAGE);

            }
        });

       
        opcionD.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evento) {
                
                cedula= JOptionPane.showInputDialog(null, "Cédula: ", "Ingrese la cédula de la persona",
                            JOptionPane.INFORMATION_MESSAGE);
                
                JOptionPane.showMessageDialog(null, "Persona en lista de vacunados: "+procesos.faltantesDosis(Integer.parseInt(cedula)), "Ingrese la cédula de la persona",
                            JOptionPane.INFORMATION_MESSAGE);

            }
        });

        
        opcionE.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evento) {

              
                    JOptionPane.showMessageDialog(null, "Cantidad de vacunados: " + procesos.cantidadTipoVacunados(), "Vacunados",
                            JOptionPane.INFORMATION_MESSAGE);
                
            }
        });
        
       

        opcionF.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evento) {

                JOptionPane.showMessageDialog(null, "Cantidad de faltantes: " + procesos.imprimirFaltantes(), "Faltantes",
                            JOptionPane.INFORMATION_MESSAGE);
              
            }
        });


        opcionG.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evento) {

                JOptionPane.showMessageDialog(null, "Lista ascendente: " + procesos.imprimirAscendente(), "Lista",
                        JOptionPane.INFORMATION_MESSAGE);
            }
        });
        
        opcionH.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evento) {

                JOptionPane.showMessageDialog(null, "Lista Descendente: " + procesos.imprimirDescendente(), "Lista",
                        JOptionPane.INFORMATION_MESSAGE);
            }
        });
        
        opcionI.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evento) {

                JOptionPane.showMessageDialog(null, "Promedio: " + procesos.imprimirPromedio(), "Promedio",
                        JOptionPane.INFORMATION_MESSAGE);
            }
        });
        

        exit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evento) {
                JOptionPane.showMessageDialog(null, "Saldra de la aplicacion", "WARNING", JOptionPane.WARNING_MESSAGE);
                System.exit(0);
            }
        });

    }

    // Metodo main()
    public static void main(String args[]) {
        Menu listen = new Menu();
        listen.setLocationRelativeTo(null);
        listen.setSize(300, 175);
        listen.setVisible(true);
    }

}
