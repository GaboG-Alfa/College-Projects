/*
 * La clase que se encarga de guardar la infromación de una excpeción para persona
 */
package model;

/**
 *
 * @author Gabriel Guzmán Afaro
 * @version 07/06/2021
 */
public class PersonaException extends Exception{
    
    /**
     * 
     * @param excepcion 
     */
     public PersonaException(String excepcion) {
        super(excepcion);
    }
    
}
