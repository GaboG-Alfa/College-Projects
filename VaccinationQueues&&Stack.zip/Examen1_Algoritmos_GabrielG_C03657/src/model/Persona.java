/*
 * Clase que se encarga de guardar información de una persona a vacunar
 */
package model;

/**
 *
 * @author Gabriel
 * @version 07/06/2021
 */
public class Persona {

    //Atributos 
    private Integer cedula;
    private String nombre;
    private Integer edad;
    private Integer vacuna;
    private Integer dosis;

    public Persona() {
    }
    
    

    /**
     * 
     * @param cedula
     * @param nombre
     * @param edad
     * @param vacuna
     * @param dosis 
     */
    public Persona(Integer cedula, String nombre, Integer edad, Integer vacuna, Integer dosis) throws PersonaException {
        this.setCedula(cedula);
        this.setNombre(nombre);
        this.setEdad(edad);
        this.setVacuna(vacuna);
        this.setDosis(dosis);
    }

    
    
    /**
     * 
     * @return  cedula
     */
    public Integer getCedula(){
        
        return cedula;
    }

    /**
     * 
     * @param cedula 
     */
    public void setCedula(Integer cedula) throws PersonaException {
        
        if(cedula<0){
            throw new PersonaException("La cédula es menor a 0");
        }
        
        this.cedula = cedula;
    }

    /**
     * 
     * @return nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * 
     * @param nombre 
     */
    public void setNombre(String nombre) throws PersonaException {
        
        if(nombre==""){
            throw new PersonaException("El nombre está vacío");
        }
        
        this.nombre = nombre;
    }

    /**
     * 
     * @return edad
     */
    public Integer getEdad() {
        return edad;
    }

    /**
     * 
     * @param edad 
     */
    public void setEdad(Integer edad) throws PersonaException {
        
        if(edad<0 && edad>120){
            
           throw new PersonaException("La edad debe estar entre 1 y 120 inclusive");
        }
        
        this.edad = edad;
    }

    /**
     * 
     * @return vacuna
     */
    public Integer getVacuna() {
        return vacuna;
    }

    /**
     * 
     * @param vacuna 
     */
    public void setVacuna(Integer vacuna) {
        this.vacuna = vacuna;
    }

    /**
     * 
     * @return dosis
     */
    public Integer getDosis() {
        return dosis;
    }

    /**
     * 
     * @param dosis 
     */
    public void setDosis(Integer dosis) {
        this.dosis = dosis;
    }
    
    public void conteoDosis(){
        dosis--;
    }

    @Override
    public String toString() {
        return "\nPersona{" + "cedula=" + cedula + ", nombre=" + nombre + ", edad=" + edad + ", vacuna=" + vacuna + ", dosis=" + dosis + '}';
    }

    
}


