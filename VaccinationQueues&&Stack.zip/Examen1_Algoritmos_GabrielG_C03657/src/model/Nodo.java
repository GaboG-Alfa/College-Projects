/*
 * La clase que se encarga de guaradar un nodo con atributo de persona
 */
package model;

/**
 *
 * @author Gabriel Guzmán Alfaro
 * @version 07/06/2021
 */
public class Nodo {
    
    //Atributo
    private Persona persona;
    private Nodo siguiente;
    private Nodo anterior;

    /**
     * 
     * @return persona 
     */
    public Persona getPersona() {
        return persona;
    }

    /**
     * 
     * @param persona 
     */
    public void setPersona(Persona persona) {
        this.persona = persona;
    }

    /**
     * 
     * @return siguiente 
     */
    public Nodo getSiguiente() {
        return siguiente;
    }

    /**
     * 
     * @param siguiente 
     */
    public void setSiguiente(Nodo siguiente) {
        this.siguiente = siguiente;
    }

    /**
     * 
     * @return anterior
     */
    public Nodo getAnterior() {
        return anterior;
    }

    /**
     * 
     * @param anterior 
     */
    public void setAnterior(Nodo anterior) {
        this.anterior = anterior;
    }
    
    
    
}
