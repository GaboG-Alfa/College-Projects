package model;

/**
 *
 * @author Gabriel Guzmán Alfaro
 * @version 20/05/2021
 */
public class ColaPrioridad {

    //Atributo
    Nodo front, reer;
    int size;


    /**
     * Constructor
     *
     * @param tamano
     */
    public ColaPrioridad() throws ColaPrioridadException {

        if (size < 0) {
            throw new ColaPrioridadException("El tamaño ingresado es menor a 0");
        }
        front = reer = null;
        size = 0;
    }

    /**
     *
     * @throws PersonaException
     */
    public void ordenarPrioridad() throws PersonaException {

        boolean ordenado = false;

        while (ordenado == false) {
            ordenado=true;
            for (Nodo temp = front; temp.getSiguiente() != null; temp = temp.getSiguiente()) {
                if (temp.getPersona().getEdad() > temp.getSiguiente().getPersona().getEdad()) {

                    Persona personaTemp = temp.getPersona();
                    temp.setPersona(temp.getSiguiente().getPersona());
                    temp.getSiguiente().setPersona(personaTemp);
                    ordenado = false;
                }
            }
        }

    }

    /**
     *
     * @return primero
     */
    public boolean isEmpty() {
        return front == null;
    }

    /**
     * Inserta la persona
     *
     * @param persona
     */
    public void enqueue(Persona persona){

        Nodo nuevo = new Nodo();
        nuevo.setPersona(persona);
        if (front == null) {

            front = nuevo;

        } else {
            reer.setSiguiente(nuevo);
        }
        reer = nuevo;
        size++;
    }

    /**
     * Extrae el primer elemento
     *
     * @return tmp
     */
    public Persona dequeue() throws ColaPrioridadException {

        if (front == null) {
            throw new ColaPrioridadException("La cola está vacía");
        }
        
        Persona tmp = front.getPersona();
        front = front.getSiguiente();

        size--;
        return tmp;

    }

    /**
     *
     * @return primero.getPersona()
     */
    public Nodo front(){

        return front;

    }

    /**
     * Retorna el tamaño de la cola
     *
     * @return tamano
     */
    public int size() {
        return size;

    }

  
}
