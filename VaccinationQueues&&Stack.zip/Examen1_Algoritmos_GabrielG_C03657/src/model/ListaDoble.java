/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Gabriel Guzmán Alfaro
 */
public class ListaDoble {

    private Nodo primero;
    private Nodo ultimo;

    /**
     * Agregar nodo al inicio de la lista
     *
     * @param persona
     */
    public boolean insertarInicio(Persona persona) {

        //Por punteros
        Nodo nuevo = new Nodo();

        nuevo.setPersona(persona);

        if (primero == null) {

            primero = ultimo = nuevo;

            return true;
        }

        nuevo.setSiguiente(primero);

        primero.setAnterior(nuevo);

        primero = nuevo;

        return true;
    }

    /**
     * Agregar nodo al final de la lista con punteros
     *
     * @param persona
     */
    public boolean insertarFinal(Persona persona) {

        //Por punteros
        Nodo nuevo = new Nodo();

        nuevo.setPersona(persona);

        if (ultimo == null) {

            primero = ultimo = nuevo;

            return true;

        }

        ultimo.setSiguiente(nuevo);
        nuevo.setAnterior(ultimo);
        ultimo = nuevo;

        return true;
    }

    /**
     * Eliminar un nodo al inicio
     *
     * @return boolean
     */
    public boolean eliminarInicio() {

        if (primero == null) {

            return false;
        }

        if (primero == ultimo) {
            primero = ultimo = null;
            return true;
        } else {

            primero = primero.getSiguiente();

            primero.setAnterior(null);

            return true;
        }

    }

    /**
     * Eliminar un nodo al final
     *
     * @return boolean
     */
    public boolean eliminarFinal() {

        if (ultimo == null) {
            return false;
        }
        if (primero == ultimo) {
            primero = ultimo = null;

            return true;

        } else {

            ultimo = ultimo.getAnterior();

            ultimo.setSiguiente(null);

            return true;
        }

    }

    /**
     * Elimina un elemento por dato
     *
     * @param dato
     * @return boolean
     */
    public boolean eliminarDato(Persona persona) {

        if (primero == null) {

            return false;

        }

        if (primero.getPersona() == persona) {

            this.eliminarInicio();

            return true;

        } else if (ultimo.getPersona() == persona) {

            this.eliminarFinal();

            return true;

        } else {

            Nodo temp;

            temp = primero.getSiguiente();

            while (temp.getSiguiente() != null) {

                if (temp.getPersona() == persona) {

                    temp.getAnterior().setSiguiente(temp.getSiguiente());
                    temp.getSiguiente().setAnterior(temp.getAnterior());

                    return true;
                }

                temp = temp.getSiguiente();
            }

            return true;
        }
    }

    /**
     * Agregar nodo al final de la lista con punteros
     *
     * @param dato
     */
    public boolean insertarDespues(Persona predecesor, Persona dato) {

        //Por punteros
        Nodo nuevo = new Nodo();

        nuevo.setPersona(dato);

        if (primero == null) {
            return false;
        }

        if (ultimo.getPersona() == predecesor) {
            this.insertarFinal(dato);

            return true;
        }

        for (Nodo temp = primero; temp != ultimo; temp = temp.getSiguiente()) {

            if (temp.getPersona() == predecesor) {

                nuevo.setSiguiente(temp.getSiguiente());
                nuevo.setAnterior(temp);
                temp.setSiguiente(nuevo);
                nuevo.getSiguiente().setAnterior(nuevo);

                return true;

            }

        }

        return true;
    }

    /**
     *
     * @return hilera
     */
    public String imprimirPrimeroUltimo() {

        String salida = "";

        for (Nodo temp = primero; temp != null; temp = temp.getSiguiente()) {

            salida += "--->" + temp.getPersona();
        }

        return salida;
    }

    /**
     *
     * @param cedula
     * @return boolean
     */
    public Persona existeDosis(int cedula) {

        for (Nodo temp = ultimo; temp != null; temp = temp.getAnterior()) {

            if (temp.getPersona().getCedula() == cedula) {

                return temp.getPersona();
            }

        }

        return null;
    }

    /**
     *
     * @param cedula
     * @return boolean
     */
    public boolean existe(int cedula) {

        for (Nodo temp = ultimo; temp != null; temp = temp.getAnterior()) {

            if (temp.getPersona().getCedula() == cedula) {

                return true;
            }

        }

        return false;
    }

    /**
     *
     * @param cedula
     * @return boolean
     */
    public String cantidadXVacuna() {

        int contVacuna1 = 0;
        int contVacuna2 = 0;
        int contVacuna3 = 0;
        int totalVacunados = 0;

        for (Nodo temp = ultimo; temp != null; temp = temp.getAnterior()) {

            if (temp.getPersona().getVacuna() == 1) {

                contVacuna1++;
            }

            if (temp.getPersona().getVacuna() == 2) {

                contVacuna2++;
            }

            if (temp.getPersona().getVacuna() == 3) {

                contVacuna3++;
            }

        }

        totalVacunados = contVacuna1 + contVacuna2 + contVacuna3;

        return "\nVacuna1: " + contVacuna1 + "personas" + " \nVacuna2: " + contVacuna2 + "personas" + "\nVacuna3: " + contVacuna3 + "personas" + "\nTotalDeVacunados: " + totalVacunados;
    }

    public String dosisFaltantes() {

        String salida = "";

        int contDosis = 0;

        for (Nodo temp = ultimo; temp != null; temp = temp.getAnterior()) {

            if (temp.getPersona().getDosis() > 0) {

                contDosis++;

                salida += "--->Persona con dosis: " + temp.getPersona();

            }
        }

        return salida += "\n Cantidad total de faltantes: " + contDosis;
    }

    public String imprimirPromedio(){
        
        int promedioV=0;
        int promedioResult=0;
        int cont=0;
        
        for (Nodo temp = ultimo; temp != null;) {

            cont++;
            
            promedioV+=temp.getPersona().getEdad();
        }
        
        promedioResult=promedioV/cont;
        
        return "\nPromedio: "+promedioResult;
    }
    
    /**
    public int promedio(int promedio,Nodo temp ) {

       return temp.getPersona().getEdad() + promedio(temp.getPersona().getEdad(), temp.getSiguiente());    
    }**/

    /**
     *
     * @return hilera
     */
    public String imprimirUltimoPrimero() {

        String salida = "";

        for (Nodo temp = ultimo; temp != null; temp = temp.getAnterior()) {

            salida += "--->" + temp.getPersona();
        }

        return salida;
    }

}
