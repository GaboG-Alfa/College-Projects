/*
 * Clase que se encarga de realizar los procesos de vacunación
 */
package controller;
import model.ColaPrioridad;
import model.ColaPrioridadException;
import model.ListaDoble;
import model.Nodo;
import model.Persona;
import model.PersonaException;

/**
 *
 * @author Gabriel Guzmán ALfaro
 * @version 07/06/2021
 */
public class ProcesosVacunacion {
    
    private ColaPrioridad cola;
    private ListaDoble lista;

    /**
     * Constructor
     */
    public ProcesosVacunacion() throws ColaPrioridadException {
       cola= new ColaPrioridad();
        lista= new ListaDoble();
    }
    
    /**
     * 
     * @param cedula
     * @return boolean
     */
    public boolean verificarPersonaCola(Integer cedula){
        
        
        for (Nodo temp = cola.front(); temp != null; temp = temp.getSiguiente()) {

            if(cedula==temp.getPersona().getCedula()){
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * 
     * @param cedula
     * @return boolean
     */
    public boolean verificarPersonaLista(Integer cedula){
       
        boolean verifica=false;
       
        verifica= lista.existe(cedula);
       
        if(verifica==true){
            return true;
        }
        
        return false;
    }
    
    /**
     * 
     * @param persona 
     */
    public void agregarPersonaACola(Persona persona) throws PersonaException{
        
         for (Nodo temp = cola.front(); temp != null; temp = temp.getSiguiente()) {

            if(temp.getPersona().getCedula()==persona.getCedula()){
                
                throw new PersonaException("La cédula esttá repetida");
            }
        }

        cola.enqueue(persona);
        cola.ordenarPrioridad();
    }
    
    public Persona mostrarSiguientePersonaVacunacion() throws ColaPrioridadException{
       
        Persona persona = new Persona();
        persona=cola.dequeue();
        
        persona.conteoDosis();
        
        this.agregarAListaDoble(persona);
        
        return persona;  
    }
    
    
    private void agregarAListaDoble(Persona persona){
        
        lista.insertarFinal(persona);
        
    }
    
    public int cantidadEnCola(){
    
        return cola.size();
    }
    
    public String faltantesDosis(int cedula){
        
        int verifica=0;
        Persona persona =new Persona();
        
        persona=lista.existeDosis(cedula);
        
       verifica= persona.getDosis();
       
       if(verifica>0){
           
           lista.eliminarDato(persona);
           cola.enqueue(persona);
       }
       
       return persona.toString();
    }
    
    
    public String cantidadTipoVacunados(){
        
        return lista.cantidadXVacuna();
        
    }
    
    public String imprimirFaltantes(){
        
        return lista.dosisFaltantes();
    }
    
    public String imprimirAscendente(){
        
        return lista.imprimirPrimeroUltimo();
    }
    
    public String imprimirDescendente(){
        
        return lista.imprimirPrimeroUltimo();
    }
    
    public String imprimirPromedio(){
    
        return lista.imprimirPromedio();
    }
}
