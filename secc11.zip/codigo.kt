<Chronometer
    android:layout_width="match_parent"
    android:layout_height="match_parent"/>
<DatePicker
    android:layout_width="match_parent"
    android:layout_height="match_parent"/>
<TimePicker
    android:layout_width="match_parent"
    android:layout_height="match_parent"/>
 
 
<NumberPicker
    android:id="@+id/npEjemplo"
    android:layout_width="wrap_content"
    android:layout_height="130dp"
    android:theme="@style/NumberPickerTheme"/>
<TextView
    android:id="@+id/tvNumberPicker"
    android:layout_width="wrap_content"
    android:layout_height="wrap_content"
    android:layout_marginTop="16dp"
    android:text="Fecha seleccionada: " />
 
<me.tankery.lib.circularseekbar.CircularSeekBar
    android:layout_width="200dp"
    android:layout_height="wrap_content"
    android:layout_gravity="center_horizontal"
    android:layout_margin="10dp"
    app:cs_progress = "30"
    app:cs_max = "100"
    app:cs_negative_enabled="true"
    app:cs_circle_style="round"
    app:cs_circle_stroke_width="8dp"
    app:cs_pointer_stroke_width="24dp"
    app:cs_pointer_halo_width="14dp"/>
