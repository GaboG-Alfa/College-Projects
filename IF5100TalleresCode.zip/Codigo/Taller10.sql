EXEC sp_spaceused @oneresultset = 1, @updateusage = 'true';

BACKUP DATABASE DEMOAZURE
TO DISK = 'var/opt/mssql/backup/DEMOAZURE_FullBK.bak'
WITH FORMAT, NAME = 'DEMOAZURE-FullBackup';

BACKUP DATABASE DEMOAZURE
TO DISK = 'var/opt/mssql/backup/DEMOAZURE_DiffBK.bak'
WITH DIFFERENTIAL, NAME = 'DEMOAZURE-DifferentialBackup';

CREATE MASTER KEY ENCRYPTION BY PASSWORD = 'GaboC03657'
GO
CREATE CERTIFICATE NuevoCertificado
WITH SUBJECT = 'CertificadoTaller10'