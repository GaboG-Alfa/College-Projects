IF OBJECT_ID (N'FN_FechaReserva', N'TF') IS NOT NULL
    DROP FUNCTION FN_FechaReserva;


CREATE FUNCTION FN_FechaReserva(@Fecha datetime)
RETURNS TABLE 
AS
RETURN
SELECT R.NumeroReserva,H.NumeroHabitacion,H.TipoCama, R.CheckIn, R.CheckOut
FROM hotelucrso.RESERVA AS R
INNER JOIN hotelucrso.HABITACION AS H
ON R.IdHabitacion = H.IdHabitacion
WHERE CAST (CheckIn AS datetime )= @Fecha

SELECT * FROM dbo.FN_FechaReserva('2023-03-05')