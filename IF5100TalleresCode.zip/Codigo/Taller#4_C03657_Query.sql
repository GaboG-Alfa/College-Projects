ALTER SCHEMA hotelucrso TRANSFER OBJECT:: dbo.VW_DetalleReservas
GO

SELECT * FROM hotelucrso.VW_DetalleReservas