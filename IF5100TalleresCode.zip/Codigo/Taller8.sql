CREATE TRIGGER TR_After_Insert ON hotelucrso.Habitacion
AFTER INSERT
AS BEGIN
PRINT 'TRANSACCI�N DE INSERCI�N NO PERMITIDA';
ROLLBACK TRANSACTION;
END
INSERT INTO hotelucrso.HABITACION(NumeroHabitacion,TipoCama,Precio) VALUES ('H19','Matrimonial',40000);

CREATE TRIGGER TR_After_CapitalLetter ON hotelucrso.Cliente
AFTER INSERT
AS BEGIN
UPDATE hotelucrso.Cliente SET NombreCompleto = UPPER(NombreCompleto) WHERE IdCliente IN (SELECT IdCliente FROM inserted)
END

INSERT INTO hotelucrso.CLIENTE(IdCiudad,NombreCompleto,NumeroTelefono,Email) VALUES(21,'gabriel guzman alfaro',64480449,'gabrielguzmanalfaro@gmail.com');

SELECT * FROM hotelucrso.Cliente WHERE Email='gabrielguzmanalfaro@gmail.com';

CREATE TRIGGER TR_Not_Table ON DATABASE
FOR CREATE_TABLE
AS BEGIN 
PRINT 'NO ESTA PERMITIDO CREAR NUEVAS TABLAS'
ROLLBACK TRANSACTION
END

CREATE TABLE ClienteVIP(
Id int identity(1,1)NOT NULL,
Nombre varchar(50)NOT NULL,
Apellido varchar(50)
CONSTRAINT PK_ClienteVIP PRIMARY KEY (Id)
)