CREATE DATABASE Northwind;
Select * from sys.database_files

SELECT
  name 'Logical Name',
  type_desc   'File type',
  FILEGROUP_NAME(data_space_id)  'Filegroup' , 
  size * 8/1024 'Size (MB)',
  growth 'Autogrowth / Maxsize',
  physical_name 'Path' 
FROM sys.database_files;

ALTER DATABASE Northwind ADD FILEGROUP SECUNDARIO;

ALTER DATABASE Northwind
ADD FILE(
    NAME=Northwind_Parte1,
    FILENAME='/var/opt/mssql/data/Northwind_Secundario.ndf',
    SIZE=15MB,
    MAXSIZE=50MB,
    FILEGROWTH=5MB
)
TO FILEGROUP SECUNDARIO;

SELECT DATABASEPROPERTYEX('Northwind','isAutoCreateStatistics')
ALTER DATABASE Northwind SET AUTO_CREATE_STATISTICS OFF
SELECT DATABASEPROPERTYEX('Northwind','isAutoCreateStatistics')
ALTER DATABASE Northwind SET AUTO_CREATE_STATISTICS ON
SELECT DATABASEPROPERTYEX('Northwind','isAutoCreateStatistics')
SELECT DATABASEPROPERTYEX('Northwind','IsAutoShrink')
ALTER DATABASE Northwind SET AUTO_SHRINK ON;
SELECT DATABASEPROPERTYEX('Northwind','IsAutoShrink')

EXEC sp_helpdb @dbname='Northwind'
EXEC sp_helpfilegroup
EXEC sp_helpfiles
DBCC SHRINKFILE(Northwind_Parte1);
DBCC SHRINKFILE(NorthwindData);

USE[master]
GO
EXEC master.dbo.sp_detach_db @dbname=N'Northwind'
GO

USE[master]
GO
CREATE DATABASE [NorthWind] ON
(FILENAME = N'/home/ubuntusql/SQLdata/Northwind.mdf'),
(FILENAME = N'/home/ubuntusql/SQLdata/Northwind_log.ldf'),
(FILENAME = N'/home/ubuntusql/SQLdata/Northwind_Secundario.ndf')
FOR ATTACH
GO

EXEC sp_helpdb 'Northwind'
CREATE DATABASE nombresnapshot ON
   (NAME = 'NorthwindData', FILENAME = '/home/ubuntusql/SQLdata/Snapshots/NorthwindData.ss'), 
   (NAME = 'Northwind_Parte1', FILENAME = '/home/ubuntusql/SQLdata/Snapshots/NorthwindParte1.ss')
AS SNAPSHOT OF Northwind;

SELECT COUNT(*) FROM [Northwind].[dbo].[Order Details]

DELETE FROM [Northwind].[dbo].[Order Details]

SELECT COUNT(*) FROM [Northwind].[dbo].[Order Details]


INSERT INTO Northwind.dbo.[Order Details]
SELECT *
FROM nombresnapshot.dbo.[Order Details];

SELECT COUNT(*) FROM [Northwind].[dbo].[Order Details]