CREATE PROCEDURE SP_VISTA_DETALLES_RESERVAS AS SELECT * FROM hotelucrso.VW_DetalleReservas;

EXECUTE dbo.SP_VISTA_DETALLES_RESERVAS;

CREATE PROCEDURE SP_NUMERO_TIPO_CAMAS @tipoCama varchar(50)
AS SELECT COUNT(R.IdCliente) AS "Total de usuarios" FROM hotelucrso.RESERVA R
INNER JOIN hotelucrso.HABITACION H on R.IdHabitacion = H.IdHabitacion
WHERE H.TipoCama = @tipoCama 

EXECUTE dbo.SP_NUMERO_TIPO_CAMAS @tipoCama = 'Individual';

CREATE PROCEDURE SP_ROWBYROW_CLIENTES
AS BEGIN
DECLARE @NombreCompleto varchar(50), @NumeroTelefono varchar(50), @Email varchar(50);
  DECLARE cursor_Cliente CURSOR FOR SELECT  NombreCompleto, NumeroTelefono, Email FROM hotelucrso.Cliente;
  OPEN cursor_Cliente;
  FETCH NEXT FROM cursor_Cliente INTO @NombreCompleto,@NumeroTelefono,@Email;
  WHILE @@FETCH_STATUS = 0
  BEGIN
  PRINT @NombreCompleto +' '+ @NumeroTelefono + ' '+@Email;
  FETCH FROM cursor_Cliente INTO @NombreCompleto,@NumeroTelefono,@Email;
  END
  CLOSE cursor_Cliente;
  DEALLOCATE cursor_Cliente;
END
GO

EXECUTE dbo.SP_ROWBYROW_CLIENTES

CREATE PROCEDURE SP_UPDATE_FK_CIUDAD
AS BEGIN
DECLARE @IdCliente int;
DECLARE @TotalCiudades int , @NumberRandom int
SET @TotalCiudades = (SELECT COUNT(IdCiudad)FROM hotelucrso.Ciudad)
    DECLARE cursor_Cliente CURSOR FOR SELECT IdCliente FROM hotelucrso.CLIENTE;
	OPEN cursor_Cliente;
	FETCH NEXT FROM cursor_Cliente INTO @IdCliente;
	WHILE @@FETCH_STATUS=0
	BEGIN UPDATE hotelucrso.CLIENTE
	SET IdCiudad = (SELECT CAST(RAND() * @TotalCiudades AS INT)AS Random)
	WHERE IdCliente = @IdCliente
	FETCH NEXT FROM cursor_Cliente INTO @IdCliente;
	END
	CLOSE cursor_Cliente;
	DEALLOCATE cursor_Cliente;
END

EXECUTE dbo.SP_UPDATE_FK_CIUDAD

SELECT * FROM hotelucrso.CLIENTE;