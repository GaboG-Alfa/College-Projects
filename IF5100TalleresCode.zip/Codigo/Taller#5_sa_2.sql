USE DEMOAZURE;
INSERT INTO hotelucrso.CLIENTE(IdCiudad,NombreCompleto,NumeroTelefono,Email) VALUES (73,'Anderson Guzm�n Alfaro','83978727','andersonguzmanalfaro@gmail.com');
