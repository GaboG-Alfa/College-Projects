SELECT c.name, tbl.name as table_name, c.is_masked, c.masking_function 
FROM sys.masked_columns AS c 
JOIN sys.tables AS tbl ON c.[object_id] = tbl.[object_id] 
WHERE is_masked = 1;

ALTER TABLE hotelucrso.Habitacion
ALTER COLUMN Precio ADD MASKED WITH (FUNCTION = 'default()')

GRANT SELECT ON hotelucrso.Habitacion to TestMask;

SELECT * FROM hotelucrso.HABITACION

SELECT * FROM hotelucrso.CLIENTE
