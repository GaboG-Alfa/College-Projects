ALTER TABLE hotelucrso.Cliente
ALTER COLUMN Email ADD MASKED WITH (FUNCTION = 'email()');
SELECT * FROM hotelucrso.CLIENTE;
GRANT unmask TO TestMask;
SELECT * FROM hotelucrso.CLIENTE;
Revoke unmask TO TestMask;
SELECT * FROM hotelucrso.CLIENTE;