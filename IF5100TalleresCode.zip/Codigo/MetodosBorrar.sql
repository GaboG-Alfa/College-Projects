--Drop certificate NuevoCertificado
USE DEMOAZURE;  
DROP MASTER KEY;  
GO 