SELECT * FROM hotelucrso.Cliente;
INSERT INTO CLIENTE (IdCiudad,NombreCompleto,NumeroTelefono,Email) VALUES (72,'Gabriel Guzm�n Alfaro','64480449','gabrielguzmanalfaro@gmail.com');
SELECT * FROM hotelucrso.Cliente WHERE NombreCompleto = 'Gabriel Guzm�n Alfaro';
SELECT * FROM hotelucrso.CIUDAD;
INSERT INTO hotelucrso.CLIENTE(IdCiudad,NombreCompleto,NumeroTelefono,Email) VALUES (73,'Anderson Guzm�n Alfaro','83978727','andersonguzmanalfaro@gmail.com');
SELECT * FROM hotelucrso.Cliente WHERE NombreCompleto = 'Anderson Guzm�n Alfaro';

