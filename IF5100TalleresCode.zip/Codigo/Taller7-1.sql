USE DEMOAZURE
SELECT * FROM hotelucrso.HABITACION
SELECT AVG(Precio) AS 'Promedio de Precios',
MIN(Precio) AS 'Precio M�nimo',
MAX(Precio) AS 'Precio M�ximo'
FROM hotelucrso.HABITACION

SELECT COUNT(HABITACION.NumeroHabitacion) AS 'Cantidad de reservas', HABITACION.NumeroHabitacion FROM hotelucrso.RESERVA
INNER JOIN
hotelucrso.HABITACION ON RESERVA.IdHabitacion = HABITACION.IdHabitacion GROUP BY HABITACION.NumeroHabitacion;

SELECT @@VERSION As 'Versi�n SQL ', @@SERVERNAME As 'Servidor de BD',@@MAX_CONNECTIONS As '# Conexiones permitidas';

IF OBJECT_ID (N'nombre de funcion', N'TF') IS NOT NULL
    DROP FUNCTION nombre de funcion;


CREATE FUNCTION FN_FechaReserva(@Fecha datetime)
RETURNS TABLE 
AS
RETURN
SELECT R.NumeroReserva,H.NumeroHabitacion,H.TipoCama, R.CheckIn, R.CheckOut
FROM hotelucrso.RESERVA AS R
INNER JOIN hotelucrso.HABITACION AS H
ON R.IdHabitacion = H.IdHabitacion
WHERE CAST (CheckIn AS datetime )= @Fecha




SELECT * FROM dbo.FN_FechaReserva('2023-03-05')