/*
 * Clase que se encarga de guardar información de un libro 
 */
package model.libro;

import model.excepciones.LibroException;

/**
 *
 * @author Gabriel
 * @version 19/07/2021
 */
public class Libro implements Comparable<Libro> {

    //Atributos 
    private Integer isbn;
    private String nombre;
    private String autor;
    private Integer anno;
            

    /**
     * Constructor
     */
    public Libro() {
    }

    /**
     * 
     * @param isbn
     * @param nombre
     * @param autor
     * @param anno
     */
    public Libro(Integer isbn, String nombre,String autor ,Integer anno) {
        this.isbn = isbn;
        this.nombre = nombre;
        this.autor = autor;
        this.anno= anno;
    }
    
    /**
     * 
     * @param isbn
     */
    public Libro(Integer isbn) {
        this.isbn = isbn;
    }
    
    /**
     * 
     * @param autor
     */
    public Libro(String autor) {
        this.autor = autor;
    }

    /**
     * 
     * @return anno 
     */
    public int getAnno() {
        return anno;
    }

    /**
     * 
     * @param anno
     */
    public void setAnno(int anno) {
        this.anno = anno;
    }

    /**
     *
     * @return isbn
     */
    public int getIsbn() {
        return isbn;
    }

    /**
     *
     * @param isbn
     */
    public void setIsbn(Integer isbn) throws LibroException {
        
        if(isbn<0){
            
            throw new LibroException("La cédula debe ser mayor a 0");
        }
        
        this.isbn = isbn;
    }

    /**
     * 
     * @return nombre 
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * 
     * @param nombre 
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * 
     * @return 
     */
    public String getAutor() {
        return autor;
    }

    /**
     * 
     * @param autor 
     */
    public void setAutor(String autor) {
        this.autor = autor;
    }
    
    

    @Override
    public String toString() {
        return "Libro{" + "isbn=" + isbn + ", nombre=" + nombre + ", autor=" + autor + ", anno=" + anno + '}';
    }
    
    
    // Overriding the compare method to sort the isbn
    @Override
    public int compareTo(Libro p) {
            return this.isbn.compareTo(p.getIsbn());
    }
   
   
}


