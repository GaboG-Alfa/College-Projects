/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.arbol;

import model.libro.Libro;


/**
 *
 * @author Gabriel Guzmán Alfaro
 * @version 10/06/2021
 */
public class Nodo <T extends Comparable<T>> {
    
    //Atributo
    private T dato;
    private Nodo<T> izquierda;
    private Nodo<T> derecha;

    /**
     * 
     * @param dato 
     */
    public Nodo(T dato) {
        this.dato = dato;
    }
    
    
    /**
     * 
     * @return dato 
     */
    public T getDato() {
        return dato;
    }

    /**
     * 
     * @param dato 
     */
    public void setDato(T dato) {
        this.dato = dato;
    }

    /**
     * 
     * @return izquierda 
     */
    public Nodo<T> getIzquierda() {
        return izquierda;
    }

    /**
     * 
     * @param izquierda 
     */
    public void setIzquierda(Nodo<T> izquierda) {
        this.izquierda = izquierda;
    }

    /**
     * 
     * @return derecha 
     */
    public Nodo<T> getDerecha() {
        return derecha;
    }

    /**
     * 
     * @param derecha 
     */
    public void setDerecha(Nodo<T> derecha) {
        this.derecha = derecha;
    }
    
}
