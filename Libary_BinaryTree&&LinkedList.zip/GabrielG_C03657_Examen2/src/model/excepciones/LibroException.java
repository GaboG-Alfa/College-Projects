/*
 * La clase que se encarga de guardar la infromación de una excepción para libro
 */
package model.excepciones;


/**
 *
 * @author Gabriel Guzmán Afaro
 * @version 19/07/2021
 */
public class LibroException extends Exception{
    
    /**
     * 
     * @param excepcion 
     */
     public LibroException(String excepcion) {
        super(excepcion);
    }
    
}
