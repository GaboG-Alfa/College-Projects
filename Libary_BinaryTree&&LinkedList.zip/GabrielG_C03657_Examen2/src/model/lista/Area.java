/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.lista;

import model.arbol.ArbolBinario;

/**
 *
 * @author GABRIEL
 */
public class Area {
    
    //Atributes
    private String nombre;
    private ArbolBinario arbol;

    /**
     * 
     * @param nombre 
     */
    public Area(String nombre) {
       this.nombre=nombre;
       arbol= new ArbolBinario();
    }
    
    
     /**
     * 
     * @return arbol
     */
    public ArbolBinario getArbol() {
        return arbol;
    }
    
    /**
     * 
     * @param arbol 
     */
    public void setArbol(ArbolBinario arbol) {
        this.arbol = arbol;
    }

    /**
     * 
     * @return nombre 
     */
    public String getNombre() {
        return nombre;
    }
    
    /**
     * 
     * @param nombre 
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Area(String nombre, ArbolBinario arbol) {
        this.nombre = nombre;
        this.arbol = arbol;
    }
    
    
    
}
