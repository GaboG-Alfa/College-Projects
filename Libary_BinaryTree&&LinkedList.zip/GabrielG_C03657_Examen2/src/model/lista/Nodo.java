/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.lista;

/**
 *
 * @author Gabriel Guzmán Alfaro
 */
public class Nodo {
    
    //Atributes
    private Area area;
    private Nodo siguiente;

   
    
    /**
     * 
     * @return siguiente
     */
    public Nodo getSiguiente() {
        return siguiente;
    }
    
    /**
     * 
     * @param siguiente 
     */
    public void setSiguiente(Nodo siguiente) {
        this.siguiente = siguiente;
    }
    
    /**
     * 
     * @return area 
     */
    public Area getArea() {
        return area;
    }
    
    /**
     * 
     * @param area 
     */
    public void setArea(Area area) {
        this.area = area;
    }
    
    
    
}
