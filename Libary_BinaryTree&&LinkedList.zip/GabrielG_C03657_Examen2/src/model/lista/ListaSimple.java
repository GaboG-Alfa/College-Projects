/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.lista;

import model.excepciones.ArbolBinarioException;
import model.excepciones.MenuException;


/**
 *
 * @author Gabriel Guzmán Alfaro
 */
public class ListaSimple {
    
    //Atributo
    private Nodo primero;
    private Nodo ultimo;


    /**
     * Agregar nodo al inicio de la lista con ciclo
     *
     * @param area
     */
    public Nodo buscar(Area area)throws MenuException {

        if (primero == null) {

            return null;
        }

        for (Nodo temp = primero; temp != null; temp = temp.getSiguiente()) {

            if (temp.getArea().getNombre().equals(area.getNombre())) {
                return temp;
            }
            
            
        }

        throw new MenuException("El área no existe");
    }
    
    /**
     * Agregar nodo al inicio de la lista con ciclo
     *
     * @param area
     */
    public Nodo buscarIsbn(Integer isbn)throws MenuException {

        for (Nodo temp = primero; temp != null; temp = temp.getSiguiente()) {

            try {
                if (temp.getArea().getArbol().find(isbn)!=null) {
                    return temp;
                }
            } catch (ArbolBinarioException ex) {
                return  null;
            }
            
        }

        return null;
    }
    

    /**
     * Agregar nodo al final de la lista con punteros
     *
     * @param area
     */
    public void insertarFinalPuntero(Area area){
        
        //Por punteros
        Nodo nuevo = new Nodo();

        nuevo.setArea(area);

        if (ultimo == null) {

            primero = ultimo = nuevo;

        } else {

            ultimo.setSiguiente(nuevo);
            ultimo = nuevo;
        }
    }

    /**
     * Eliminar un nodo al inicio
     *
     * @return boolean
     */
    public boolean eliminarInicio() {

        if (primero == null) {
            
            return false;
        }

        if (primero == ultimo) {
            primero = ultimo = null;
        } else {

            primero = primero.getSiguiente();
        }

        return true;

    }

    /**
     * Eliminar un nodo al final
     *
     * @return boolean
     */
    public boolean eliminarFinal() {

        if (ultimo == null) {
            return false;
        }
        if (primero == ultimo) {
            primero = ultimo = null;
        } else {

            Nodo temp;

            for (temp = primero; temp.getSiguiente() != ultimo; temp = temp.getSiguiente());
            temp.setSiguiente(null);

            ultimo = temp;
        }
        return true;

    }

    /**
     * Elimina un elemento por area
     *
     * @param area
     * @return boolean
     */
    public boolean eliminarareaPuntero(Area area) {

        if (primero == null) {

            return false;

        }

        if (primero.getArea() == area) {

            this.eliminarInicio();

            return true;

        } else if (ultimo.getArea() == area) {

            this.eliminarFinal();

            return true;

        } else {

            Nodo temp;

            temp = primero;

            while (temp.getSiguiente() != null) {

                if (temp.getSiguiente().getArea() == area) {

                    temp.setSiguiente(temp.getSiguiente().getSiguiente());

                    return true;
                }

                temp = temp.getSiguiente();
            }

        }

        return false;
    }

    /**
     * 
     * @return imprimir recursivo 
     */
    public String imprimirRecursivo() {

        return imprimirRecursivo(primero);
    }
    
    /**
     * 
     * @param temp
     * @return imprimir recursivo 
     */
    private String imprimirRecursivo(Nodo temp) {

        if (temp == null) {

            return "";
        }

        return "--->" + temp.getArea().getArbol().enOrden() + imprimirRecursivo(temp.getSiguiente());
    }

  

    /**
     *
     * @return hilera
     */
    public String imprimir() {

        String salida = "";

        for (Nodo temp = primero; temp != null; temp = temp.getSiguiente()) {

            salida += "--->" + temp.getArea().getArbol().enOrden();
        }

        return salida;
    }

}
