//package Sockets;

/**
 *El Cliente se ejecuta de esta manera en el shell del sistema operativo:
 *java Cliente servidor_IP numero_puerto
 *java Client 127.0.0.1 6990
 */
import java.io.*;
import java.net.*;
import javax.swing.*;

/**
 *
 * @author Gabriel Guzmán Alfaro
 * @author Carlos Jesús Guevara
 * @version 11/06/2021
 */
public class Client {

    //Atributos
    private Socket conectorSimple;
    private ObjectInputStream entrada;
    private ObjectOutputStream salida;

    /**
     * Constructor
     *
     * @param nombreServidor
     * @param puerto
     */
    public Client(String nombreServidor, String puerto) {
        try {
            conectorSimple = new Socket(nombreServidor, Integer.parseInt(puerto));
        } catch (Exception e) {
            System.err.println(e);
        }
    }

    /**
     * Método para obtener flujos
     */
    public void obtenerFlujos() {
        try {
            salida = new ObjectOutputStream(conectorSimple.getOutputStream());
            salida.flush();
            entrada = new ObjectInputStream(conectorSimple.getInputStream());
        } catch (Exception e) {
            System.err.println(e);
        }
    }

    /**
     * Método para cerrar flujos
     */
    public void cerrarFlujos() {
        try {
            entrada.close();
            salida.close();
            conectorSimple.close();
        } catch (Exception e) {
            System.err.println(e);
        }
    }

    /**
     * Método para recibir el mensaje
     *
     * @return mensaje
     */
    public String recibirMensaje() {
        String mensaje = "";
        try {
            mensaje = (String) entrada.readObject();
        } catch (Exception e) {
            System.err.println(e);
        }
        return mensaje;
    }

    /**
     * Método para enviar el mensaje
     *
     * @param mensaje
     */
    public void enviarMensaje(String mensaje) {
        try {
            salida.writeObject(mensaje);
        } catch (Exception e) {
            System.err.println(e);
        }
    }

    /**
     * main
     *
     * @param arg
     */
    public static void main(String arg[]) {
        if (arg.length == 2) {
            Client c = new Client(arg[0], arg[1]);
            c.obtenerFlujos();
            String mensaje = "";
            //mientras es distinto a cerrar asc y cerrar des hace un ciclo
            while ((!mensaje.toLowerCase().equals("cerrar asc")) && (!mensaje.toLowerCase().equals("cerrar des"))) {
                mensaje = JOptionPane.showInputDialog("MENSAJE");
                c.enviarMensaje(mensaje);
                String respuesta = c.recibirMensaje();
                System.out.println(respuesta);
            }
            c.cerrarFlujos();
        } else {
            System.out.println("No se han recibido los 2 parametros necesarios...");
        }
        System.exit(0);
    }
}
