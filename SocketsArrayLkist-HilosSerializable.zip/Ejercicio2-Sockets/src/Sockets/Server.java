//package Sockets;

/**
 *java Server numero_puerto
 *java Server 6990
 */
import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.Collections;

/**
 *
 * @author Gabriel Guzmán Alfaro
 * @author Carlos Jesús Guevara
 * @version 11/06/2021
 */
public class Server {

    private ServerSocket conectorDeServicio;
    private Socket conectorSimple;
    private ObjectInputStream entrada;
    private ObjectOutputStream salida;
    private static ArrayList<String> mensajesList;

    /**
     * Constructor
     *
     * @param puerto
     */
    public Server(String puerto) {
        try {
            conectorDeServicio = new ServerSocket(Integer.parseInt(puerto));
        } catch (Exception e) {
            System.err.println(e);
        }
        mensajesList = new ArrayList<>();
    }

    /**
     * Método para aceptar la conexión
     */
    public void aceptarConexion() {
        try {
            conectorSimple = conectorDeServicio.accept();
        } catch (Exception e) {
            System.err.println(e);
        }
    }

    /**
     * Método para obtener los flujos
     */
    public void obtenerFlujos() {
        try {
            entrada = new ObjectInputStream(conectorSimple.getInputStream());
            salida = new ObjectOutputStream(conectorSimple.getOutputStream());
            salida.flush();
        } catch (Exception e) {
            System.err.println(e);
        }
    }

    /**
     * Método para cerrar flujos
     */
    public void cerrarFlujos() {
        try {
            entrada.close();
            salida.close();
            conectorSimple.close();
            salida.flush();
        } catch (Exception e) {
            System.err.println(e);
        }
    }

    /**
     * Método para recibir el mensaje
     *
     * @return mensaje
     */
    public String recibirMensaje() {
        String mensaje = "";
        try {
            mensaje = (String) entrada.readObject(); //Se lee un objeto String
        } catch (Exception e) {
            System.err.println(e);
        }
        return mensaje;
    }

    /**
     * Método para enviar el mensaje
     *
     * @param mensaje
     */
    public void enviarMensaje(String mensaje) {
        try {
            salida.writeObject(mensaje);
        } catch (Exception e) {
            System.err.println(e);
        }
    }

    /**
     * main
     *
     * @param arg
     */
    public static void main(String arg[]) {
        if (arg.length == 1) {
            Server s = new Server(arg[0]);
            String mensaje = "";
            String txt = "";
            s.aceptarConexion();
            s.obtenerFlujos();

            //Ciclo de flujos
            while ((!mensaje.toLowerCase().equals("cerrar asc")) && (!mensaje.toLowerCase().equals("cerrar des"))) {
                mensaje = s.recibirMensaje();
                s.enviarMensaje(mensaje);
                System.out.println(mensaje);
                System.out.println("Se envio de vuelta el mensaje");
                if ((!mensaje.toLowerCase().equals("cerrar asc")) && (!mensaje.toLowerCase().equals("cerrar des"))) {
                    mensajesList.add(mensaje.toUpperCase());
                }
            }

            //Si se ordena de forma ascendente
            if (mensaje.toLowerCase().equals("cerrar asc")) {
                Collections.sort(mensajesList);
                for (String mensajes : mensajesList) {
                    txt += mensajes + " , ";
                }
                System.out.println("Palabras con orden ascendente: " + txt);
            }

            //Si se ordena de forma descendente
            if (mensaje.toLowerCase().equals("cerrar des")) {
                Collections.sort(mensajesList, Collections.reverseOrder());
                for (String mensajes : mensajesList) {
                    txt += mensajes + " , ";
                }
                System.out.println("Palabras con orden descendente: " + txt);
            }
            s.cerrarFlujos();
        } else {
            System.out.println("No se ha recibido el parametro del puerto del Servidor...");
        }
    }
}
