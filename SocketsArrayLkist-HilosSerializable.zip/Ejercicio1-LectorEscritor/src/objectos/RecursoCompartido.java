package objectos;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

/**
 *
 * @author Gabriel Guzmán Alfaro
 * @author Carlos Guevara Ramirez
 * @version 11/06/2021
 */
public class RecursoCompartido {

    //Ruta compartida
    private File file;
    private Mensaje mensaje;
    private FileOutputStream fwOutput;
    private ObjectOutputStream bwOutput;
    private FileInputStream fwInput;
    private ObjectInputStream bwInput;

    /**
     * Constructor
     */
    public RecursoCompartido() {
        this.crearArchivo();
        this.establecerFlujosEscritor();
        this.establecerFlujosLector();
    }

    /**
     * Define la ruta del archivo en el que vamos a trabajar, y lo crea si no
     * existe
     */
    private void crearArchivo() {
        try {
            String ruta = "Mensaje.src";
            file = new File(ruta);
            //Si el archivo no existe, se creara
            if (!file.exists()) {
                file.createNewFile();
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    /**
     * Este metodo se encarga de escribir nuestro objeto en nuestro archivo
     *
     * @param mensaje Instancia serializable de Mensaje
     */
    public void escribirMensaje(Mensaje mensaje) {
        try {
            this.establecerFlujosEscritor();
            if (bwOutput != null) {
                bwOutput.writeObject(mensaje);
                bwOutput.flush();
                bwOutput.close();
            }
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    /**
     *
     * @return Retorna el mensaje leido en nuestro archivo
     * @throws IOException
     * @throws ClassNotFoundException
     */
    public Mensaje leerMensaje() throws IOException, ClassNotFoundException {
        mensaje = null;
        this.establecerFlujosLector();
        if (bwInput != null) {
            synchronized (this) {
                mensaje = (Mensaje) bwInput.readObject();
                bwInput.close();
                return mensaje;
            }
        }
        return null;
    }

    /**
     * Crea el flujo de salida entre el cliente y el archivo
     */
    private void establecerFlujosEscritor() {
        try {
            fwOutput = new FileOutputStream(this.file);
            bwOutput = new ObjectOutputStream(this.fwOutput);
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    /**
     * Crea el flujo de entrada entre el cliente y el archivo
     */
    private void establecerFlujosLector() {
        try {
            fwInput = new FileInputStream(this.file);
            bwInput = new ObjectInputStream(this.fwInput);
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

    public Mensaje getMensaje() {
        return mensaje;
    }

}
