
package objectos;

import java.io.Serializable;

/**
 *
 * @author Gabriel Guzmán Alfaro
 * @author Carlos Guevara Ramirez
 * @version 11/06/2021
 */
public class Mensaje implements Serializable{
    
    //Atributos
    private String texto;
    private int contador=0;
    private boolean fueLeido=false;

    /**
     * 
     * @param texto 
     */
    public Mensaje(String texto) {
        this.texto = texto;
    }

    /**
     * 
     * @param texto
     * @param contador 
     */
    public Mensaje(String texto, int contador) {
        this.texto = texto;
        this.contador=contador;
    }

    /**
     * 
     * @return texto 
     */
    public String getTexto() {
        return texto;
    }

    /**
     * 
     * @param texto 
     */
    public void setTexto(String texto) {
        this.texto = texto;
    }

    /**
     * 
     * @return contador 
     */
    public int getContador() {
        return contador;
    }

    /**
     * 
     * @param contador 
     */
    public void setContador(int contador) {
        this.contador = contador;
    }

    /**
     * 
     * @return fueLeido 
     */
    public boolean getFueLeido() {
        return fueLeido;
    }

    /**
     * 
     * @param fueLeido 
     */
    public void setFueLeido(boolean fueLeido) {
        this.fueLeido = fueLeido;
    }

    @Override
    public String toString() {
        return texto+ " #"+this.getContador()+"\tFue leido: "+this.getFueLeido();
    }
}
