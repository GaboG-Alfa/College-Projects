package objectos;

import java.io.IOException;

/**
 *
 * @author Gabriel Guzmán Alfaro
 * @author Carlos Guevara Ramirez
 * @version 11/06/2021
 */
public class Escritor implements Runnable {

    //Atributos
    private RecursoCompartido recurso;
    private Mensaje mensaje;

    /**
     *
     * @param recurso
     */
    public Escritor(RecursoCompartido recurso) {
        this.recurso = recurso;
    }

    @Override
    public void run() {
        recurso.escribirMensaje(null);
        mensaje = null;
        int ciclos = 10;
        //Se escriben 10 datos en el archivo
        for (int i = 0; i < ciclos; i++) {
            try {
                mensaje = recurso.leerMensaje();
                if (mensaje != null && !mensaje.getFueLeido()) {
                    System.out.println("Escritor esta intentando escritor, esperando que mensaje sea leido");
                    synchronized (recurso) {
                        recurso.wait();
                    }
                }
                if (mensaje == null || mensaje.getFueLeido()) {
                    mensaje = new Mensaje("Mensaje de prueba", i + 1);
                    mensaje.setFueLeido(false);
                    recurso.escribirMensaje(mensaje);
                    System.out.println("El escritor escribio: " + mensaje);
                    mensaje = null;
                }
                synchronized (recurso) {
                    recurso.notifyAll();
                }
                if (ciclos < 10) {
                    System.out.println("Tratando de escribir");
                    Thread.sleep((int) Math.floor(Math.random() * (2000 - 500 + 1) + 500));
                } else {
                    Thread.sleep(2000);
                }

            } catch (IOException | ClassNotFoundException | InterruptedException ex) {
                System.out.println(ex.getMessage());
            }

        }
        synchronized (recurso) {
            recurso.notifyAll();
        }
    }

}
