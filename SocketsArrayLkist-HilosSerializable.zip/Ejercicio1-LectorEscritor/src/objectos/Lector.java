package objectos;

import java.io.IOException;

/**
 *
 * @author Gabriel Guzmán Alfaro
 * @author Carlos Guevara Ramirez
 * @version 11/06/2021
 */
public class Lector implements Runnable {

    //Atributos
    private final RecursoCompartido recurso;
    private Mensaje mensaje;

    /**
     *
     * @param recurso
     */
    public Lector(RecursoCompartido recurso) {
        this.recurso = recurso;
    }

    @Override
    public void run() {
        mensaje = null;
        int i=0;
        int ciclos =10;
        //Se realiza la lectura 10 veces del archivo
        for (; i < ciclos; i++) {
            try {
                System.out.println("Se espera mientras el escritor escribe......");
                synchronized (recurso) {
                    recurso.wait();
                }
                mensaje = recurso.leerMensaje();
                if (mensaje != null) {
                    if (!mensaje.getFueLeido()) {
                        mensaje.setFueLeido(true);
                        recurso.escribirMensaje(mensaje);
                        System.out.println("El lector leyo el mensaje: " + mensaje.toString()+"\n\n");
                    } else {
                        i++;
                    }
                }
                Thread.sleep((long) Math.floor(Math.random() * (2000 - 500 + 1) + 500));
            } catch (IOException | ClassNotFoundException | InterruptedException ex) {
                System.out.println("Se esta tratando de leer");
            }
        }

    }

}
