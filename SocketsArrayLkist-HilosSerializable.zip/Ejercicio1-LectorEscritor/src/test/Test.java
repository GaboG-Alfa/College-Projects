
package test;

import objectos.Escritor;
import objectos.Lector;
import objectos.RecursoCompartido;

/**
 *
 * @author Gabriel Guzmán Alfaro
 * @author Carlos Guevara Ramirez
 * @version 11/06/2021
 */
public class Test {

    /**
     * 
     * @param args 
     */
    public static void main(String[] args) {
        RecursoCompartido recurso = new RecursoCompartido();
        Runnable escritor = new Escritor(recurso);
        Runnable lector = new Lector(recurso);
        new Thread(escritor).start();
        new Thread(lector).start();
        
    }
}
