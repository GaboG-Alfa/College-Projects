import tkinter as tk
from tkinter import ttk, messagebox
import random
import numpy as np
import sqlite3
import pandas as pd
import math
import matplotlib.pyplot as plt
from PIL import Image, ImageDraw, ImageTk

class Ruleta:
    def __init__(self, root):
        self.root = root
        self.root.title("Ruleta de Casino")

        self.main_frame = tk.Frame(root)
        self.main_frame.pack(padx=15, pady=20)

        self.canvas = tk.Canvas(self.main_frame, width=500, height=400)
        self.canvas.pack(side=tk.LEFT, padx=15)
        self.canvas.pack_propagate(False)

        self.table_canvas = tk.Canvas(self.main_frame, width=200, height=300, bg='green', highlightthickness=0)
        self.table_canvas.pack(side=tk.LEFT, padx=15)
        self.table_canvas.pack_propagate(False)
        
        self.center_x = 300
        self.center_y = 200
        self.radius = 150
        self.angle = 0

        self.min_bet = 10
        self.max_bet = 100000
        self.num_players = 2

        self.arrow = None
        
        self.sectors = 37  # Números del 0 al 36
        self.colors = ["green"] + ["red", "black"] * 18
        
        self.results = [0] * self.sectors  # Para registrar los resultados de Montecarlo

        self.create_board()
        self.create_table_board()
        self.create_bet_frame()
        self.create_buttons()

        self.result_label = ttk.Label(root, text="", font=("Times New Roman", 16))
        self.result_label.pack(pady=10)
        
    def create_board(self):
        # Crear la ruleta gráfica
        self.canvas.create_oval(150, 50, 450, 350, fill='white')

        self.numbers_positions = {}
        self.text_ids = []
        self.rect_ids = []

        self.create_wheel_background()

        self.numbers_order = [0, 32, 15, 19, 4, 21, 2, 25, 17, 34, 6, 27, 13, 36, 11, 30, 8, 23,
                                10, 5, 24, 16, 33, 1, 20, 14, 31, 9, 22, 18, 29, 7, 28, 12, 35, 3, 26]

        for i, number in enumerate(self.numbers_order):
            angle = ((i - 0.5) / 37) * 360
            x = 300 + 130 * np.cos(np.radians(angle))
            y = 200 - 130 * np.sin(np.radians(angle))
            text_color = 'white'
            
            text = self.canvas.create_text(x, y, text=str(number), fill=text_color, font=("Times New Roman", 10, "bold"))
            
            self.numbers_positions[number] = (x, y)
            self.text_ids.append(text)

        self.canvas.create_oval(275, 175, 325, 225, fill='yellow')

    def create_wheel_background(self):
        self.wheel_background = []
        for i in range(0, 37):
            start_angle = ((i - 1) / 37) * 360
            extent = 360 / 37
            color = 'green' if i == 0 else 'red' if i % 2 == 0 else 'black'
            arc_id = self.canvas.create_arc(150, 50, 450, 350, start=start_angle, extent=extent, fill=color, outline=color)
            self.wheel_background.append(arc_id)

    def create_table_board(self):
        # Crear un tablero de números al estilo de los casinos
        rows, cols = 3, 12
        cell_width, cell_height = 50, 50
        table_width = cols * cell_width
        table_height = rows * cell_height

        # Ajustar tamaño del canvas según el tamaño del tablero
        self.table_canvas.config(width=table_width, height=table_height)

        self.number_labels = []
        for row in range(rows):
            for col in range(cols):
                number = row * cols + col + 1
                x1 = col * cell_width
                y1 = row * cell_height
                x2 = x1 + cell_width
                y2 = y1 + cell_height
                color = 'red' if number % 2 == 0 else 'black'
                label = self.table_canvas.create_text((x1 + x2) / 2, (y1 + y2) / 2, text=str(number), fill=color, font=("Times New Roman", 14, "bold"))
                
                # Agregar líneas divisorias
                self.table_canvas.create_line(x1, y1, x2, y1, fill='white', width=1)  # línea superior
                self.table_canvas.create_line(x1, y1, x1, y2, fill='white', width=1)  # línea izquierda
                self.table_canvas.create_line(x2, y1, x2, y2, fill='white', width=1)  # línea derecha
                self.table_canvas.create_line(x1, y2, x2, y2, fill='white', width=1)  # línea inferior
                
                # Dibujar rectángulo con esquinas ligeramente curvadas
                curve_radius = 5
                self.table_canvas.create_arc(x1, y1, x1 + curve_radius * 2, y1 + curve_radius * 2, start=90, extent=90, outline=color, width=1, style=tk.ARC)
                self.table_canvas.create_arc(x2 - curve_radius * 2, y1, x2, y1 + curve_radius * 2, start=0, extent=90, outline=color, width=1, style=tk.ARC)
                self.table_canvas.create_arc(x1, y2 - curve_radius * 2, x1 + curve_radius * 2, y2, start=180, extent=90, outline=color, width=1, style=tk.ARC)
                self.table_canvas.create_arc(x2 - curve_radius * 2, y2 - curve_radius * 2, x2, y2, start=270, extent=90, outline=color, width=1, style=tk.ARC)

                self.number_labels.append((label, number))

    def create_bet_frame(self):
        # Crear el marco para las apuestas de ambos jugadores
        bet_frame = tk.Frame(self.root)
        bet_frame.pack()

        player1_frame = tk.Frame(bet_frame)
        player1_frame.pack(side=tk.LEFT, padx=10)
        self.create_bet_options(player1_frame, 1)

        player2_frame = tk.Frame(bet_frame)
        player2_frame.pack(side=tk.RIGHT, padx=10)
        self.create_bet_options(player2_frame, 2)

    def create_bet_options(self, frame, player):
        # Crear los campos de entrada para las apuestas de cada jugador
        setattr(self, f'bet_amount_{player}', tk.DoubleVar())
        getattr(self, f'bet_amount_{player}').set(0)
        
        setattr(self, f'bet_type_{player}', tk.StringVar())
        getattr(self, f'bet_type_{player}').set("Par")

        setattr(self, f'number_bet_{player}', tk.IntVar())
        getattr(self, f'number_bet_{player}').set(1)

        tk.Label(frame, text=f"Jugador {player} - Cantidad de Apuesta:", font=("Times New Roman",11)).pack()
        tk.Entry(frame, textvariable=getattr(self, f'bet_amount_{player}')).pack()

        tk.Label(frame, text=f"Jugador {player} - Tipo de Apuesta:", font=("Times New Roman",11)).pack()
        tk.OptionMenu(frame, getattr(self, f'bet_type_{player}'), "Par", "Impar", "Número").pack()

        tk.Label(frame, text=f"Jugador {player} - Número de Apuesta:", font=("Times New Roman",11)).pack()
        tk.Spinbox(frame, from_=0, to=36, textvariable=getattr(self, f'number_bet_{player}')).pack()

    def create_buttons(self):
        # Botón para girar la ruleta
        self.spin_button = tk.Button(self.root, text="Girar la Ruleta", font=("Times New Roman",11), command=self.spin_wheel)
        self.spin_button.pack(pady=10)

        # Botón para ejecutar la simulación Montecarlo
        self.simulate_button = tk.Button(self.root, text="Simular Montecarlo", font=("Times New Roman", 11), command=self.simulate_montecarlo)
        self.simulate_button.pack(pady=10)
        
    def spin_wheel(self):

        for player in range(1, self.num_players + 1):
            bet_amount = getattr(self, f'bet_amount_{player}').get()
            bet_number = getattr(self, f'number_bet_{player}').get()
        
            if bet_amount < self.min_bet or bet_amount > self.max_bet:
                messagebox.showerror("Error de Apuesta", f" Jugador {player}: La cantidad de apuesta debe estar entre ${self.min_bet} y ${self.max_bet}.")
                return

            if bet_number < 0 or bet_number >= self.sectors:
                messagebox.showerror("Error de Apuesta", "Por favor, ingrese un número entre 0 y 36.")
                return

        # Girar la ruleta y determinar el número ganador
        self.spin_animation()
    
    def spin_animation(self):
        steps = 100
        duration = 10
        total_angle = 360  # Ángulo total de una vuelta completa
        current_angle = 0

        for step in range(steps):
            angle_shift = total_angle * (step / steps)
            
            for i in range(1, 38):
                angle = ((i - 0.5) / 37) * 360 + angle_shift
                x = 300 + 130 * np.cos(np.radians(angle))
                y = 200 - 130 * np.sin(np.radians(angle))
                self.canvas.coords(self.text_ids[i-1], x, y)
                
            self.update_wheel_background(angle_shift)

            self.root.update()
            self.root.after(duration)

        # Determinar el número ganador
        number = random.randint(0, 36)

        index = self.numbers_order.index(number)
        number_index = (index + 1) % len(self.numbers_order)
        win_number = self.numbers_order[number_index]
        
        # Mostrar la flecha indicando el número ganador
        if self.arrow:
            self.canvas.delete(self.arrow)
        x, y = self.numbers_positions[win_number]
        self.arrow = self.canvas.create_line(300, 200, x, y, arrow=tk.LAST, fill="blue", width=2)

        results_text = f"Resultado: {number} ({'Par' if number % 2 == 0 else 'Impar'})\n"
        results_text += self.display_result(1, number)
        results_text += self.display_result(2, number)

        # Crear una nueva ventana para mostrar los resultados
        result_window = tk.Toplevel(self.root)
        result_window.title("Resultados de la Ruleta")

        # Configurar el tamaño de la ventana
        result_window.geometry("350x200")

        # Calcular la posición para centrar la ventana en la pantalla
        window_width = result_window.winfo_reqwidth()
        window_height = result_window.winfo_reqheight()
        position_right = int(result_window.winfo_screenwidth() / 2 - window_width / 2)
        position_down = int(result_window.winfo_screenheight() / 2 - window_height / 2)

        # Establecer la posición centrada
        result_window.geometry("+{}+{}".format(position_right, position_down))

        results_label = tk.Label(result_window, text=results_text, font=("Times New Roman", 12), justify='left')
        results_label.pack(padx=20, pady=20)
        
        
    def update_wheel_background(self, angle_shift):
        for arc_id, i in zip(self.wheel_background, range(1, 38)):
            start_angle = ((i - 1) / 37 * 360 + angle_shift) % 360
            self.canvas.itemconfig(arc_id, start=start_angle)


    def display_result(self, player, number):
        # Mostrar el resultado de la apuesta de cada jugador
        bet_amount = getattr(self, f'bet_amount_{player}').get()
        bet_type = getattr(self, f'bet_type_{player}').get()
        selected_number = getattr(self, f'number_bet_{player}').get()
        result = "Par" if number % 2 == 0 else "Impar"
        win = False
        payout = 0

        if bet_type == "Número":
            win = (number == selected_number)
            if win:
                payout = bet_amount * 36  # Pago típico por acertar el número
            else:
                payout = -bet_amount
        else:
            win = (result == bet_type)
            if win:
                payout = bet_amount * 2  # Pago típico por acertar paridad
            else:
                payout = -bet_amount

        result_text = f"\nJugador {player} - Resultado: {number} ({result})\n"
        result_text += f"{'¡Ganaste!' if win else 'Perdiste'} Tu ganancia/pérdida es: {payout:.2f}"
        return result_text

    def simulate_montecarlo(self):
        conn = sqlite3.connect('casino_simulations.db')
        c = conn.cursor()
        c.execute('DELETE FROM resultados') # Resetear las simulaciones y volver a hacer 10000 simulaciones
        conn.commit()
        # Ejecutar la simulación Montecarlo y mostrar los resultados en una nueva ventana
        montecarlo_simulation()

        sim_window = tk.Toplevel(self.root)
        sim_window.title("Resultados de la Simulación Montecarlo")
        sim_window.geometry("500x620")
        
          # Actualizar la geometría para obtener las dimensiones correctas
        sim_window.update_idletasks()

        # Calcular la posición para centrar la ventana en la pantalla
        window_width = sim_window.winfo_width()
        window_height = sim_window.winfo_height()
        position_right = int(sim_window.winfo_screenwidth() / 2 - window_width / 2)
        position_down = int(sim_window.winfo_screenheight() / 2 - window_height / 2)

        # Establecer la posición centrada
        sim_window.geometry("+{}+{}".format(position_right, position_down))

        # Establecer la posición centrada
        sim_window.geometry("+{}+{}".format(position_right, position_down))

        tk.Label(sim_window, text="Resultados de la Simulación Montecarlo", font=("Times New Roman", 16)).pack(pady=10)

        c.execute('SELECT COUNT(*) FROM resultados WHERE ganador = "Jugador 1"')
        win_prob_1= c.fetchone()[0]
    
        c.execute('SELECT COUNT(*) FROM resultados WHERE ganador = "Jugador 2"')
        win_prob_2 = c.fetchone()[0]

        c.execute('SELECT COUNT(*) FROM resultados WHERE ganador = "Ambos"')
        both_win_prob = c.fetchone()[0]
    
        c.execute('SELECT COUNT(*) FROM resultados WHERE ganador = "Casa"')
        house_prob = c.fetchone()[0]

        total_simulaciones = win_prob_1 + win_prob_2 + house_prob + both_win_prob

        tk.Label(sim_window, text=f"Victorias Jugador 1: {win_prob_1}",font=("Times New Roman", 12)).pack()
        tk.Label(sim_window, text=f"Victorias Jugador 2: {win_prob_2}",font=("Times New Roman", 12)).pack()
        tk.Label(sim_window, text=f"Victorias de ambos jugadores: {both_win_prob}",font=("Times New Roman", 12)).pack()
        tk.Label(sim_window, text=f"Victorias de la Casa: {house_prob}",font=("Times New Roman", 12)).pack()

        tk.Label(sim_window, text="\nProbabilidades después de la simulación Montecarlo (10000 iteraciones):",font=("Times New Roman", 12)).pack(pady=12)
        tk.Label(sim_window, text=f"Jugador 1 Probabilidad de ganar: {win_prob_1 / total_simulaciones * 100:.2f}%",font=("Times New Roman", 12) ).pack()
        tk.Label(sim_window, text=f"Jugador 2 Probabilidad de ganar: {win_prob_2 / total_simulaciones * 100:.2f}%" ,font=("Times New Roman", 12)).pack()
        tk.Label(sim_window, text=f"Probabilidad que ganen ambos: {both_win_prob / total_simulaciones * 100:.2f}%",font=("Times New Roman", 12)).pack()
        tk.Label(sim_window, text=f"Probabilidad de ganar de la casa: {house_prob / total_simulaciones * 100:.2f}%",font=("Times New Roman", 12)).pack()

        tk.Label(sim_window, text="\nMonto mínimo de apuesta para tener alguna ganancia (en dólares):",font=("Times New Roman", 12)).pack(pady=12)
        optimal_bet_1, optimal_bet_2 = obtener_montos_optimos()
        tk.Label(sim_window, text=f"Jugador 1 debería apostar: {optimal_bet_1:.2f}",font=("Times New Roman", 12)).pack()
        tk.Label(sim_window, text=f"Jugador 2 debería apostar: {optimal_bet_2:.2f}",font=("Times New Roman", 12)).pack()

        show_graph_button = tk.Button(sim_window, text="Mostrar Gráficos",font=("Times New Roman", 12) , command=self.show_graph)
        show_graph_button.pack(pady=12)

        show_table_button = tk.Button(sim_window, text="Mostrar Resultados en Tabla",font=("Times New Roman", 12), command=self.show_table)
        show_table_button.pack(padx=30,pady=12)
        
        show_recomendations_button=tk.Button(sim_window, text="Recomendaciones", font=("Times New Roman",12),command=lambda: self.show_recomendations(optimal_bet_1, optimal_bet_2))
        show_recomendations_button.pack(padx=30,pady=12)

        conn.close()
        
    def show_recomendations(self, optimal_bet_1, optimal_bet_2):
        conn = sqlite3.connect('casino_simulations.db')
        c = conn.cursor()

        # Obtener los resultados de la simulación para Jugador 1
        c.execute('SELECT ganador, jugador1_tipo_apuesta FROM resultados WHERE ganador = "Jugador 1"')
        results_player1 = c.fetchall()

        # Obtener los resultados de la simulación para Jugador 2
        c.execute('SELECT ganador, jugador2_tipo_apuesta FROM resultados WHERE ganador = "Jugador 2"')
        results_player2 = c.fetchall()
        
        # Obtener los resultados de la simulación
        c.execute('SELECT ganador FROM resultados')
        results = [row[0] for row in c.fetchall()]
        total_games = len(results)
        
        # Calcular el porcentaje de victorias para cada jugador
        total_games_player1 = len(results)
        total_games_player2 = len(results)

        player1_wins = sum(1 for result in results_player1 if result[0] == 'Jugador 1')
        player2_wins = sum(1 for result in results_player2 if result[0] == 'Jugador 2')

        player1_win_percentage = (player1_wins / total_games_player1) * 100 if total_games_player1 > 0 else 0
        player2_win_percentage = (player2_wins / total_games_player2) * 100 if total_games_player2 > 0 else 0

        # Calcular ganancia promedio por juego para cada jugador
        player1_average_gain = sum(optimal_bet_1 if result[0] == 'Jugador 1' else 0 for result in results_player1) / total_games_player1 if total_games_player1 > 0 else 0
        player2_average_gain = sum(optimal_bet_2 if result[0] == 'Jugador 2' else 0 for result in results_player2) / total_games_player2 if total_games_player2 > 0 else 0

        # Determinar el tipo de apuesta más frecuente para cada jugador
        player1_bets = [result[1] for result in results_player1 if result[0] == 'Jugador 1']
        player2_bets = [result[1] for result in results_player2 if result[0] == 'Jugador 2']


        from collections import Counter

        player1_most_common_bet = Counter(player1_bets).most_common(1)
        player2_most_common_bet = Counter(player2_bets).most_common(1)

        # Generar recomendaciones basadas en el análisis detallado
        recommendations = []
        recommendations.append(f"ANALISIS PROFUNDO Y RECOMENDACIONES:\n")
        
        recommendations.append(f"Ganancia promedio por juego de Jugador 1: {player1_average_gain:.2f}$")
        recommendations.append(f"Ganancia promedio por juego de Jugador 2: {player2_average_gain:.2f}$")
        
        if player1_average_gain > player2_average_gain:
            recommendations.append("Jugador 1 está obteniendo una ganancia promedio por juego más alta.")
        elif player2_average_gain > player1_average_gain:
            recommendations.append("Jugador 2 está obteniendo una ganancia promedio por juego más alta.")
        else:
            recommendations.append("Ambos jugadores tienen una ganancia promedio por juego similar.")

        if optimal_bet_1 > optimal_bet_2:
            recommendations.append(f"Jugador 1 debería considerar aumentar sus apuestas para optimizar ganancias\nya que tiene un buen promedio de ganancias.\n")
        elif optimal_bet_1 < optimal_bet_2:
            recommendations.append(f"Jugador 2 debería considerar aumentar sus apuestas para optimizar ganancias\nya que tiene un buen promedio de ganancias.\n")
        else:
            recommendations.append(f"Ambos jugadores están apostando de manera óptima.\n")

            
        if player1_most_common_bet:
            recommendations.append(f"Tipo de apuesta más frecuente para Jugador 1: {player1_most_common_bet[0][0]}")
        if player2_most_common_bet:
            recommendations.append(f"Tipo de apuesta más frecuente para Jugador 2: {player2_most_common_bet[0][0]}")
            
        # Mitigación de riesgos y predicción de tendencias futuras
        if total_games > 0:
            # Analizar tendencias de apuestas y recomendar ajustes
            player1_bet_trends = Counter(player1_bets)
            player2_bet_trends = Counter(player2_bets)

            # Ejemplo de recomendaciones para mitigar riesgos y prever tendencias
            if len(player1_bet_trends) > 1:
                recommendations.append("Jugador 1 debería diversificar más sus tipos de apuesta para mitigar riesgos.")
            if len(player2_bet_trends) > 1:
                recommendations.append("Jugador 2 debería diversificar más sus tipos de apuesta para mitigar riesgos.\n")
                
                # Recomendaciones adicionales según el análisis
            if player1_win_percentage > player2_win_percentage:
                recommendations.append("Jugador 1 tiene un mejor desempeño en términos de porcentaje de victorias.\n")
            elif player2_win_percentage > player1_win_percentage:
                recommendations.append("Jugador 2 tiene un mejor desempeño en términos de porcentaje de victorias.\n")
            else:
                recommendations.append("Ambos jugadores tienen un porcentaje de victorias similar.\n")

            # Predicción de tendencias
            if player1_win_percentage > 23:
                recommendations.append("Tendencia favorable para Jugador 1 debido a que su porcentaje\nde victorias está por encima del 23%.")
            elif player2_win_percentage > 23:
                recommendations.append("Tendencia favorable para Jugador 2 debido a que su porcentaje\nde victorias está por encima del 23%.")
            else:
                recommendations.append("No hay una clara tendencia hacia un jugador en particular para las próximas sesiones.\n")

        conn.close()

    # Mostrar recomendaciones en una ventana emergente
        recommendation_window = tk.Toplevel(self.root)
        recommendation_window.title("Recomendaciones Detalladas")
    
        recommendation_text = "\n*".join(recommendations)
        recommendation_label = tk.Label(recommendation_window, text=recommendation_text, padx=20, pady=20, font=("Times New Roman", 12),justify="left")
        recommendation_label.pack()
  
    
    def show_graph(self):
        # Conectar a la base de datos
        conn = sqlite3.connect('casino_simulations.db')

        # Leer datos de la tabla 'resultados' en un DataFrame de pandas
        df = pd.read_sql_query("SELECT * FROM resultados", conn)

        # Cerrar la conexión
        conn.close()

        # Contar las frecuencias de cada número
        number_counts = df['numero_ganador'].value_counts().sort_index()

        # Graficar los números más repetidos
        plt.figure(figsize=(10, 6))
        number_counts.plot(kind='bar', color='skyblue')
        plt.xlabel('Número')
        plt.ylabel('Frecuencia')
        plt.title('Frecuencia de Números Ganadores en la Ruleta')
        plt.xticks(rotation=0)
        plt.show()

        # Ganancias/Pérdidas por Jugador
        ganancia_jugador_1 = df['jugador1_resultado'].sum()
        ganancia_jugador_2 = df['jugador2_resultado'].sum()

        plt.figure(figsize=(10, 5))
        plt.bar(['Jugador 1', 'Jugador 2'], [ganancia_jugador_1, ganancia_jugador_2], color=['blue', 'green'])
        plt.xlabel('Jugador')
        plt.ylabel('Ganancia/Pérdida Total')
        plt.title('Ganancias/Pérdidas Totales por Jugador')
        plt.show()

        # Distribución de Tipos de Apuestas
        bet_types_player1 = df['jugador1_tipo_apuesta'].value_counts()
        bet_types_player2 = df['jugador2_tipo_apuesta'].value_counts()

        fig, axes = plt.subplots(1, 2, figsize=(12, 6))
        axes[0].pie(bet_types_player1, labels=bet_types_player1.index, autopct='%1.1f%%', startangle=140)
        axes[0].set_title('Distribución de Tipos de Apuestas del Jugador 1')

        axes[1].pie(bet_types_player2, labels=bet_types_player2.index, autopct='%1.1f%%', startangle=140)
        axes[1].set_title('Distribución de Tipos de Apuestas del Jugador 2')

        plt.show()

        # Resultados por Tipo de Apuesta
        resultado_tipo_apuesta1 = df.groupby('jugador1_tipo_apuesta')['jugador1_resultado'].sum()
        resultado_tipo_apuesta2 = df.groupby('jugador2_tipo_apuesta')['jugador2_resultado'].sum()
        resultado_tipo_apuesta = resultado_tipo_apuesta1.add(resultado_tipo_apuesta2, fill_value=0)

        plt.figure(figsize=(10, 5))
        resultado_tipo_apuesta.plot(kind='bar', color='orange')
        plt.xlabel('Tipo de Apuesta')
        plt.ylabel('Ganancia/Pérdida Total')
        plt.title('Ganancias/Pérdidas Totales por Tipo de Apuesta')
        plt.xticks(rotation=0)
        plt.show()

    def show_table(self):
        conn = sqlite3.connect('casino_simulations.db')
        df = pd.read_sql_query("SELECT * FROM resultados", conn, index_col='id')
        conn.close()

        table_window = tk.Toplevel(self.root)
        table_window.title("Resultados de la Simulación")

        # Estilos y configuraciones para la tabla
        style = ttk.Style()
        style.configure("Treeview", rowheight=25)
        style.configure("Treeview.Heading", font=("Times New Roman", 8, "bold"), background="blue", foreground="black")
        style.configure("Treeview", font=("Verdana", 8), fieldbackground="lightblue")
        style.map('Treeview', background=[('selected', 'green')])

        table_frame = tk.Frame(table_window)
        table_frame.pack(fill=tk.BOTH, expand=True)

        # Creación de la tabla usando ttk.Treeview
        table = ttk.Treeview(table_frame, show="headings", height=20)
        table.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        scrollbar = ttk.Scrollbar(table_frame, orient=tk.VERTICAL, command=table.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        table.configure(yscrollcommand=scrollbar.set)

        # Configuración de las columnas y encabezados de la tabla
        table['columns'] = df.columns.tolist()
        for col in df.columns:
            table.heading(col, text=col)  # Configurar los encabezados de las columnas
            table.column(col, width=100, anchor=tk.CENTER)

        # Insertar datos en la tabla
        for index, row in df.iterrows():
            if index % 2 == 0:
                tag = 'evenrow'
            else:
                tag = 'oddrow'
            table.insert('', 'end', values=row.tolist(), tags=(tag,))

        # Configurar etiquetas para colores alternados de filas
        table.tag_configure('oddrow', background='lightblue')
        table.tag_configure('evenrow', background='white')

        # Empaquetar la tabla en el marco
        table.pack()

    def show_table(self):
        conn = sqlite3.connect('casino_simulations.db')
        df = pd.read_sql_query("SELECT * FROM resultados", conn, index_col='id')
        conn.close()

        table_window = tk.Toplevel(self.root)
        table_window.title("Resultados de la Simulación")

        # Estilos y configuraciones para la tabla
        style = ttk.Style()
        style.configure("Treeview", rowheight=25)
        style.configure("Treeview.Heading", font=("Times New Roman", 8, "bold"), background="blue", foreground="black")
        style.configure("Treeview", font=("Verdana", 8), fieldbackground="lightblue")
        style.map('Treeview', background=[('selected', 'green')])

        table_frame = tk.Frame(table_window)
        table_frame.pack(fill=tk.BOTH, expand=True)

        # Creación de la tabla usando ttk.Treeview
        table = ttk.Treeview(table_frame, show="headings", height=20)
        table.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        scrollbar = ttk.Scrollbar(table_frame, orient=tk.VERTICAL, command=table.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        table.configure(yscrollcommand=scrollbar.set)

        # Configuración de las columnas y encabezados de la tabla
        table['columns'] = df.columns.tolist()
        for col in df.columns:
            table.heading(col, text=col)  # Configurar los encabezados de las columnas
            table.column(col, width=100, anchor=tk.CENTER)

        # Insertar datos en la tabla
        for index, row in df.iterrows():
            if index % 2 == 0:
                tag = 'evenrow'
            else:
                tag = 'oddrow'
            table.insert('', 'end', values=row.tolist(), tags=(tag,))

        # Configurar etiquetas para colores alternados de filas
        table.tag_configure('oddrow', background='lightblue')
        table.tag_configure('evenrow', background='white')

        # Empaquetar la tabla en el marco
        table.pack()

def montecarlo_simulation(iterations=10000):
    wins_player1 = 0
    wins_player2 = 0
    house_wins = 0
    posibles_apuestas = list(range(10, 100001, 10))

    conn = sqlite3.connect('casino_simulations.db')
    c = conn.cursor()

    for _ in range(iterations):
        number = np.random.randint(0, 36)

        optimal_bet_1 = random.choice(posibles_apuestas)
        optimal_bet_2 = random.choice(posibles_apuestas)

        # Apuestas del Jugador 1
        bet_type_1 = random.choice(["Par", "Impar", "Número"])
        selected_number_1 = np.random.randint(0, 36)
        bet_amount_1 = optimal_bet_1
        result_1 = "Par" if number % 2 == 0 else "Impar"
        win_1 = (bet_type_1 == "Número" and number == selected_number_1) or (bet_type_1 != "Número" and bet_type_1 == result_1)
        payout_1 = bet_amount_1 * 36 if bet_type_1 == "Número" and win_1 else (bet_amount_1 * 2 if bet_type_1 != "Número" and win_1 else -bet_amount_1)

        # Apuestas del Jugador 2
        bet_type_2 = random.choice(["Par", "Impar", "Número"])
        selected_number_2 = np.random.randint(0, 36)
        bet_amount_2 = optimal_bet_2
        result_2 = "Par" if number % 2 == 0 else "Impar"
        win_2 = (bet_type_2 == "Número" and number == selected_number_2) or (bet_type_2 != "Número" and bet_type_2 == result_2)
        payout_2 = bet_amount_2 * 36 if bet_type_2 == "Número" and win_2 else (bet_amount_2 * 2 if bet_type_2 != "Número" and win_2 else -bet_amount_2)

        if win_1 and win_2:
            wins_player1 += 1
            wins_player2 += 1
            winner = 'Ambos'
        elif win_1:
            wins_player1 += 1
            winner = 'Jugador 1'
        elif win_2:
            wins_player2 += 1
            winner = 'Jugador 2'
        else:
            house_wins += 1
            winner = 'Casa'

        c.execute('''
        INSERT INTO resultados (iteracion, numero_ganador, jugador1_apuesta, jugador1_tipo_apuesta, jugador1_numero_apuesta, jugador1_resultado, jugador2_apuesta, jugador2_tipo_apuesta, jugador2_numero_apuesta, jugador2_resultado, ganador)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (_, number, bet_amount_1, bet_type_1, selected_number_1, payout_1, bet_amount_2, bet_type_2, selected_number_2, payout_2, winner))

    conn.commit()

def obtener_montos_optimos():
    conn = sqlite3.connect('casino_simulations.db')
    c = conn.cursor()

    # Consulta para obtener el monto mínimo de apuesta que resulta en ganancia para jugador 1
    c.execute('SELECT jugador1_apuesta FROM resultados WHERE jugador1_resultado > 0 ORDER BY jugador1_apuesta ASC LIMIT 1')
    row = c.fetchone()
    optimal_bet_1 = row[0] if row else None

    # Consulta para obtener el monto mínimo de apuesta que resulta en ganancia para jugador 2
    c.execute('SELECT jugador2_apuesta FROM resultados WHERE jugador2_resultado > 0 ORDER BY jugador2_apuesta ASC LIMIT 1')
    row = c.fetchone()
    optimal_bet_2 = row[0] if row else None

    conn.close()
    return optimal_bet_1, optimal_bet_2

if __name__ == "__main__":
    root = tk.Tk()
    ruleta = Ruleta(root)
    root.mainloop()