import sqlite3

# Crear y conectar a la base de datos
conn = sqlite3.connect('casino_simulations.db')
c = conn.cursor()

# Crear la tabla de resultados de simulaciones
c.execute('''
CREATE TABLE IF NOT EXISTS resultados (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    iteracion INTEGER,
    numero_ganador INTEGER,
    jugador1_apuesta REAL,
    jugador1_tipo_apuesta TEXT,
    jugador1_numero_apuesta INTEGER,
    jugador1_resultado REAL,
    jugador2_apuesta REAL,
    jugador2_tipo_apuesta TEXT,
    jugador2_numero_apuesta INTEGER,
    jugador2_resultado REAL,
    ganador TEXT
)
''')
conn.commit()
conn.close()