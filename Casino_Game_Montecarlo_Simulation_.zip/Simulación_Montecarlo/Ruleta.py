import tkinter as tk
import random

class Ruleta:
    def __init__(self, root):
        self.root = root
        self.root.title("Juego de Ruleta")
        
        self.canvas = tk.Canvas(root, width=600, height=400)
        self.canvas.pack()

        self.create_board()
        self.create_bet_options()
        self.create_spin_button()
        self.create_results_display()

    def create_board(self):
        self.canvas.create_oval(150, 50, 450, 350, fill='white')
        self.canvas.create_text(300, 200, text="Ruleta", font=("Helvetica", 16))

    def create_bet_options(self):
        self.bet_amount = tk.DoubleVar()
        self.bet_amount.set(0)
        self.bet_type = tk.StringVar()
        self.bet_type.set("Par")

        tk.Label(self.root, text="Cantidad de Apuesta:").pack()
        tk.Entry(self.root, textvariable=self.bet_amount).pack()

        tk.Label(self.root, text="Tipo de Apuesta:").pack()
        tk.OptionMenu(self.root, self.bet_type, "Par", "Impar").pack()

    def create_spin_button(self):
        self.spin_button = tk.Button(self.root, text="Girar la Ruleta", command=self.spin_wheel)
        self.spin_button.pack()

    def create_results_display(self):
        self.results_label = tk.Label(self.root, text="")
        self.results_label.pack()

    def spin_wheel(self):
        number = random.randint(0, 36)
        bet_amount = self.bet_amount.get()
        bet_type = self.bet_type.get()
        result = "Par" if number % 2 == 0 else "Impar"
        win = (result == bet_type)

        result_text = f"Resultado: {number} ({result})\n"
        result_text += "¡Ganaste!" if win else "Perdiste"
        self.results_label.config(text=result_text)

if __name__ == "__main__":
    root = tk.Tk()
    ruleta = Ruleta(root)
    root.mainloop()
