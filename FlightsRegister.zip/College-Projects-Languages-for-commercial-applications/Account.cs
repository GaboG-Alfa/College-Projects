namespace Models
{
    public partial class Account
    {
        public string Email { get; set; }
        public string AccountPassword { get; set; }
        public string AccountRole { get; set; }
    }
}