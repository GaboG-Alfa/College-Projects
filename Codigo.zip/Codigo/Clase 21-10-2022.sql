USE ModeloLogico;

CREATE TABLE dbo.TipoImpuesto(
TipoImpuestoID SMALLINT IDENTITY(1,1) PRIMARY KEY,
DescTipo NVARCHAR(50)
);

CREATE TABLE dbo.TipoIdentificadorProducto(
TipoIdentificadorID TINYINT IDENTITY(1,1) PRIMARY KEY,
DescTipo NVARCHAR(100)
);

CREATE TABLE dbo.TipoAsociacion(
TipoAsociacionID TINYINT IDENTITY(1,1) PRIMARY KEY,
DescTipo NVARCHAR(100)
);

CREATE TABLE dbo.Producto(
ProductoID INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
TipoImpuestoID SMALLINT NOT NULL,
Nombre NVARCHAR(100) NOT NULL
);

ALTER TABLE dbo.Producto
ADD CONSTRAINT FK_Producto_TipoImpuesto 
FOREIGN KEY (TipoImpuestoID)
REFERENCES dbo.TipoImpuesto(TipoImpuestoID);

CREATE TABLE dbo.IdentificadorProducto(
IdentificadorProductoID INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
TipoIdentificadorProductoID TINYINT NOT NULL,
ProductoID INT  NOT NULL,
Valor NVARCHAR(50) NOT NULL
);

ALTER TABLE dbo.IdentificadorProducto
ADD CONSTRAINT FK_IdentificadorProducto_Producto 
FOREIGN KEY(ProductoID)
REFERENCES dbo.Producto(ProductoID);

ALTER TABLE dbo.IdentificadorProducto
ADD CONSTRAINT FK_IdentificadorProducto_TipoIdentificadorProducto
FOREIGN KEY(TipoIdentificadorProductoID)
REFERENCES dbo.TipoIdentificadorProducto(TipoIdentificadorID);

CREATE TABLE dbo.Asociacion(
AsociacionID INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
TipoAsociacionID TINYINT NOT NULL,
ProductoID INT  NOT NULL,
ProductoAsociadoID INT  NOT NULL,
Cantidad SMALLINT  NULL,
Instrucciones NVARCHAR(500) NULL
);


ALTER TABLE dbo.Asociacion
ADD CONSTRAINT FK_Asociacion_TipoAsociacion 
FOREIGN KEY(TipoAsociacionID)
REFERENCES dbo.TipoAsociacion(TipoAsociacionID);

ALTER TABLE dbo.Asociacion
ADD CONSTRAINT FK_Producto_Asociacion 
FOREIGN KEY(ProductoID)
REFERENCES dbo.Producto(ProductoID);

ALTER TABLE dbo.Asociacion
ADD CONSTRAINT FK_ProductoAsociado_Asociacion 
FOREIGN KEY(ProductoAsociadoID)
REFERENCES dbo.Producto(ProductoID);