﻿CREATE DATABASE ModeloLogico;

USE ModeloLogico;

CREATE TABLE dbo.NaturalezaPersona(
TipoNaturalezaID TINYINT IDENTITY(1,1) PRIMARY KEY,
DescNaturaleza NVARCHAR(100)
);

INSERT INTO dbo.NaturalezaPersona(DescNaturaleza)
VALUES (N'F�sica'),
       (N'Jur�dica');

SELECT *
FROM dbo.NaturalezaPersona;

CREATE TABLE dbo.TipoIdentificador(
TipoIdentificadorID TINYINT IDENTITY(1,1) PRIMARY KEY,
DescTipo NVARCHAR(100)
);

INSERT INTO dbo.TipoIdentificador(DescTipo)
VALUES (N'C�dula'),
       (N'C�dula Jur�dica');

SELECT *
FROM dbo.TipoIdentificador;

INSERT INTO dbo.TipoIdentificador(DescTipo)
VALUES (N'Pasaporte'),
       (N'C�dula Residencia');

--UPDATE dbo.TipoIdentificador
--SET DescTipo = N'C�dula Jur�dica'
--WHERE TipoIdentificadorID = 2;

CREATE TABLE dbo.TipoRelacion(
TipoRelacionID TINYINT IDENTITY(1,1) PRIMARY KEY,
DescRelacion NVARCHAR(50)
);

INSERT INTO dbo.TipoRelacion(DescRelacion)
VALUES (N'Parentesco'),
       (N'Beneficiario');

SELECT *
FROM dbo.TipoRelacion;

CREATE TABLE dbo.Idioma(
IdiomaID SMALLINT IDENTITY(1,1) PRIMARY KEY,
DescIdioma NVARCHAR(100)
);

INSERT INTO dbo.Idioma(DescIdioma)
VALUES (N'Espa�ol'),
       (N'Ingl�s'),
	   (N'Portugu�s');

SELECT *
FROM dbo.Idioma;

CREATE TABLE dbo.EstadoCivil(
EstadoCivilID TINYINT IDENTITY(1,1) PRIMARY KEY,
DescEstadoCivil NVARCHAR(50)
);

INSERT INTO dbo.EstadoCivil(DescEstadoCivil)
VALUES (N'Casado'),
       (N'Soltero'),
	   (N'Uni�n Soltero');

SELECT *
FROM dbo.EstadoCivil;

CREATE TABLE dbo.Persona(
PersonaID INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
TipoNaturalezaID TINYINT NOT NULL,
EstadoCivilID TINYINT  NOT NULL,
PrimerNombre NVARCHAR(100) NOT NULL
);

ALTER TABLE dbo.Persona
ADD CONSTRAINT FK_Persona_TipoPersona FOREIGN KEY (TipoNaturalezaID)
REFERENCES dbo.NaturalezaPersona (TipoNaturalezaID);

ALTER TABLE dbo.Persona
ADD CONSTRAINT FK_Persona_EstadoCivil FOREIGN KEY (EstadoCivilID)
REFERENCES dbo.EstadoCivil (EstadoCivilID);

INSERT INTO dbo.Persona (TipoNaturalezaID,
                         EstadoCivilID,
						 PrimerNombre)
VALUES (1,1,N'Luis');

INSERT INTO dbo.Persona (TipoNaturalezaID,
                         EstadoCivilID,
						 PrimerNombre)
VALUES (2,1,N'Mar�a');

INSERT INTO dbo.Persona (TipoNaturalezaID,
                         EstadoCivilID,
						 PrimerNombre)
VALUES (2,4,N'Dos Pinos');

DELETE dbo.NaturalezaPersona
WHERE TipoNaturalezaID = 1;

CREATE TABLE dbo.IdiomaXPersona(
PersonaID INT,
IdiomaID SMALLINT
);

ALTER TABLE dbo.IdiomaXPersona
ADD CONSTRAINT PK_IdiomaXPersona PRIMARY KEY(PersonaID,IdiomaID);

ALTER TABLE dbo.NaturalezaPersona
ALTER COLUMN DescNaturaleza NVARCHAR(100) NOT NULL;

ALTER TABLE dbo.IdiomaXPersona
ADD CONSTRAINT FK_IdiomaXPersona_Idioma FOREIGN KEY(IdiomaID)
REFERENCES dbo.Idioma(IdiomaID);

ALTER TABLE dbo.IdiomaXPersona
ADD CONSTRAINT FK_IdiomaXPersona_Persona FOREIGN KEY(PersonaID)
REFERENCES dbo.Persona(PersonaID);

SELECT *
FROM dbo.Persona;

SELECT *
FROM dbo.IdiomaXPersona;

INSERT INTO dbo.IdiomaXPersona (PersonaID,IdiomaID)
VALUES (3,1);

INSERT INTO dbo.IdiomaXPersona (PersonaID,IdiomaID)
VALUES (3,2);

INSERT INTO dbo.IdiomaXPersona (PersonaID,IdiomaID)
VALUES (4,2);

DELETE FROM dbo.IdiomaXPersona
WHERE IdiomaID = 2
  AND PersonaID = 4;

DELETE FROM dbo.Idioma
WHERE IdiomaID = 3; -- vs DROP

CREATE TABLE dbo.Identificador(
IdentificadorID INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
TipoIdentificadorID TINYINT NOT NULL,
PersonaID INT  NOT NULL,
Valor NVARCHAR(20) NOT NULL,
FechaExpiracion DATE NOT NULL
);

ALTER TABLE dbo.Identificador
ADD CONSTRAINT FK_Identificador_Persona FOREIGN KEY(PersonaID)
REFERENCES dbo.Persona(PersonaID);

ALTER TABLE dbo.Identificador
ADD CONSTRAINT FK_Identificador_TipoIdentificador FOREIGN KEY(TipoIdentificadorID)
REFERENCES dbo.TipoIdentificador(TipoIdentificadorID);

INSERT INTO dbo.Identificador(TipoIdentificadorID,
                              PersonaID,
							  Valor,
							  FechaExpiracion)
VALUES (1,3,N'1-1111-1111',CAST('20261231' AS DATE)),
       (2,4,N'3-2345-098',DATEFROMPARTS (2027,11,22));

CREATE TABLE dbo.Relacion(
RelacionID INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
TipoRelacionID TINYINT NOT NULL,
PersonaID INT  NOT NULL,
PersonaRelacionadaID INT  NOT NULL,
Porcentaje NVARCHAR(20) NOT NULL,
);

ALTER TABLE dbo.Relacion
ALTER COLUMN Porcentaje NVARCHAR(20) NULL;

ALTER TABLE dbo.Relacion
ADD CONSTRAINT FK_Relacion_TipoRelacion FOREIGN KEY(TipoRelacionID)
REFERENCES dbo.TipoRelacion(TipoRelacionID);

SELECT *
FROM dbo.Persona;

INSERT INTO dbo.Relacion (TipoRelacionID,
                          PersonaID ,
						  PersonaRelacionadaID ,
						  Porcentaje)
VALUES (1,5,3,NULL);

INSERT INTO dbo.Relacion (TipoRelacionID,
                          PersonaID ,
						  PersonaRelacionadaID ,
						  Porcentaje)
VALUES (2,5,3,N'50%');

SELECT *
FROM dbo.Relacion;

INSERT INTO dbo.Persona (TipoNaturalezaID,
                         EstadoCivilID,
						 PrimerNombre)
SELECT 1,1,contactname
FROM TSQLV4.SALES.Customers;

SELECT PersonaID
      ,TipoNaturalezaID 
	  ,EstadoCivilID 
	  ,PrimerNombre 
FROM dbo.Persona
WHERE TipoNaturalezaID = 1;

--CREATE SCHEMA Persona;

CREATE TABLE Persona.NaturalezaPersona(
TipoNaturalezaID TINYINT IDENTITY(1,1) PRIMARY KEY,
DescNaturaleza NVARCHAR(100)
);

CREATE TABLE Persona.[Tipo Identificador](
TipoIdentificadorID TINYINT IDENTITY(1,1) PRIMARY KEY,
DescTipo NVARCHAR(100)
);

SELECT *
FROM Persona.[Tipo Identificador];

ALTER TABLE dbo.Identificador
ADD CONSTRAINT CHK_Verificar_Fecha
CHECK (FechaExpiracion > GETDATE());

INSERT INTO dbo.Identificador(TipoIdentificadorID,
                              PersonaID,
							  Valor,
							  FechaExpiracion)
VALUES (1,3,N'1-1111-1111',CAST('20211231' AS DATE));