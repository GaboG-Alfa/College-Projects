USE TSQLV4;
SELECT E.companyname
      ,O.orderid
	  ,O.orderdate
FROM	Sales.Customers AS E
  INNER JOIN SALES.Orders AS O
    ON (E.custid = O.custid)

SELECT
     E.companyname AS Cliente
    ,CONCAT(H.firstname,' ', H.lastname) AS Empleado
    ,O.orderid 
    ,O.orderdate
FROM	Sales.Customers AS E
  INNER JOIN SALES.Orders AS O
    ON (E.custid = O.custid)
  INNER JOIN HR.Employees AS H
	ON (O.empid = H.empid);

/*EDAD EMPLEADOS*/
SELECT CONCAT(firstname,' ', lastname) AS Empleado
       ,DATEDIFF(YEAR,birthdate,GETDATE()) AS Edad
FROM HR.Employees;

/*analisis para ver la cantidad de ordenes por volumenes*/

SELECT  CONCAT(H.firstname,' ', H.lastname) AS Empleado
       ,DATEDIFF(YEAR,birthdate,GETDATE()) AS Edad
	   ,COUNT(*) AS Cantidad_Vendida
FROM HR.Employees AS H
    INNER JOIN Sales.Orders AS O
	ON(H.empid = O.empid)
GROUP BY CONCAT(H.firstname,' ', H.lastname)
       ,DATEDIFF(YEAR,birthdate,GETDATE());


/*Cantidad de a�os que lleva una persona en la empresa*/

SELECT  CONCAT(H.firstname,' ', H.lastname) AS Empleado
       ,DATEDIFF(YEAR,H.hiredate,GETDATE()) AS Anios_En_Organizacion
	   ,COUNT(*) AS Cantidad_Vendida
FROM HR.Employees AS H
    INNER JOIN Sales.Orders AS O
	ON(H.empid = O.empid)
GROUP BY CONCAT(H.firstname,' ', H.lastname)
       ,DATEDIFF(YEAR,H.hiredate,GETDATE());

/*TOP 3 DE CLIENTES CON MAS ORDENES*/

SELECT TOP (3)  H.companyname AS Cliente
	   ,COUNT(*) AS Cantidad_Vendida
FROM Sales.Customers AS H
    INNER JOIN Sales.Orders AS O
	ON(H.custid = O.custid)
GROUP BY H.companyname
ORDER BY Cantidad_Vendida DESC;

/*Cantidad de ordenes x pa�s de clientes*/
SELECT C.country
      ,Count(*) AS Cantidad
FROM Sales.Orders AS O
  INNER JOIN Sales.Customers AS C
    ON (C.custid = O.custid)
GROUP BY C.country
ORDER BY Cantidad  DESC;

/*Cual es el mes en que mas ordenes se hacen*/
      
SELECT TOP (1)
       MONTH(O.orderdate) AS Mes
      ,COUNT(*) AS Cantidad
FROM Sales.Orders AS O
  INNER JOIN SALES.OrderDetails AS OD
    ON (O.orderid = OD.orderid)
GROUP BY MONTH(O.orderdate);
