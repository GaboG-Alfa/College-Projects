--Practica para examen 2

USE TSQLV4

--1--
UPDATE OD
SET OD.discount += OD.discount * 0.01
FROM Sales.OrderDetails AS OD
 INNER JOIN Production.Products AS P
   ON (OD.productid = P.productid)
WHERE P.productname = N'Product TBTBL'

--2--
WITH EmpleadoPorOrdenes AS 
(SELECT CONCAT(E.firstname,' ',E.lastname) AS nombre
        ,YEAR(O.orderdate) AS a�o
        ,MONTH(O.orderdate) AS mes
	    ,SUM(OD.qty * OD.unitprice) AS amount
FROM HR.Employees AS E
 INNER JOIN Sales.Orders AS O
   ON(E.empid = O.empid)
 INNER JOIN Sales.OrderDetails AS OD
  ON (O.orderid = OD.orderid)
GROUP BY CONCAT(E.firstname,' ',E.lastname) 
        ,YEAR(O.orderdate) 
        ,MONTH(O.orderdate) 
)
SELECT nombre
      ,a�o
      ,mes
      ,amount
	  ,(amount/SUM(amount)OVER (PARTITION BY  nombre
	                      ORDER BY nombre,a�o))*100 AS Porcentaje
	  ,SUM(amount) OVER (PARTITION BY  nombre
	                      ORDER BY nombre,a�o,mes
						  ROWS BETWEEN UNBOUNDED PRECEDING
						  AND CURRENT ROW) AS acumulado
FROM EmpleadoPorOrdenes;

--3--
SELECT O.orderid AS orderid,
       O.orderdate AS orderdate ,
	   O.shippeddate AS shippeddate,
	   O.freight AS freight,
	   O.shipcountry AS shipcountry 
FROM Sales.Orders AS O
INNER JOIN HR.Employees AS E
ON(O.empid=E.empid)
WHERE E.empid IN (8,1,3,4) AND 
O.shipcountry IN ('USA','CANADA') AND 
O.freight >= 100 
AND O.shippeddate = DATEADD (DAY,2,O.orderdate)  
