SELECT contactname AS 'Contact Name'
      ,city AS 'City'
	  ,COALESCE(region,'NA') AS 'Region'
	  ,COALESCE(fax,'NA') AS 'Fax'
FROM Sales.Customers
WHERE country = N'Mexico';

SELECT CONVERT(DATE,'20221020') AS FechaHoy;

SELECT CAST('20221020' AS DATE) AS FechaHoy;

SELECT CAST(20 AS VARCHAR(20)) AS FechaHoy;

SELECT CONCAT(firstname,' ',lastname) AS FullName
      ,COALESCE(region,'NA') AS 'Region'
	  ,CAST(hiredate AS DATE) AS hiredate
FROM HR.Employees;

SELECT DISTINCT country
FROM Sales.Customers
ORDER BY country DESC;

SELECT CONCAT(firstname,' ',lastname) AS FullName
      ,country 
	  ,region 
FROM HR.Employees
WHERE country = N'USA'
ORDER BY FullName ASC;

SELECT
FROM
WHERE
GROUP BY
HAVING
ORDER BY

FROM
WHERE
GROUP BY
HAVING
SELECT
ORDER BY

SELECT country
      ,COUNT(*) AS Cantidad
FROM SALES.Customers
--WHERE region IS NULL
GROUP BY country
--HAVING COUNT(*) > 5
ORDER BY Cantidad DESC;

SELECT *
FROM HR.Employees
ORDER BY lastname ASC;

SELECT *
FROM HR.Employees
ORDER BY country 
        ,City ASC;

SELECT country 
      ,YEAR(hiredate) AS AnioContratado
	  ,COUNT(*) AS CantidadEmpleados
FROM HR.Employees
WHERE hiredate >= CAST('20100101' AS DATE)
GROUP BY country 
        ,YEAR(hiredate)
HAVING COUNT(*) > 1
ORDER BY country
        ,AnioContratado ASC;

-- En qu� pa�ses, regiones y cuidades trabajan mis colaboradores
SELECT DISTINCT country 
      ,region 
	  ,city
FROM HR.Employees;

-- En qu� pa�ses y regiones trabajan mis colaboradores
SELECT DISTINCT country 
      ,region 
FROM HR.Employees;

SELECT 10 + 10 AS "$Resultado";

SELECT CONCAT(firstname, ' ', lastname) AS NombreCompleto
      ,hiredate
FROM HR.Employees
WHERE country = N'UK';

SELECT CONCAT(firstname, ' ', lastname) AS NombreCompleto
      ,hiredate
FROM HR.Employees
WHERE hiredate >= CAST('20150101' AS DATE);

SELECT CONCAT(firstname, ' ', lastname) AS NombreCompleto
      ,hiredate
FROM HR.Employees
WHERE hiredate >= DATEFROMPARTS(2015,1,15)
   AND country = N'UK';

SELECT DISTINCT country
FROM Sales.CustomerS;

SET STATISTICS IO ON;

SELECT companyname
      ,contactname 
	  ,country
	  ,city
FROM Sales.Customers
WHERE country IN (N'USA', N'Mexico',N'Canada')
ORDER BY country
        ,city;

SELECT DISTINCT companyname
      ,contactname 
	  ,country
	  ,city
FROM Sales.Customers
WHERE country IN (N'USA', N'Mexico',N'Canada');

SELECT CONCAT(firstname, ' ', lastname) AS NombreCompleto
      ,hiredate
	  ,country
	  ,region
FROM HR.Employees;

SELECT CONCAT(firstname, ' ', lastname) AS NombreCompleto
      ,hiredate
	  ,country
	  ,region
FROM HR.Employees
WHERE region = N'WA';

SELECT CONCAT(firstname, ' ', lastname) AS NombreCompleto
      ,hiredate
	  ,country
	  ,region
FROM HR.Employees
WHERE region <> N'WA'
  OR region IS NULL;

SELECT CONCAT(firstname, ' ', lastname) AS NombreCompleto
      ,hiredate
	  ,country
	  ,region
FROM HR.Employees;

SELECT CONCAT(firstname, ' ', lastname) AS NombreCompleto
      ,hiredate
	  ,country
	  ,region
FROM HR.Employees
WHERE lastname = N'Davis';

SELECT CONCAT(firstname, ' ', lastname) AS NombreCompleto
      ,hiredate
	  ,country
	  ,region
FROM HR.Employees
WHERE firstname LIKE N'%ra%';

SELECT TOP 15 *
FROM Sales.Customers;

SELECT contactname
      ,contacttitle 
FROM Sales.Customers
WHERE contacttitle LIKE N'%Manager%'
ORDER BY contacttitle ASC;

SELECT contactname
      ,contacttitle 
FROM Sales.Customers
WHERE contacttitle LIKE N'%Accounting%'
ORDER BY contacttitle ASC;

SELECT contactname
      ,contacttitle 
FROM Sales.Customers
WHERE contactname LIKE N'___e%';

SELECT orderid 
      ,orderdate
	  ,custid 
	  ,empid 
FROM SALES.Orders
WHERE orderdate = CAST('20141231' AS DATE);

SELECT orderid 
      ,orderdate
	  ,custid 
	  ,empid 
FROM SALES.Orders
WHERE orderdate = DATEFROMPARTS(2014,12,31);

SELECT orderid 
      ,orderdate
	  ,custid 
	  ,empid 
FROM SALES.Orders
WHERE orderdate >= DATEFROMPARTS(2014,1,1)
  AND orderdate <= DATEFROMPARTS(2014,12,31);

SELECT orderid 
      ,orderdate
	  ,custid 
	  ,empid 
FROM SALES.Orders
WHERE orderdate >= CAST('20140101' AS DATE)
  AND orderdate <= CAST('20141231' AS DATE);

SELECT orderid 
      ,orderdate
	  ,custid 
	  ,empid 
FROM SALES.Orders
WHERE orderdate BETWEEN CAST('20140101' AS DATE)
  AND CAST('20141231' AS DATE);

SELECT orderid 
      ,orderdate
	  ,custid 
	  ,empid 
FROM SALES.Orders
WHERE YEAR(orderdate) = 2014 ;

SELECT DAY(GETDATE());

SELECT orderid 
      ,orderdate
	  ,custid 
	  ,empid 
	  ,YEAR(orderdate) AS Anio
	  ,MONTH(orderdate) AS Mes
	  ,DAY(orderdate) AS Dia
FROM SALES.Orders
WHERE orderdate BETWEEN CAST('20140101' AS DATE)
  AND CAST('20141231' AS DATE);

SELECT CONCAT(firstname, ' ', lastname) AS NombreCompleto
      ,country
	  ,hiredate
	  ,region
FROM HR.Employees
ORDER BY hiredate DESC;

SELECT TOP (5) *
FROM Sales.Orders;


SELECT TOP (5)
     orderid 
	,orderdate 
	,custid 
	,empid
FROM Sales.Orders
ORDER BY orderdate ASC;

SELECT TOP (5)
     orderid 
	,orderdate 
	,custid 
	,empid
FROM Sales.Orders
ORDER BY orderdate DESC;

SELECT TOP (5) PERCENT
     orderid 
	,orderdate 
	,custid 
	,empid
FROM Sales.Orders
ORDER BY orderdate ASC;

DECLARE @Numero AS BIGINT;

SET @Numero = 4;

SELECT TOP (@Numero) PERCENT
     orderid 
	,orderdate 
	,custid 
	,empid
FROM Sales.Orders
ORDER BY orderdate ASC;

SELECT TOP (5)
     orderid 
	,orderdate 
	,custid 
	,empid
FROM Sales.Orders
ORDER BY (SELECT NULL);

SELECT TOP (5)
     orderid 
	,orderdate 
	,custid 
	,empid
FROM Sales.Orders
ORDER BY orderdate ASC;

SELECT TOP (3) WITH TIES
     orderid 
	,orderdate 
	,custid 
	,empid
FROM Sales.Orders
ORDER BY orderdate ASC;

SELECT TOP 100 *
FROM HR.Employees;

SELECT orderid 
	  ,orderdate 
	  ,custid 
	  ,empid
FROM Sales.Orders
ORDER BY orderdate ASC
OFFSET 0 ROWS FETCH NEXT 3 ROWS ONLY;

SELECT orderid 
	  ,orderdate 
	  ,custid 
	  ,empid
FROM Sales.Orders
ORDER BY (SELECT NULL)
OFFSET 0 ROWS FETCH NEXT 3 ROWS ONLY;

SELECT orderid 
	  ,orderdate 
	  ,custid 
	  ,empid
FROM Sales.Orders
ORDER BY orderdate ASC
OFFSET 50 ROWS FETCH NEXT 3 ROWS ONLY;

-- Esto es un comentario
/*  esto 
son varis lineas de comentarios*/

SELECT orderid 
	  ,orderdate 
	  ,custid 
	  ,empid
FROM Sales.Orders
ORDER BY orderdate ASC
OFFSET 50 ROWS;

SELECT CONCAT(firstname, ' ', lastname) AS NombreCompleto
      ,CONCAT(NombreCompleto, '        ')
FROM HR.Employees
ORDER BY hiredate DESC;

SELECT  
   COALESCE(REGION, 'NA') AS Region
FROM Sales.Customers;

SELECT  
   ISNULL(REGION, 'NA') AS Region
FROM Sales.Customers;

SELECT DISTINCT country
FROM Sales.Customers;

SELECT *
FROM sales.Orders;

SELECT supplierid
      ,count(*)
FROM Production.Products
group by supplierid;


SELECT TOP 5 *
FROM Production.Products;

-- CUALES CUMPLEN CON LA CONDICION
SELECT productid
      ,productname
	  ,unitprice
FROM Production.Products
WHERE unitprice >=90;

SELECT COUNT(*) AS Cantidad
FROM Production.Products
WHERE unitprice >=90;

SELECT COUNT(*) AS Cantidad
FROM Production.Products
WHERE discontinued = 1;

SELECT COUNT(*) AS Cantidad
FROM Production.Products
WHERE discontinued = 1
  AND unitprice >=90;


SELECT productid
      ,productname
	  ,unitprice
	  ,discontinued 
FROM Production.Products
WHERE discontinued = 1
  AND unitprice >=90;

SELECT COUNT(*) AS Cantidad 
FROM Production.Products;

SELECT country
      ,COUNT(*) AS Cantidad
FROM SALES.Customers
GROUP BY country;

SELECT YEAR(orderdate) AS Anio
      ,COUNT(*) AS Cantidad
FROM Sales.Orders 
GROUP BY YEAR(orderdate)
ORDER BY Cantidad DESC;

SELECT YEAR(orderdate) AS Anio
      ,MONTH(orderdate) AS Mes
      ,COUNT(*) AS Cantidad
FROM Sales.Orders 
GROUP BY YEAR(orderdate)
        ,MONTH(orderdate)
ORDER BY Anio
        ,Mes ASC;

SELECT P.productid 
      ,P.productname
	  ,C.categoryname
FROM Production.Products AS P
  INNER JOIN Production.Categories AS C
    ON (P.categoryid = C.categoryid);

SELECT P.productid 
      ,P.productname
	  ,C.categoryname
	  ,S.companyname
FROM Production.Products AS P
  INNER JOIN Production.Categories AS C
    ON (P.categoryid = C.categoryid)
  INNER JOIN Production.Suppliers AS S
    ON (P.supplierid = S.supplierid);

SELECT C.categoryname
      ,COUNT(*) AS Cantidad
FROM Production.Products AS P
  INNER JOIN Production.Categories AS C
    ON (P.categoryid = C.categoryid)
GROUP BY C.categoryname;

SELECT C.orderid
      ,C.custid 
	  ,E.firstname
	  ,C.orderdate 
FROM SALES.Orders AS C
  INNER JOIN HR.Employees AS E
   ON (C.empid = E.empid);

SELECT O.orderid
      ,C.companyname
	  ,E.firstname
	  ,O.orderdate 
FROM SALES.Orders AS O
  INNER JOIN HR.Employees AS E
   ON (O.empid = E.empid)
  INNER JOIN Sales.Customers AS C
   ON (O.custid = C.custid);

SELECT E.firstname
	  ,COUNT(*) AS Cantidad
FROM SALES.Orders AS C
  INNER JOIN HR.Employees AS E
   ON (C.empid = E.empid)
 GROUP BY E.firstname
 ORDER BY Cantidad DESC;

SELECT C.companyname
	  ,COUNT(*) AS Cantidad
FROM SALES.Orders AS O
  INNER JOIN Sales.Customers AS C
   ON (O.custid = C.custid)
 GROUP BY C.companyname
 ORDER BY Cantidad DESC;

 SELECT C.companyname
	  ,SUM((OD.qty * OD.unitprice) - OD.discount) AS Monto
FROM SALES.Orders AS O
  INNER JOIN Sales.Customers AS C
   ON (O.custid = C.custid)
  INNER JOIN SALES.OrderDetails AS OD
   ON (O.orderid = OD.orderid)
 GROUP BY C.companyname
 ORDER BY Monto DESC;

SELECT C.companyname
	  ,SUM((OD.qty * OD.unitprice) - OD.discount) AS Monto
	  ,COUNT(*) AS Cantidad
FROM SALES.Orders AS O
  INNER JOIN Sales.Customers AS C
   ON (O.custid = C.custid)
  INNER JOIN SALES.OrderDetails AS OD
   ON (O.orderid = OD.orderid)
 GROUP BY C.companyname
 ORDER BY Monto DESC;

SELECT C.companyname
	  ,SUM((OD.qty * OD.unitprice) - OD.discount) AS Monto
	  ,COUNT(*) AS Cantidad
FROM SALES.Orders AS O
  INNER JOIN Sales.Customers AS C
   ON (O.custid = C.custid)
  INNER JOIN SALES.OrderDetails AS OD
   ON (O.orderid = OD.orderid)
 GROUP BY C.companyname
 ORDER BY Cantidad DESC;

SELECT C.companyname
      ,YEAR(O.orderdate) AS Anio
	  ,SUM((OD.qty * OD.unitprice) - OD.discount) AS Monto
	  ,COUNT(*) AS Cantidad
FROM SALES.Orders AS O
  INNER JOIN Sales.Customers AS C
   ON (O.custid = C.custid)
  INNER JOIN SALES.OrderDetails AS OD
   ON (O.orderid = OD.orderid)
GROUP BY C.companyname
        ,YEAR(O.orderdate)
ORDER BY C.companyname 
        ,Anio ASC;

SELECT C.categoryname
      ,P.productname
FROM Production.Categories AS C
  INNER JOIN Production.Products AS P
    ON (C.categoryid = P.categoryid)
ORDER BY C.categoryname ASC;

SELECT E.firstname
      ,O.orderid
	  ,O.orderdate
	  ,C.companyname
	  ,C.country
FROM HR.Employees AS E
  INNER JOIN SALES.Orders AS O
    ON (E.empid = O.empid)
  INNER JOIN SALES.Customers AS C
    ON (O.custid = C.custid)
WHERE C.country IN (N'USA', N'CANADA');

SELECT CONCAT(E.firstname , ' ' , E.lastname) AS Employee
      ,CONCAT(M.firstname , ' ' , M.lastname) AS Manager
FROM HR.Employees AS E
  INNER JOIN HR.Employees AS M
    ON (E.mgrid = M.empid);

