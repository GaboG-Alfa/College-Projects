SELECT firstname + ' ' + lastname AS FullName
FROM HR.Employees;

SELECT CONCAT(firstname, ' ', lastname) AS FullName
FROM HR.Employees;

SELECT CONVERT(DATE,'20211021');

SELECT CAST('20211021' AS DATE);

SELECT 10+2 AS Resultado;

SELECT CONCAT(firstname, ' ', lastname) AS FullName
      ,hiredate 
	  ,city AS Ciudad
FROM HR.Employees
WHERE country = N'USA'
  AND city = N'Seattle'
ORDER BY Ciudad;

SELECT *
FROM HR.Employees;

--¿En cuáles países trabajan los empleados?
SELECT country
FROM HR.Employees;

SELECT DISTINCT country
FROM HR.Employees;

SELECT city
FROM HR.Employees;

SELECT DISTINCT city
FROM HR.Employees;

SELECT empid
      ,country
FROM HR.Employees;

SELECT DISTINCT empid
               ,country
FROM HR.Employees;

SELECT country
      ,city
FROM HR.Employees;

SELECT DISTINCT country
               ,city
FROM HR.Employees;

SELECT empid
      ,firstname
      ,lastname
FROM HR.Employees
ORDER BY firstname ASC;

SELECT empid
      ,firstname
      ,lastname
FROM HR.Employees
ORDER BY empid ASC;

SELECT empid AS 'Employee ID'
      ,CONCAT(firstname,' ',lastname) AS 'Full Name'
FROM HR.Employees;

SELECT empid AS "Employee ID"
      ,CONCAT(firstname,' ',lastname) AS "Full Name"
FROM HR.Employees;

SELECT empid AS [Employee ID]
      ,CONCAT(firstname,' ',lastname) AS [Full Name]
FROM HR.Employees;

SELECT empid AS 'Employee ID'
      ,CONCAT(firstname,' ',lastname) AS 'Full Name'
FROM HR.Employees
ORDER BY lastname;

SELECT empid AS 'Employee ID'
      ,CONCAT(firstname,' ',lastname) AS 'Full Name'
FROM HR.Employees
ORDER BY 'Full Name';

--¿Cuál país tiene más empleados?
SELECT country
      ,COUNT(*) AS Cantidad
FROM HR.Employees
GROUP BY country;

SELECT country
      ,COUNT(*) AS Cantidad
FROM HR.Employees
GROUP BY country
ORDER BY Cantidad DESC;

SELECT TOP 1 country
      ,COUNT(*) AS Cantidad
FROM HR.Employees
GROUP BY country
ORDER BY Cantidad DESC;

SELECT country
      ,COUNT(*) AS Cantidad
FROM SALES.Customers
GROUP BY country;

SELECT country
      ,COUNT(*) AS Cantidad
FROM SALES.Customers
GROUP BY country
ORDER BY Cantidad DESC;

SELECT TOP 3 country
      ,COUNT(*) AS Cantidad
FROM SALES.Customers
GROUP BY country
ORDER BY Cantidad DESC;

SELECT TOP 5 country
      ,COUNT(*) AS Cantidad
FROM SALES.Customers
GROUP BY country
ORDER BY Cantidad DESC;

SELECT TOP 3 country
      ,COUNT(*) AS Cantidad
FROM SALES.Customers
GROUP BY country
ORDER BY Cantidad ASC;

SELECT * 
FROM SALES.Customers

SELECT city
      ,COUNT(*) AS Cantidad
FROM SALES.Customers
WHERE country = 'USA'
GROUP BY city
ORDER BY Cantidad DESC;

SELECT country
      ,city
      ,COUNT(*) AS Cantidad
FROM SALES.Customers
GROUP BY country
        ,city
ORDER BY country
        ,city;

SELECT city
      ,COUNT(*) AS Cantidad
FROM SALES.Customers
WHERE country = 'France'
GROUP BY city
HAVING COUNT(*) >= 2
ORDER BY Cantidad DESC;


SELECT country
      ,city
      ,COUNT(*) AS Cantidad
FROM SALES.Customers
GROUP BY country
        ,city
HAVING COUNT(*) >= 4
ORDER BY country
        ,city;

SELECT CONCAT(firstname,' ',lastname) AS 'Full Name'
FROM HR.Employees;

SELECT CONCAT(firstname,' ',lastname) AS 'Full Name'
      ,hiredate
FROM HR.Employees;

SELECT CONCAT(firstname,' ',lastname) AS 'Full Name'
      ,hiredate
      ,YEAR(hiredate) AS Year
      ,MONTH(hiredate) AS Month
      ,DAY(hiredate) AS Day
FROM HR.Employees
WHERE hiredate >= CAST('20140131' AS DATE);

SELECT CONCAT(firstname,' ',lastname) AS 'Full Name'
      ,hiredate
      ,YEAR(hiredate) AS Year
      ,MONTH(hiredate) AS Month
      ,DAY(hiredate) AS Day
FROM HR.Employees
WHERE YEAR(hiredate) >= 2014;

SELECT CAST('2014' AS DATE)

SELECT firstname
      ,lastname 
FROM HR.Employees;

SELECT empid
      ,CONCAT(firstname,' ',lastname) AS 'Full Name'
      ,country
      ,region
      ,city
FROM HR.Employees;

SELECT empid
      ,CONCAT(firstname,' ',lastname) AS 'Full Name'
      ,country
      ,region
      ,city
FROM HR.Employees
WHERE region = N'WA';

SELECT empid
      ,CONCAT(firstname,' ',lastname) AS 'Full Name'
      ,country
      ,region
      ,city
FROM HR.Employees
WHERE region <> N'WA'
  OR region IS NULL;

SELECT empid
      ,CONCAT(firstname,' ',lastname) AS 'Full Name'
      ,country
      ,region
      ,city
FROM HR.Employees
WHERE region = NULL;

SELECT empid
      ,CONCAT(firstname,' ',lastname) AS 'Full Name'
      ,country
      ,region
      ,city
FROM HR.Employees
WHERE region IS NULL;

SELECT empid
      ,CONCAT(firstname,' ',lastname) AS 'Full Name'
      ,country
      ,region
      ,city
FROM HR.Employees
WHERE region  IS NOT NULL;

SELECT empid
      ,CONCAT(firstname,' ',lastname) AS 'Full Name'
      ,country
      ,region
      ,city
FROM HR.Employees
WHERE lastname = N'Davis';

SELECT empid
      ,CONCAT(firstname,' ',lastname) AS 'Full Name'
      ,country
      ,region
      ,city
FROM HR.Employees
WHERE lastname LIKE N'D%';

SELECT empid
      ,CONCAT(firstname,' ',lastname) AS 'Full Name'
      ,country
      ,region
      ,city
FROM HR.Employees
WHERE lastname LIKE N'%N';

SELECT empid
      ,CONCAT(firstname,' ',lastname) AS 'Full Name'
      ,country
      ,region
      ,city
FROM HR.Employees
WHERE firstname LIKE N'%IA%';

SELECT empid
      ,CONCAT(firstname,' ',lastname) AS 'Full Name'
      ,country
      ,region
      ,city
FROM HR.Employees
WHERE firstname LIKE N'_A%';


SELECT empid
      ,CONCAT(firstname,' ',lastname) AS 'Full Name'
      ,country
      ,region
      ,city
FROM HR.Employees
WHERE firstname LIKE N'_[AO]%';

SELECT orderid
      ,orderdate
FROM SALES.Orders
WHERE orderdate = CAST('20160212' AS DATE);

SELECT orderid
      ,orderdate
FROM SALES.Orders
WHERE orderdate = DATEFROMPARTS(2016,1,1);

-- MEJOR FORMA DE HACERLO
SELECT orderid
      ,orderdate
FROM SALES.Orders
WHERE orderdate >= DATEFROMPARTS(2016,1,1)
  AND orderdate <= DATEFROMPARTS(2016,12,31);

SELECT orderid
      ,orderdate
FROM SALES.Orders
WHERE orderdate BETWEEN DATEFROMPARTS(2016,1,1)
  AND DATEFROMPARTS(2016,12,31);

SELECT orderid
      ,orderdate
FROM SALES.Orders
WHERE YEAR(orderdate) = 2016;

SELECT empid
      ,CONCAT(firstname,' ',lastname) AS 'Full Name'
      ,country
      ,region
      ,city
FROM HR.Employees
WHERE country = N'USA' AND region = N'WA'
ORDER BY city ASC;

SELECT empid
      ,CONCAT(firstname,' ',lastname) AS 'Full Name'
      ,country
      ,region
      ,city
FROM HR.Employees
WHERE country = N'USA' AND region = N'WA'
ORDER BY city DESC;

SELECT empid
      ,CONCAT(firstname,' ',lastname) AS 'Full Name'
      ,country
      ,region
      ,city
FROM HR.Employees
WHERE country = N'USA' AND region = N'WA'
ORDER BY city
        ,empid ASC;

SELECT DISTINCT country
      ,city
FROM SALES.Customers
ORDER BY country
       ,city;

SELECT empid
      ,CONCAT(firstname,' ',lastname) AS 'Full Name'
      ,country
      ,region
      ,city
      ,birthdate
FROM HR.Employees
WHERE country = N'USA' AND region = N'WA'
ORDER BY birthdate DESC;

SELECT empid
      ,CONCAT(firstname,' ',lastname) AS 'Full Name'
      ,country
      ,region
      ,city
      ,birthdate
FROM HR.Employees
ORDER BY birthdate DESC;

SELECT TOP 3 orderid
      ,orderdate
      ,custid
FROM SALES.Orders;

SELECT TOP (3) orderid
      ,orderdate
      ,custid
FROM SALES.Orders;

SELECT TOP (3) orderid
      ,orderdate
      ,custid
FROM SALES.Orders
ORDER BY orderid ASC;

SELECT TOP (3) orderid
      ,orderdate
      ,custid
FROM SALES.Orders
ORDER BY orderid DESC;

DECLARE @NTOP AS SMALLINT = 3;

SELECT TOP (@NTOP) orderid
      ,orderdate
      ,custid
FROM SALES.Orders
ORDER BY orderid ASC;

SELECT TOP (@NTOP) PERCENT orderid
      ,orderdate
      ,custid
FROM SALES.Orders
ORDER BY orderid ASC;

SELECT empid
      ,CONCAT(firstname,' ',lastname) AS 'Full Name'
      ,country
      ,region
      ,city
      ,hiredate
FROM HR.Employees;

SELECT TOP (3) empid
      ,CONCAT(firstname,' ',lastname) AS 'Full Name'
      ,country
      ,region
      ,city
      ,hiredate
FROM HR.Employees
ORDER BY hiredate DESC;

SELECT TOP (3) empid
      ,CONCAT(firstname,' ',lastname) AS 'Full Name'
      ,country
      ,region
      ,city
      ,hiredate
FROM HR.Employees
ORDER BY (SELECT NULL);

SELECT TOP (3) WITH TIES orderid
      ,orderdate
      ,custid
FROM SALES.Orders
ORDER BY orderdate ASC;

SELECT TOP (3) WITH TIES orderid
      ,orderdate
      ,custid
FROM SALES.Orders
ORDER BY orderdate DESC;

-- SELECT TOP 3
SELECT orderid
      ,orderdate
      ,custid
FROM SALES.Orders
ORDER BY orderdate ASC
OFFSET 0 ROWS FETCH NEXT 3 ROWS ONLY;

-- SELECT TOP 3, PERO INGORE LAS 5 PRIMERAS
SELECT orderid
      ,orderdate
      ,custid
FROM SALES.Orders
ORDER BY orderdate ASC
OFFSET 5 ROWS FETCH NEXT 3 ROWS ONLY;

SELECT orderid
      ,orderdate
      ,custid
FROM SALES.Orders
ORDER BY (SELECT NULL)
OFFSET 5 ROWS FETCH NEXT 3 ROWS ONLY;

SELECT orderid
      ,orderdate
      ,custid
FROM SALES.Orders
ORDER BY orderdate ASC
OFFSET 500 ROWS;

SELECT orderid AS ElIdDeLaOrden
      ,orderdate
      ,custid
FROM SALES.Orders
ORDER BY orderdate DESC
OFFSET 0 ROWS FETCH NEXT 3 ROWS ONLY;

SELECT country
      ,COUNT(*) AS Cantidad
FROM SALES.Customers
WHERE country IN ('Argentina','Brazil','Canada','Mexico','USA','Venezuela')
GROUP BY country
HAVING COUNT(*)>= 8;


SELECT orderid 
      ,orderdate
      ,'book'
FROM SALES.Orders

SELECT *
FROM SALES.Customers;

SELECT *
FROM HR.Employees;

SELECT country
      ,city
      ,COUNT(*) AS CantidadDeClientes
FROM SALES.Customers
GROUP BY country
         ,city
ORDER BY country;

SELECT DISTINCT country
      ,city
FROM SALES.Customers
UNION
SELECT DISTINCT country
      ,city
FROM HR.Employees;

SELECT COUNT(*) AS Cantidad
FROM Production.Categories;

SELECT P.productname
     ,P.unitprice
     ,C.categoryname
FROM Production.Products AS P
  INNER JOIN Production.Categories AS C
    ON (P.categoryid = C.categoryid);


SELECT P.productname
     ,P.unitprice
     ,C.categoryname
     ,S.companyname
FROM Production.Products AS P
  INNER JOIN Production.Categories AS C
    ON (P.categoryid = C.categoryid)
  INNER JOIN Production.Suppliers AS S
    ON (P.supplierid = S.supplierid);

SELECT C.categoryname
      ,COUNT(*) AS CantidadDeProductos
FROM Production.Products AS P
  INNER JOIN Production.Categories AS C
    ON (P.categoryid = C.categoryid)
GROUP BY C.categoryname
ORDER BY CantidadDeProductos DESC;

SELECT S.companyname
      ,COUNT(*) AS CantidadDeProductos
FROM Production.Products AS P
  INNER JOIN Production.Suppliers AS S
    ON (P.supplierid = S.supplierid)
GROUP BY  S.companyname
ORDER BY CantidadDeProductos DESC;

-- MONTO VENDIDO POR PRODUCTO
SELECT P.productname
      ,SUM(OD.qty * OD.unitprice) AS MontoVendido
FROM Production.Products AS P
  INNER JOIN SALES.OrderDetails AS OD
    ON (P.productid = OD.productid)
GROUP BY P.productname
ORDER BY MontoVendido DESC;

--MONTO TOTAL VENDIDO
SELECT SUM(qty * unitprice) AS MontoVendido
FROM SALES.OrderDetails 
--1 354 458.5900

-- VOLUMEN VENDIDO (CANTIDAD) POR PRODUCTO
SELECT P.productname
      ,SUM(OD.qty) AS CantidadVendida
FROM Production.Products AS P
  INNER JOIN SALES.OrderDetails AS OD
    ON (P.productid = OD.productid)
GROUP BY P.productname
ORDER BY CantidadVendida DESC;

SELECT P.productname
      ,SUM(OD.qty) AS CantidadVendida
      ,SUM(OD.qty * OD.unitprice) AS MontoVendido
FROM Production.Products AS P
  INNER JOIN SALES.OrderDetails AS OD
    ON (P.productid = OD.productid)
GROUP BY P.productname
ORDER BY MontoVendido DESC;

SELECT C.categoryname
      ,SUM(OD.qty) AS CantidadVendida
      ,SUM(OD.qty * OD.unitprice) AS MontoVendido
FROM Production.Products AS P
  INNER JOIN SALES.OrderDetails AS OD
    ON (P.productid = OD.productid)
  INNER JOIN Production.Categories AS C
    ON (C.categoryid = P.categoryid)
GROUP BY C.categoryname
ORDER BY MontoVendido DESC;

SELECT C.categoryname
      ,SUM(OD.qty * OD.unitprice) AS MontoVendido
FROM Production.Products AS P
  INNER JOIN SALES.OrderDetails AS OD
    ON (P.productid = OD.productid)
  INNER JOIN Production.Categories AS C
    ON (C.categoryid = P.categoryid)
GROUP BY C.categoryname
ORDER BY MontoVendido DESC;

SELECT YEAR(O.orderdate) AS 'Year'
      ,SUM(OD.qty * OD.unitprice) AS MontoVendido
FROM Sales.Orders AS O
  INNER JOIN SALES.OrderDetails AS OD
    ON (O.orderid = OD.orderid)
GROUP BY YEAR(O.orderdate)
ORDER BY MontoVendido ASC;

SELECT C.country
      ,SUM(OD.qty * OD.unitprice) AS MontoVendido
FROM Sales.Orders AS O
  INNER JOIN SALES.OrderDetails AS OD
    ON (O.orderid = OD.orderid)
  INNER JOIN Sales.Customers AS C
    ON (C.custid = O.custid)
GROUP BY C.country
ORDER BY MontoVendido DESC;

SELECT C.country
      ,SUM(OD.qty) AS CantidadVendida
FROM Sales.Orders AS O
  INNER JOIN SALES.OrderDetails AS OD
    ON (O.orderid = OD.orderid)
  INNER JOIN Sales.Customers AS C
    ON (C.custid = O.custid)
GROUP BY C.country
ORDER BY CantidadVendida DESC;

SELECT TOP 5 C.companyname
      ,SUM(OD.qty * OD.unitprice) AS MontoVendido
FROM Sales.Orders AS O
  INNER JOIN SALES.OrderDetails AS OD
    ON (O.orderid = OD.orderid)
  INNER JOIN Sales.Customers AS C
    ON (C.custid = O.custid)
GROUP BY C.companyname
ORDER BY MontoVendido DESC;


SELECT CONCAT_WS(' ',E.firstname,E.lastname) AS Colaborador
      ,CONCAT_WS(' ',J.firstname,J.lastname) AS Jefe
FROM HR.Employees AS E
  INNER JOIN HR.Employees AS J
    ON (E.mgrid = J.empid);


SELECT CONCAT_WS('-','STRING1','STRING2','STRING3');
SELECT CONCAT('STRING1','-','STRING2','-','STRING3');

SELECT P.productname
      ,C.categoryname
FROM Production.Products AS P,
     Production.Categories AS C
WHERE P.categoryid = C.categoryid
   AND P.discontinued = 0;

SELECT P.productname
      ,C.categoryname
FROM Production.Products AS P
     INNER JOIN Production.Categories AS C
       ON (P.categoryid = C.categoryid)
WHERE P.discontinued = 0;

-- PRODUCTO CARTESIANO
SELECT P.productname
      ,C.categoryname
FROM Production.Products AS P,
     Production.Categories AS C;

SELECT P.productname
      ,C.categoryname
FROM Production.Products AS P CROSS JOIN
     Production.Categories AS C;

INSERT INTO Production.Categories (categoryname,description)
VALUES ('CARBONATADOS','DEBIDAS A BASE DE SODA');

SELECT *
FROM Production.Categories AS C;

SELECT P.productname
      ,C.categoryname
FROM Production.Products AS P
     INNER JOIN Production.Categories AS C
       ON (P.categoryid = C.categoryid);

-- LEFT JOIN
SELECT C.categoryname
      ,P.productname
FROM Production.Categories AS C
     LEFT OUTER JOIN Production.Products AS P
       ON (P.categoryid = C.categoryid);

SELECT *
FROM Production.Categories AS C
     LEFT OUTER JOIN Production.Products AS P
       ON (P.categoryid = C.categoryid);

-- DEVOLVER LAS CATS QUE NO TIENEN PRODUCTOS AUN
SELECT C.*
FROM Production.Categories AS C
     LEFT OUTER JOIN Production.Products AS P
       ON (P.categoryid = C.categoryid)
WHERE P.productname IS NULL;

SELECT C.categoryname
      ,P.productname
FROM Production.Products AS P
     RIGHT OUTER JOIN Production.Categories AS C
       ON (P.categoryid = C.categoryid);

SELECT C.categoryname
      ,SUM(OD.qty * OD.unitprice) AS MontoVendido
FROM Production.Categories AS C
     LEFT OUTER JOIN Production.Products AS P
       ON (P.categoryid = C.categoryid)
     LEFT OUTER JOIN SALES.OrderDetails AS OD
       ON (P.productid = OD.productid)
GROUP BY C.categoryname;

SELECT C.categoryname
      ,COALESCE(SUM(OD.qty * OD.unitprice),0) AS MontoVendido
FROM Production.Categories AS C
     LEFT OUTER JOIN Production.Products AS P
       ON (P.categoryid = C.categoryid)
     LEFT OUTER JOIN SALES.OrderDetails AS OD
       ON (P.productid = OD.productid)
GROUP BY C.categoryname;

SELECT CONCAT_WS(' ',E.firstname,E.lastname) AS Colaborador
FROM HR.Employees AS E
  LEFT OUTER JOIN SALES.Orders AS O
    ON (E.empid = O.empid)
WHERE O.orderid IS NULL
  AND YEAR(orderdate) = 2014 OR YEAR(orderdate) IS NULL;


SELECT C.companyname, O.orderdate
FROM Sales.Customers AS C
  LEFT OUTER JOIN SALES.Orders AS O
    ON (C.custid = O.custid)
WHERE O.orderid IS NULL
  AND YEAR(O.orderdate) = 2014 OR YEAR(O.orderdate) IS NULL;

SELECT GETDATE();
SELECT SYSDATETIME();

SELECT YEAR(GETDATE());
SELECT CAST(GETDATE() AS DATE);
SELECT CAST(GETDATE() AS TIME);
SELECT DATEPART(DAYOFYEAR,GETDATE());
SELECT DATENAME(DD,GETDATE());
SELECT EOMONTH(GETDATE());

SELECT EOMONTH(CAST('20210202' AS DATE));

SELECT DATEADD(YEAR,10,GETDATE());

SELECT DATEDIFF(YEAR,CAST('19830516' AS DATE),GETDATE());
SELECT DATEDIFF(MONTH,CAST('19830516' AS DATE),GETDATE());
SELECT DATEDIFF(DAY,CAST('19830516' AS DATE),GETDATE());

SELECT firstname
       ,DATEDIFF(YEAR,birthdate,GETDATE())
FROM HR.Employees
WHERE DATEDIFF(YEAR,birthdate,GETDATE()) >= 40;

SELECT LEFT('LUIS DIEGO',3);
SELECT RIGHT('LUIS DIEGO',3);
SELECT SUBSTRING('LUIS DIEGO',3,4);
SELECT LEN('LUIS DIEGO');
SELECT REPLACE('.1.2.3','.','_');
SELECT REPLICATE('D',10);
SELECT UPPER('Luis');
SELECT LOWER('Luis');
SELECT LTRIM('  LUIS  ');
SELECT RTRIM('  LUIS  ');
SELECT LTRIM(RTRIM('  LUIS  '));
SELECT TRIM('  LUIS  ');

SELECT LEFT(contactname,6)
FROM SALES.Customers;

SELECT contactname
      ,LEN(contactname) AS Largo
FROM SALES.Customers
ORDER BY LARGO DESC;

DECLARE @Estudiantes AS VARCHAR(200) = 'Luis,Pablo,Paola,Octavio';
SELECT @Estudiantes;

DECLARE @Estudiantes AS VARCHAR(200); 
SET @Estudiantes = 'Luis,Pablo,Paola,Octavio';

SELECT VALUE AS Nombre
FROM STRING_SPLIT(@Estudiantes,',');

SELECT productname
      ,discontinued
      ,CASE discontinued
          WHEN 0 THEN 'FALSO'
          WHEN 1 THEN 'VERDADERO'
          ELSE 'NA'
       END AS discontinued
FROM Production.Products;

SELECT productname
      ,discontinued
      ,CASE 
          WHEN discontinued = 0 THEN 'FALSO'
          WHEN discontinued = 1 THEN 'VERDADERO'
          ELSE 'NA'
       END AS discontinued
FROM Production.Products;

SELECT productname
      ,unitprice
      ,CASE 
          WHEN unitprice <= 20 THEN 'Bajo'
          WHEN unitprice > 20  AND unitprice <= 40 THEN 'Medio'
          WHEN unitprice > 40 THEN 'Alto'
          ELSE 'NA'
       END AS Precio
FROM Production.Products;

INSERT INTO Production.Categories (categoryname,description)
VALUES ('CARBONATADOS','DEBIDAS A BASE DE SODA');

INSERT INTO Production.Categories (description,categoryname)
VALUES ('BEDIDAS TIPO TÉ','TES');

SELECT *
FROM Production.Categories;

INSERT INTO Production.Categories (categoryname,description)
VALUES ('ISOTONICOS','DEBIDAS ENERGETICAS'),
       ('JUGOS','BEDIDAS TIPO JUGOS DE FRUTAS');

INSERT INTO Production.Categories (categoryname,description)
SELECT LEFT(Name,15)
      ,LEFT(Name,15)
FROM AdventureWorks2019.Production.ProductSubcategory;

DELETE FROM Production.Categories
WHERE categoryid >= 166;

GO;

CREATE OR ALTER PROC Production.DevolverSubCategoriasAW 
AS
BEGIN
      SELECT LEFT(Name,15) AS CategoryName
            ,LEFT(Name,15) AS Description
      FROM AdventureWorks2019.Production.ProductSubcategory;

END;

EXEC Production.DevolverSubCategoriasAW;

INSERT INTO Production.Categories (categoryname,description)
EXEC Production.DevolverSubCategoriasAW;

INSERT INTO Production.Categories (categoryname,description)
SELECT LEFT(Name,15)
      ,LEFT(Name,15)
FROM AdventureWorks2019.Production.ProductSubcategory AS AW
  LEFT OUTER JOIN Production.Categories AS P
    ON (AW.Name = P.categoryname COLLATE Modern_Spanish_CI_AS)
WHERE P.categoryid IS NULL;

SELECT *
FROM Production.Categories;

UPDATE Production.Categories
SET description = N'Bedidas energéticas'
WHERE categoryid = 11;

SELECT unitprice
      ,unitprice + (unitprice * 0.05)
FROM Production.Products;

UPDATE Production.Products
SET unitprice = unitprice + (unitprice * 0.05);

UPDATE Production.Products
SET unitprice += (unitprice * 0.02);

UPDATE P
SET unitprice += (P.unitprice * 0.01)
FROM Production.Products AS P
   INNER JOIN SALES.OrderDetails AS OD 
     ON (P.productid = OD.productid)
   INNER JOIN Sales.Orders AS O
     ON (OD.orderid = O.orderid)
WHERE O.shipcountry = N'CANADA';

SELECT YEAR(O.orderdate) AS 'Year'
      ,SUM(OD.qty * OD.unitprice) AS MontoVendido
FROM Sales.Orders AS O
  INNER JOIN SALES.OrderDetails AS OD
    ON (O.orderid = OD.orderid)
GROUP BY YEAR(O.orderdate)
ORDER BY MontoVendido ASC;

UPDATE O
SET orderdate = DATEADD(YEAR,5,orderdate)
FROM SALES.Orders AS O
  INNER JOIN Sales.Customers AS C
    ON (O.custid = C.custid)
WHERE C.country = N'BRAZIL';

UPDATE O
SET orderdate = DATEADD(YEAR,-5,orderdate)
FROM SALES.Orders AS O
  INNER JOIN Sales.Customers AS C
    ON (O.custid = C.custid)
WHERE C.country = N'BRAZIL';

DELETE FROM OD
FROM SALES.Orders AS O
  INNER JOIN Sales.Customers AS C
    ON (O.custid = C.custid)
  INNER JOIN Sales.OrderDetails AS OD
    ON (O.orderid = OD.orderid)
WHERE C.country = N'BRAZIL';

DELETE FROM O
FROM SALES.Orders AS O
  INNER JOIN Sales.Customers AS C
    ON (O.custid = C.custid)
WHERE C.country = N'BRAZIL';

SELECT companyname
      ,contacttitle
INTO Sales.Customer2
FROM SALES.Customers
WHERE country = N'BRAZIL';

SELECT *
FROM Sales.Customer2;

DELETE FROM Sales.Customer2;
TRUNCATE TABLE Sales.Customer2;

SELECT COUNT(DISTINCT custid)
FROM SALES.ORDERS;

SELECT COUNT(*)
FROM SALES.Customers;

SELECT productname
      ,unitprice
FROM Production.Products
WHERE unitprice > (SELECT AVG(unitprice)
                   FROM Production.Products
                  );

SELECT AVG(OD.qty * OD.unitprice)
FROM Sales.Orders AS O
 INNER JOIN SALES.OrderDetails AS OD
   ON (O.orderid = OD.orderid);


SELECT AVG(M.Monto)
FROM (SELECT O.orderid
            ,SUM(OD.qty * OD.unitprice) AS Monto
      FROM Sales.Orders AS O
         INNER JOIN SALES.OrderDetails AS OD
            ON (O.orderid = OD.orderid)
      GROUP BY O.orderid) AS M
      ;

WITH MontoTotalVenta
AS (SELECT O.orderid
          ,SUM(OD.qty * OD.unitprice) AS Monto
    FROM Sales.Orders AS O
      INNER JOIN SALES.OrderDetails AS OD
         ON (O.orderid = OD.orderid)
    GROUP BY O.orderid),
VentaPromedio 
AS (SELECT AVG(Monto) AS MontoAVG
    FROM MontoTotalVenta)
SELECT C.companyname
      ,SUM(OD.qty * OD.unitprice) AS Monto
FROM sales.Customers AS C
  INNER JOIN SALES.Orders AS O
    ON (C.custid = O.custid)
  INNER JOIN SALES.OrderDetails AS OD
         ON (O.orderid = OD.orderid)
GROUP BY C.companyname
HAVING SUM(OD.qty * OD.unitprice) > (SELECT MontoAVG
                                     FROM VentaPromedio);

--1631.8778

SELECT TOP (3)
      P.productname
     ,C.categoryname
     ,SUM(OD.qty * OD.unitprice) AS Monto
FROM Production.Products AS P
 INNER JOIN SALES.OrderDetails AS OD
   ON (P.productid = OD.productid)
 INNER JOIN Production.Categories AS C
   ON (P.categoryid = C.categoryid)
GROUP BY P.productname
        ,C.categoryname
ORDER BY Monto DESC;

SELECT C.categoryname
      ,TOPN.productname
      ,TOPN.Monto
FROM Production.Categories AS C
CROSS APPLY (SELECT TOP (3)
                  P.productname
                 ,SUM(OD.qty * OD.unitprice) AS Monto
            FROM Production.Products AS P
              INNER JOIN SALES.OrderDetails AS OD
                ON (P.productid = OD.productid)
            WHERE P.categoryid = C.categoryid
            GROUP BY P.productname
            ORDER BY Monto DESC) AS TOPN;

SELECT C.categoryname
      ,TOPN.productname
      ,TOPN.Monto
FROM Production.Categories AS C
OUTER APPLY (SELECT TOP (3)
                  P.productname
                 ,SUM(OD.qty * OD.unitprice) AS Monto
            FROM Production.Products AS P
              INNER JOIN SALES.OrderDetails AS OD
                ON (P.productid = OD.productid)
            WHERE P.categoryid = C.categoryid
            GROUP BY P.productname
            ORDER BY Monto DESC) AS TOPN;

INSERT INTO  Production.Categories(categoryname,[description])
VALUES (N'Carbonatados',N'Carbonatados');


WITH TOPNCatByAmount
AS
(SELECT TOP 3 C.categoryname
       ,C.categoryid
       ,SUM(OD.qty * OD.unitprice) AS Monto
 FROM Production.Categories AS C
  INNER JOIN Production.Products AS P
    ON (P.categoryid = C.categoryid)
  INNER JOIN SALES.OrderDetails AS OD
    ON (P.productid = OD.productid)
 GROUP BY C.categoryname
         ,C.categoryid
 ORDER BY Monto DESC
)
SELECT C.categoryname
      ,TOPN.productname
      ,TOPN.Monto
FROM TOPNCatByAmount AS C
CROSS APPLY (SELECT TOP (3)
                  P.productname
                 ,SUM(OD.qty * OD.unitprice) AS Monto
            FROM Production.Products AS P
              INNER JOIN SALES.OrderDetails AS OD
                ON (P.productid = OD.productid)
            WHERE P.categoryid = C.categoryid
            GROUP BY P.productname
            ORDER BY Monto DESC) AS TOPN;

GO;

CREATE OR ALTER VIEW v_TOP3ProdByTop3Categ
AS
WITH TOPNCatByAmount
AS
(SELECT TOP 3 C.categoryname
       ,C.categoryid
       ,SUM(OD.qty * OD.unitprice) AS Monto
 FROM Production.Categories AS C
  INNER JOIN Production.Products AS P
    ON (P.categoryid = C.categoryid)
  INNER JOIN SALES.OrderDetails AS OD
    ON (P.productid = OD.productid)
 GROUP BY C.categoryname
         ,C.categoryid
 ORDER BY Monto DESC
)
SELECT C.categoryname
      ,TOPN.productname
      ,TOPN.Monto
FROM TOPNCatByAmount AS C
CROSS APPLY (SELECT TOP (3)
                  P.productname
                 ,SUM(OD.qty * OD.unitprice) AS Monto
            FROM Production.Products AS P
              INNER JOIN SALES.OrderDetails AS OD
                ON (P.productid = OD.productid)
            WHERE P.categoryid = C.categoryid
            GROUP BY P.productname
            ORDER BY Monto DESC) AS TOPN;

SELECT *
FROM dbo.v_TOP3ProdByTop3Categ;

CREATE OR ALTER PROC TOPNProdByTopNCateg
  @TopNProd AS INT,
  @TopNCat AS INT
AS
BEGIN

      WITH TOPNCatByAmount
      AS
      (SELECT TOP (@TopNCat) C.categoryname
            ,C.categoryid
            ,SUM(OD.qty * OD.unitprice) AS Monto
      FROM Production.Categories AS C
      INNER JOIN Production.Products AS P
      ON (P.categoryid = C.categoryid)
      INNER JOIN SALES.OrderDetails AS OD
      ON (P.productid = OD.productid)
      GROUP BY C.categoryname
            ,C.categoryid
      ORDER BY Monto DESC
      )
      SELECT C.categoryname
            ,TOPN.productname
            ,TOPN.Monto
      FROM TOPNCatByAmount AS C
      CROSS APPLY (SELECT TOP (@TopNProd)
                        P.productname
                  ,SUM(OD.qty * OD.unitprice) AS Monto
                  FROM Production.Products AS P
                  INNER JOIN SALES.OrderDetails AS OD
                  ON (P.productid = OD.productid)
                  WHERE P.categoryid = C.categoryid
                  GROUP BY P.productname
                  ORDER BY Monto DESC) AS TOPN;

END;

EXEC TOPNProdByTopNCateg 2,4;

CREATE OR ALTER PROC InsertCategory
  @CatName AS NVARCHAR(15),
  @CatDesc AS NVARCHAR(200)
AS
BEGIN

      INSERT INTO  Production.Categories(categoryname,[description])
      VALUES (@CatName,@CatDesc);

END;

EXEC InsertCategory @CatName = N'Jugos',
                    @CatDesc = N'Jugos';

CREATE OR ALTER VIEW v_Catetories
AS
SELECT categoryid AS CategoryID
      ,categoryname AS CategoryName
      ,[description] as Descrip
FROM Production.Categories;

SELECT *
FROM DBO. v_Catetories;


CREATE OR ALTER PROC UpdateCategory
  @CatName AS NVARCHAR(15),
  @CatDesc AS NVARCHAR(200),
  @CatID AS INT
AS
BEGIN

      UPDATE Production.Categories
      SET categoryname = @CatName
         ,[description] = @CatDesc
      WHERE categoryid = @CatID
       AND (COALESCE(categoryname,'') <> COALESCE(@CatName,'')
            OR COALESCE([description],'') <> COALESCE(@CatDesc,'')
           );

END;

EXEC dbo.UpdateCategory @CatName = N'Carbonatados'
                       ,@CatDesc = N'Esta es la descripción de Carbonatados'
                       ,@CatID = 9;

CREATE OR ALTER FUNCTION f_UltAnioOrders ()
RETURNS INT
AS
BEGIN

      RETURN(SELECT MAX(YEAR(orderdate))
             FROM SALES.ORDERS)
END;

CREATE OR ALTER FUNCTION f_ConcatNames (@FirstName AS NVARCHAR(20),
    @LastName AS NVARCHAR(20))
RETURNS NVARCHAR(60)
AS
BEGIN

      RETURN(SELECT CONCAT_WS(' ',@FirstName,@LastName))
END;


SELECT *
FROM Sales.Orders
WHERE YEAR(orderdate) = dbo.f_UltAnioOrders ()

SELECT dbo.f_ConcatNames(N'LUIS',N'BOLANOS');

SELECT CONCAT_WS(' ',firstname,lastname)
      ,country
FROM HR.EMPLOYEES;

GO;

SELECT SUM(OD.qty * OD.unitprice) AS TotalAmount
FROM Sales.Orders AS O
 INNER JOIN Sales.OrderDetails AS OD
   ON (O.orderid = OD.orderid);

-- 1354458.5900
-- 1,354,458.5900

WITH MontoTotalVenta
AS (SELECT O.orderid
          ,O.custid
          ,O.orderdate
          ,SUM(OD.qty * OD.unitprice) AS TotalAmount
    FROM Sales.Orders AS O
      INNER JOIN Sales.OrderDetails AS OD
        ON (O.orderid = OD.orderid)
    GROUP BY O.orderid
            ,O.custid
            ,O.orderdate
    )
SELECT custid
      ,orderid
      ,TotalAmount
      --,SUM(TotalAmount) OVER (PARTITION BY custid) AS TotalAmountByCustomer
      ,100 * ((TotalAmount)/SUM(TotalAmount) OVER (PARTITION BY custid)) AS PorcOrdCliente
      --,SUM(TotalAmount) OVER () AS GrandTotal
      ,100 * ((SUM(TotalAmount) OVER (PARTITION BY custid))/(SUM(TotalAmount) OVER ())) AS PorcTotal
FROM MontoTotalVenta
ORDER BY PorcTotal DESC;

WITH MontoTotalVenta
AS (SELECT O.orderid
          ,O.custid
          ,O.orderdate
          ,SUM(OD.qty * OD.unitprice) AS TotalAmount
    FROM Sales.Orders AS O
      INNER JOIN Sales.OrderDetails AS OD
        ON (O.orderid = OD.orderid)
    GROUP BY O.orderid
            ,O.custid
            ,O.orderdate
    )
SELECT custid
      ,orderid
      ,orderdate
      ,TotalAmount
      ,SUM(TotalAmount) OVER (PARTITION BY custid) AS TotalAmountByCustomer
      ,SUM(TotalAmount) OVER (PARTITION BY custid
                              ORDER BY orderdate, orderid 
                              ROWS BETWEEN UNBOUNDED PRECEDING 
                                AND CURRENT ROW
                              ) AS AcumuladoPorFecha
FROM MontoTotalVenta;


WITH MontoTotalVenta
AS (SELECT YEAR(O.orderdate) AS Anio
          ,MONTH(O.orderdate) AS Mes
          ,SUM(OD.qty * OD.unitprice) AS TotalAmount
    FROM Sales.Orders AS O
      INNER JOIN Sales.OrderDetails AS OD
        ON (O.orderid = OD.orderid)
    GROUP BY YEAR(O.orderdate)
          ,MONTH(O.orderdate)
    )
SELECT Anio
      ,Mes
      ,TotalAmount
      ,SUM(TotalAmount) OVER (PARTITION BY Anio) AS TotalAmountByAnnio
      ,SUM(TotalAmount) OVER (PARTITION BY Anio
                              ORDER BY Anio, Mes 
                              ROWS BETWEEN UNBOUNDED PRECEDING 
                                AND CURRENT ROW
                              ) AS AcumuladoPorMes
FROM MontoTotalVenta;

ALTER TABLE SALES.Customers
DROP COLUMN test;

ALTER TABLE SALES.Customers
ADD Test INT NULL;

CREATE OR ALTER VIEW v_USACust
 WITH SCHEMABINDING
AS
SELECT custid
      ,companyname
      ,contactname
FROM SALES.Customers
WHERE country = N'USA';

SELECT *
FROM v_USACust;

BEGIN TRAN
ALTER TABLE SALES.Customers
DROP COLUMN companyname;
ROLLBACK TRAN;

CREATE OR ALTER VIEW v_USACust
 WITH SCHEMABINDING, ENCRYPTION
AS
SELECT custid
      ,companyname
      ,contactname
FROM SALES.Customers
WHERE country = N'USA';

CREATE OR ALTER FUNCTION dbo.MyGetDate()
RETURNS DATE
AS
BEGIN
      RETURN CAST(GETDATE() AS DATE)
END;

SELECT dbo.MyGetDate()

CREATE OR ALTER FUNCTION dbo.GetUSACust (@Pais AS NVARCHAR(15))
RETURNS TABLE
WITH SCHEMABINDING
AS
   RETURN (SELECT custid
                 ,companyname
                 ,contactname
           FROM SALES.Customers
           WHERE country = @Pais
           );

SELECT *
FROM dbo.GetUSACust ();

GO;

CREATE OR ALTER PROC InsertCategory
     @CatName AS NVARCHAR(20)  = N''
    ,@CatDesc AS NVARCHAR(200) = N''
    ,@new_id INT = NULL OUTPUT
    ,@ErrDesc AS NVARCHAR(200)  OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    BEGIN TRY
        INSERT INTO  Production.Categories
        (categoryname,[description])
         VALUES (@CatName ,@CatDesc);

        SET @new_id = SCOPE_IDENTITY();

        RETURN 1

    END TRY
    BEGIN CATCH

        SET @ErrDesc = ERROR_MESSAGE();

        RETURN 0;

    END CATCH

END;

DECLARE @new_id AS INT = NULL,
        @Resultado AS INT,
        @ErrDesc AS NVARCHAR(200)
        ;

EXEC @Resultado = dbo.InsertCategory @CatName = null, 
                                     @CatDesc = N'XXXXXXX', 
                                     @new_id = @new_id OUTPUT,
                                     @ErrDesc = @ErrDesc OUTPUT;

IF @Resultado = 1 
BEGIN 
      SELECT @new_id
END
ELSE
BEGIN
      PRINT @ErrDesc
END;

SELECT *
FROM Production.Categories;


