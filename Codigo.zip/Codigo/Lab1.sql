CREATE DATABASE Lab1;

USE Lab1;

CREATE TABLE Producto(
ProductoID INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
Nombre NVARCHAR(100) NOT NULL,
ExcentoImpuestos BIT NOT NULL
);


CREATE TABLE IdentificadorTipo(
IdentificadorTipoID TINYINT IDENTITY(1,1) PRIMARY KEY NOT NULL,
TipoDescripcion NVARCHAR(100) NOT NULL
);

INSERT INTO IdentificadorTipo(TipoDescripcion)
VALUES (N'SKU'),
       (N'UPCA'),
       (N'ISBN');

CREATE TABLE Identificador(
IdentificadorID INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
IdentificadorTipoID TINYINT NOT NULL,
ProductoID INT NOT NULL,
Valor NVARCHAR(100) NOT NULL
);

CREATE TABLE AsociacionTipo(
AsociacionTipoID TINYINT IDENTITY(1,1) PRIMARY KEY NOT NULL,
TipoDescripcion NVARCHAR (100) NOT NULL
);

INSERT INTO AsociacionTipo(TipoDescripcion )
VALUES (N'Combo'),
       (N'Sustituto');


CREATE TABLE Asociacion(
AsociacionID INT IDENTITY(1,1) PRIMARY KEY NOT NULL,
ProductoID INT NOT NULL,
ProductoAsociadoID INT NOT NULL,
AsociacionTipoID TINYINT NOT NULL,
FechaDesde DATE NULL,
FechaHasta DATE NULL,
Cantidad TINYINT NOT NULL,
Instrucciones NVARCHAR(150) NULL
);

ALTER TABLE Asociacion
ADD CONSTRAINT FK_Asociacion_AsociacionTipo FOREIGN KEY(AsociacionTipoID)
REFERENCES AsociacionTipo(AsociacionTipoID);

ALTER TABLE Asociacion
ADD CONSTRAINT FK_Producto_Asociacion FOREIGN KEY(ProductoID)
REFERENCES Producto(ProductoID);

ALTER TABLE Asociacion
ADD CONSTRAINT FK_Asociacion_ProductoAsociadoID FOREIGN KEY(ProductoAsociadoID)
REFERENCES Producto(ProductoID);

ALTER TABLE Identificador
ADD CONSTRAINT FK_Identificador_IdentificadorTipo FOREIGN KEY(IdentificadorTipoID)
REFERENCES IdentificadorTipo(IdentificadorTipoID);

ALTER TABLE Identificador
ADD CONSTRAINT FK_Producto_Identificador FOREIGN KEY(ProductoID)
REFERENCES Producto(ProductoID);

