USE TSQLV4;

/*Mediante un ejemplo (consulta SQL), demuestre el uso de una instrucci�n
est�ndar y su equivalente en el dialecto. Debe usar un ejemplo con una tabla de
la base de datos*/

--Estandar
SELECT	firstname AS PrimerNombre,
        lastname AS Apellido,
        ISNULL(region,'NA') AS Region
FROM HR.Employees;

--Dialecto
SELECT	firstname AS PrimerNombre,
        lastname AS Apellido,
        COALESCE(region,'NA') AS Region
FROM HR.Employees;


/*Demuestre mediante un ejemplo, la raz�n por la que NULL es una marca y no un
valor o tipo de datos. Debe usar un ejemplo con una tabla de la base de datos.*/

SELECT	companyname AS NombreCompania,
		CONCAT (city,', ',address) AS Localizacion,
		region
FROM Sales.Customers
WHERE (region = NULL);

/*En este caso el utilizar region como un valor da error debido a que esta no es 
ningun valor, por lo que ejecutar el siguiente codigo no lanzara nada.*/

SELECT	companyname AS NombreCompania,
		CONCAT (city,', ',address) AS Localizacion,
		region
FROM Sales.Customers
WHERE (region <> N'BC'
	OR region IS NULL);

/*En este caso el utilizar region como una marca si funciona debido a que algunas 
regiones no poseen datos y seleccionar cuando region es null funciona.*/


/*�Se puede hacer uso de un alias definido en el SELECT en el mismo SELECT?
Mediante un ejemplo justifique su respuesta.*/

SELECT	CONCAT(city,', ',address) AS Localizacion,
		CONCAT(companyname,' ',Localizacion) AS 'Compania y Localizacion'
FROM Production.Suppliers;

/* No se puede definir un alias en SELECT y posteriormente utilizarlo, ya que el comando
SELECT se ejecuta en una sola linea y cambiar el nombre a una columna no es posible.*/


/*Mediante una consulta devuelva un listado de clientes de Am�rica Latina (use el
filtro de pa�s) donde no se haya proporcionado un fax. La consulta debe
desplegar: custid (CustomerID), companyname concatenado con un guion y
contactname (CustomerName), country, city, Region. Ordene los resultados
por pa�s. Si no se ha proporcionado una regi�n use el valor N/A y no despliegue
NULL. El resultado de la consulta se muestra en la siguiente imagen (no todos los
registros).*/

SELECT	custid AS  CustomerID,
		CONCAT(companyname,'-',contactname) AS CustomerName,
		country,
		city,
		COALESCE(region,'N/A') AS Region
FROM Sales.Customers
WHERE country = N'Mexico'
	OR country = N'argentina'
	OR country = N'brazil'
	OR country = N'venezuela'
ORDER BY country ASC;


/*�Por qu� la instrucci�n SELECT * es una mala pr�ctica?, justifique mediante dos
ejemplos*/

/*Utilizar SELECT * es una mala practica debido a que se desperdician recursos
los cuales pueden ser utilizados en otros lados. El seleccionar todo de una columnas 
muy grande puede tomar mucho tiempo, en este caso las columnas no contienen mucha informacion
por la cual no tarda, pero a la vez de que proporciona toda la informacion en desorden
existen cosas que no ocupamos o buscar elementos especificos y realizarlo de esta manera 
nos desperdicia recursos y tiempo.*/

SELECT *
FROM HR.Employees;

/*En este caso, si queremos buscar unicament empleados de la ciudad 'USA' tendriamos que manualmente
descartar empleado por empleado, viendo quienes son del pais seleccionado, pero con un SELECT bien hecho
nos ahorarriamos tiempo.*/

SELECT *
FROM Production.Products;

/*En este otro caso, si queremos buscar productos cuyo precio sea menor a los 30 y que no esten discontinuos
alguna persona tendria que manualmente ver tanto la columna de precio como la de discontinuidad para lograr
seleccionar los productos deseados. Con la buena practica de un SELECT se realizaria automaticamente.*/