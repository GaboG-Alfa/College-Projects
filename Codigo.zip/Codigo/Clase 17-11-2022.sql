SELECT *
FROM HR.Employees;

DELETE FROM HR.Employees
WHERE empid = 16;

DELETE FROM OD
FROM Sales.OrderDetails AS OD
 INNER JOIN SALES.ORDERS AS O
   ON (OD.orderid = O.orderid)
 INNER JOIN SALES.Customers AS C
   ON (O.custid = C.custid)
WHERE C.country = N'MEXICO';

DELETE FROM O
FROM SALES.ORDERS AS O
 INNER JOIN SALES.Customers AS C
   ON (O.custid = C.custid)
WHERE C.country = N'MEXICO';

SELECT C.country 
      ,COUNT(O.orderid) AS Cantidad
FROM SALES.Customers AS C
  LEFT OUTER JOIN SALES.Orders AS O
    ON (O.custid = C.custid)
GROUP BY C.country;

SELECT C.country 
      ,C.contactname 
	  ,O.orderdate
FROM SALES.Customers AS C
  LEFT OUTER JOIN SALES.Orders AS O
    ON (O.custid = C.custid)

SELECT C.country 
      ,C.contactname 
FROM SALES.Customers AS C
  LEFT OUTER JOIN SALES.Orders AS O
    ON (O.custid = C.custid)
WHERE O.orderdate IS NULL;

SELECT *
FROM SALES.Customers AS C
  LEFT OUTER JOIN SALES.Orders AS O
    ON (O.custid = C.custid)
WHERE O.orderdate IS NULL;

UPDATE OD
SET OD.discount = 0.9
FROM Sales.OrderDetails AS OD
 INNER JOIN SALES.ORDERS AS O
   ON (OD.orderid = O.orderid)
 INNER JOIN SALES.Customers AS C
   ON (O.custid = C.custid)
WHERE C.country = N'USA';

GO;

CREATE OR ALTER VIEW v_EstadisticaCliente
AS
SELECT C.companyname AS CLIENTE
      ,SUM((OD.unitprice * OD.qty) - OD.discount) AS MONTO
	  ,COUNT(DISTINCT O.orderid) AS CANTIDAD
	  ,AVG((OD.unitprice * OD.qty) - OD.discount) AS PROMEDIO
FROM Sales.Customers AS C
  INNER JOIN Sales.Orders AS O
    ON (C.custid = O.custid)
  INNER JOIN Sales.OrderDetails AS OD
    ON (OD.orderid = O.orderid)
GROUP BY C.companyname;

SELECT *
FROM v_EstadisticaCliente
WHERE CLIENTE = N'Customer AZJED';


SELECT MAX (discount)
FROM Sales.OrderDetails 

CREATE OR ALTER VIEW v_EstadisticaCliente
AS
SELECT C.companyname AS CLIENTE
      ,SUM((OD.unitprice * OD.qty) - OD.discount) AS MONTO
	  ,COUNT(DISTINCT O.orderid) AS CANTIDAD
	  ,AVG((OD.unitprice * OD.qty) - OD.discount) AS PROMEDIO
FROM Sales.Customers AS C
  INNER JOIN Sales.Orders AS O
    ON (C.custid = O.custid)
  INNER JOIN Sales.OrderDetails AS OD
    ON (OD.orderid = O.orderid)
GROUP BY C.companyname;

CREATE OR ALTER PROC InsertarCategoria
   @Nombre AS NVARCHAR(15),
   @Descripcion AS NVARCHAR(200)
AS
INSERT INTO Production.Categories (categoryname,description )
VALUES (@Nombre,@Descripcion);

CREATE OR ALTER VIEW v_Categoria
AS
SELECT categoryid AS CategoriaID
      ,categoryname AS Nombre
	  ,COALESCE(description,'NO TIENE') AS Descripcion
FROM Production.Categories;

SELECT *
FROM v_Categoria;

EXEC dbo.InsertarCategoria N'Aguas',N'Desc';

CREATE OR ALTER PROC ActualizarCategoria
   @Nombre AS NVARCHAR(15),
   @Descripcion AS NVARCHAR(200),
   @CategoriaID AS INT
AS
UPDATE Production.Categories 
SET categoryname = @Nombre
   ,description = @Descripcion
WHERE categoryid = @CategoriaID;

EXEC ActualizarCategoria N'Carbonatados', N'Gaseosas',16;

CREATE OR ALTER PROC ObtnerEstadisticaCliente
   @CustID AS INT
AS
SELECT C.companyname AS CLIENTE
      ,SUM((OD.unitprice * OD.qty) - OD.discount) AS MONTO
	  ,COUNT(DISTINCT O.orderid) AS CANTIDAD
	  ,AVG((OD.unitprice * OD.qty) - OD.discount) AS PROMEDIO
FROM Sales.Customers AS C
  INNER JOIN Sales.Orders AS O
    ON (C.custid = O.custid)
  INNER JOIN Sales.OrderDetails AS OD
    ON (OD.orderid = O.orderid)
WHERE C.custid = @CustID
GROUP BY C.companyname;

EXEC dbo.ObtnerEstadisticaCliente 40;
