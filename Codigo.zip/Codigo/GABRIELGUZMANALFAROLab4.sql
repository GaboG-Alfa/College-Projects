USE TSQLV4

--1--
SELECT YEAR(OS.orderdate) AS YearOfSale,
       PN.productname AS product,
       SUM(ODT.unitprice * ODT.qty) AS SalesAmount
FROM Sales.OrderDetails AS ODT
 INNER JOIN Production.Products AS PN
  ON(ODT.productid = PN.productid)
 INNER JOIN Sales.Orders AS OS
  ON(ODT.orderid = OS.orderid)
GROUP BY YEAR(OS.orderdate),
         PN.productname
HAVING(SUM(ODT.unitprice * ODT.qty) > 20500)
ORDER BY YearOfSale ASC

--2--
SELECT CS.contactname,
       CASE
	     WHEN SUM(ODS.unitprice * ODS.qty) > 99999 THEN 'AAA'
		 WHEN SUM(ODS.unitprice * ODS.qty) > 49999 AND SUM(ODS.unitprice * ODS.qty) < 100000 THEN 'AA'
		 WHEN SUM(ODS.unitprice * ODS.qty) < 50000 THEN 'A'
		 ELSE 'NA'
	   END AS CustCategory
FROM Sales.Customers AS CS
  INNER JOIN Sales.Orders AS OS
    ON(CS.custid = OS.custid)
  INNER JOIN Sales.OrderDetails AS ODS
    ON(OS.orderid = ODS.orderid)
GROUP BY CS.contactname
ORDER BY CustCategory DESC;

--3--
DECLARE @ENDYEAR AS INT;

SET @ENDYEAR = (SELECT YEAR(MAX(orderdate))
                FROM Sales.Orders);

SELECT CONCAT(CS.custid, ' - ', CS.contactname) AS CustomerName,
       COALESCE(CS.country, 'N/A') AS Country,
	   SUM(ODS.unitprice * ODS.qty) AS TotalAmount
FROM Sales.Customers AS CS
  LEFT OUTER JOIN Sales.Orders AS OS
    ON(CS.custid = OS.custid)
  LEFT OUTER JOIN Sales.OrderDetails AS ODS
    ON(OS.orderid = ODS.orderid)
WHERE @ENDYEAR  >= 2016
GROUP BY CONCAT(CS.custid, ' - ', CS.contactname),
         COALESCE(CS.country, 'N/A');

--4--
SELECT CS.categoryname AS CategoryName,
       SUM(ODS.unitprice * ODS.qty) AS TotalAmount,
	   AVG((ODS.unitprice * ODS.qty) - ODS.discount) AS AvgAmount
FROM Production.Categories AS CS
  LEFT OUTER JOIN Production.Products AS PS
    ON(CS.categoryid = PS.categoryid)
  LEFT OUTER JOIN Sales.OrderDetails AS ODS
    ON(PS.productid = ODS.productid)
GROUP BY CS.categoryname;
