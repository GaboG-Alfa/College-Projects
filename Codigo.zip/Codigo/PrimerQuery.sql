CREATE DATABASE HolaMundo;

USE HolaMundo;

CREATE TABLE Estudiante(
Carne char(6) NOT NULL PRIMARY KEY,
Nombre varchar (100) NOT NULL);