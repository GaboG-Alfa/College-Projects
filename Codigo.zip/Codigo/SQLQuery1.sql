SELECT contactname AS 'ContactName'
       ,city AS 'City'
	   ,region AS 'Region'
	   ,COALESCE(region,'NA') AS 'Region'
	   ,COALESCE(fax,'NA') AS 'Fax'
FROM Sales.Customers
WHERE country = N'Mexico';

SELECT CONVERT(DATE,'20221020') AS FechaHoy;

SELECT CAST('20221020' AS DATE) AS FechaHoy;

SELECT CAST('2022A' AS VARCHAR(20)) AS FechaHoy;

SELECT CAST('2022A' AS VARCHAR(20)) AS FechaHoy;

SELECT CAST('2022A' AS VARCHAR(20)) AS FechaHoy;

SELECT CONCAT (firstname ,' ', lastname) AS FULLNAME
               ,COALESCE(region,'NA') AS 'Region'
			   ,CAST(hiredate AS DATE) AS hiredate
FROM HR.Employees