USE TSQLV4

--1--
INSERT INTO HR.Employees(lastname,firstname,title,titleofcourtesy,birthdate,hiredate,address,city,region,postalcode,country,phone,mgrid)
VALUES (N'Salas',N'Diego',N'Sales',N'Sr.',CONVERT(DATE,'19900202'),CONVERT(DATE,'20150515'),N'Central,SJO',N'SJO',NULL,NULL,N'Costa Rica',N'555',NULL);

--2--
UPDATE HR.Employees
SET mgrid = 1
WHERE empid = 10;

--3--
INSERT INTO Production.Categories(categoryname,description)
VALUES(N'Category XYZ',N'Description Category XYZ')

--4--
INSERT INTO Production.Products(productname,supplierid,categoryid,unitprice,discontinued)
VALUES(N'Product XYZ',1,1,20.00,0)

--5--
DELETE FROM OD
FROM SALES.OrderDetails AS OD
WHERE OD.productid=77;

--6--
SELECT *
FROM Production.Suppliers
INSERT INTO Production.Suppliers(companyname,contactname,contacttitle,address,city,region,postalcode,country,phone,fax)
VALUES (N'Supplier XYZ',N'Contact XYZ',N'Sales',N'Central,SJO',N'SJO',NULL,NULL,N'Costa Rica',N'555',NULL)

--7--
SELECT *
FROM Sales.Customers

INSERT INTO Sales.Customers(companyname,contactname,contacttitle,address,city,region,postalcode,country,phone,fax)
VALUES (N'Customer XYZ',N'Contact XYZ',N'Sales',N'Central,SJO',N'SJO',NULL,NULL,N'Costa Rica',N'555',NULL)

--8--
DELETE FROM OD
FROM Sales.OrderDetails AS OD
 INNER JOIN HR.Employees AS E
   ON (OD.orderid = E.empid)
WHERE E.country = N'USA' AND E.region = N'NY';

--9--
DELETE FROM O
FROM Sales.Orders AS O
 INNER JOIN HR.Employees AS E
   ON (O.empid = E.empid)
WHERE E.country = N'USA' AND E.region = N'NY';

--10--
UPDATE OD
SET OD.discount = 0.18
FROM Sales.OrderDetails AS OD
 INNER JOIN SALES.ORDERS AS O
   ON (OD.orderid = O.orderid)
 INNER JOIN SALES.Customers AS C
   ON (O.custid = C.custid)
WHERE C.country = N'Spain' AND YEAR(O.orderdate) = 2015 ;

--11--

DECLARE @ENDYEAR AS INT = (SELECT YEAR(MAX(orderdate))
                  FROM Sales.Orders)

SELECT C.companyname,
       COALESCE(C.country,N'N/A') AS Country
	   ,COALESCE(C.region,N'N/A') AS Region
,CASE 
     WHEN COUNT(*) = 0 THEN 'NO hicieron ninguna transacci�n'
	 WHEN COUNT(*) >= 1 AND COUNT(*) <= 10 THEN '1+'
	 WHEN COUNT(*) >= 11 AND COUNT(*) <= 20 THEN '11+'
	 WHEN COUNT(*) >= 21 AND COUNT(*) <= 50 THEN '21+'
	 WHEN COUNT(*) >= 51 AND COUNT(*) <= 80 THEN '51+'
	 WHEN COUNT(*) > 81  THEN '81+'
	 ELSE 'N/A'
END AS RangoTransaccionalidad
FROM Sales.Customers AS C
INNER JOIN Sales.Orders AS O
ON(C.custid = O.custid)
WHERE YEAR(O.orderdate)= @ENDYEAR 
GROUP BY C.companyname,
         COALESCE(C.country,N'N/A'),
		 COALESCE(C.region,N'N/A')

--12--
SELECT C.companyname AS CompanyName,
       COALESCE(C.country, N'N/A') AS Country,
	   COALESCE(C.region,N'N/A') AS Region,
	   CT.categoryname AS CategoryName,
	   COUNT(O.orderid) AS CantidadTransacciones
FROM Sales.Customers AS C
INNER JOIN Sales.Orders AS O
ON(O.custid = C.custid)
INNER JOIN Sales.OrderDetails AS OD
ON(O.orderid=OD.orderid)
INNER JOIN Production.Products AS P
ON(P.productid = OD.productid)
INNER JOIN Production.Categories AS CT
ON(CT.categoryid=P.categoryid)
WHERE(DATEPART(YEAR,O.orderdate)='2015') AND (DATEPART(MONTH,O.orderdate)='12')
GROUP BY C.companyname,
         COALESCE (C.country,N'N/A'),
		 COALESCE (C.region,N'N/A'),
		 CT.categoryname
HAVING COUNT(*) > 3
ORDER BY C.companyname;



