USE TSQLV4;

/*1. Mediante una consulta devuelva el nombre del cliente (contactname) y el puesto (contacttitle) 
para los clientes que viven en Alemania, que tienen un puesto (contacttitle) relacionado a ventas (sales).
Ordene el resultado de mayor a menor por contactname. Para la columna contactname use el alias NombreDelContacto 
y para puesto (contacttitle) use el alias de PuestoDelContacto. */

SELECT contactname AS NombreDelCliente
       ,contacttitle AS PuestoDelContacto
FROM Sales.Customers
WHERE contacttitle LIKE '%Sales%' AND country = 'Germany'
ORDER BY contactname DESC;

/*2. Demuestre mediante un ejemplo �cu�nto registros puede devolver TOP 3 WITH TIES? 
Use un predicado WHERE, no repita ejemplos de la clase.*/

SELECT TOP (3) WITH TIES
        empid
	   ,firstname
	   ,lastname
	   ,city
FROM HR.Employees
ORDER BY city ASC;

/*Permite que devuelva los datos repetidos. Si fuese sin TIES devolveria hasta Paul, 
es decir, devuelve los valores iguales al tercero*/

/*3. Mediante una consulta devuelva un listado de clientes que tengan un puesto de manager o un puesto de owner.
La consulta debe desplegar: custid (CustomerID), contactname (CustomerName), contacttitle.
El resultado de la consulta debe estar ordenado seg�n el contacttitle. Lo que est� entre par�ntesis es el ALIAS de las columnas.*/

SELECT custid AS CustomerID
       ,contactname AS CustomerName
	   ,contacttitle
FROM Sales.Customers
WHERE contacttitle LIKE '%Owner%' OR contacttitle LIKE '%Manager%' 
ORDER BY contacttitle ASC;

/*4. �Cu�nto productos son de la categor�a (CategoryID) 2 � Condiments? */
SELECT COUNT(*) AS Cantidad
FROM Production. Products
WHERE categoryid=2;

/*5. �Cu�ntos productos tienen un precio (UnitPrice) superior o igual a 90 USD?*/

SELECT COUNT(*) AS Cantidad
FROM Production.Products
WHERE unitprice >= 90;

/*6. �Cu�ntos productos est�n descontinuados (Discontinued)? */

SELECT COUNT(*) AS Cantidad
FROM Production.Products
WHERE discontinued = 1;

/*7. �Cu�ntos productos que provee el suplidor (supplierid) 12 - Supplier SVIYA tienen un precio superior o igual a 50 UDS 
y NO est�n descontinuados?*/

SELECT COUNT(*) AS Cantidad
FROM Production.Products
WHERE discontinued = 0 AND supplierid = 12 AND unitprice>=50;



/*8. �Cu�ntos proveedores Production.Suppliers son de Europa y cu�ntos son de Am�rica?*/

SELECT COUNT(*) AS CantidadPorContinente
       ,'AMERICA' AS Continente
FROM Production.Suppliers
WHERE country IN ('Brazil','Canada','USA')
UNION 
SELECT COUNT(*) AS CantidadPorContinente
       ,'EUROPA' AS Continente
FROM Production.Suppliers
WHERE country IN ('UK','Sweden','Spain','Norway', 'Netherlands', 'Italy', 'Germany', 'France', 'Finland', 'Denmark');

SELECT DISTINCT country
FROM Production.Suppliers;

/*9. �Cu�ntos proveedores Production.Suppliers no tienen a�n una Regi�n (region)?*/

SELECT COUNT(*) AS CantidadDeProveedoresSinRegion
FROM Production.Suppliers
WHERE region IS NULL;


/*10. �Cu�l es el producto que m�s se ha vendido en cantidad (QTY) en una orden �nica?  Use la tabla sales.OrderDetails */

SELECT TOP 1 
       productid
       ,qty
FROM Sales.OrderDetails
ORDER BY qty DESC;

/*11. �Cu�l es el descuento m�s alto que se ha hecho a un producto? �A cu�l producto? Use la tabla sales.OrderDetails */
SELECT TOP 1
       productid
	   ,discount
FROM Sales.OrderDetails
ORDER BY discount DESC;

/*12. �Cu�ntas �rdenes se hicieron los �ltimos seis meses del 2015?*/
SELECT COUNT(*) NumeroDeOrdenes
FROM Sales.Orders
WHERE orderdate BETWEEN DATEFROMPARTS(2015,7,1)
  AND  DATEFROMPARTS(2015,12,31);

/*13. �Cu�les son las 3 �rdenes con el mayor costo de env�o (freight)?*/

SELECT TOP 3
         orderid
		 ,custid
		 ,empid
		 ,freight
FROM Sales.Orders
ORDER BY freight DESC;

/*14. �Cu�les �rdenes se han atrasado en su entrega?
Una orden tienen una fecha requerida de entrega (requireddate) y fue entregada en una fecha (shippeddate)?*/

SELECT orderid
       ,requireddate
	   ,shippeddate
FROM Sales.Orders
WHERE requireddate != shippeddate;

/*15. �Cu�ntos clientes tenemos en cada continente?*/
SELECT COUNT(*) AS CantidadPorContinente
       ,'AMERICA'
FROM Sales.Customers
WHERE country IN ('Argentina','Brazil','Canada','Mexico','USA','Venezuela')
UNION 
SELECT COUNT(*) AS CantidadPorContinente
       ,'EUROPA'
FROM Sales.Customers
WHERE country IN ('UK','Sweden','Portugal','Poland','Ireland','Switzerland' ,'Spain','Norway', 'Netherlands', 'Italy', 'Germany', 'France', 
'Finland', 'Denmark','Belgium', 'Austria');


SELECT DISTINCT
       country
FROM Sales.Customers;

/*16. �Cu�ntos clientes tenemos en cada continente que tienen un cargo de Manager?*/
SELECT COUNT(*) AS CantidadPorContinente
       ,'AMERICA'
FROM Sales.Customers
WHERE country IN ('Argentina','Brazil','Canada','Mexico','USA','Venezuela') AND contacttitle LIKE '%Manager%'
UNION 
SELECT COUNT(*) AS CantidadPorContinente
       ,'EUROPA'
FROM Sales.Customers
WHERE country IN ('UK','Sweden','Portugal','Poland','Ireland','Switzerland' ,'Spain','Norway', 'Netherlands', 'Italy', 'Germany', 'France', 
'Finland', 'Denmark','Belgium', 'Austria') AND contacttitle LIKE '%Manager%';

/*17. �Cu�ntas ordenes se han enviado a M�xico (shipcountry) en el segundo semestre del 2014, que fueron enviadas por el supplierid 3 o 2?*/

SELECT COUNT(*) AS CantidadDeOrdenesEnviadas
FROM Sales.Orders
WHERE shipperid = 3 OR shipperid=2 AND shipcountry IN ('Mexico') AND shippeddate BETWEEN DATEFROMPARTS(2014,6,1)
  AND  DATEFROMPARTS(2014,12,31);

/*FORMA MEJOR DE HACERLO SEGUN EL PROFE*/
SELECT COUNT(*) AS CantidadDeOrdenesEnviadas
FROM Sales.Orders
WHERE shipperid IN (3,2) 
AND shipcountry IN ('Mexico') 
AND shippeddate BETWEEN DATEFROMPARTS(2014,6,1)
AND  DATEFROMPARTS(2014,12,31);