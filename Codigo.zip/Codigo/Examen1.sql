CREATE DATABASE ExamenTiquete;

USE ExamenTiquete;

CREATE TABLE Persona(
PersonaID BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
PrimerNombre NVARCHAR(50) NOT NULL,
SegundoNombre NVARCHAR(50) NULL,
PrimerApellido NVARCHAR(50) NOT NULL,
SegundoApellido NVARCHAR(50) NULL,
Tipo NVARCHAR(100) NOT NULL,
);

CREATE TABLE Identificador(
IdentificadorID BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
Valor NVARCHAR(50) NOT NULL,
FechaExpira NVARCHAR(50) NULL,
);

CREATE TABLE TipoIdentificador(
TipoIdentificadorID BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
DescTipo NVARCHAR(50) NOT NULL,
);

CREATE TABLE MedioDeContacto(
MedioID BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
Valor NVARCHAR(50) NOT NULL,
Tipo NVARCHAR(100) NOT NULL,
);

CREATE TABLE Producto(
ProductoID BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
Nombre NVARCHAR(50) NOT NULL,
Cantidad INT NOT NULL,
Precio FLOAT NOT NULL,
);

CREATE TABLE TiqueteElectronico(
TiqueteId BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
Consecutivo NVARCHAR (50) NOT NULL,
Clave NVARCHAR(50) NOT NULL,
Cliente NVARCHAR(50) NOT NULL,
Comprobante NVARCHAR(50) NOT NULL,
FechaYHora NVARCHAR(50) NOT NULL,
Caja NVARCHAR(50) NOT NULL,
);

CREATE TABLE Monto(
MontoId BIGINT IDENTITY(1,1) NOT NULL PRIMARY KEY,
Valor FLOAT NOT NULL,
Tipo NVARCHAR (50) NOT NULL,
);

ALTER TABLE dbo.Persona
ADD CONSTRAINT FK_Persona_Identificador
FOREIGN KEY(PersonaID)
REFERENCES dbo.Identificador(IdentificadorID);

ALTER TABLE dbo.Identificador
ADD CONSTRAINT FK_Identificador_TipoIdentificador
FOREIGN KEY(IdentificadorID)
REFERENCES dbo.TipoIdentificador(TipoIdentificadorID);

ALTER TABLE dbo.Persona
ADD CONSTRAINT FK_Persona_MedioDeContacto
FOREIGN KEY(PersonaID)
REFERENCES dbo.MedioDeContacto(MedioID);

ALTER TABLE dbo.TiqueteElectronico
ADD CONSTRAINT FK_TiqueteElectronico_Monto
FOREIGN KEY(TiqueteID)
REFERENCES dbo.Monto(MontoID);

SET IDENTITY_INSERT Persona ON
INSERT INTO Persona (PersonaID,PrimerNombre,SegundoNombre,PrimerApellido,SegundoApellido,Tipo)
VALUES (3101077742, N'Luis', N'Diego',N'Bola�os',N'Alvarado',N'Cliente');
SET IDENTITY_INSERT Persona OFF

SET IDENTITY_INSERT Identificador ON
INSERT INTO Identificador(IdentificadorID,FechaExpira,Valor)
VALUES (3101077742,'NA','3101077742')
SET IDENTITY_INSERT Identificador OFF

SET IDENTITY_INSERT TipoIdentificador ON
INSERT INTO TipoIdentificador(TipoIdentificadorID,DescTipo)
VALUES (3101077742,'C�dula')
SET IDENTITY_INSERT TipoIdentificador OFF

SET IDENTITY_INSERT MedioDeContacto ON
INSERT INTO MedioDeContacto(MedioID,Valor,Tipo)
VALUES (2,'2105-2400','Tel�fono')
SET IDENTITY_INSERT MedioDeContacto OFF

SET IDENTITY_INSERT Producto ON
INSERT INTO Producto(ProductoID,Nombre,Cantidad,Precio)
VALUES (1,'CLORO BOTELLA 900 ML',1,641.19)
SET IDENTITY_INSERT Monto OFF

SET IDENTITY_INSERT Producto ON
INSERT INTO Producto(ProductoID,Nombre,Cantidad,Precio)
VALUES (2,'ACEITE DE SOYA 900M BT',2,2367.19)
SET IDENTITY_INSERT Monto OFF

SET IDENTITY_INSERT TiqueteElectronico ON
INSERT INTO TiqueteElectronico(TiqueteId,Clave,Consecutivo,Comprobante,Cliente,Caja,FechaYHora)
VALUES (1,'08700002040000287578','20870000204000028757','298058','LUIS DIEGO BOLA�OS A.','298058','21-10-2022 10:58 AM')
SET IDENTITY_INSERT TiqueteElectronico OFF

SET IDENTITY_INSERT Monto ON
INSERT INTO Monto(MontoId,Valor,Tipo)
VALUES (1,641.19,'Monto Total')
SET IDENTITY_INSERT Monto OFF

SET IDENTITY_INSERT Monto ON
INSERT INTO Monto(MontoId,Valor,Tipo)
VALUES (2,4734.38,'Monto Total')
SET IDENTITY_INSERT Monto OFF

SET IDENTITY_INSERT Monto ON
INSERT INTO Monto(MontoId,Valor,Tipo)
VALUES (3,5375.5,'Monto A Pagar')
SET IDENTITY_INSERT Monto OFF

SET IDENTITY_INSERT Monto ON
INSERT INTO Monto(MontoId,Valor,Tipo)
VALUES (4,5375.5,'Monto Cancelado')
SET IDENTITY_INSERT Monto OFF

SET IDENTITY_INSERT Monto ON
INSERT INTO Monto(MontoId,Valor,Tipo)
VALUES (5,0,'Cambio')
SET IDENTITY_INSERT Monto OFF

SET IDENTITY_INSERT Monto ON
INSERT INTO Monto(MontoId,Valor,Tipo)
VALUES (6,0,'Descuento')
SET IDENTITY_INSERT Monto OFF

SET IDENTITY_INSERT Monto ON
INSERT INTO Monto(MontoId,Valor,Tipo)
VALUES (7,97.21,'IVA')
SET IDENTITY_INSERT Monto OFF







