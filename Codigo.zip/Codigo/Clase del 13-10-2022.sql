CREATE DATABASE ModeloLogico;

USE ModeloLogico;

CREATE TABLE dbo.NaturalezaPersona(
  TipoNaturalezaID TINYINT IDENTITY (1,1) PRIMARY KEY,
  DescNaturaleza NVARCHAR(100) NOT NULL
);

INSERT INTO dbO.NaturalezaPersona(DescNaturaleza)
VALUES (N'Fisica'),
       (N'Juridica');

SELECT *
FROM NaturalezaPersona;

CREATE TABLE dbo.TipoIdentificador(
    TipoIdentificadorID TINYINT IDENTITY (1,1) PRIMARY KEY,
    DescTIpo NVARCHAR(100) NOT NULL
);

INSERT INTO dbO.TipoIdentificador(DescTIpo)
VALUES (N'Cedula'),
       (N'Pasaporte');

CREATE TABLE dbo.TipoRelacion(
    TipoRelacionID TINYINT IDENTITY (1,1) PRIMARY KEY,
    DescRelacion NVARCHAR(100) NOT NULL
);

INSERT INTO dbO.TipoIdentificador(DescTIpo)
VALUES (N'Parentesco'),
       (N'Beneficiario');

CREATE TABLE dbo.Idioma(
    IdiomaID SMALLINT IDENTITY (1,1) PRIMARY KEY,
    DescIdioma NVARCHAR(100) NOT NULL
);

INSERT INTO dbO.Idioma(DescIdioma)
VALUES (N'Espanol'),
       (N'Ingles'),
        (N'Portugues');

SELECT *
FROM Idioma;

CREATE TABLE dbo.EstadoCivil(
    EStadoID TINYINT IDENTITY (1,1) PRIMARY KEY,
    DescEstado NVARCHAR(50)
);

INSERT INTO dbO.EstadoCivil(DescEstado)
VALUES (N'Casado'),
       (N'Soltero'),
       (N'Union Soltera');


CREATE TABLE dbo.Persona(
    PersonaID INT IDENTITY (1,1) PRIMARY KEY,
    TipoNaturalezaID TINYINT NOT NULL,
    EstadoCivilID TINYINT NOT NULL,
    PrimerNombre NVARCHAR(100) NOT NULL
);

ALTER TABLE dbo.Persona ADD CONSTRAINT FK_Persona_TipoPersona FOREIGN KEY (TipoNaturalezaID)
REFERENCES dbo.NaturalezaPersona (TipoNaturalezaID);

ALTER TABLE dbo.Persona ADD CONSTRAINT FK_Persona_EstadoCivil FOREIGN KEY (EstadoCivilID)
    REFERENCES dbo.EstadoCivil (EStadoID);

INSERT INTO Persona (TipoNaturalezaID, EstadoCivilID, PrimerNombre)
VALUES (1, 1, N'Luis');

INSERT INTO dbO.EstadoCivil(DescEstado)
VALUES (N'N/A');

INSERT INTO Persona (TipoNaturalezaID, EstadoCivilID, PrimerNombre)
VALUES (2, 4, N'Dos Pinos');

DELETE dbo.NaturalezaPersona
WHERE TipoNaturalezaID = 1;

CREATE TABLE dbo.IdiomaXPersona(
PersonaID INT NOT NULL,
IdiomaID SMALLINT NOT NULL
);

ALTER TABLE dbo.IdiomaXPersona
ADD CONSTRAINT PK_IdiomaXPersona PRIMARY KEY(PersonaID,IdiomaID);

ALTER TABLE dbo.NaturalezaPersona
ALTER COLUMN DescNaturaleza NVARCHAR(100) NOT NULL;

ALTER TABLE dbo.IdiomaXPersona
ADD CONSTRAINT PK_IdiomaXPersona_Idioma FOREIGN KEY(IdiomaID)
REFERENCES dbo.Idioma(IdiomaID);

ALTER TABLE dbo.IdiomaXPersona
ADD CONSTRAINT PK_IdiomaXPersona_Persona FOREIGN KEY(PersonaID)
REFERENCES dbo.Persona(PersonaID);