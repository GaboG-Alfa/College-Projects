/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author DELL USER
 */
public class StackZ {

    private int contNode = 0;
    private NodeZ head;

    public int getContNode() {
        return contNode;
    }

    public void setContNode(int contNode) {
        this.contNode = contNode;
    }

    public NodeZ getHead() {
        return head;
    }

    public void setHead(NodeZ head) {
        this.head = head;
    }

    

    public void push(NodeZ n) {

        contNode++;

        if (head == null) {

            head = n;

        } else {

            n.setDown(head);

            head.setUp(n);
            
            head = n;

        }

    }

    public void pop() {

        if (contNode > 0) {

            contNode--;

            head = head.getDown();

        }

    }

    public String peek() {

        return head.getDato();

    }

}
