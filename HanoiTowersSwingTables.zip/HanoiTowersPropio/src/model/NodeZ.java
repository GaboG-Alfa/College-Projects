/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author DELL USER
 */
public class NodeZ {
    
    private String dato;
    private NodeZ up;
    private NodeZ down;

    public String getDato() {
        return dato;
    }

    public void setDato(String dato) {
        this.dato = dato;
    }

    public NodeZ getUp() {
        return up;
    }

    public void setUp(NodeZ up) {
        this.up = up;
    }

    public NodeZ getDown() {
        return down;
    }

    public void setDown(NodeZ down) {
        this.down = down;
    }
    
    
}
