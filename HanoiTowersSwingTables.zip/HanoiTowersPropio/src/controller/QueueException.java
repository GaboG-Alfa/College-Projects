package controller;
/**
 * Class with queue exceptions
 */
public class QueueException extends Exception {

    /**
     *
     * @param message
     */
    public QueueException(String message) {
        super(message);
    }
}
