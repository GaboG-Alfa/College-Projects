package controller;

/**
 * Class with stack exceptions
 */
public class StackException extends Exception {

        //Atributes
        private static final long serialVersionUID = 1L;

        /**
         * 
         * @param errorMessage 
         */
        public StackException(String errorMessage) {
                super(errorMessage);
        }

}
