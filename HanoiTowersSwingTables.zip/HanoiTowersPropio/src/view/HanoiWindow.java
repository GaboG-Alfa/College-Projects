package view;

/*
 *
 */

import controller.StackException;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import model.NodeZ;
import model.StackZ;

/**
 *
 * @author Gabriel Guzmán Alfaro
 * @version 1/06/2021
 */
public class HanoiWindow extends javax.swing.JFrame {

    int contNumbMov = 0;
    StackZ stackTowerA;
    StackZ stackTowerB;
    StackZ stackTowerC;

    DefaultTableModel ModelTowerTableA, ModelTowerTableB, ModelTowerTableC;

    int objetivo = 0;

    double numbMinMov = 0;

    boolean stop = false;

    private void restart() {

        try {

            if (!LblMinMov.getText().equals("")) {
                Limpiar();
                start();
            }

        } catch (Exception e) {

            JOptionPane.showMessageDialog(null,"Error "+e,"Error",JOptionPane.ERROR_MESSAGE);

        }

    }

    private void start() throws StackException {

        stackTowerA = new StackZ();
        stackTowerB = new StackZ();
        stackTowerC = new StackZ();

        objetivo = Integer.parseInt(CbNumbDisks.getSelectedItem().toString());

        numbMinMov = Math.pow(2, objetivo) - 1;

        LblNumMov.setText(String.valueOf(contNumbMov));

        LblMinMov.setText(String.valueOf(String.format("%.0f", numbMinMov)));

        for (int x = objetivo; x >= 1; x--) {

            NodeZ plataform = new NodeZ();

            String disk = "";

            for (int y = x; y > 0; y--) {

                disk += "#";

            }

            plataform.setDato(disk);

            stackTowerA.push(plataform);

        }

        PresentarTowerA();
        PresentarTowerB();
        PresentarTowerC();

    }

    /**
     * Creates new form VentanaHanoi
     */
    public HanoiWindow() {
        initComponents();

        ModelTowerTableA = (DefaultTableModel) TowerA.getModel();
        ModelTowerTableA.setRowCount(10);

        ModelTowerTableB = (DefaultTableModel) TowerB.getModel();
        ModelTowerTableB.setRowCount(10);

        ModelTowerTableC = (DefaultTableModel) TowerC.getModel();
        ModelTowerTableC.setRowCount(10);

        DefaultTableCellRenderer renderA = new DefaultTableCellRenderer();
        renderA.setHorizontalAlignment(SwingConstants.CENTER);
        TowerA.getColumnModel().getColumn(0).setCellRenderer(renderA);

        DefaultTableCellRenderer renderB = new DefaultTableCellRenderer();
        renderB.setHorizontalAlignment(SwingConstants.CENTER);
        TowerB.getColumnModel().getColumn(0).setCellRenderer(renderB);

        DefaultTableCellRenderer renderC = new DefaultTableCellRenderer();
        renderC.setHorizontalAlignment(SwingConstants.CENTER);
        TowerC.getColumnModel().getColumn(0).setCellRenderer(renderC);

    }

    private void Limpiar() {

        contNumbMov = 0;
        numbMinMov = 0;
        CbNumbDisks.setSelectedItem(String.valueOf(objetivo));
    }

    private void PresentarCantMov() {

        contNumbMov++;
        LblNumMov.setText(String.valueOf(contNumbMov));

    }

    private void PresentarTowerA() throws StackException {

        ((DefaultTableModel) TowerA.getModel()).setRowCount(0);

        ModelTowerTableA.setRowCount(10);

        NodeZ k;

        int rowDisk = (10 - stackTowerA.getContNode()); //The original have a contNode, no size

        if (stackTowerA.getContNode() > 0) {

            for (k = stackTowerA.getHead(); k.getDown() != null; k = k.getDown()) {

                String[] vectorNormal = {k.getDato()};

                ModelTowerTableA.insertRow(rowDisk, vectorNormal);
                rowDisk++;
            }

            if (k.getDown() == null) {

                String[] vectorNormal = {k.getDato()};
                ModelTowerTableA.insertRow(rowDisk, vectorNormal);

            }

        }

        TowerA.setModel(ModelTowerTableA);
        ModelTowerTableA.setRowCount(10);

    }

    private void PresentarTowerB() throws StackException {

        ((DefaultTableModel) TowerB.getModel()).setRowCount(0);

        ModelTowerTableB.setRowCount(10);

        NodeZ k;

        int rowDisk = (10 - stackTowerB.getContNode()); //The original have a contNode, no size

        if (stackTowerB.getContNode() > 0) {

            for (k = stackTowerB.getHead(); k.getDown() != null; k = k.getDown()) {

                String[] vectorNormal = {k.getDato()};

                ModelTowerTableB.insertRow(rowDisk, vectorNormal);
                rowDisk++;
            }

            if (k.getDown() == null) {

                String[] vectorNormal = {k.getDato()};
                ModelTowerTableB.insertRow(rowDisk, vectorNormal);

            }

        }

        TowerB.setModel(ModelTowerTableB);
        ModelTowerTableB.setRowCount(10);

    }

    private void PresentarTowerC() throws StackException {

        ((DefaultTableModel) TowerC.getModel()).setRowCount(0);

        ModelTowerTableC.setRowCount(10);

        NodeZ k;

        int rowDisk = (10 - stackTowerC.getContNode()); //The original have a contNode, no size

        if (stackTowerC.getContNode() > 0) {

            for (k = stackTowerC.getHead(); k.getDown() != null; k = k.getDown()) {

                String[] vectorNormal = {k.getDato()};

                ModelTowerTableC.insertRow(rowDisk, vectorNormal);
                rowDisk++;
            }

            if (k.getDown() == null) {

                String[] vectorNormal = {k.getDato()};
                ModelTowerTableC.insertRow(rowDisk, vectorNormal);

            }

        }

        TowerC.setModel(ModelTowerTableC);
        ModelTowerTableC.setRowCount(10);

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        BtnA_B = new javax.swing.JButton();
        BtnA_C = new javax.swing.JButton();
        BtnB_A = new javax.swing.JButton();
        BtnB_C = new javax.swing.JButton();
        BtnC_B = new javax.swing.JButton();
        BtnC_A = new javax.swing.JButton();
        CbNumbDisks = new javax.swing.JComboBox<>();
        LblMinMov = new javax.swing.JLabel();
        LblNumMov = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        BtnStart = new javax.swing.JButton();
        BtnReStart = new javax.swing.JButton();
        BtnResolve = new javax.swing.JButton();
        jScrollPane4 = new javax.swing.JScrollPane();
        TowerC = new javax.swing.JTable();
        jScrollPane5 = new javax.swing.JScrollPane();
        TowerA = new javax.swing.JTable();
        jScrollPane6 = new javax.swing.JScrollPane();
        TowerB = new javax.swing.JTable();

        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(jTable1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        BtnA_B.setText("B");
        BtnA_B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnA_BActionPerformed(evt);
            }
        });

        BtnA_C.setText("C");
        BtnA_C.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnA_CActionPerformed(evt);
            }
        });

        BtnB_A.setText("A");
        BtnB_A.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnB_AActionPerformed(evt);
            }
        });

        BtnB_C.setText("C");
        BtnB_C.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnB_CActionPerformed(evt);
            }
        });

        BtnC_B.setText("B");
        BtnC_B.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnC_BActionPerformed(evt);
            }
        });

        BtnC_A.setText("A");
        BtnC_A.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnC_AActionPerformed(evt);
            }
        });

        CbNumbDisks.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "3", "4", "5", "6", "7", "8", "9", "10" }));

        LblMinMov.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        LblMinMov.setForeground(new java.awt.Color(204, 0, 0));
        LblMinMov.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        LblMinMov.setBorder(javax.swing.BorderFactory.createEtchedBorder());

        LblNumMov.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        LblNumMov.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED));

        jLabel4.setText("Number of disks");

        jLabel5.setText("Number of movements");

        jLabel6.setText("Min number of movements");

        BtnStart.setText("Start");
        BtnStart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnStartActionPerformed(evt);
            }
        });

        BtnReStart.setText("ReStart");
        BtnReStart.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnReStartActionPerformed(evt);
            }
        });

        BtnResolve.setText("Resolve");
        BtnResolve.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BtnResolveActionPerformed(evt);
            }
        });

        TowerC.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Tower C"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane4.setViewportView(TowerC);
        if (TowerC.getColumnModel().getColumnCount() > 0) {
            TowerC.getColumnModel().getColumn(0).setResizable(false);
        }

        TowerA.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Tower A"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane5.setViewportView(TowerA);
        if (TowerA.getColumnModel().getColumnCount() > 0) {
            TowerA.getColumnModel().getColumn(0).setResizable(false);
        }

        TowerB.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null},
                {null},
                {null},
                {null},
                {null},
                {null},
                {null},
                {null},
                {null},
                {null}
            },
            new String [] {
                "Tower B"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        TowerB.setShowGrid(false);
        jScrollPane6.setViewportView(TowerB);
        if (TowerB.getColumnModel().getColumnCount() > 0) {
            TowerB.getColumnModel().getColumn(0).setResizable(false);
        }

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(81, 81, 81)
                .addComponent(BtnA_B)
                .addGap(27, 27, 27)
                .addComponent(BtnA_C)
                .addGap(102, 102, 102)
                .addComponent(BtnB_A)
                .addGap(27, 27, 27)
                .addComponent(BtnB_C)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(BtnC_B)
                .addGap(18, 18, 18)
                .addComponent(BtnC_A)
                .addGap(82, 82, 82))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(64, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 118, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(378, 378, 378))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel5, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel6, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(BtnStart)
                                .addGap(79, 79, 79))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(47, 47, 47)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(42, 42, 42))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(CbNumbDisks, javax.swing.GroupLayout.PREFERRED_SIZE, 97, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(19, 19, 19)
                                        .addComponent(BtnReStart)
                                        .addGap(59, 59, 59)
                                        .addComponent(BtnResolve))
                                    .addGroup(layout.createSequentialGroup()
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(LblNumMov, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(LblMinMov, javax.swing.GroupLayout.PREFERRED_SIZE, 127, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                .addGap(152, 152, 152))))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(BtnA_C)
                    .addComponent(BtnA_B)
                    .addComponent(BtnB_A)
                    .addComponent(BtnB_C)
                    .addComponent(BtnC_B)
                    .addComponent(BtnC_A))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(CbNumbDisks, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6)
                    .addComponent(LblMinMov, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(LblNumMov, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(BtnStart)
                    .addComponent(BtnReStart)
                    .addComponent(BtnResolve))
                .addGap(28, 28, 28))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    public void moveA_B() {

        try {

            if (stackTowerA.getContNode() > 0) {

                NodeZ plataform = new NodeZ();

                plataform.setDato(stackTowerA.peek());

                if (stackTowerB.getContNode() > 0) {

                    if (plataform.getDato().compareTo(stackTowerB.peek()) > 0) {

                        return;
                    }

                }

                stackTowerA.pop();
                stackTowerB.push(plataform);

            }

            PresentarTowerA();
            PresentarTowerB();
            PresentarCantMov();

        } catch (StackException ex) {
            JOptionPane.showMessageDialog(null,"Error "+ex,"Error",JOptionPane.ERROR_MESSAGE);
        }

    }

    private void BtnA_BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnA_BActionPerformed

        moveA_B();

    }//GEN-LAST:event_BtnA_BActionPerformed

    public void moveA_C() {

        try {

            if (stackTowerA.getContNode() > 0) {

                NodeZ plataform = new NodeZ();

                plataform.setDato(stackTowerA.peek());

                if (stackTowerC.getContNode() > 0) {

                    if (plataform.getDato().compareTo(stackTowerC.peek()) > 0) {

                        return;
                    }

                }

                stackTowerA.pop();
                stackTowerC.push(plataform);

            }

            PresentarTowerC();
            PresentarTowerA();
            PresentarCantMov();

            if (stackTowerC.getContNode() == objetivo && contNumbMov == numbMinMov) {

                JOptionPane.showMessageDialog(null, "Felicidades has alcanzado el objetivo de minimo de movimientos\n\nIntenta con otro nivel de dificultad", "Felicitaciones", JOptionPane.WARNING_MESSAGE);

            } else if (stackTowerC.getContNode() == objetivo && contNumbMov != numbMinMov) {

                JOptionPane.showMessageDialog(null, "Felicidades lo has resuelto\n\nIntenta superar el objetivo mínimo de movimientos ", "Felicitaciones", JOptionPane.INFORMATION_MESSAGE);

            }

        } catch (StackException ex) {
            JOptionPane.showMessageDialog(null,"Error "+ex,"Error",JOptionPane.ERROR_MESSAGE);
        }

    }

    private void BtnA_CActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnA_CActionPerformed

        moveA_C();

    }//GEN-LAST:event_BtnA_CActionPerformed

    public void moveB_A() {

        try {

            if (stackTowerB.getContNode() > 0) {

                NodeZ plataform = new NodeZ();

                plataform.setDato(stackTowerB.getHead().getDato());

                if (stackTowerA.getContNode() > 0) {

                    if (plataform.getDato().compareTo(stackTowerA.getHead().getDato()) > 0) {

                        return;
                    }

                }

                stackTowerB.pop();
                stackTowerA.push(plataform);

            }

            PresentarTowerB();
            PresentarTowerA();
            PresentarCantMov();

        } catch (StackException ex) {
            JOptionPane.showMessageDialog(null,"Error "+ex,"Error",JOptionPane.ERROR_MESSAGE);
        }

    }

    private void BtnB_AActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnB_AActionPerformed

        moveB_A();
    }//GEN-LAST:event_BtnB_AActionPerformed

    public void moveB_C() {

        try {

            if (stackTowerB.getContNode() > 0) {

                NodeZ plataform = new NodeZ();

                plataform.setDato(stackTowerB.getHead().getDato());

                if (stackTowerC.getContNode() > 0) {

                    if (plataform.getDato().compareTo(stackTowerC.getHead().getDato()) > 0) {

                        return;
                    }

                }

                stackTowerB.pop();
                stackTowerC.push(plataform);

            }

            PresentarTowerC();
            PresentarTowerB();
            PresentarCantMov();

            if (stackTowerC.getContNode() == objetivo && contNumbMov == numbMinMov) {

                JOptionPane.showMessageDialog(null, "Felicidades has alcanzado el objetivo de minimo de movimientos\n\nIntenta con otro nivel de dificultad", "Felicitaciones", JOptionPane.WARNING_MESSAGE);

            } else if (stackTowerC.getContNode() == objetivo && contNumbMov != numbMinMov) {

                JOptionPane.showMessageDialog(null, "Felicidades lo has resuelto\n\nIntenta superar el objetivo mínimo de movimientos ", "Felicitaciones", JOptionPane.INFORMATION_MESSAGE);

            }

        } catch (StackException ex) {
            JOptionPane.showMessageDialog(null,"Error "+ex,"Error",JOptionPane.ERROR_MESSAGE);
        }

    }

    private void BtnB_CActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnB_CActionPerformed

        moveB_C();

    }//GEN-LAST:event_BtnB_CActionPerformed

    public void moveC_B() {

        try {

            if (stackTowerC.getContNode() > 0) {

                NodeZ plataform = new NodeZ();

                plataform.setDato(stackTowerC.getHead().getDato());

                if (stackTowerB.getContNode() > 0) {

                    if (plataform.getDato().compareTo(stackTowerB.getHead().getDato()) > 0) {

                        return;
                    }

                }

                stackTowerC.pop();
                stackTowerB.push(plataform);

            }

            PresentarTowerB();
            PresentarTowerC();
            PresentarCantMov();

        } catch (StackException ex) {
            JOptionPane.showMessageDialog(null,"Error "+ex,"Error",JOptionPane.ERROR_MESSAGE);
        }

    }

    private void BtnC_BActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnC_BActionPerformed

        moveC_B();

    }//GEN-LAST:event_BtnC_BActionPerformed

    public void moveC_A() {

        try {

            if (stackTowerC.getContNode() > 0) {

                NodeZ plataform = new NodeZ();

                plataform.setDato(stackTowerC.getHead().getDato());

                if (stackTowerA.getContNode() > 0) {

                    if (plataform.getDato().compareTo(stackTowerA.getHead().getDato()) > 0) {

                        return;
                    }

                }

                stackTowerC.pop();
                stackTowerA.push(plataform);

            }

            PresentarTowerA();
            PresentarTowerC();
            PresentarCantMov();

        } catch (StackException ex) {
            System.out.println("Error " + ex);
        }

    }

    private void BtnC_AActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnC_AActionPerformed

        moveC_A();
    }//GEN-LAST:event_BtnC_AActionPerformed

    private void BtnStartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnStartActionPerformed

        try {
            start();
        } catch (StackException ex) {
            JOptionPane.showMessageDialog(null,"Error "+ex,"Error",JOptionPane.ERROR_MESSAGE);
        }
    }//GEN-LAST:event_BtnStartActionPerformed


    private void move_Plataform(StackZ origin, StackZ destiny  ) throws StackException{
        
        if(stop== false){
            
            NodeZ plataform = new NodeZ();
            
            plataform.setDato(origin.peek());
            
            origin.pop();
            
            destiny.push(plataform);
            
            PresentarTowerA();
            PresentarTowerB();
            PresentarTowerC();
            PresentarCantMov();
            
            JOptionPane pane = new JOptionPane("Step # "+LblNumMov.getText()+"\n\nContinuar?",JOptionPane.QUESTION_MESSAGE,JOptionPane.YES_NO_OPTION);
            
            JDialog dialog = pane.createDialog("Number of steps");
            
            dialog.setLocation(600,400);
            
            dialog.setVisible(true);
            
            int opt = (int) pane.getValue();
            
            if(opt == JOptionPane.NO_OPTION){
                
                stop=true;
            }
            
        }
        
    }
    
    private void resolveHanoiRecursive(int n, StackZ origin,StackZ aux, StackZ destiny) throws StackException{
        
        if(n==1){
            
            move_Plataform(origin,destiny);
            
        }else{
            
            resolveHanoiRecursive(n -1,origin,destiny,aux);
            
            move_Plataform(origin,destiny);
            
            resolveHanoiRecursive(n -1,aux,origin,destiny);
            
        }
    }
    
    
    
    private void BtnResolveActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnResolveActionPerformed
        
        if(!LblMinMov.getText().equals("") && stackTowerC.getContNode() != objetivo ){
            
            try {
                restart();
                stop = false;
                resolveHanoiRecursive(objetivo,stackTowerA,stackTowerB,stackTowerC);
            } catch (StackException ex) {
              JOptionPane.showMessageDialog(null,"Error "+ex,"Error",JOptionPane.ERROR_MESSAGE);
            }
        }
    }//GEN-LAST:event_BtnResolveActionPerformed

    private void BtnReStartActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BtnReStartActionPerformed
        restart();
    }//GEN-LAST:event_BtnReStartActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(HanoiWindow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(HanoiWindow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(HanoiWindow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(HanoiWindow.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new HanoiWindow().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BtnA_B;
    private javax.swing.JButton BtnA_C;
    private javax.swing.JButton BtnB_A;
    private javax.swing.JButton BtnB_C;
    private javax.swing.JButton BtnC_A;
    private javax.swing.JButton BtnC_B;
    private javax.swing.JButton BtnReStart;
    private javax.swing.JButton BtnResolve;
    private javax.swing.JButton BtnStart;
    private javax.swing.JComboBox<String> CbNumbDisks;
    private javax.swing.JLabel LblMinMov;
    private javax.swing.JLabel LblNumMov;
    private javax.swing.JTable TowerA;
    private javax.swing.JTable TowerB;
    private javax.swing.JTable TowerC;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
}
