package model;

/**
* BinaryCharacter
* @author Diego Alfaro
* @author Carlos Guevara
* @author Nicole Luna
* @author Gabriel Guzman
*/
public class BinaryCharacter implements Comparable<BinaryCharacter> {

    private String binaryCode;
    private Character character;

    public BinaryCharacter(Character character) {
        this.character = character;
    }

    /**
     * @param binaryCode
     */
    public BinaryCharacter(String binaryCode) {
        this.binaryCode = binaryCode;
    }

    /**
     * @param binaryCode
     * @param character
     */
    public BinaryCharacter(Character character, String binaryCode) {
        this.binaryCode = binaryCode;
        this.character = character;
    }

    @Override
    public int compareTo(BinaryCharacter binaryCharacter) {
        return ((Integer) this.binaryCode.length()).compareTo(((Integer) binaryCharacter.getBinaryCode().length()));
    }

    public String getBinaryCode() {
        return binaryCode;
    }

    /**
     * @param binaryCode the binaryCode to set
     */
    public void setBinaryCode(String binaryCode) {
        this.binaryCode = binaryCode;
    }

    /**
     * @return the character
     */
    public Character getCharacter() {
        return character;
    }

    /**
     * @param character the character to set
     */
    public void setCharacter(Character character) {
        this.character = character;
    }

    @Override
    public String toString() {
        return (int) character + "," + binaryCode;
    }

}
