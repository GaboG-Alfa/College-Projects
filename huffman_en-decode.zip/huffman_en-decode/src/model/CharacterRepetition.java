package model;


/**
* CharacterRepetition
* @author Diego Alfaro
* @author Carlos Guevara
* @author Nicole Luna
* @author Gabriel Guzman
*/
public class CharacterRepetition implements Comparable<CharacterRepetition> {
    private Character character;
    private Integer repetitions;

    /**
    * @param character
    */
    public CharacterRepetition(Character character) {
        this.character = character;
        this.repetitions = 1;
    }

    /**
     * @param repetitions of the character in the text
     * @param character 
     */
    public CharacterRepetition(Character character, Integer repetitions) {
        this.character = character;
        this.repetitions = repetitions;
    }

    @Override
    public int compareTo(CharacterRepetition other) {
        return ((Integer) this.repetitions).compareTo(((Integer) other.repetitions));
    }

    /**
     * @return the repetitions
     */
    public Integer getRepetitions() {
        return repetitions;
    }

    /**
     * @param repetitions the repetitions to set
     */
    public void setRepetitions(Integer repetitions) {
        this.repetitions = repetitions;
    }

    /**
     * @return the character
     */
    public Character getCharacter() {
        return character;
    }

    /**
     * @param character the character to set
     */
    public void setCharacter(Character character) {
        this.character = character;
    }

    @Override
    public String toString() {
        return "\n\tcharacter=" + character + ", \n\trepetitions=" + repetitions;
    }

}
