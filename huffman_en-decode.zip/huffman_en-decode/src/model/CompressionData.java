package model;

import java.io.File;

import model.exceptions.LinkedListException;
import model.structures.LinkedList;


/**
* CompressionData
* @author Diego Alfaro
* @author Carlos Guevara
* @author Nicole Luna
* @author Gabriel Guzman
*/

public class CompressionData {
    private File file;
    private String textFile;
    private LinkedList<BinaryCharacter> binaryCharacterCodesList;
    private String binaryText;
    private double compressionPercentage;

    /**
     * @return the compressionPercentage
     */
    public double getCompressionPercentage() {
        return compressionPercentage;
    }

    /**
     * @param compressionPercentage the compressionPercentage to set
     */
    public void setCompressionPercentage(double compressionPercentage) {
        this.compressionPercentage = compressionPercentage;
    }

    /**
     * @return the textFileBits
     */
    public int getTextFileBits() {
        return textFile.length() * 8;
    }

    /**
     * @return the binaryTe xtBits
     */
    public int getBinaryTextBits() {
        return binaryText.length();
    }

    /**
     * @return the file
     */
    public File getFile() {
        return file;
    }

    /**
     * @param file the file to set
     */
    public void setFile(File file) {
        this.file = file;
    }

    /**
     * @return the textFile
     */
    public String getTextFile() {
        return textFile;
    }

    /**
     * @param textFile the textFile to set
     */
    public void setTextFile(String textFile) {
        this.textFile = textFile;
    }

    /**
     * @return the binaryCharacterCodesList
     */
    public LinkedList<BinaryCharacter> getBinaryCharacterCodes() {
        return binaryCharacterCodesList;
    }

    /**
     * @param binaryCharacterCodesList the binaryCharacterCodesList to set
     */
    public void setBinaryCharacterCodes(LinkedList<BinaryCharacter> binaryCharacterCodesList) {
        this.binaryCharacterCodesList = binaryCharacterCodesList;
    }

    /**
     * @return the binaryText
     */
    public String getBinaryText() {
        return binaryText;
    }

    /**
     * @param binaryText the binaryText to set
     */
    public void setBinaryText(String binaryText) {
        this.binaryText = binaryText;
    }

    /**
    * @return the binaryCharacterCodesList
    */
    public String getBinaryCharacterCodesToFileString() {
        if (binaryCharacterCodesList == null)
            return "";
        String exit = "";
        for (int i = 0; i < binaryCharacterCodesList.size(); i++) {
            try {
                exit += (int) binaryCharacterCodesList.get(i).getCharacter() + ","
                        + binaryCharacterCodesList.get(i).getBinaryCode();
            } catch (LinkedListException e) {
                System.out.println(e);
            }
            if (i < binaryCharacterCodesList.size() - 1) {
                exit += ";";
            }
        }
        return exit;
    }

}
