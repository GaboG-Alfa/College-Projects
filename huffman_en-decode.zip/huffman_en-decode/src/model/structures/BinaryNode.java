package model.structures;

/**
 * BinaryNode
 * @author Diego Alfaro
 * @author Carlos Guevara
 * @author Nicole Luna
 * @author Gabriel Guzman
 */
public class BinaryNode<T extends Comparable<T>> implements Comparable<BinaryNode<T>> {
    //
    //Attribute
    private T data;
    private Integer weight;
    private BinaryNode<T> left;
    private BinaryNode<T> right;

    /**
     *
     * @param data
     */
    public BinaryNode(T data) {
        this.data = data;
        this.weight = 0;
    }

    /**
     * @param left
     * @param right
     */
    public BinaryNode(BinaryNode<T> left, BinaryNode<T> right) {
        this.left = left;
        this.right = right;
        this.weight = left.getWeight() + right.getWeight();
    }

    @Override
    public int compareTo(BinaryNode<T> o) {
        return this.weight.compareTo(o.getWeight());
    }

    /**
     *
     * @return dato
     */
    public T getData() {
        return data;
    }

    /**
     * @return the weight
     */
    public Integer getWeight() {
        return weight;
    }

    /**
     * @param weight the weight to set
     */
    public void setWeight(Integer weight) {
        this.weight = weight;
    }

    /**
     *
     * @param data
     */
    public void setData(T data) {
        this.data = data;
    }

    /**
     *
     * @return left
     */
    public BinaryNode<T> getLeft() {
        return this.left;
    }

    /**
     * @param left
     */
    public void setLeft(BinaryNode<T> left) {
        this.weight += left.getWeight();
        this.left = left;
    }

    /**
     *
     * @return right
     */
    public BinaryNode<T> getRight() {
        return this.right;
    }

    /**
     *
     * @param right
     */
    public void setRight(BinaryNode<T> right) {
        this.weight += right.getWeight();
        this.right = right;
    }

    //p^!p
    @Override
    public String toString() {
        return "data: " + (data != null ? data.toString() : "") + ",\nweight " + weight + ",\nleft :"
                + (left != null && left.data != null ? left.data.toString() : "") + ",\nright :"
                + (right != null && right.data != null ? right.data.toString() : "");
    }

}