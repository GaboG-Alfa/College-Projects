package model;

import model.exceptions.LinkedListException;
import model.exceptions.CharacterRepeticionsListException;
import model.structures.BinaryNode;
import model.structures.LinkedList;


/**
* CharacterRepeticionsList
* @author Diego Alfaro
* @author Carlos Guevara
* @author Nicole Luna
* @author Gabriel Guzman
*/
public class CharacterRepeticionsList {
    LinkedList<BinaryNode<CharacterRepetition>> linkedList;

    public CharacterRepeticionsList() {
        linkedList = new LinkedList<BinaryNode<CharacterRepetition>>();
    }

    /**
     * @param binaryNode to insert into a list
     * @return inserted binaryNode
     */
    public BinaryNode<CharacterRepetition> insert(BinaryNode<CharacterRepetition> binaryNode) {
        linkedList.addAtEnd(binaryNode);
        linkedList.sortAcendent();
        return binaryNode;
    }

    /**
     * 
     * @param characterRepetition to insert into a list
     * @return inserted caracter
     */
    public CharacterRepetition insert(CharacterRepetition characterRepetition) {
        BinaryNode<CharacterRepetition> temp = new BinaryNode<CharacterRepetition>(characterRepetition);
        temp.setWeight(characterRepetition.getRepetitions());
        return insert(temp).getData();
    }

    /**
     * 
     * @param charact to search into a list
     * @return the found element
     * @throws CharacterRepeticionsListException if the list is empty or no found
     */
    public BinaryNode<CharacterRepetition> search(Character charact) throws CharacterRepeticionsListException {
        BinaryNode<CharacterRepetition> temp = new BinaryNode<CharacterRepetition>(new CharacterRepetition(charact));
        try {
            temp = linkedList.search(temp,
                    (BinaryNode<CharacterRepetition> data, BinaryNode<CharacterRepetition> other) -> {
                        return data.getData().getCharacter().compareTo(other.getData().getCharacter());
                    });
        } catch (LinkedListException e) {
            throw new CharacterRepeticionsListException(e.getMessage());
        }
        return temp;
    }

    /**
     * 
     * @param binaryNode to search and update
     * @return the updated node
     * @throws CharacterRepeticionsListException
     */
    public BinaryNode<CharacterRepetition> update(BinaryNode<CharacterRepetition> binaryNode)
            throws CharacterRepeticionsListException {
        try {
            binaryNode = linkedList.update(binaryNode, //
                    (BinaryNode<CharacterRepetition> data, BinaryNode<CharacterRepetition> other) -> {
                        return data.getData().getCharacter().compareTo(other.getData().getCharacter());
                    });
        } catch (LinkedListException e) {
            throw new CharacterRepeticionsListException(e.getMessage());
        }
        linkedList.sortAcendent();
        return binaryNode;
    }

    public int size() {
        return linkedList.size();
    }

    /**
     * 
     * @return the removed element
     * @throws CharacterRepeticionsListException  if the list is empty
     */
    public BinaryNode<CharacterRepetition> removeAtStart() throws CharacterRepeticionsListException {
        BinaryNode<CharacterRepetition> temp = null;
        try {
            temp = linkedList.removeAtStart();
        } catch (LinkedListException e) {
            throw new CharacterRepeticionsListException(e.getMessage());
        }
        return temp;
    }

    /**
     * sort the list in a acendent way
     */
    public void sortAcendent() {
        linkedList.sortAcendent();
    }

    /**
     * 
     * @return exit with a string representation of the data of the list
     */
    public String print() {
        String exit = "";
        for (int i = 0; i < linkedList.size(); i++) {
            try {
                if (linkedList.get(i).getData().getCharacter() == '\n') {
                    exit += "'\\n', ";
                } else if (linkedList.get(i).getData().getCharacter() == '\t') {
                    exit += "'\\t', ";
                } else {
                    exit += "'" + linkedList.get(i).getData().getCharacter() + "', ";
                }
                exit += linkedList.get(i).getData().getRepetitions() + "\n";

            } catch (LinkedListException e) {
                System.out.println(e);
            }
        }
        return exit;
    }
}
