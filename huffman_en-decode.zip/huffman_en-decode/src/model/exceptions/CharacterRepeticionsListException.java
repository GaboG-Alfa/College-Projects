package model.exceptions;

/**
* CharacterRepeticionsListException
* @author Diego Alfaro
* @author Carlos Guevara
* @author Nicole Luna
* @author Gabriel Guzman
*/
public class CharacterRepeticionsListException extends Exception {

    /**
     * @param message
     */
    public CharacterRepeticionsListException(String message) {
        super("CharacterRepeticionsList: " + message);
    }

}
