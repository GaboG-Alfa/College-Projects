package model.exceptions;

/**
* DecodeException
* @author Diego Alfaro
* @author Carlos Guevara
* @author Nicole Luna
* @author Gabriel Guzman
*/
public class DecodeException extends Exception {

    /**
     * @param message
     */
    public DecodeException(String message) {
        super("Decode: " + message);
    }

}
