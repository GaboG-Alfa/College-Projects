package model;

import java.io.File;

import model.exceptions.LinkedListException;
import model.structures.LinkedList;

/**
 * DecompressionData
 * @author Diego Alfaro
 * @author Carlos Guevara
 * @author Nicole Luna
 * @author Gabriel Guzman
 */

public class DecompressionData {
    private File file;
    private LinkedList<BinaryCharacter> binaryCharacterCodesList;
    private String binaryText;

    /**
     * @return the file
     */
    public File getFile() {
        return file;
    }

    /**
     * @param file the file to set
     */
    public void setFile(File file) {
        this.file = file;
    }

    /**
     * @return the binaryCharacterCodesList
     */
    public LinkedList<BinaryCharacter> getBinaryCharacterCodes() {
        return binaryCharacterCodesList;
    }

    /**
     * @param binaryCharacterCodesList the binaryCharacterCodesList to set
     */
    public void setBinaryCharacterCodes(LinkedList<BinaryCharacter> binaryCharacterCodesList) {
        this.binaryCharacterCodesList = binaryCharacterCodesList;
    }

    /**
     * @return the binaryText
     */
    public String getBinaryText() {
        return binaryText;
    }

    /**
     * @param binaryText the binaryText to set
     */
    public void setBinaryText(String binaryText) {
        this.binaryText = binaryText;
    }

    /**
    * @return the binaryCharacterCodesList
    */
    public String getBinaryCharacterCodesToString() {
        if (binaryCharacterCodesList == null)
            return "";
        String exit = "";
        for (int i = 0; i < binaryCharacterCodesList.size(); i++) {
            try {
                if (binaryCharacterCodesList.get(i).getCharacter() == '\n') {
                    exit += "'\\n' ";
                } else if (binaryCharacterCodesList.get(i).getCharacter() == '\t') {
                    exit += "'\\t' ";
                } else {
                    exit += "'" + binaryCharacterCodesList.get(i).getCharacter() + "'";
                }
                exit += "\t=\t" + binaryCharacterCodesList.get(i).getBinaryCode();
            } catch (LinkedListException e) {
                System.out.println(e);
            }
            if (i < binaryCharacterCodesList.size() - 1) {
                exit += "\n";
            }
        }
        return exit;
    }

}
