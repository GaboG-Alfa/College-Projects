package controller;

import java.io.File;

import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.stage.Stage;

/**
* FileChoosersHandler
* @author Diego Alfaro
* @author Carlos Guevara
* @author Nicole Luna
* @author Gabriel Guzman
*/
public class FileChoosersHandler {

    /**
    * 
    * @param parentComponent this allows FileChooser to show on top of the app view and disable the app while showing
    * @param title of the FileChooser window
    * @param inicialDirectory  of the FileChooser 
    * @return file choosen
    */

    public static File openFileAndGetPath(Stage parentComponent, String title, String inicialDirectory) {
        return instanciateAFileChooser(title, inicialDirectory).showOpenDialog(parentComponent);
    }

    /**
     * 
     * @param parentComponent this allows FileChooser to show on top of the app view and disable the app while showing
     * @param title of the FileChooser window
     * @param inicialDirectory  of the FileChooser 
     * @return file choosen
     */
    public static File getPathToSaveFile(Stage parentComponent, String title, String inicialDirectory) {
        return instanciateAFileChooser(title, inicialDirectory).showSaveDialog(parentComponent);
    }

    /**
    * @param title of the FileChooser window
    * @param inicialDirectory  of the FileChooser 
    * @return  fileChooser instanced with the parameters 
    */
    private static FileChooser instanciateAFileChooser(String title, String inicialDirectory) {
        FileChooser fileChooser = new FileChooser();
        fileChooser.setTitle(title);

        fileChooser.getExtensionFilters().add(new ExtensionFilter("Text Files", "*.txt"));

        fileChooser.setInitialDirectory(new File("./Files/"));
        fileChooser.setInitialDirectory(new File(inicialDirectory));
        return fileChooser;
    }

}
