package controller.grafical;

import java.net.URL;
import java.util.ResourceBundle;

import controller.FXMLHandler;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import model.CompressionData;
import model.DecompressionData;
import model.grafical.FXMLController;

/**
 * testView
 */
public class ShowCompressedFile implements Initializable, FXMLController {

    @FXML
    private Button backButton;
    @FXML
    private TextArea tableTA;
    @FXML
    private TextArea binaryTextTA;

    private CompressionData compression;
    private DecompressionData decompression;

    /**
     * @param compression
     * @param decompression
     */
    public ShowCompressedFile(CompressionData compression, DecompressionData decompression) {
        this.compression = compression;
        this.decompression = decompression;
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
    }

    @FXML
    private void handleBackButtonClickAction(ActionEvent event) {
        FXMLHandler.loadAndShowFxml(new MainMenu(compression, decompression), "../view/MainMenu.fxml");
        ((Stage) backButton.getScene().getWindow()).close();
    }

    @Override
    public void afterLoad() {
        tableTA.appendText(decompression.getBinaryCharacterCodesToString());
        binaryTextTA.appendText(decompression.getBinaryText());
    }

    @Override
    public EventHandler<WindowEvent> getCloseWindowEvent() {
        return (WindowEvent event) -> {
            FXMLHandler.loadAndShowFxml(new MainMenu(compression, decompression), "../view/MainMenu.fxml");
        };
    }

    @Override
    public String getWindowTitle() {
        return "Huffman Algorithm";
    }

}