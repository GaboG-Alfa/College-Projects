package controller.grafical;

import java.net.URL;
import java.util.ResourceBundle;

import controller.FXMLHandler;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import model.CompressionData;
import model.DecompressionData;
import model.grafical.FXMLController;

/**
 * testView
 */
public class ShowAfterCompressData implements Initializable, FXMLController {

    @FXML
    private Button backButton;

    @FXML
    private TextArea showTA;

    private CompressionData compresion;
    private DecompressionData decompresion;

    /**
     * @param compresion
     * @param decompresion
     */
    public ShowAfterCompressData(CompressionData compresion, DecompressionData decompresion) {
        this.compresion = compresion;
        this.decompresion = decompresion;
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
    }

    @FXML
    private void handleBackButtonClickAction(ActionEvent event) {
        FXMLHandler.loadAndShowFxml(new MainMenu(compresion, decompresion), "../view/MainMenu.fxml");
        ((Stage) backButton.getScene().getWindow()).close();
    }

    @Override
    public void afterLoad() {
        showTA.appendText("amount of bits of original text: " + compresion.getTextFileBits()
                + "\namount of bits of compresed text: " + compresion.getBinaryTextBits() + "\ncompresion percentaje: "
                + compresion.getCompressionPercentage());
    }

    @Override
    public EventHandler<WindowEvent> getCloseWindowEvent() {
        return (WindowEvent e) -> {
            FXMLHandler.loadAndShowFxml(new MainMenu(compresion, decompresion), "../view/MainMenu.fxml");
        };
    }

    @Override
    public String getWindowTitle() {
        return "Huffman Algorithm";
    }

}