package controller;

import java.io.IOException;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import model.grafical.FXMLController;

/**
* FXMLHandler
* @author Diego Alfaro
* @author Carlos Guevara
* @author Nicole Luna
* @author Gabriel Guzman
*/
public class FXMLHandler {

    /**
     * Function is load And Show Fxml
     * @param stage
     * @param controller
     * @param path
     * @param title
     */
    public static void loadAndShowFxml(//
            Stage stage, FXMLController controller, String path) {
        if (stage == null) {
            stage = new Stage();
        }
        Parent root = null;
        FXMLLoader loader = new FXMLLoader(FXMLHandler.class.getResource(path));
        loader.setController(controller);
        try {
            root = loader.load();
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }
        Scene scene = new Scene(root);
        stage.setTitle(controller.getWindowTitle());
        stage.setScene(scene);
        stage.getScene().//
                getWindow().//
                addEventHandler(//
                        WindowEvent.WINDOW_CLOSE_REQUEST, //
                        controller.getCloseWindowEvent()//
                );
        stage.setAlwaysOnTop(false);
        controller = loader.getController();
        controller.afterLoad();
        stage.show();

    }

    /**
     * Function is load And Show Fxml
     * @param controller
     * @param path
     * @param title
     */
    public static void loadAndShowFxml(FXMLController controller, String path) {
        loadAndShowFxml(null, controller, path);
    }

}
