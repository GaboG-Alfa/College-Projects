package controller.Exceptions;

/**
 * @author Gabriel Guzmán Alfaro
 * @author Diego Alfaro Gonzales
 * @author Nicole Garcia Luna
 * @version 02/06/2021
 */
public class MovementQueueException extends Exception {

    /**
     * Throw custom exception message
     * 
     * @param message
     */
    public MovementQueueException(String message) {
        super("MovementQueueException: " + message);
    }
}
