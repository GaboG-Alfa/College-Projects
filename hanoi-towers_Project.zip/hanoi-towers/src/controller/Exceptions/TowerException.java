/**
 * @author Gabriel Guzmán Alfaro
 * @author Diego Alfaro Gonzales
 * @author Nicole Garcia Luna
 * @version 02/06/2021
 */package controller.Exceptions;

public class TowerException extends Exception {

  /**
   * Throw custom exception message
   * @param message
   */
  public TowerException(String message) {
    super("TowerException: " + message);
  }
}
