package controller.Exceptions;

/**
 * @author Gabriel Guzmán Alfaro
 * @author Diego Alfaro Gonzales
 * @author Nicole Garcia Luna
 * @version 02/06/2021
 */
public class QueueException extends Exception {

    /**
     * Throw custom exception message
     * 
     * @param message
     */
    public QueueException(String message) {
        super(message);
    }
}
