package controller;

import controller.Exceptions.MovementQueueException;
import model.Movement;
import model.MovementQueue;
import model.Tower;
import view.Start;

/**
 * @author Gabriel Guzmán Alfaro
 * @author Diego Alfaro Gonzales
 * @author Nicole Garcia Luna
 * @version 02/06/2021
 */
public class GameManager {

  // Attributes
  private Tower firtsTower;
  private Tower secondTower;
  private Tower thirdTower;
  private MovementQueue playerMovements; // Movement Queue of the movements of the player
  private MovementQueue ToSolveMovements = new MovementQueue();
  private int amountDisk;

  /**
   * Constructor
   */
  public GameManager() {
    // new InGame(this);
    new Start(this);

  }

  /**
   * Method that creates the towers. In the first tower it assigns the amount of
   * discs with which the user wishes to play.
   *
   * @param amountDisk number of discs that the user enters to play
   */
  public void inicializateGame(int amountDisk) {
    try {
      firtsTower = new Tower(amountDisk);
      secondTower = new Tower();
      thirdTower = new Tower();
    } catch (Exception e) {
      System.out.println(e);
    }
    this.amountDisk = amountDisk;
    playerMovements = new MovementQueue();
  }

  /**
   * @return the firtsTower
   */
  public Tower getFirtsTower() {
    return firtsTower;
  }

  /**
   * @return the secondTower
   */
  public Tower getSecondTower() {
    return secondTower;
  }

  /**
   * @return the thirdTower
   */
  public Tower getThirdTower() {
    return thirdTower;
  }

  /**
   * @return the playerMovements
   */
  public MovementQueue getPlayerMovements() {
    return playerMovements;
  }

  /**
   * If all the disks have already been passed to the third tower, the player has
   * won the game
   * 
   * @return the true if the player won the game
   */
  public boolean hasWon() {
    return thirdTower.size() == amountDisk;
  }

  /**
   * @return the amount Disk
   */
  public int getAmountDisk() {
    return amountDisk;
  }

  /**
   * Method to validate that a larger disk is not placed on a smaller one
   * 
   * @param initialTowerId origin tower
   * @param finalTowerId   destiny tower
   * @return true if the movement is valid or false if it is not
   */
  public boolean validateMovement(int initialTowerId, int finalTowerId) {
    try {
      if (getTowerById(finalTowerId).size() != 0)
        return getTowerById(finalTowerId).topDisk().getSize() > getTowerById(initialTowerId).topDisk().getSize();
    } catch (Exception e) {
      System.out.println(e.getMessage());
    }
    return true;
  }

  /**
   * Validate If To Select Tower Have Disk
   * 
   * @param initialTowerId origin tower
   * @return true if is valid or false if it is not
   * 
   */
  public boolean validateIfToSelectTowerHaveDisk(int initialTowerId) {
    try {
      return getTowerById(initialTowerId).size() != 0;
    } catch (Exception e) {
      System.out.println(e.getMessage());
    }
    return false;
  }

  /**
   * Method to realize movement the tower a tower
   * 
   * @param initialTowerId
   * @param finalTowerId
   */
  public void doMovement(int initialTowerId, int finalTowerId) {
    try {
      getTowerById(finalTowerId).pushDisk(getTowerById(initialTowerId).popDisk());
    } catch (Exception e) {
      System.out.println(e.getMessage());
    }
  }

  /**
   * Method to get tower objet by id
   * 
   * @param id
   * @return Tower
   */
  private Tower getTowerById(int id) {
    switch (id) {
      case 1:
        return firtsTower;
      case 2:
        return secondTower;
      case 3:
        return thirdTower;
    }
    return null;
  }

  /**
   * Method to get Movements To Solve
   * 
   * @param disks number of discs in tower
   * @return MovementQueue with the movements to solve the game
   */
  public MovementQueue getMovementsToSolve(int disks) {
    return resolveHanoiRecursive(disks, 1, 2, 3);
  }

  /**
   * Method recursive to resolve the game
   * 
   * @param disks          number of discs in tower
   * @param initialTowerId origin tower
   * @param temp
   * @param finalTowerId   distiny tower
   * @return
   */
  private MovementQueue resolveHanoiRecursive(int disks, int initialTowerId, int temp, int finalTowerId) {
    try {
      if (disks == 1) {

        ToSolveMovements.enqueueMovement(new Movement(initialTowerId, finalTowerId));

      } else {

        resolveHanoiRecursive(disks - 1, initialTowerId, finalTowerId, temp);

        ToSolveMovements.enqueueMovement(new Movement(initialTowerId, finalTowerId));

        resolveHanoiRecursive(disks - 1, temp, initialTowerId, finalTowerId);
      }

    } catch (MovementQueueException e) {
      System.out.println(e.getMessage());
    }
    return ToSolveMovements;
  }
}
