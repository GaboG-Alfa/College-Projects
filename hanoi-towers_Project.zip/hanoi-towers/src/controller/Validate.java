package controller;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/*
 * @author Gabriel Guzmán Alfaro
 * @author Diego Alfaro Gonzales
 * @author Nicole Garcia Luna
 * @version 02/06/2021
*/
public class Validate {

  /**
   * Verify the lenght of tower
   * @param password
   * @param minlength
   * @return boolean 
   */
  public static boolean length(String password, int minlength) {
    if (password.length() < minlength) {
      return false;
    }
    return true;
  }

  /**
   * Verify length
   * @param string
   * @param minlength
   * @param maxlength
   * @return boolean
   */
  public static boolean length(String string, int minlength, int maxlength) {
    if (string.length() < minlength && string.length() > maxlength) {
      return false;
    }
    return true;
  }


  /**
   * Verify if contains the numbers
   * @param string
   * @return boolean 
   */
  public static boolean containsNumbers(String string) {
    for (int i = 0; i < string.length(); i++) {
      if (Character.isDigit(string.charAt(i))) {
        return true;
      }
    }
    return false;
  }

  /**
   * Verify if contains the letter
   * @param string
   * @return booleans 
   */
  public static boolean containsUpperCaseLetter(String string) {
    for (int i = 0; i < string.length(); i++) {
      if (Character.isLetter(string.charAt(i)) && Character.isUpperCase(string.charAt(i))) {
        return true;
      }
    }
    return false;
  }

  /**
   * Verify if contains the letter
   * @param string
   * @return 
   */
  public static boolean containsLowerCaseLetter(String string) {
    for (int i = 0; i < string.length(); i++) {
      if (Character.isLetter(string.charAt(i)) && Character.isLowerCase(string.charAt(i))) {
        return true;
      }
    }
    return false;
  }

  /*
   *Verify if contains the simbol 
   * @param string
   * @return 
   */
  public static boolean containsSimbol(String string) {
    for (int i = 0; i < string.length(); i++) {
      if (!Character.isDigit(string.charAt(i)) && !Character.isLetter(string.charAt(i))) {
        return true;
      }
    }
    return false;
  }

  /**
  * Letters and Numbers
  * @param string
  * @return true if the string only have Letters And Numbers
  */
  public static boolean onlyContainsLettersAndNumbers(String string) {
    boolean OnlyHaveLettersAndNumbers = false;
    for (int i = 0; i < string.length(); i++) {
      if (Character.isDigit(string.charAt(i)) || Character.isLetter(string.charAt(i))) {
        OnlyHaveLettersAndNumbers = true;
      } else {
        OnlyHaveLettersAndNumbers = false;
      }
    }
    return OnlyHaveLettersAndNumbers;
  }

  /**
  * Validate if the string only have letters
  * @param string
  * @return true if the string only have Letters
  */
  public static boolean onlyContainsLetters(String string) {
    boolean OnlyHaveLetters = false;
    for (int i = 0; i < string.length(); i++) {
      if (Character.isLetter(string.charAt(i))) {
        OnlyHaveLetters = true;
      } else {
        OnlyHaveLetters = false;
      }
    }
    return OnlyHaveLetters;
  }

  /**
   *Verify  of cotains number
   * @param string
   * @return true if the string only have numbers
   */
  public static boolean onlyContainsNumbers(String string) {
    boolean OnlyHaveNumbers = false;
    for (int i = 0; i < string.length(); i++) {
      if (Character.isDigit(string.charAt(i))) {
        OnlyHaveNumbers = true;
      } else {
        OnlyHaveNumbers = false;
      }
    }
    return OnlyHaveNumbers;
  }

  /**
   * 
   * @param string
   * @return 
   */
  public static boolean isAEmail(String string) {
    Pattern pattern = Pattern.compile("[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}");
    Matcher mat = pattern.matcher(string);
    return mat.matches();
  }

  public static boolean isBetweenIncluded(int val,int min, int max) {
    return val >= min && val <= max;
  }

}
