package model;

import controller.Exceptions.MovementQueueException;
import controller.Exceptions.QueueException;
import model.Lists.Queue;

/**
 * 
 * @author Gabriel Guzmán Alfaro
 * @author Diego Alfaro Gonzales
 * @author Nicole Garcia Luna
 * @version 02/06/2021
 */
public class MovementQueue {

	// Queue containing movements inside
	private Queue<Movement> moves;

	/**
	 * Constructor
	 */
	public MovementQueue() {
		moves = new Queue<Movement>();
	}

	/**
	 * @param movement to enqueue
	 * @throws MovementQueueException
	 */
	public void enqueueMovement(Movement movement) throws MovementQueueException {
		try {
			moves.enqueue(movement);
		} catch (QueueException e) {
			throw new MovementQueueException(e.getMessage());
		}
	}

	/**
	 * 
	 * 
	 * @return movement to dequeue
	 * @throws MovementQueueException
	 */
	public Movement dequeueMovement() throws MovementQueueException {
		try {
			return moves.dequeue();
		} catch (QueueException e) {
			throw new MovementQueueException(e.getMessage());
		}
	}

	/**
	 * 
	 * @return the size of the queue
	 */
	public int getSize() {
		return moves.size();
	}

}
