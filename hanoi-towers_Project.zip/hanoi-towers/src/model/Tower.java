package model;

import controller.Exceptions.StackException;
import controller.Exceptions.TowerException;
import model.Lists.Stack;

/**
 * @author Gabriel Guzmán Alfaro
 * @author Diego Alfaro Gonzales
 * @author Nicole Garcia Luna

 * @version 31/05/2021
 */
public class Tower {

    //Atributes
    private Stack<Disk> stack;

    /**
     * Constructor
     * 
     * @throws TowerException
     */
    public Tower() throws TowerException {
        stack = new Stack<Disk>();
    }

    /**
     * Constructor
     * 
     * @param initialAmountDisk number of discs with which the tower starts
     * @throws TowerException
     */
    public Tower(int initialAmountDisk) throws TowerException {
        stack = new Stack<Disk>();
        try {
            for (int i = initialAmountDisk; i >= 1; i--) {
                stack.push(new Disk(i));
            }
        } catch (StackException e) {
            throw new TowerException(e.getMessage());
        }
    }

    /**
     * @param disk to push
     * @throws StackException
     * @throws TowerException
     */
    public void pushDisk(Disk disk) throws TowerException {
        try {
            if (stack.size() != 0 && disk.getSize() < stack.top().getSize()) {
                stack.push(disk);
            } else if (stack.size() == 0) {
                stack.push(disk);
            }
        } catch (StackException e) {
            throw new TowerException(e.getMessage());
        }
    }

    /**
     * 
     * @return returns and removes the top disk from the stack
     * @throws TowerException
     */
    public Disk popDisk() throws TowerException {
        try {
            return stack.pop();
        } catch (StackException e) {
            throw new TowerException(e.getMessage());
        }
    }

    /**
     * 
     * @return size of the tower (stack)
     */
    public int size() {
        return stack.size();

    }

    /**
     * 
     * @return the disk in the top
     * @throws TowerException
     */
    public Disk topDisk() throws TowerException {
        try {
            return stack.top();
        } catch (StackException e) {
            throw new TowerException(e.getMessage());
        }

    }
    

}
