package model;

/**
 * @author Gabriel Guzmán Alfaro
 * @author Diego Alfaro Gonzales
 * @author Nicole Garcia Luna
  * @version 02/06/2021
 */
public class Movement {

	private int initialTowerId;
	private int finalTowerId;

	/**
	 * Constructor
	 * 
	 * @param initialTowerId is origin tower
	 * @param finalTowerId   is destiny tower
	 */
	public Movement(int initialTowerId, int finalTowerId) {
		this.initialTowerId = initialTowerId;
		this.finalTowerId = finalTowerId;
	}

	/**
	 * @param initialTowerId the initialTowerId to set
	 */
	public void setInitialTowerId(int initialTowerId) {
		this.initialTowerId = initialTowerId;
	}

	/**
	 * @return the initialTowerId
	 */
	public int getInitialTowerId() {
		return initialTowerId;
	}

	/**
	 * @param finalTowerId the finalTowerId to set
	 */
	public void setFinalTowerId(int finalTowerId) {
		this.finalTowerId = finalTowerId;
	}

	/**
	 * @return the finalTowerId
	 */
	public int getFinalTowerId() {
		return finalTowerId;
	}

	@Override
	public String toString() {
		return "Torre inicial " + initialTowerId + " Torre final " + finalTowerId;
	}
}
