package model.Lists;

import controller.Exceptions.StackException;

/**
 * @author Gabriel Guzmán Alfaro
 * @author Diego Alfaro Gonzales
 * @author Nicole Garcia Luna
 * @version 31/05/2021
 */
public class Stack<T> {

	// Atributes
	private Node<T> top;
	private int size;
	private int limitSize;

	/**
	 * Constructor
	 */
	public Stack() {
		limitSize = 0;
		size = 0;
	}

	/**
	 *
	 * @param limitSize
	 * @throws StackException
	 */
	public Stack(int limitSize) throws StackException {
		if (limitSize < 0) {
			throw new StackException("The limit size cant be negative number");
		}
		this.limitSize = limitSize;
	}

	/**
	 *
	 * @param newFact
	 * @return
	 * @throws StackException
	 */
	public T push(T newFact) throws StackException {
		if (limitSize != 0 && size + 1 > limitSize) {
			throw new StackException("The stack is full");
		}
		Node<T> currentNew = new Node<T>(newFact);

		if (top == null) {
			top = currentNew;
			size++;
			return currentNew.getData();
		}

		currentNew.setNext(top);
		top = currentNew;
		size++;
		return currentNew.getData();
	}

	/**
	 *
	 * @return
	 * @throws StackException
	 */
	public T pop() throws StackException {
		if (isEmpty()) {
			throw new StackException("The stack is empty");
		}
		T temp = top.getData();
		top = top.getNext();
		size--;
		return temp;
	}

	/**
	 *
	 * @return top
	 * @throws StackException
	 */
	public T top() throws StackException {
		if (isEmpty()) {
			throw new StackException("The stack is empty");
		}
		return top.getData();
	}

	/**
	 *
	 * @return size
	 */
	public int size() {
		return this.size;
	}

	/**
	 *
	 * @return size
	 */
	public boolean isEmpty() {
		return this.size == 0;
	}

	/**
	 *
	 * @return String representation of the stack
	 */
	public String print() {
		String exit = "\n\ttop";
		for (Node<T> temp = top; temp != null; temp = temp.getNext()) {
			exit += "\n\t | \n\t v \n\t" + temp.getData();
		}
		return exit;
	}

}
