package model.Lists;

/**
 * @author Gabriel Guzmán Alfaro
 * @author Diego Alfaro Gonzales
 * @author Nicole Garcia Luna
 * @version 02/06/2021
 */

public class SingleList<T> {

        //Atributo
	private Node<T> first, last;
	private int size;



        /**
         * Constructor
         */

	public SingleList() {
		size = 0;
	}


        /**
         * 
         * @param stringArray 
         */


	public SingleList(T[] stringArray) {
		size = 0;
		for (T s : stringArray) {
			insertAtStart(s);
		}
	}

        /**
         * Method to insert at the start of the tower
         * @param newFact
         * @return true 
         */
	public boolean insertAtStart(T newFact) {
		
                //Verify if the fact already exist
                if (contains(newFact)) {
			return false;
		}
		Node<T> currentNew = new Node<T>(newFact);
                
                //Insert the fact at start
		if (this.first == null) {
			this.first = last = currentNew;
			size++;
		} else {
			currentNew.setNext(first);
			first = currentNew;
			size++;
		}
		return true;
	}

        /**
         * Print the singleList
         * @return exit 
         */
	public String print() {
		String exit = "";
		for (Node<T> temp = first; temp != null; temp = temp.getNext()) {
			exit += " -> " + temp.getData();
		}
		return exit;
	}

        /**
         * Print with recursive method
         * @return recursivePrint
         */
	public String recursivePrint() {
		return recursivePrint(first);
	}

        /**
         * Print recursive print
         * @param temp
         * @return recursivePrint 
         */
	private String recursivePrint(Node<T> temp) {
		if (temp == null) {
			return "";
		}
		return " -> " + temp.getData() + recursivePrint(temp.getNext());
	}

        /**
         * Insert the fact at the final
         * @param newFact
         * @return insertAtFinal 
         */
	public boolean insertAtFinalPointer(T newFact) {
            
                //Verify if the fact already exists
		if (contains(newFact)) {
			return false;
		}
		Node<T> currentNew = new Node<T>(newFact);

                //insert the fact at the final
		if (last == null) {
			first = last = currentNew;
			size++;
		} else {
			last.setNext(currentNew);
			last = currentNew;
			size++;

		}
		return true;
	}

        /**
         * Remove the first node
         * @return removed element
         */
	public T removeFirst() {
		if (first == null) {
			return null;
		}
		Node<T> toReturn = null;
		if (first == last) {
			toReturn = first;
			first = last = null;
			size--;
		} else {
			toReturn = first;
			first = first.getNext();
			size--;
		}
		return toReturn.getData();

	}

        /**
         * Remove the last node
         * @return toReturn 
         */
	public T removeLast() {
		if (last == null) {
			return null;
		}
		Node<T> toReturn = null;
		if (last == first) {
			toReturn = first;
			first = last = null;
			size--;
		} else {
			Node<T> temp = first;
			while (temp.getNext() != last) {
				temp = temp.getNext();
			}
			toReturn = temp.getNext();
			temp.setNext(null);
			last = temp;
			size--;
		}
		return toReturn.getData();
	}

        /**
         * Remove a node
         * @param index
         * @return toReturn 
         */
	public T remove(int index) {
            
                //Can´t remove
		if (index >= size) {
			return null;
		}
                //Can´t remove
		if (last == null) {
			return null;
		}
                
                //Remove first
		if (index == 0) {
			return removeFirst();
		}
                //Remove last
		if (index == size - 1) {
			return removeLast();
		}
                
                //Remove in middle
		Node<T> temp = first;
		int i = 0;
		while (i != index - 1) {
			temp = temp.getNext();
			i++;
		}
		Node<T> toReturn = temp.getNext();
		temp.setNext(temp.getNext().getNext());
		size--;
		return toReturn.getData();
	}

        /**
         * Search a fact
         * @param toSearchFact
         * @return contains 
         */
	public boolean contains(T toSearchFact) {
                
                //The fact no exist
		if (first == null) {
			return false;
		}
                //The fact exists
		if (last.getData() == toSearchFact) {
			return true;
		}

                //Verify
		for (Node<T> temp = first; temp != null; temp = temp.getNext()) {
			if (temp.getData() == toSearchFact) {
				return true;
			}
		}
		return false;
	}

        /**
         * Return the size of list
         * @return size 
         */
	public int size() {
		return size;
	}

}
