package model.Lists;

/**
 * @author Gabriel Guzmán Alfaro
 * @author Diego Alfaro Gonzales
 * @author Nicole Garcia Luna
 * @version 02/06/2021
 */
public class Node<T> {

        //Atributes
	private T data;
	private Node<T> next;

	/**
	 * Constructor
	 */
	public Node() {
	}

	/**
	 * 
	 * @param data
	 */
	public Node(T data) {
		this.data = data;
	}

	/**
	 * 
	 * @param data
	 * @param next
	 */
	public Node(T data, Node<T> next) {
		this.data = data;
		this.next = next;
	}

	/**
	 * Send data
	 * @param data
	 */
	public void setData(T data) {
		this.data = data;
	}

	/**
	 * Send data to the next nodo
	 * @param next
	 */
	public void setNext(Node<T> next) {
		this.next = next;
	}

	/**
	 * 
	 * @return data
	 */
	public T getData() {
		return data;
	}

	/**
	 * 
	 * @return next nodo
	 */
	public Node<T> getNext() {
		return next;
	}

}
