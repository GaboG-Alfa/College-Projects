package model.Lists;

import controller.Exceptions.QueueException;

/**
 * @author Gabriel Guzmán Alfaro
 * @author Diego Alfaro Gonzales
 * @author Nicole Garcia Luna
 * @version 31/05/2021
 */
public class Queue<T> {

        //Atributos
	private Node<T> front;
	private Node<T> rear;
	private int sizeLimit;
	private int size;

	/**
	 * Constructor
	 */
	public Queue() {
		this.sizeLimit = 0;
		size = 0;
		front = null;
	}

	/**
	 *
	 * @param sizeLimit
	 * @throws QueueException
	 */
	public Queue(int sizeLimit) throws QueueException {
		if (sizeLimit < 0) {
			throw new QueueException("The maximum capacity must be 0 or greater.");
		}
		this.sizeLimit = sizeLimit;
		size = 0;
		front = null;
	}

	/**
	 * size of the queue
	 *
	 * @return
	 */
	public int size() {
		return size;
	}

	/**
	 *
	 * @return true or false
	 */
	public boolean isEmpty() {
		if (front == null) {
			return true;
		} else {
			return false;
		}
	}

	/**
	 *
	 * @return the data front
	 * @throws QueueException
	 */
	public T front() throws QueueException {

		if (front == null) {
			throw new QueueException("The queue is empty.");
		}
		return this.front.getData();
	}

	/**
	 *
	 * @return the front
	 * @throws QueueException
	 */
	public T dequeue() throws QueueException {
		if (this.front == null) {
			throw new QueueException("The queue is empty.");
		}
		T temp = front.getData();
		front = front.getNext();
		size--;
		return temp;
	}

	/**
	 *
	 * @param factToEnqueue
	 * @return factToEnqueue
	 * @throws QueueException
	 */
	public T enqueue(T factToEnqueue) throws QueueException {
		if (this.sizeLimit != 0 && this.size == this.sizeLimit) {
			throw new QueueException("The queue is full.");
		}
		Node<T> newNode = new Node<T>(factToEnqueue);
		if (front == null) {
			front = rear = newNode;
			size++;
			return factToEnqueue;
		}
		rear.setNext(newNode);
		rear = newNode;
		size++;
		return factToEnqueue;
	}

	/**
	 * print the queue
	 * @return queue values
	 */
	public String print() {
		String exit = "";
		for (Node<T> temp = front; temp != null; temp = temp.getNext()) {
			exit += " -> " + temp.getData();
		}
		return exit;
	}
}
