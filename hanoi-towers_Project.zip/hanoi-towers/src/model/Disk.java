package model;

import java.awt.Color;
import java.util.Random;

import model.Lists.SingleList;

/**
 * @author Gabriel Guzmán Alfaro
 * @author Diego Alfaro Gonzales
 * @author Nicole Garcia Luna
 * @version 02/06/2021
 */
public class Disk {

	private int size;
	private Color color;

	/**
	 * Constructor
	 * 
	 * @param size of disk in the grafic
	 */
	public Disk(int size) {
		this.size = size;
		color = getColorRand();
	}

	/**
	 * @return the size of the disk
	 */
	public int getSize() {
		return size;
	}

	/**
	 * Create a variable static of type SingleList<String> and instance the
	 * constructor of the class SingleList<String>
	 */
	private static SingleList<String> colorsToPick = new SingleList<String>(new String[] { "#39add1", // light blue
			"#3f51b5", // dark blue
			"#009688", // teal
			"#f44336", // red
			"#ff9800", // orange
			"#673ab7", // deep purple
			"#9c27b0", // purple
			"#03a9f4", // ligth blue
			"#4caf50", // green
			"#795548", // brown
			"#e81e63", // pink
			"#607d8b" // light gray
	});

	/**
	 * @return a random color with out duplicate
	 */
	private Color getColorRand() {
		String color = "";

		// Randomly select a fact
		Random randomGenerator = new Random(); // Construct a new Random number generator
		int randomNumber = randomGenerator.nextInt(colorsToPick.size());

		color = colorsToPick.remove(randomNumber);

		return Color.decode(color);
	}

	/**
	 * @return the color
	 */
	public Color getColor() {
		return color;
	}

}
