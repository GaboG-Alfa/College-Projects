package view;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;

import controller.GameManager;
import controller.Exceptions.MovementQueueException;
import model.Movement;
import model.MovementQueue;

/**
 * @author Gabriel Guzmán Alfaro
 * @author Diego Alfaro Gonzales
 * @author Nicole Garcia Luna
 * @version 31/05/2021
 */

public class ShowPlayerMovements extends JFrame {

	private JPanel headerJPanel, centerJPanel, buttonJPanel;
	private JScrollPane movementsJScrollPane;
	private JTextArea movementsJTextArea;

	public ShowPlayerMovements(JFrame Patern, GameManager gameManager) {
		super("Hanoi Towers");
		JFrame contextPaternComponent = this;
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLayout(new FlowLayout());

		headerJPanel = new JPanel();
		centerJPanel = new JPanel();
		buttonJPanel = new JPanel();
		headerJPanel.setLayout(new BoxLayout(headerJPanel, BoxLayout.Y_AXIS));
		headerJPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		centerJPanel.setLayout(new BoxLayout(centerJPanel, BoxLayout.X_AXIS));
		centerJPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		buttonJPanel.setLayout(new BoxLayout(buttonJPanel, BoxLayout.X_AXIS));
		buttonJPanel.setBorder(BorderFactory.createEmptyBorder(50, 10, 10, 10));

		setLayout(new FlowLayout());
		add(headerJPanel);
		add(centerJPanel);
		add(buttonJPanel);

		JLabel playerMovementsJLabel = new JLabel("To solve it you done: "+gameManager.getPlayerMovements().getSize()+" movements");
		JLabel minSolveMovementsJLabel = new JLabel("To solve it min amount of movements needed is: " + (int)(Math.pow(2, gameManager.getAmountDisk()) - 1));

		headerJPanel.add(playerMovementsJLabel);
		centerJPanel.add(minSolveMovementsJLabel);

		movementsJTextArea = new JTextArea();
		movementsJTextArea.setEditable(false);
		movementsJScrollPane = new JScrollPane(movementsJTextArea);
		movementsJScrollPane.setAutoscrolls(true);
		movementsJScrollPane.setPreferredSize(new Dimension(300, 100));
		buttonJPanel.add(movementsJScrollPane);

		buttonJPanel.add(Box.createHorizontalStrut(30));
		JButton backJButton = new JButton("Back");
		buttonJPanel.add(backJButton);
		backJButton.addActionListener((ActionEvent evento) -> {
			Patern.setVisible(true);
			contextPaternComponent.dispose();
			gameManager.inicializateGame(gameManager.getAmountDisk());
		});
		backJButton.setHorizontalAlignment(SwingConstants.RIGHT);

		this.setLocationRelativeTo(null);

		int screenSizeWidth = Toolkit.getDefaultToolkit().getScreenSize().width;
		int screenSizeHeight = Toolkit.getDefaultToolkit().getScreenSize().height;
		int jFrameWidth = 500;
		int jFrameHeight = 300;

		this.setLocation((screenSizeWidth - jFrameWidth) / 2, (screenSizeHeight - jFrameHeight) / 2);
		this.setSize(jFrameWidth, jFrameHeight);
		this.setVisible(true);

		MovementQueue movements = gameManager.getPlayerMovements();
		Movement movement = null;
		String exit = "";
		int i = 0;
		while (movements.getSize() > 0) {
			i++;
			try {
				movement = movements.dequeueMovement();
			} catch (MovementQueueException e) {
				System.out.println(e.getMessage());
			}
			exit = i + ": Moved a disk from tower " + movement.getInitialTowerId() + " to tower "
					+ movement.getFinalTowerId() + ".\n";
			movementsJTextArea.append(exit);
			gameManager.doMovement(movement.getInitialTowerId(), movement.getFinalTowerId());
		}

	}
}
