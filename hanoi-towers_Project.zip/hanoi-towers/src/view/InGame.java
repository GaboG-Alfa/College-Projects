package view;

import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.Dimension;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.Box;
import javax.swing.SwingConstants;
import javax.swing.border.TitledBorder;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Container;

import controller.GameManager;
import controller.Validate;
import controller.Exceptions.MovementQueueException;
import model.Movement;

/**
 * @author Gabriel Guzmán Alfaro
 * @author Diego Alfaro Gonzales
 * @author Nicole Garcia Luna
 * @version 03/06/2021
 */
public class InGame extends JFrame {

	private GraficTower firstTower, secondTower, thirdTower;
	private JPanel headerJPanel, centerJPanel, buttonJPanel;
	private JLabel variableJLabel;
	private JTextField toweridJTextField;
	private Boolean initialTowerIdSelected;
	private JButton variableTextJButton;
	private JLabel variableMovementJLabel;

	private JButton deselectJButton;

	private int initialTowerId;

	private GameManager gameManager;

	public InGame(GameManager gameManager) {
		super("Hanoi Towers");
		JFrame contextPaternComponent = this;
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLayout(new FlowLayout());
		this.gameManager = gameManager;
		headerJPanel = new JPanel();
		centerJPanel = new JPanel();
		buttonJPanel = new JPanel();

		// empty components to sort set a ubication to anothers componets
		headerJPanel.setLayout(new BoxLayout(headerJPanel, BoxLayout.Y_AXIS));
		headerJPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		centerJPanel.setLayout(new BoxLayout(centerJPanel, BoxLayout.X_AXIS));
		centerJPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		buttonJPanel.setLayout(new BoxLayout(buttonJPanel, BoxLayout.X_AXIS));
		buttonJPanel.setBorder(BorderFactory.createEmptyBorder(50, 10, 10, 10));

		// send grafics dimencions to towers
		firstTower = new GraficTower(8, 250, 220, gameManager.getFirtsTower());
		secondTower = new GraficTower(8, 250, 220, gameManager.getSecondTower());
		thirdTower = new GraficTower(8, 250, 220, gameManager.getThirdTower());
		JPanel firstTowerPane = new JPanel();
		TitledBorder firstTowerTitledBorder = BorderFactory
				.createTitledBorder(BorderFactory.createEmptyBorder(2, 2, 2, 2), "1");
		firstTowerTitledBorder.setTitleJustification(TitledBorder.CENTER);
		firstTowerPane.setBorder(firstTowerTitledBorder);
		firstTowerPane.add(firstTower);
		centerJPanel.add(firstTowerPane);
		centerJPanel.add(Box.createHorizontalStrut(20));
		JPanel secondTowerPane = new JPanel();
		TitledBorder secondTowerTitledBorder = BorderFactory
				.createTitledBorder(BorderFactory.createEmptyBorder(2, 2, 2, 2), "2");
		secondTowerTitledBorder.setTitleJustification(TitledBorder.CENTER);
		secondTowerPane.setBorder(secondTowerTitledBorder);
		secondTowerPane.add(secondTower);
		centerJPanel.add(secondTowerPane);
		centerJPanel.add(Box.createHorizontalStrut(20));
		JPanel thirdTowerPane = new JPanel();
		TitledBorder thirdTowerTitledBorder = BorderFactory
				.createTitledBorder(BorderFactory.createEmptyBorder(2, 2, 2, 2), "3");
		thirdTowerTitledBorder.setTitleJustification(TitledBorder.CENTER);
		thirdTowerPane.setBorder(thirdTowerTitledBorder);
		thirdTowerPane.add(thirdTower);
		centerJPanel.add(thirdTowerPane);

		setLayout(new FlowLayout());
		add(headerJPanel);
		add(centerJPanel);
		add(buttonJPanel);

		// set a controls to game

		JPanel movementlabelLayout = new JPanel();
		movementlabelLayout.setLayout(new BoxLayout(movementlabelLayout, BoxLayout.Y_AXIS));
		variableMovementJLabel = new JLabel("Movement made the movement is shown here");
		movementlabelLayout.add(variableMovementJLabel);
		JPanel labelLayout = new JPanel();
		labelLayout.setLayout(new BoxLayout(labelLayout, BoxLayout.Y_AXIS));

		JLabel label = new JLabel("Select a tower");
		variableJLabel = new JLabel("to move the top disk:");
		JPanel textFieldLayout = new JPanel();
		textFieldLayout.setLayout(new BoxLayout(textFieldLayout, BoxLayout.Y_AXIS));

		toweridJTextField = new JTextField(2);
		textFieldLayout.add(toweridJTextField);
		textFieldLayout.setMaximumSize(new Dimension(40, 25));
		initialTowerIdSelected = false;
		JPanel buttonLayout = new JPanel();
		buttonLayout.setLayout(new BoxLayout(buttonLayout, BoxLayout.Y_AXIS));
		variableTextJButton = new JButton("select");
		deselectJButton = new JButton("deselect");

		buttonJPanel.add(movementlabelLayout);
		buttonJPanel.add(Box.createHorizontalStrut(10));
		labelLayout.add(label);
		labelLayout.add(variableJLabel);
		buttonJPanel.add(Box.createHorizontalStrut(10));
		buttonJPanel.add(labelLayout);
		buttonJPanel.add(Box.createHorizontalStrut(10));
		buttonJPanel.add(textFieldLayout);
		buttonJPanel.add(Box.createHorizontalStrut(10));

		buttonLayout.add(variableTextJButton);
		buttonJPanel.add(buttonLayout);
		variableTextJButton.addActionListener(new ActionListener() {

			// validates
			public void actionPerformed(ActionEvent ev) {
				if (!Validate.onlyContainsNumbers(toweridJTextField.getText())) {
					showMessage("must be a number");
					toweridJTextField.setText("");
					return;
				}
				int finalTowerId = Integer.parseInt(toweridJTextField.getText());
				if (!Validate.isBetweenIncluded(finalTowerId, 1, 3)) {
					showMessage("invalid number of tower");
					toweridJTextField.setText("");
					return;
				}

				if (!initialTowerIdSelected) {
					if (!gameManager.validateIfToSelectTowerHaveDisk(Integer.parseInt(toweridJTextField.getText()))) {
						showMessage("this tower not have disk");
						toweridJTextField.setText("");
						return;
					}
					initialTowerId = Integer.parseInt(toweridJTextField.getText());
					initialTowerIdSelected = true;
					variableJLabel.setText("to push selected disk:");
					variableTextJButton.setText("move");
					toweridJTextField.setText("");
					buttonLayout.add(deselectJButton);
					update();
					return;
				} else {

					try {
						gameManager.getPlayerMovements().enqueueMovement(new Movement(initialTowerId, finalTowerId));
					} catch (MovementQueueException e) {
						System.out.println(e.getMessage());
					}
					if (gameManager.validateMovement(initialTowerId, finalTowerId)) {
						gameManager.doMovement(initialTowerId, finalTowerId);
						variableMovementJLabel
								.setText("Moved a disk from tower " + initialTowerId + " to tower " + finalTowerId);
						initialTowerIdSelected = false;
						variableJLabel.setText("to move the top disk:");
						variableTextJButton.setText("select");
						toweridJTextField.setText("");
						buttonLayout.remove(deselectJButton);
						updateGraficTowers();

						// if player won
						if (gameManager.hasWon()) {
							showMessage("Congratulations you solved it");
							contextPaternComponent.setVisible(false);
							new ShowPlayerMovements(contextPaternComponent, gameManager);
							return;
						}
					} else {
						showMessage("invalid movement");
						toweridJTextField.setText("");
					}
				}

			}
		});

		// Logic for the button deselect in initial tower
		deselectJButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ev) {
				initialTowerIdSelected = false;
				variableJLabel.setText("to move the top disk:");
				variableTextJButton.setText("select");
				toweridJTextField.setText("");
				buttonLayout.remove(deselectJButton);
				update();
			}
		});

		// button for view the solve moments
		putButton(buttonJPanel, "Solve", (ActionEvent evento) -> {
			contextPaternComponent.setVisible(false);
			new ShowSolve(contextPaternComponent, gameManager);
		});

		// button for back
		putButton(buttonJPanel, "Back", (ActionEvent evento) -> {
			showMessage("Thanks for play");
			closeThisWindows();
			new Start(gameManager);
		});

		this.setLocationRelativeTo(null);

		// show this window in a center of the screen
		int screenSizeWidth = Toolkit.getDefaultToolkit().getScreenSize().width;
		int screenSizeHeight = Toolkit.getDefaultToolkit().getScreenSize().height;
		int jFrameWidth = 900;
		int jFrameHeight = 500;

		this.setLocation((screenSizeWidth - jFrameWidth) / 2, (screenSizeHeight - jFrameHeight) / 2);
		this.setSize(jFrameWidth, jFrameHeight);
		this.setVisible(true);
	}

	private void putButton(Container container, String title, ActionListener listener) {
		JButton button = new JButton(title);
		container.add(button);
		button.addActionListener(listener);
		button.setHorizontalAlignment(SwingConstants.LEFT);
		button.setFocusPainted(true);
	}

	// for showMessage
	private void showMessage(String message) {
		JOptionPane.showMessageDialog(this, message, "Hanoi Towers", JOptionPane.INFORMATION_MESSAGE);
	}

	// close actual showing frame
	private void closeThisWindows() {
		this.dispose();
	}

	// for repaint the all window
	private void update() {
		this.repaint();
	}

	// for actualice the logic towers in the grafics towers
	private void updateGraficTowers() {
		firstTower.setLogicTower(gameManager.getFirtsTower());
		secondTower.setLogicTower(gameManager.getSecondTower());
		thirdTower.setLogicTower(gameManager.getThirdTower());
		update();
	}
}
