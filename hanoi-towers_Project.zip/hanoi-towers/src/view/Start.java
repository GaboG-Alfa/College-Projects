package view;

import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import controller.GameManager;

/**
 * @author Gabriel Guzmán Alfaro
 * @author Diego Alfaro Gonzales
 * @author Nicole Garcia Luna
 * @version 02/06/2021
 */
public class Start extends JFrame {

	private static final long serialVersionUID = 1L;

	private JPanel headerJPanel, centerJPanel, buttonJPanel;

	private JLabel welcomeMessageJLabel, toStartMessageJLabel;

	private JLabel diskAmountJLabel;
	private Integer[] diskAmountSelection = new Integer[] { 3, 4, 5, 6, 7, 8, 9, 10 };
	private JComboBox<Integer> diskAmountJComboBox;

	private JButton startJButton, exitJButton;

	public Start(GameManager gameManager) {
		super("Hanoi Towers");
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);

		headerJPanel = new JPanel();
		centerJPanel = new JPanel();
		buttonJPanel = new JPanel();

		headerJPanel.setLayout(new BoxLayout(headerJPanel, BoxLayout.Y_AXIS));
		headerJPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

		centerJPanel.setLayout(new BoxLayout(centerJPanel, BoxLayout.X_AXIS));
		centerJPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

		buttonJPanel.setLayout(new BoxLayout(buttonJPanel, BoxLayout.X_AXIS));
		buttonJPanel.setBorder(BorderFactory.createEmptyBorder(50, 10, 10, 10));

		welcomeMessageJLabel = new JLabel("¡Welcome to hanoi towers game!");
		toStartMessageJLabel = new JLabel("To Start:");
		welcomeMessageJLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
		toStartMessageJLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

		headerJPanel.add(welcomeMessageJLabel);
		headerJPanel.add(toStartMessageJLabel);

		diskAmountJLabel = new JLabel("Select disk number: ");
		diskAmountJComboBox = new JComboBox<Integer>(diskAmountSelection);

		centerJPanel.add(diskAmountJLabel);
		centerJPanel.add(diskAmountJComboBox);

		startJButton = new JButton("Start");
		exitJButton = new JButton("Exit");
		startJButton.setAlignmentX(Component.CENTER_ALIGNMENT);
		exitJButton.setAlignmentX(Component.CENTER_ALIGNMENT);

		buttonJPanel.setSize(300, 100);
		buttonJPanel.add(startJButton);
		buttonJPanel.add(exitJButton);

		setLayout(new FlowLayout());
		add(headerJPanel);
		add(centerJPanel);
		add(buttonJPanel);

		startJButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				gameManager.inicializateGame((Integer) diskAmountJComboBox.getSelectedItem());
				new InGame(gameManager);
				closeThisWindows();
			}
		});
		exitJButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				showMessage("Thanks! Have a good day");
				System.exit(0);
			}
		});

		this.setLocationRelativeTo(null);

		int screenSizeWidth = Toolkit.getDefaultToolkit().getScreenSize().width;
		int screenSizeHeight = Toolkit.getDefaultToolkit().getScreenSize().height;
		int jFrameWidth = 350;
		int jFrameHeight = 230;

		this.setLocation((screenSizeWidth - jFrameWidth) / 2, (screenSizeHeight - jFrameHeight) / 2);
		this.setSize(jFrameWidth, jFrameHeight);
		this.setVisible(true);
	}

	private void showMessage(String message) {
		JOptionPane.showMessageDialog(this, message, "Hanoi Towers", JOptionPane.INFORMATION_MESSAGE);
	}

	private void closeThisWindows() {
		this.dispose();
	}
}
