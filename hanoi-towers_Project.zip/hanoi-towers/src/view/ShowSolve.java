package view;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;
import javax.swing.border.TitledBorder;

import controller.GameManager;
import controller.Exceptions.MovementQueueException;
import model.Movement;
import model.MovementQueue;

/**
 * @author Gabriel Guzmán Alfaro
 * @author Diego Alfaro Gonzales
 * @author Nicole Garcia Luna
 * @version 01/06/2021
 */

public class ShowSolve extends JFrame {

	private GraficTower firstTower, secondTower, thirdTower;
	private JPanel headerJPanel, centerJPanel, buttonJPanel;
	private JScrollPane scroll;
	private JTextArea textArea;
	private Thread solver;
	private boolean threadExit;


	private GameManager gameManager;

	public ShowSolve(JFrame Patern, GameManager gameManager) {
		super("Hanoi Towers");
		JFrame contextPaternComponent = this;
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLayout(new FlowLayout());

		this.gameManager = gameManager;
		threadExit = false;
		headerJPanel = new JPanel();
		centerJPanel = new JPanel();
		buttonJPanel = new JPanel();

		// empty components to sort set a ubication to anothers componets
		headerJPanel.setLayout(new BoxLayout(headerJPanel, BoxLayout.Y_AXIS));
		headerJPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		centerJPanel.setLayout(new BoxLayout(centerJPanel, BoxLayout.X_AXIS));
		centerJPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		buttonJPanel.setLayout(new BoxLayout(buttonJPanel, BoxLayout.X_AXIS));
		buttonJPanel.setBorder(BorderFactory.createEmptyBorder(50, 10, 10, 10));

		// send grafics dimencions to towers
		firstTower = new GraficTower(8, 250, 220, gameManager.getFirtsTower());
		secondTower = new GraficTower(8, 250, 220, gameManager.getSecondTower());
		thirdTower = new GraficTower(8, 250, 220, gameManager.getThirdTower());
		gameManager.inicializateGame(gameManager.getAmountDisk());

		// Set title for the towers
		JPanel firstTowerPane = new JPanel();
		TitledBorder firstTowerTitledBorder = BorderFactory
				.createTitledBorder(BorderFactory.createEmptyBorder(2, 2, 2, 2), "1");
		firstTowerTitledBorder.setTitleJustification(TitledBorder.CENTER);
		firstTowerPane.setBorder(firstTowerTitledBorder);
		firstTowerPane.add(firstTower);
		centerJPanel.add(firstTowerPane);
		centerJPanel.add(Box.createHorizontalStrut(20));
		JPanel secondTowerPane = new JPanel();
		TitledBorder secondTowerTitledBorder = BorderFactory
				.createTitledBorder(BorderFactory.createEmptyBorder(2, 2, 2, 2), "2");
		secondTowerTitledBorder.setTitleJustification(TitledBorder.CENTER);
		secondTowerPane.setBorder(secondTowerTitledBorder);
		secondTowerPane.add(secondTower);
		centerJPanel.add(secondTowerPane);
		centerJPanel.add(Box.createHorizontalStrut(20));
		JPanel thirdTowerPane = new JPanel();
		TitledBorder thirdTowerTitledBorder = BorderFactory
				.createTitledBorder(BorderFactory.createEmptyBorder(2, 2, 2, 2), "3");
		thirdTowerTitledBorder.setTitleJustification(TitledBorder.CENTER);
		thirdTowerPane.setBorder(thirdTowerTitledBorder);
		thirdTowerPane.add(thirdTower);
		centerJPanel.add(thirdTowerPane);

		// add any elements to the frame
		setLayout(new FlowLayout());
		add(headerJPanel);
		add(centerJPanel);
		add(buttonJPanel);
		textArea = new JTextArea();
		textArea.setEditable(false);
		scroll = new JScrollPane(textArea);
		scroll.setAutoscrolls(true);
		scroll.setPreferredSize(new Dimension(300, 80));
		buttonJPanel.add(scroll);
		buttonJPanel.add(Box.createHorizontalStrut(30));

		JButton backJButton = new JButton("Back");
		buttonJPanel.add(backJButton);
		// set the back botton logic
		backJButton.addActionListener((ActionEvent evento) -> {

				threadExit = true;

			Patern.setVisible(true);
			contextPaternComponent.dispose();
			gameManager.inicializateGame(gameManager.getAmountDisk());
		});
		backJButton.setHorizontalAlignment(SwingConstants.RIGHT);

		// show this window at the center of the screen
		this.setLocationRelativeTo(null);

		int screenSizeWidth = Toolkit.getDefaultToolkit().getScreenSize().width;
		int screenSizeHeight = Toolkit.getDefaultToolkit().getScreenSize().height;
		int jFrameWidth = 900;
		int jFrameHeight = 500;

		this.setLocation((screenSizeWidth - jFrameWidth) / 2, (screenSizeHeight - jFrameHeight) / 2);
		this.setSize(jFrameWidth, jFrameHeight);
		this.setVisible(true);

		// thread to run the resolution of movements with their respective graphic view
		solver = new Thread(new Runnable() {
			@Override
			public void run() {
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					System.out.println(e.getMessage());
				}
				MovementQueue movements = gameManager.getMovementsToSolve(gameManager.getAmountDisk());
				Movement movement = null;
				String exit = "";
				int i = 0;

				// as long as there are movements to show
				while (movements.getSize() > 0 && !threadExit) {
					i++;
					try {// dequeue movement
						movement = movements.dequeueMovement();
					} catch (MovementQueueException e) {
						System.out.println(e.getMessage());
					}

					// message with resolved movement
					exit = i + ": Moved a disk from tower " + movement.getInitialTowerId() + " to tower "
							+ movement.getFinalTowerId() + ".\n";
					textArea.append(exit);

					// perform the move
					gameManager.doMovement(movement.getInitialTowerId(), movement.getFinalTowerId());
					try {
						Thread.sleep(800);
					} catch (InterruptedException e) {
						System.out.println(e.getMessage());
					}
					updateGraficTowers();
				}
			}
		});
		solver.start();
	}

	// for repaint the all window
	private void update() {
		this.repaint();
	}

	// for actualice the logic towers in the grafics towers
	private void updateGraficTowers() {
		firstTower.setLogicTower(gameManager.getFirtsTower());
		secondTower.setLogicTower(gameManager.getSecondTower());
		thirdTower.setLogicTower(gameManager.getThirdTower());
		update();
	}

}
