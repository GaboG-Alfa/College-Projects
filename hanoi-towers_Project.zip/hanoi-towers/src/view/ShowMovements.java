package view;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.SwingConstants;

import controller.GameManager;
import controller.Exceptions.MovementQueueException;
import model.Movement;
import model.MovementQueue;

/**
 * @author Gabriel Guzmán Alfaro
 * @author Diego Alfaro Gonzales
 * @author Nicole Garcia Luna
 * @version 02/06/2021
 */

public class ShowMovements extends JFrame {

	private GraficTower firstTower, secondTower, thirdTower;
	private JPanel headerJPanel, centerJPanel, buttonJPanel;
	private JScrollPane scroll;
	private JTextArea textArea;
	private GameManager gameManager;

	public ShowMovements(JFrame Patern, GameManager gameManager) {
		super("Hanoi Towers");
		JFrame contextPaternComponent = this;
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLayout(new FlowLayout());
		gameManager.inicializateGame(gameManager.getAmountDisk());

		this.gameManager = gameManager;

		headerJPanel = new JPanel();
		centerJPanel = new JPanel();
		buttonJPanel = new JPanel();

		// empty components to sort set a ubication to anothers componets
		headerJPanel.setLayout(new BoxLayout(headerJPanel, BoxLayout.Y_AXIS));
		headerJPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		centerJPanel.setLayout(new BoxLayout(centerJPanel, BoxLayout.X_AXIS));
		centerJPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		buttonJPanel.setLayout(new BoxLayout(buttonJPanel, BoxLayout.X_AXIS));
		buttonJPanel.setBorder(BorderFactory.createEmptyBorder(50, 10, 10, 10));

		// send grafics dimencions to towers
		firstTower = new GraficTower(8, 250, 220, gameManager.getFirtsTower());
		secondTower = new GraficTower(8, 250, 220, gameManager.getSecondTower());
		thirdTower = new GraficTower(8, 250, 220, gameManager.getThirdTower());

		centerJPanel.add(firstTower);
		centerJPanel.add(Box.createHorizontalStrut(20));
		centerJPanel.add(secondTower);
		centerJPanel.add(Box.createHorizontalStrut(20));
		centerJPanel.add(thirdTower);

		setLayout(new FlowLayout());
		add(headerJPanel);
		add(centerJPanel);
		add(buttonJPanel);
		textArea = new JTextArea();
		textArea.setEditable(false);
		scroll = new JScrollPane(textArea);
		scroll.setAutoscrolls(true);
		scroll.setPreferredSize(new Dimension(300, 80));
		buttonJPanel.add(scroll);
		buttonJPanel.add(scroll);

		buttonJPanel.add(Box.createHorizontalStrut(30));
		JButton backJButton = new JButton("Back");
		buttonJPanel.add(backJButton);

		// set the back botton logic
		backJButton.addActionListener((ActionEvent evento) -> {
			Patern.setVisible(true);
			contextPaternComponent.dispose();
		});
		backJButton.setHorizontalAlignment(SwingConstants.RIGHT);

		// show this window at the center of the screen
		this.setLocationRelativeTo(null);

		int screenSizeWidth = Toolkit.getDefaultToolkit().getScreenSize().width;
		int screenSizeHeight = Toolkit.getDefaultToolkit().getScreenSize().height;
		int jFrameWidth = 900;
		int jFrameHeight = 500;

		this.setLocation((screenSizeWidth - jFrameWidth) / 2, (screenSizeHeight - jFrameHeight) / 2);
		this.setSize(jFrameWidth, jFrameHeight);
		this.setVisible(true);

		// thread to run the resolution of movements with their respective graphic view
		new Thread(new Runnable() {
			@Override
			public void run() {
				try {
					Thread.sleep(1000);
				} catch (InterruptedException e) {
					System.out.println(e.getMessage());
				}
				MovementQueue movements = gameManager.getMovementsToSolve(gameManager.getAmountDisk());
				Movement movement = null;
				String exit = "";
				int i = 0;

				// as long as there are movements to show
				while (movements.getSize() > 0) {
					i++;
					try {// dequeue movement
						movement = movements.dequeueMovement();
					} catch (MovementQueueException e) {
						System.out.println(e.getMessage());
					}
					// message with resolved movement
					exit = i + ": Moved a disk from tower " + movement.getInitialTowerId() + " to tower "
							+ movement.getFinalTowerId() + "\n";
					textArea.append(exit);// send the message to the textAre with the movement resolved

					// perform the move
					gameManager.doMovement(movement.getInitialTowerId(), movement.getFinalTowerId());
					try {
						Thread.sleep(600);
					} catch (InterruptedException e) {
						System.out.println(e.getMessage());
					}

					updateGraficTowers();
				}
			}
		}).start();

	}

	// for repaint the all window
	private void update() {
		this.repaint();
	}

	// for actualice the logic towers in the grafics towers
	private void updateGraficTowers() {
		firstTower.setLogicTower(gameManager.getFirtsTower());
		secondTower.setLogicTower(gameManager.getSecondTower());
		thirdTower.setLogicTower(gameManager.getThirdTower());
		update();
	}

}
