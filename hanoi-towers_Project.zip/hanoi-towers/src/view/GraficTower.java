package view;

import javax.swing.JComponent;

import controller.Exceptions.StackException;
import controller.Exceptions.TowerException;
import model.Disk;
import model.Tower;
import model.Lists.Stack;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Color;

/**
 * @author Gabriel Guzmán Alfaro
 * @author Diego Alfaro Gonzales
 * @author Nicole Garcia Luna
 * @version 31/05/2021
 */
public class GraficTower extends JComponent {

	private int tickness;
	private int width;
	private int height;

	private Tower logicTower;

	/**
	 * Receives by parameter the graphic dimensions of the tower
	 * 
	 * @param tickness   of the line of the towers
	 * @param width      of the entire tower
	 * @param height     of the entire tower
	 * @param logicTower a object with logic representation of the tower
	 */
	public GraficTower(int tickness, int width, int height, Tower logicTower) {
		setPreferredSize(new Dimension(width, height));
		this.tickness = tickness;
		this.width = width;
		this.height = height;

		this.logicTower = logicTower;
	}

	/**
	 * Method use diferents math calcs to paint a grafical tower with disk
	 * 
	 */
	public void paintComponent(Graphics g) {
		super.paintComponent(g);

		// draw tower structure
		g.setColor(Color.BLACK);
		g.fillRect(((width / 2) - (tickness / 2)), 0, tickness, height - tickness);
		g.fillRect(0, height - tickness, width, tickness);

		try {
			// draw disks of the logic tower
			Stack<Disk> tempStack = new Stack<Disk>();
			if (logicTower.size() == 0)
				return;

			while (logicTower.size() != 0) {
				tempStack.push(logicTower.popDisk());
			}
			int diskTickness = 20;
			int diskAnchorMultiplier = 25;
			int countForCalcDiskHeight = 1;

			Disk temp;
			do {
				temp = tempStack.pop();
				g.setColor(temp.getColor());

				g.fillRoundRect(((width / 2) - ((diskAnchorMultiplier * temp.getSize()) / 2)),
						height - (diskTickness * countForCalcDiskHeight) - tickness,
						(diskAnchorMultiplier * temp.getSize()), diskTickness, 5, 6);
				countForCalcDiskHeight++;
				logicTower.pushDisk(temp);

			} while (tempStack.size() != 0);
		} catch (StackException | TowerException e) {
			System.out.println(e.getMessage());
		}

	}

	/**
	 * @param logicTower the logicTower to set
	 */
	public void setLogicTower(Tower logicTower) {
		this.logicTower = logicTower;
	}
}
