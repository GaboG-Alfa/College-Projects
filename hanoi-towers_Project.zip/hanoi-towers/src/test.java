import controller.GameManager;
/**
 * @author Gabriel Guzmán Alfaro
 * @author Diego Alfaro Gonzales
 * @author Nicole Garcia Luna
 * @version 28/05/2021
 */

public class test {
    
        /**
         * 
         * @param args 
         */
	public static void main(String[] args) {
		new GameManager();
	}
}
