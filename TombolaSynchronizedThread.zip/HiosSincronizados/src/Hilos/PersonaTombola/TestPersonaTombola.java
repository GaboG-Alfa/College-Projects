package Hilos.PersonaTombola;

import Hilos.PersonaTombola.Personas;
import java.util.List;
import java.util.ArrayList;

public class TestPersonaTombola{
   public static void main(String... args) throws InterruptedException{
      //numero de bola es el OBJETO compartido
      List<String> numero = new ArrayList<>();
      //El comun denominador es numero, lo comparten tanto la tombola como el emplead
      RecursosCompartidos tombola = new RecursosCompartidos(numero);
      Personas persona = new Personas(numero);
      //Se crean los consumidores
      Thread c1 = new Thread(persona);
      Thread c2 = new Thread(persona);
      Thread c3 = new Thread(persona);
      Thread c4 = new Thread(persona);
      Thread c5 = new Thread(persona);
      Thread c6 = new Thread(persona);
      Thread c7 = new Thread(persona);
      Thread c8 = new Thread(persona);
      Thread c9 = new Thread(persona);
      Thread c10 = new Thread(persona);
      Thread c11 = new Thread(persona);
      Thread c12 = new Thread(persona);
      Thread c13 = new Thread(persona);
      Thread c14 = new Thread(persona);
      Thread c15 = new Thread(persona);
      Thread c16 = new Thread(persona);
      Thread c17 = new Thread(persona);
      Thread c18 = new Thread(persona);
      Thread c19 = new Thread(persona);
      Thread c20 = new Thread(persona);
      //Se crea la tombola
      Thread t = new Thread(tombola);
      //Se levantan primero los empleados, estos se pondran en modo wait al iniciar
      c1.start();
      c2.start();
      c3.start();
      c4.start();
      c5.start();
      c6.start();
      c7.start();
      c8.start();
      c9.start();
      c10.start();
      c11.start();
      c12.start();
      c13.start();
      c14.start();
      c15.start();
      c16.start();
      c17.start();
      c18.start();
      c19.start();
      c20.start();
      //Se levanta las bolitas de la tombola que va notificando a los empleados uno por uno
      t.start();
   }
}
