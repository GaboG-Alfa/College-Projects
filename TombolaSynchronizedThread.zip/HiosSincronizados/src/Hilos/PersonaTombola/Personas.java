package Hilos.PersonaTombola;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 
 * @author Gabriel Guzmán
 * @version 21/05/2021
 */
public class Personas implements Runnable {

    //Atributos
    List<String> numeros;
    RecursosCompartidos tombola;
    private Map<String, String> premios = new HashMap<>();
    
    /**
     * 
     * @param n 
     */
    public Personas(List<String> n) {
        numeros = n;
        premios.put("2", "Celular");
        premios.put("13", "Tv");
        premios.put("20", "Carro");
        premios.put("17", "GameBoy");
        premios.put("5", "USB");
        premios.put("7", "Bicicleta");
        premios.put("6", "Tablet");
        premios.put("8", "Tupper");
        premios.put("9", "Peluche");
        premios.put("10", "Moto");
        premios.put("14", "Laptop");
        premios.put("12", "Parlante");
        premios.put("1", "Mouse");
        premios.put("11", "Juego de mesas");
        premios.put("15", "Microondas");
        premios.put("16", "Guitarra");
        premios.put("4", "Refrigeradora");
        premios.put("18", "Piano");
        premios.put("19", "Canasta de Chocolates");
        premios.put("3", "Teclado");
    }

    public void run() {
        synchronized (numeros) {
            if (numeros.size() == 0) {
                try {
                    System.out.println("Tombola Girando... " + " El empleado " + Thread.currentThread().getName() + " Esta en espera....");
                    numeros.wait();
                    System.out.println("\nEl empleado " + Thread.currentThread().getName()
                            + "----->Tomó la bola: " + numeros.get(numeros.size() - 1));
                    System.out.println("\nEl gerente entregó el premio " + premios.get(numeros.get(numeros.size() - 1)) + " al empleado con la bola " + numeros.get(numeros.size() - 1));
                    premios.remove(numeros.get(numeros.size() - 1));
                    
                } catch (Exception e) {
                    System.out.println("Error: " + e);
                }
            }

            while (numeros.size() < 19) {
               
                try {
                    numeros.wait();
                    System.out.println("\nB- El empleado " + Thread.currentThread().getName()
                            + "----->Tomó la bola: " + numeros.get(numeros.size() - 1));
                } catch (Exception e) {
                    System.out.println("Error: " + e);
                }

            }
           
        }
    }
}
