package Hilos.PersonaTombola;

import java.util.ArrayList;
import java.util.List;

public class RecursosCompartidos implements Runnable {

    //Atributos
    private List<String> numeros;
    private ArrayList<Integer> azar;

    /**
     * Constructor
     */
    public RecursosCompartidos() {
    }

    /**
     *
     * @param n
     */
    public RecursosCompartidos(List<String> n) {
        numeros = n;
        azar = new ArrayList<>();
        for(int i = 1; i < 21; i++){
            azar.add(i);
        }
    }

    //Se producen 20 numeros de la tombola
    public void run() {
        int random = 0;
        for (int i = 1; i < 21; i++) {
            random = (int) Math.floor(Math.random() * (azar.size()-1));
            try {
                Thread.sleep(1000);
                synchronized (numeros) {
                    System.out.println("\nLa bola número: " + azar.get(random) + " salió de la tombola...");

                    numeros.add(azar.remove(random)+"");
                    numeros.notify();
                }
            } catch (Exception e) {
                System.out.println("Error: " + e);
            }
        }
    }
    
}
