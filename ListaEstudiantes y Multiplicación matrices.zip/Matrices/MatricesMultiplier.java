/**
 * Matrix class that compute matrix operations
 * 
 * @version October 21, 2020
 * @author Gabriel Guzmán Alfaro
 */
public class MatricesMultiplier {
	
    /**
     * Multiply two matrices
     * @param matrix1
     * @param matrix2
     * @return resultVector
     */
    public static int[] Multiplier(int[][] matrix1, int[][] matrix2) {

        int resultVector[] = new int[matrix1.length];
        if (matrix1.length != matrix2[0].length) {
            return null;
        } else {
            for (int i = 0; i < matrix1.length ; i++) {
                for (int j = 0; j < matrix1[i].length ; j++) {
                    resultVector[i] += matrix1[i][j] * matrix2[j][i];
                }
            }
            return resultVector;
        }
    }
    
    /**
     * Print the matrix
     * @param vector
     * @return text
     */
    public static String printMatrix(int[] vector) {
        String text= "Result of Multiply"; 
        for (int result: vector) {
        	
            text = text+ "\n"+ result;
        }
        return text;
    }

}