/**
 * TestMatrix that controls the program
 * 
 * @version October 21, 2020
 * @author Gabriel GuzmÃ¡n Alfaro
 */
public class TestMatrix {
	
    /**
     * Main method
     * @param args
     */
	public static void main(String[] args) {

		// Define variables
		int matrix1[][] = new int[3][4];
		int matrix2[][] = new int[4][3];

		// Define matrix1
		matrix2[0][0] = 10;
		matrix2[0][1] = 50;
		matrix2[0][2] = 90;

		matrix2[1][0] = 20;
		matrix2[1][1] = 60;
		matrix2[1][2] = 100;

		matrix2[2][0] = 30;
		matrix2[2][1] = 70;
		matrix2[2][2] = 110;

		matrix2[3][0] = 40;
		matrix2[3][1] = 80;
		matrix2[3][2] = 120;

		// Define matrix2
		matrix1[0][0] = 1;
		matrix1[0][1] = 2;
		matrix1[0][2] = 3;
		matrix1[0][3] = 4;

		matrix1[1][0] = 5;
		matrix1[1][1] = 6;
		matrix1[1][2] = 7;
		matrix1[1][3] = 8;

		matrix1[2][0] = 9;
		matrix1[2][1] = 10;
		matrix1[2][2] = 11;
		matrix1[2][3] = 12;
		
        
		System.out.println(MatricesMultiplier.printMatrix(MatricesMultiplier.Multiplier(matrix1, matrix2)));

	}
}
