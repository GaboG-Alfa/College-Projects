/**
 * Class Student that saves all information about a student.
 * 
 * @version October 14, 2020
 * @author Gabriel Guzmán Alfaro
 */

public class Student {

	// Student attributes
	private String id;
	private String name;
	private String lastName;
	private String secondLastName;
	private Course courseList[];
	private int index = 0;

	/**
	 * Constructor without parameters
	 */
	public Student() {

		this.courseList = new Course[10];
	}

	/**
	 * Constructor initializes variables
	 */
	public Student(String name, String id, String last, String secondLast) {
		this.name = name;
		this.id = id;
		this.lastName = last;
		this.secondLastName = secondLast;
		this.courseList = new Course[10];
	}

	/**
	 * Sets the student id
	 * 
	 * @param nom
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * Sets the student name
	 * 
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Sets the student first last name
	 * 
	 * @param last
	 */
	public void setLastName(String last) {
		this.lastName = last;
	}

	/**
	 * Sets the student second last name
	 * 
	 * @param secondLast
	 */
	public void setSecondLastName(String secondLast) {
		this.secondLastName = secondLast;
	}

	/**
	 * Gets the student id
	 * 
	 * @return
	 */
	public String getId() {
		return id;
	}

	/**
	 * Gets the student name
	 * 
	 * @return name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Gets the student last name
	 * 
	 * @return lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * Gets the student second last name
	 * 
	 * @return secondLastName
	 */
	public String getSecondLastName() {
		return secondLastName;
	}

	/**
	 * Método de ordenamiento burbuja
	 */

	private void burbleSortByYear_Period() {
		for (int i = 0; i < index - 1; i++) {
			for (int n = 0; n < index - 1; n++) {
				int currentItemYear = courseList[n].getYear();
				int nextItemYear = courseList[n + 1].getYear();
				int currentItemPeriod = courseList[n].getPeriod();
				int nextItemPeriod = courseList[n + 1].getPeriod();
				// swap
				if (currentItemYear < nextItemYear) {
					Course currentCourse = courseList[n];
					courseList[n] = courseList[n + 1];
					courseList[n + 1] = currentCourse;
				}
				if ((currentItemYear == nextItemYear) && (currentItemPeriod < nextItemPeriod)) {
					Course currentCourse = courseList[n];
					courseList[n] = courseList[n + 1];
					courseList[n + 1] = currentCourse;
				}

			}
		}
	}

	/**
	 * print the course list
	 * 
	 * @return listCourses
	 */
	public String printList() {
		burbleSortByYear_Period();
		String listCourses = "";
		for (int n = 0; n < index; n++) {
			listCourses = listCourses + "\n" + "\n" + courseList[n].toString() + "\n" + "\n";
		}
		return listCourses;
	}

	/**
	 * Insert a course
	 * 
	 * @param course
	 */
	public void insertion(Course course) {

		if (index < courseList.length) {
			this.courseList[index] = course;
			index = index + 1;
		} else {
			this.extendList();
			this.courseList[index] = course;
			index = index + 1;
		}

	}

	/**
	 * Insert courses without limits
	 * 
	 * @param course
	 */
	public void insertCourses(Course... course) {

		for (Course toInsert : course) {
			this.insertion(toInsert);
		}
	}

	/**
	 * Computes the average of grades
	 * 
	 * @return average
	 */
	public double average() {
		double average = 0;
		double sum = 0;
		int size= index;
		for (int i = 0; i < index; i++) {
			if (courseList[i].getGrade() != -1) {
				sum = sum + courseList[i].getGrade();
			}else{
				size=size-1;
			}
		}

		average = sum /size ;

		return average;
	}

	/**
	 * Delete Course
	 */
	public void deleteCourse(int inx) {
		if (inx >= 0 && inx < courseList.length) {

			for (int i = inx; i < courseList.length - 1; i++) {
				courseList[i] = courseList[i + 1];
			}
			courseList[courseList.length - 1] = null;
		}

		index = index - 1;

	}

	/**
	 * Extend list limit
	 */
	private void extendList() {
		Course[] newVector = new Course[10];
		for (int i = 0; i < courseList.length; i++) {
			newVector[i] = courseList[i];
		}
		courseList = new Course[20];
		for (int i = 0; i < newVector.length; i++) {
			courseList[i] = newVector[i];
		}
	}

	/**
	 * return all attributes of student
	 */
	public String toString() {
		return "\nStudent" + "\nId: " + id + "\nName: " + name + "\nFirst last name: " + lastName
				+ "\nSecond last name: " + secondLastName;
	}

} // End of Student class