/**
 * List of Students
 * 
 * @version October 14, 2020
 * @author Gabriel Guzmán Alfaro
 */
public class StudentList {

	// Attributes
	private Student studentList[];
	private int index = 0;

	/**
	 * Constructor without parameters
	 */
	public StudentList() {
		this.studentList = new Student[10];
	}

	/**
	 * Print the list student
	 * 
	 * @return listStudents
	 */
	public String printList() {
		String listStudents = "";
		for (int i = 0; i < studentList.length; i++) {
			if (studentList[i] != null) {
				listStudents = listStudents + " \n" + "\n" + studentList[i].toString() + "\n" + "Enrolled Courses: "
						+ studentList[i].printList() + "\n" + "\n";
			}
		}
		return listStudents;
	}

	/**
	 * Gets the id and student
	 * 
	 * @param student
	 */
	public void insertion(Student student) {
		int i = 0;
		if (index < this.studentList.length) {
			while (i < index && student.getId().compareTo(studentList[i].getId()) > 0) {
				i++;
			}
			Student aux = studentList[i];
			for (int j = i; j < index; j++) {
				Student aux2 = studentList[j + 1];
				studentList[j + 1] = aux;
				aux = aux2;
			}
			studentList[i] = student;

		} else {
			this.extendList();
            insertion(student);
		}

		index = index + 1;

	}

	/**
	 * Search the student id
	 * 
	 * @return student or null
	 */
	public Student searchId(String id) {
		int low = 0;
		int high = studentList.length - 1;
		int middle;

		while (low <= high) {
			middle = (low + high) / 2;
			if (studentList[middle] != null && studentList[middle].getId().equals(id)) {
				return studentList[middle];
			} else if (studentList[middle] != null && studentList[middle].getId().compareTo(id) < 0) {
				low = middle + 1;
			} else {
				high = middle - 1;
			}
		}
		return null;
	}

	/**
	 * Extend list limit
	 */
	private void extendList() {
		Student[] newVector = new Student[10];
		for (int i = 0; i < studentList.length; i++) {
			newVector[i] = studentList[i];
		}
		studentList = new Student[20];
		for (int i = 0; i < newVector.length; i++) {
			studentList[i] = newVector[i];
		}
	}

}// End ListStudent class