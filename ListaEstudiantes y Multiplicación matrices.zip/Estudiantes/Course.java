/**
 * Class course that save all information about an enroll course
 * 
 * @version October 14, 2020
 * @author Gabriel Guzmán Alfaro
 */

public class Course {

	// Course attributes
	private String acronym;
	private String name;
	private double grade;
	private byte period;
	private int year;

	/**
	 * Constructor without parameters
	 */
	public Course() {
	}

	/**
	 * Constructor initializes variables
	 * 
	 * @param init
	 * @param grad
	 * @param ape
	 * @param edad
	 */
	public Course(String acro, String name, double grad, byte period, int year) {
		this.name = name;
		this.acronym = acro;
		this.period = period;
		this.grade = grad;
		this.year = year;
	}

	/**
	 * Sets the course acronym
	 * 
	 * @param acro
	 */
	public void setAcronym(String acro) {
		this.acronym = acro;
	}

	/**
	 * Sets the course name
	 * 
	 * @param name
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * Sets the course grade
	 * 
	 * @param grade
	 */
	public void setGrade(int grade) {
		this.grade = grade;
	}

	/**
	 * Sets the course period
	 * 
	 * @param ape
	 */
	public void setPeriod(byte period) {
		this.period = period;
	}

	/**
	 * Sets the course year
	 * 
	 * @param year
	 */
	public void setYear(int year) {
		this.year = year;
	}

	/**
	 * Gets the course acronym
	 * 
	 * @return acronym
	 */
	public String getAcronym() {
		return acronym;
	}

	/**
	 * Gets the course name
	 * 
	 * @return name
	 */
	public String getName() {
		return name;
	}

	/**
	 * Gets the courseGrade
	 * 
	 * @return grade
	 */
	public double getGrade() {
		return grade;
	}

	/**
	 * Gets the course period
	 * 
	 * @return period
	 */
	public int getPeriod() {
		return period;
	}

	/**
	 * Gets the course year
	 * 
	 * @return year
	 */
	public int getYear() {
		return year;
	}

	/**
	 * @return all course attributes
	 */
	public String toString() {
		return "Course " + "\nAcronym: " + acronym + "\nName: " + name + "\nGrade: " + grade + "\nPeriod: " + period
				+ "\nYear: " + year;
	}

} // end Course class