/**
 * TestStudentCourse that controls the program
 * 
 * @version October 14, 2020
 * @author Gabriel Guzmán Alfaro
 */
public class TestStudentCourse {

	/**
	 * Main method
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		// Create the student object
		Student studentGeneral = new Student();

		// Create student list object
		StudentList studentList = new StudentList();

		// Send courses atributtes
		Course course1 = new Course("IF1200", "Programming I", 9, (byte) 2, 2020);
		Course course2 = new Course("EG0078", "Musical Apreciation", 10, (byte) 3, 2019);
		Course course3 = new Course("IF1400", "Logic", 8, (byte) 1, 2020);
		Course course4 = new Course("EG0125", "Humanities II", 10, (byte) 2, 2019);
		Course course5 = new Course("XS0105", "Statistics", 7, (byte) 1, 2020);
		Course course6 = new Course("MA0320", "Discrete Math", 7, (byte) 2, 2020);
		Course course7 = new Course("MA0321", "Calculus", 7, (byte) 3, 2020);
		Course course8 = new Course("IF3001", "Algoritms", 7, (byte) 1, 2021);
		Course course9 = new Course("MA0322", "Algebra", 7, (byte) 2, 2021);
		Course course10 = new Course("IF7100", "Software Engineer", 7, (byte) 3, 2021);
		Course course11 = new Course("IF4001", "Operative Systems", -1, (byte) 2, 2021);
		Course course12 = new Course("IF6200", "Programming II", 7, (byte) 1, 2021);
		Course course13 = new Course("IF4001", "Economy", 7, (byte) 1, 2019);

		// Send students atributtes
		Student student1 = new Student("Gabriel", "C03657", "Guzmán", "Alfaro");
		Student student2 = new Student("Ronan", "B13217", "Jimenez", "Ruiz");
		Student student3 = new Student("Alfredo", "A05677", "Oretga", "Nuñez");
		Student student4 = new Student("Ana", "A12345", "Madrigal", "Fonseca");
		Student student5 = new Student("Rodrigo", "B02145", "López", "Chavez");
		Student student6 = new Student("Valeria", "C01234", "Bolaños", "Arias");
		Student student7 = new Student("Juan", "A23948", "Pérez", "Campos");
		Student student8 = new Student("Carlos", "B35632", "Barquero", "Márquez");
		Student student9 = new Student("Marcos", "B89254", "Ugalde", "Vargas");
		Student student10 = new Student("Luis", "B59840", "Nuñez", "Barrantes");
		Student student11 = new Student("Manuel", "B21230", "Mora", "Fernandez");
		Student student12 = new Student("Pablo", "B74234", "Suárez", "Delgado");

		// Proof the different methods

		// Create a courseList variable

		// Insert courses
		studentGeneral.insertion(course1);
		studentGeneral.insertion(course2);
		studentGeneral.insertion(course3);
		studentGeneral.insertion(course4);
		studentGeneral.insertion(course5);
		studentGeneral.insertion(course6);
		studentGeneral.insertion(course7);
		studentGeneral.insertion(course8);
		studentGeneral.insertion(course9);
		studentGeneral.insertion(course10);
		studentGeneral.insertion(course11);

		// Insert students
		studentList.insertion(student1);
		studentList.insertion(student2);
		studentList.insertion(student3);
		studentList.insertion(student4);
		studentList.insertion(student5);
		studentList.insertion(student6);
		studentList.insertion(student7);
		studentList.insertion(student8);
		studentList.insertion(student9);
		studentList.insertion(student10);
		studentList.insertion(student11);
		studentList.insertion(student12);

		// BubbleSort
		System.out.println("List course: " + studentGeneral.printList());

		// Average
		System.out.printf("%s%.2f", "Average:", studentGeneral.average());

		// Delete course
		studentGeneral.deleteCourse(0);
		System.out.println("\n" + "\nList course without first course: " + studentGeneral.printList() + "\n" + "\n"
				+ "New Average: " + studentGeneral.average());

		// Order students for Id and try out insert many courses
		student1.insertCourses(course1, course2);
		student2.insertCourses(course3, course4);
		student3.insertCourses(course5, course6);
		student4.insertCourses(course7, course8);
		student5.insertCourses(course9, course10);
		student6.insertCourses(course1, course3);
		student7.insertCourses(course4, course5);
		student8.insertCourses(course6, course10);
		student9.insertCourses(course7, course9);
		student10.insertCourses(course1, course2, course3, course4, course5, course6, course7, course8, course9,
				course10, course11, course12, course13);

		System.out.print("\nStudent List: " + studentList.printList());

		// Search Student for Id
		Student search;
		search = studentList.searchId("C03657");
		if (search != null) {
			System.out.println("\nThe student was found! " + search);
		} else {
			System.out.println("\nStudent was not found!");
		}
	}
}
