// src/components/PokemonList.js
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Spinner } from 'react-bootstrap';
import PokemonCard from './PokemonCard';
import PokemonModal from './PokemonModal';
import './PokemonList.css';

const PokemonList = () => {
  const [pokemons, setPokemons] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState("");
  const [selectedPokemon, setSelectedPokemon] = useState(null);

  useEffect(() => {
    axios.get(`${process.env.REACT_APP_POKEMONS_API_URL}/pokemon?limit=30`)
      .then((response) => {
        const results = response.data.results.map((pokemon, index) => ({
          ...pokemon,
          id: index + 1
        }));
        setPokemons(results);
        setError('');
      })
      .catch(() => {
        setError('Error encountered while retrieving Pokémon');
      })
      .finally(() => {
        setIsLoading(false);
      });
  }, []);

  const fetchPokemonDetails = (url) => {
    axios.get(url)
      .then((response) => {
        setSelectedPokemon(response.data);
        setError('');
      })
      .catch(() => {
        setError('Error encountered while retrieving Pokémon details');
      });
  };

  return (
    <div className="pokemon-list-container mt-4">
      <h1 className="text-center">Pokémon List</h1>
      {isLoading && <Spinner animation="border" role="status" className="d-block mx-auto">
        <span className="visually-hidden">Loading...</span>
      </Spinner>}
      {error && <p className="text-danger text-center">{error}</p>}
      <div className="pokemon-grid">
        {pokemons.map(pokemon => (
          <PokemonCard key={pokemon.name} pokemon={pokemon} onClick={fetchPokemonDetails} />
        ))}
      </div>
      {selectedPokemon && (
        <PokemonModal pokemon={selectedPokemon} onHide={() => setSelectedPokemon(null)} />
      )}
    </div>
  );
}

export default PokemonList;