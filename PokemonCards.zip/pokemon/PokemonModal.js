// src/components/PokemonModal.js
import React from 'react';
import { Modal, Button } from 'react-bootstrap';
import './PokemonModal.css';

const PokemonModal = ({ pokemon, onHide }) => {
  return (
    <Modal show={true} onHide={onHide}>
      <Modal.Header closeButton>
        <Modal.Title className="text-capitalize">{pokemon.name}</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <img src={pokemon.sprites.front_default} alt={pokemon.name} className="pokemon-image d-block mx-auto" />
        <div className="pokemon-details">
          <p><strong>Height:</strong> {pokemon.height}</p>
          <p><strong>Weight:</strong> {pokemon.weight}</p>
          <h5>Abilities</h5>
          <ul>
            {pokemon.abilities.map(ability => (
              <li key={ability.ability.name}>{ability.ability.name}</li>
            ))}
          </ul>
        </div>
      </Modal.Body>
      <Modal.Footer>
        <Button variant="secondary" onClick={onHide}>Close</Button>
      </Modal.Footer>
    </Modal>
  );
}

export default PokemonModal;