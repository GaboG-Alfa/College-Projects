// src/components/PokemonCard.js
import React from 'react';
import { Card } from 'react-bootstrap';
import './PokemonCard.css';

const PokemonCard = ({ pokemon, onClick }) => {
  return (
    <div className="pokemon-card-container" onClick={() => onClick(pokemon.url)}>
      <Card className="pokemon-card">
        <Card.Img variant="top" src={`https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${pokemon.id}.png`} alt={pokemon.name} />
        <Card.Body>
          <Card.Title className="text-center">{pokemon.name}</Card.Title>
        </Card.Body>
      </Card>
    </div>
  );
}

export default PokemonCard;