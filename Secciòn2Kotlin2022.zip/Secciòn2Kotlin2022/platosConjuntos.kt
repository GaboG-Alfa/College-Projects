package com.example.ejercicio4seccion2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class platosConjuntos : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var plato1: Map<String,Int> = mapOf(
            "pie de limón" to 6 ,
        )

        var plato2: Map<String,Int> = mapOf(
            "chifrijo" to 8 ,
        )

        var plato3: Map<String,Int> = mapOf(
            "arroz cantonés" to 9 ,
        )

        var plato4: Map<String,Int> = mapOf(
            "pollo con papas fritas" to 17 ,
        )

        var platos:Array<Map<String,Int>> = arrayOf(plato1,plato2,plato3,plato4)

        for (i in platos)
            println("Nombre del plato ${i.keys} , Precio $ ${i.values} ")
    }
    }
