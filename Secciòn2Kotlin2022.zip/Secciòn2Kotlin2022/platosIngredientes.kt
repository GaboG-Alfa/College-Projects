package com.example.ejercicio5seccion2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class platosIngredientes: AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var plato1: Map<String,Int> = mapOf(
            "pie de limón" to 6 ,
        )

        var plato2: Map<String,Int> = mapOf(
            "chifrijo" to 8 ,
        )

        var plato3: Map<String,Int> = mapOf(
            "arroz cantonés" to 9 ,
        )

        var plato4: Map<String,Int> = mapOf(
            "pollo con papas fritas" to 17 ,
        )

        var ingredientes1: Array<String> = arrayOf("pan","limón","azucar")
        var ingredientes2: Array<String> = arrayOf("arroz","carne","frijoles")
        var ingredientes3: Array<String> = arrayOf("arroz","carne","oregano")
        var ingredientes4: Array<String> = arrayOf("pollo","papas","salsas")

        var plato1Ing: Map<Map<String,Int>,Array<String>> = mapOf(
            plato1 to ingredientes1 ,
        )

        var plato2Ing: Map<Map<String,Int>,Array<String>> = mapOf(
            plato2 to ingredientes2 ,
        )

        var plato3Ing: Map<Map<String,Int>,Array<String>> = mapOf(
            plato3 to ingredientes3 ,
        )

        var plato4Ing: Map<Map<String,Int>,Array<String>> = mapOf(
            plato4 to ingredientes4 ,
        )


        var platos:Array<Map<Map<String,Int>,Array<String>>> = arrayOf(plato1Ing,plato2Ing,plato3Ing,plato4Ing)

        var texto : String

        for (i in platos) {

            for (j in i) {

                texto = " Nombre del plato: ${j.key.keys} , Precio: $ ${j.key.values} "

                for(k in i.values){

                    for(l in k){

                        println("$texto , ingredientes: $l ")

                    }
                }

            }

        }
    }
}