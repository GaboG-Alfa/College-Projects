package com.example.ejercicio2_seccion2

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

    class DelUnoAlDiez : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var contador = 1

        while((contador!=11) ) {
            if(contador%2==0) {
                println(contador)
            }
            contador++
        }

    }
    }