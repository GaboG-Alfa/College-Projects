package com.example.introduccionkotlin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class MainActivity : AppCompatActivity() {

    companion object{
        const val moneda ="EUR"
    }

    var saldo : Float = 300.54f
    var sueldo= 764.82f
    var sueldoDouble= 764.82
    var entero: Int = 42
    var cantidad : Float = 5f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val fecha="05/06/1990"
        var nombre = "jota"
        var vip: Boolean = false
        var inicial: Char = '3'
        var saludo = "Hola " + nombre

        if (vip == true) saludo += ", te queremos mucho"
        else saludo+= ", quieres ser vip? paga la cuota"

        var dia = fecha.subSequence(3,5).toString().toInt()
        if (dia==1)ingresar_sueldo()
        var mes = fecha.subSequence(3 , 5).toString().toInt()


        mostrar_saldo()

        when(mes){
            1-> println("\n En enero hay la superoferta del 7% de interés")
            2,3 -> println("\n En invierno no hay ofertas de inversiones")
            4,5,6 -> println("\n En primavera hay ofertas de inversiones con el 1.5% de interés ")
            7,8,9 -> print("\n En verano hay ofertas de inversiones con el 2.5% de interés")
            10,11,12 -> print("\n En otoño hay ofertas de inversiones con el 3.5% de interès")

            else -> print("\n La fecha es erronea")
        }
        println(saludo)

        var pin = 1234
        var intentos = 0

        var clave_ingresada: Int = 1232

        do{
            println("Ingrese el PIN: ")
            println("Clave ingresada: ${clave_ingresada}++ ")
            if(clave_ingresada == pin) break
            intentos++
        }while(intentos < 3 && clave_ingresada != pin)

        if(intentos == 3) println("Tarjeta Bloqueada")

        mostrar_saldo()
        ingresar_dinero(cantidad= 50.5f)
        retirar_dinero(cantidad= 50f);
        retirar_dinero(cantidad= 2000f);

        var recibos:Array<String> = arrayOf("luz","agua","gas","pago académicos")

        recorrer_array(recibos)

        var matriz= arrayOf(
            intArrayOf(1,2,3),
            intArrayOf(4,5,6),
            intArrayOf(7,8,9)


        )

        for(i in (0 until matriz.size)){
            println()
            for(j in (0 until matriz[i].size))
                    println("Posicion[$i][$j]: ${matriz[i][j]}")
        }

        var clientesVIP: Set<Int> = setOf(1234,5678,4040)
        val setMezclado= setOf(2,4.454,"casa","c")

        println("Clientes VIP: \n")
        println(clientesVIP)
        println("Numero de cleintes VIP: ${clientesVIP.size}")

        if(clientesVIP.contains(1234)) println("1234 es VIP")
        if(clientesVIP.contains(1235)) print("1235 es VIP")

        var clientes : MutableSet<Int> = mutableSetOf(1234,5678,4040,8970)
        println("Clientes:")
        println(clientes)

        clientes.add(3026)
        println(clientes)

        clientes.remove(5678)
        println(clientes)

        clientes.clear()
        println(clientes)

        println("Número de clientes: ${clientes.size}")

        var divisas : List<String> = listOf("USB","EUR","YER")
        print(divisas)

        var bolsa: MutableList<String> = mutableListOf("Coca-Cola","Adios","Amazon","Pfizer")
        println(bolsa)

        bolsa.add("Adobe")
        println(bolsa)

        bolsa.add("Nvidia")
        println(bolsa)

        bolsa.removeAt(2)
        println(bolsa)

        println(bolsa.first())
        println(bolsa.last())
        println(bolsa.elementAt(2))
        println(bolsa.none())

        bolsa.clear()
        println(bolsa)

        println(bolsa.none())
        bolsa.firstOrNull()

        bolsa.clear()
        println(bolsa)

        println(bolsa.none())
        println(bolsa.firstOrNull())

        bolsa = mutableListOf("Coca-Cola","Adidas","Amazon","Pfizier","Nvidia","Adoba")

        var mapa: Map<Int,String> = mapOf(
            1 to "España",
            2 to "Mexico",
            3 to "Colombia"
        )

        println(mapa)

        var inversiones = mutableMapOf<String,Float>()
        inversiones.put("Coca-Cola",50f)
        println(inversiones)

        var inversiones2 = mutableMapOf<String,Float>()
        println(inversiones2)

        var empresa: String? = null
        println(empresa)

        mostrar_saldo()
        var cantidad_a_invertir = 90f
        var index = 0

        while(saldo >= cantidad_a_invertir){

            empresa= bolsa.elementAtOrNull(index)

            if(empresa!=null){
                saldo -= cantidad_a_invertir
                println("Se ha invertido $cantidad_a_invertir $moneda en $empresa")

                inversiones.put(empresa, cantidad_a_invertir)
            }

            else break
            index++

        }

        var aB: Boolean = true
        var bB: Boolean = true
        var cB: Boolean = false
        var dB: Boolean = false

        aB && bB // and

        aB || bB // OR

        aB && cB
        aB && cB

        !dB // != NEGACION

        var a: Int = 5 + 5 // 10
        var b: Int = 10 - 2 // 0
        var c: Int = 3 + 4 // 12
        var d: Int = 10 / 5 // 2
        var e: Int = 10 % 3 // 1 no se puede dividir, se queda con el resto
        var f: Int = 10 / 6 // 1 division infinita, solo se mantiene la parte entera

        var aPreIncremento: Int = 5
        var bPreDecremento: Int = 5
        var cPostIncremento: Int = 5
        var dPostDecremento: Int = 5

        println(aPreIncremento)
        println(++aPreIncremento) //Incremento primero, luego regresa, Salida: 6
        println(aPreIncremento)

        println(bPreDecremento)
        println(--bPreDecremento) //Primero Decrementa, luego regresa, Salida: 4
        println(bPreDecremento)

        println(cPostIncremento)
        println(cPostIncremento--) //Primero regresa, luego decrementa, Salida: 5
        println(cPostIncremento)

        println(dPostDecremento)
        println(dPostDecremento--) //Primero regresa, luego incrementa, Salida: 5
        println(dPostDecremento)

        saldo+=sueldo
        saldo++

        a == b
        a != b
        a > b
        a < b
        a >= b
        a <= b

    }

    fun mostrar_saldo(){
        println(" Tienes $saldo $moneda")
    }

    fun ingresar_sueldo(){
        saldo+=sueldo
        println("Se ha ingresado tu sueldo de $sueldo $moneda")
        mostrar_saldo()
    }

    fun ingresar_dinero(cantidad: Float){
        saldo+=cantidad
        println("Se ha ingresado $cantidad $moneda")
        mostrar_saldo()
    }

    fun retirar_dinero(cantidad: Float){
        if(verificarCantidad(cantidad)){
            saldo-=cantidad
            println("Se ha hecho una retirada de $cantidad $moneda")
            mostrar_saldo()
        }
        else println("Cantidad superior al saldo. Imposible realizar la operación")

    }

    fun verificarCantidad(cantidad_a_retirar:Float): Boolean{
        if(cantidad_a_retirar > saldo) return false
        else return true
    }

    fun recorrer_array(array:Array<String>) {

        for (i in array)
            println(i)

        for (i in array.indices)
            println(array.get(i))

        for(i in 0 .. array.size - 1 )
            println("${i+1}: ${array.get(i)}")
    }
}