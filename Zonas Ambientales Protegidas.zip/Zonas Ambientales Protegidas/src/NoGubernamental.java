/**
 * Interface que establece el m�todo para calcular ayuda no gubernamental
 * @author Gabriel Guzm�n Alfaro
 * @version 19 de noviembre del 2020
 */
public interface NoGubernamental {
	
	//Calcula la ayuda no gubernamental
	public abstract double calcularNoGubernamental();

}
