/**
 * La clase que establece los datos de un parque nacional
 *
 * @author Gabriel Guzm�n Alfaro
 * @version 19 de noviembre del 2020
 */
public class ParqueNacional extends PagoEntradas implements SubvencionEstado {
	
	//Definir atributos
	private int clientes;
	public final int IMPUESTO_ANUAL = 1200;
	
	
    /**
     * Constructor con par�metros
     * @param nombre
     * @param provincia
     * @param cantidadCostarricenses
     * @param cantidadExtranjeros
     * @param clientes
     */
	public ParqueNacional(String nombre, String provincia, int cantidadCostarricenses, int cantidadExtranjeros,
			int clientes) {
		super(nombre, provincia, cantidadCostarricenses, cantidadExtranjeros);
		this.clientes = clientes;
	}

	/**
	 * Obtiene los clientes
	 * @return clientes
	 */
	public int getClientes() {
		return clientes;
	}
     
	/**
	 * Establece los clientes
	 * @param clientes
	 */
	public void setClientes(int clientes) {
		this.clientes = clientes;
	}
		

	@Override
	public double calcularSubvencion() {
		
		//Definir variable
		double rebajoCliente;
		
		//Calcular rebajo
		rebajoCliente = clientes * IMPUESTO_ANUAL;
		   
		return rebajoCliente;
	}

	@Override
	public double ingresos() {
		
		//Definir variables
		double calculoNacionales;
		double calculoExtranjeros;
		double total;
		
		//Calcular
		calculoNacionales = super.getCantidadCostarricenses() * 5000;
		calculoExtranjeros = super.getCantidadExtranjeros() * 6000;
		
		total= calculoNacionales+calculoExtranjeros+this.calcularSubvencion();
	
		
		return total;
	}

	@Override
	public String toString() {
		return "ParqueNacional , Clientes: " + clientes ;
	}
	
	
	
	
	
	

}
