/**
 * La clase que establece los datos de un monumento nacional
 *
 * @author Gabriel Guzm�n Alfaro
 * @version 19 de noviembre del 2020
 */
public class MonumentoNacional extends PagoEntradas {

	/**
	 * Construcotr con par�metros
	 * 
	 * @param nombre
	 * @param provincia
	 * @param cantidadCostarricenses
	 * @param cantidadExtranjeros
	 */
	public MonumentoNacional(String nombre, String provincia, int cantidadCostarricenses, int cantidadExtranjeros) {
		super(nombre, provincia, cantidadCostarricenses, cantidadExtranjeros);
	}

	@Override
	public double ingresos() {

		// Definir variables
		double calculoNacionales;
		double calculoExtranjeros;
		double total;

		// Calcular
		calculoNacionales = super.getCantidadCostarricenses() * 5000;
		calculoExtranjeros = super.getCantidadExtranjeros() * 6000;

		total = calculoNacionales + calculoExtranjeros;

		return total;
	}

	@Override
	public String toString() {
		return "Monumento Nacional ," + super.toString() + ", Nombre: " + getNombre() + ", Provincia: " + getProvincia();
	}

}
