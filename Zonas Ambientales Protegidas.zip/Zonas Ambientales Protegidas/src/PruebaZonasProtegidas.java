/**
 * La clase que prueba el funcinamiento del programa
 * @author Gabriel Guzm�n Alfaro
 * @version 19 de noviembre del 2020
 */
public class PruebaZonasProtegidas {

	public static void main(String[] args) {
		
		//Instanciar las zonas
		ZonaProtegida parqueNacional = new ParqueNacional("Manuel Antonio","Puntarenas",5000,2000,500);
		ZonaProtegida reservaBiologica = new ReservaBiologica("Tirimbina","Heredia",2500000);
		ZonaProtegida monumentoNacional = new MonumentoNacional("Guayabo","Puntarenas",9000,7000);
		ZonaProtegida patrimonioCultural = new PatrimonioCultural("Guayabo","Puntarenas",11000,10000,60000000);
		ZonaProtegida refugioGobierno = new RefugioVidaSilvestreGobierno("La Marta","Cartago",1000000);
		ZonaProtegida refugioPrivado = new RefugioVidaSilvestrePrivado("Cerro Dantas","Heredia",2000000);
         
		
		//Instanciar la lista de zonas
		ListaZonasProtegidas  listaZonas = new ListaZonasProtegidas();
		
		//Agregar las zonas a la lista
		listaZonas.agregarElemento(parqueNacional);
		listaZonas.agregarElemento(reservaBiologica);
		listaZonas.agregarElemento(monumentoNacional);
		listaZonas.agregarElemento(patrimonioCultural);
		listaZonas.agregarElemento(refugioGobierno);
		listaZonas.agregarElemento(refugioPrivado);
		
		//Mostrar Datos
		System.out.println("Reporte 1: "+listaZonas.reporte1()+"\n\nReporte 2: "+listaZonas.reporte2());
		
		
		
	}

}
