/**
 * La clase que establece los datos de un refugio de vida del gobierno
 * 
 * @author Gabriel Guzm�n Alfaro
 * @version 19 de noviembre del 2020
 */
public class RefugioVidaSilvestreGobierno extends ZonaProtegida implements SubvencionEstado {

	// Definir atributos
	private double montoCombustibles;
	private final double PORCENTAJE_IMPUESTO_COMBUSTIBLE = 0.005;

	/**
	 * Constructor con par�metros
	 * 
	 * @param montoCombustibles
	 */
	public RefugioVidaSilvestreGobierno(String nombre, String provincia, double montoCombustibles) {
		super(nombre, provincia);
		this.montoCombustibles = montoCombustibles;
	}

	/**
	 * Obtiene el monto de combustibles
	 * 
	 * @return montoCombustibles
	 */
	public double getMontoCombustibles() {
		return montoCombustibles;
	}

	/**
	 * Establece el monto de combustibles
	 * 
	 * @param montoCombustibles
	 */
	public void setMontoCombustibles(double montoCombustibles) {
		this.montoCombustibles = montoCombustibles;
	}

	@Override
	public double ingresos() {
		
		return this.calcularSubvencion();
	}
	
	

	@Override
	public double calcularSubvencion() {
		 
		//Defnir variable 
		double calcularMonto = montoCombustibles * PORCENTAJE_IMPUESTO_COMBUSTIBLE; 
		
		return calcularMonto ;
	}

	@Override
	public String toString() {
		return "RefugioVidaSilvestreGobierno,  MontoCombustibles: " + montoCombustibles;
	}
	
	
	

}
