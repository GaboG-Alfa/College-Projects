/**
 * La clase que almacena el pago de las entradas
 * 
 * @author Gabriel Guzmán Alfaro
 * @version 19 de noviembre del 2020
 */
public abstract class PagoEntradas extends ZonaProtegida {

    //Definir atributos
    private int cantidadCostarricenses;
    private int cantidadExtranjeros;
    public final int ETRADA_COSTARRICENSES = 5000;
    public final int ETRADA_EXTRANJEROS = 6000;
    
         
     /**
      * Constructor con parámetros
      * @param nombre
      * @param provincia
      * @param cantidadCostarricenses
      * @param cantidadExtranjeros
      */
	public PagoEntradas(String nombre, String provincia, int cantidadCostarricenses, int cantidadExtranjeros) {
		super(nombre, provincia);
		this.cantidadCostarricenses = cantidadCostarricenses;
		this.cantidadExtranjeros = cantidadExtranjeros;
	}



	/**
      * Obtiene la cantidad de costarricenses
      * @return cantidadCostarricenses
      */
	public int getCantidadCostarricenses() {
		return cantidadCostarricenses;
	}

     /**
      * Establece la cantidad de costarricenses
      * @param cantidadCostarricenses
      */
	public void setCantidadCostarricenses(int cantidadCostarricenses) {
		this.cantidadCostarricenses = cantidadCostarricenses;
	}
     
    /**
     * Obtiene la cantidad de extranjeros
     * @return cantidad de extranjeros
     */
	public int getCantidadExtranjeros() {
		return cantidadExtranjeros;
	}

    /**
     * Establece la cantidad de extranjeros
     * @param cantidadExtranjeros
     */
	public void setCantidadExtranjeros(int cantidadExtranjeros) {
		this.cantidadExtranjeros = cantidadExtranjeros;
	}
    
	/**
	 * Calcula los ingresos recibidos por las entradas
	 * @return ingresoEntradas
	 */
	public double calcularIngresosEntradas() {
		
		//Defnir variables 
		double entradaCostarricenses;
		double entradaExtranjeros;
		double ingresoEntradas;
		
		//Hacer cálculo
		entradaCostarricenses = cantidadCostarricenses *  ETRADA_COSTARRICENSES;
		entradaExtranjeros = cantidadExtranjeros * ETRADA_EXTRANJEROS;
		ingresoEntradas = entradaCostarricenses + entradaExtranjeros;
		
		return ingresoEntradas;
		
	}

	@Override
	public String toString() {
		return "Cantidad de Costarricenses: " + cantidadCostarricenses + ", Cantidad de Extranjeros: "
				+ cantidadExtranjeros;
	}
    
    
    
      
    
}