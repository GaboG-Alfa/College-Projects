/**
 * La clase que establece los datos de una zona protegida
 * @author Gabriel Guzmán Alfaro
 * @version 19 de noviembre del 2020
 */
public abstract class ZonaProtegida {

    // Defnir atributos
    private String nombre;
    private String provincia;

    /**
     * Constructor con parámetros
     * 
     * @param nombre
     * @param provincia
     */
    public ZonaProtegida(String nombre, String provincia) {
        this.nombre = nombre;
        this.provincia = provincia;

    }

    /**
     * Obtener el nombre
     * 
     * @return nombre
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Establecer el nombre
     * 
     * @param nombre
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Obtener provincia
     * 
     * @return provincia
     */
    public String getProvincia() {
        return provincia;
    }

    /**
     * Establecer provincia
     * 
     * @param provincia
     */
    public void setProvincia(String provincia) {
        this.provincia = provincia;
    }

    // Calcula los ingresos de la zona
    public abstract double ingresos();

    @Override
    public String toString() {
        return "ZonaProtegida,  Nombre: " + nombre + ", Provincia: " + provincia;
    }

}
