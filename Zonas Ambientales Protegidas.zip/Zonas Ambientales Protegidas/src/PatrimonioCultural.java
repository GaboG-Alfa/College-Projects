/**
 * La clase que establece los datos de un patrimonio cultural
 *
 * @author Gabriel Guzm�n Alfaro
 * @version 19 de noviembre del 2020
 */
public class PatrimonioCultural extends MonumentoNacional implements NoGubernamental {

	// Definir atributos
	private double pib;
	public final double NO_GUBERNAMENTAL = 0.002;

	/**
	 * Constructor con par�metros
	 * 
	 * @param nombre
	 * @param provincia
	 * @param cantidadCostarricenses
	 * @param cantidadExtranjeros
	 * @param pib
	 */
	public PatrimonioCultural(String nombre, String provincia, int cantidadCostarricenses, int cantidadExtranjeros,
			double pib) {
		super(nombre, provincia, cantidadCostarricenses, cantidadExtranjeros);
		this.pib = pib;
	}

	/**
	 * Obtiene el pib
	 * 
	 * @return pib
	 */
	public double getPib() {
		return pib;
	}

	/**
	 * Establece el pib
	 * 
	 * @param pib
	 */
	public void setPib(double pib) {
		this.pib = pib;
	}

	@Override
	public double calcularNoGubernamental() {
		
        //Defnir variable
		double internoBrutoPais;
		
		//Calcular
		internoBrutoPais = pib * 0.002;

		return internoBrutoPais;
	}

	@Override
	public double ingresos() {

		// Definir variables
		double calculoNacionales;
		double calculoExtranjeros;
		double total;

		// Calcular
		calculoNacionales = super.getCantidadCostarricenses() * 5000;
		calculoExtranjeros = super.getCantidadExtranjeros() * 6000;

		total = calculoNacionales + calculoExtranjeros + this.calcularNoGubernamental();

		return total;
	}

	@Override
	public String toString() {
		return "PatrimonioCultural, PIB: " + pib + ", Ingreso no gubernamental: " + NO_GUBERNAMENTAL;
	}

}
