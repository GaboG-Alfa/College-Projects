/**
 * La clase que almacena una lista de zonas protegidas
 * 
 * @author Gabriel Guzmán Alfaro
 * @version 19 de noviembre del 2020
 */
public class ListaZonasProtegidas {

	// Definir atributos
	private ZonaProtegida listaZonasProtegidas[];
	private final int TAM_INICIAL = 10;
	private int cantidadElementos = 0;

	/**
	 * Constructor sin parámetros
	 */
	public ListaZonasProtegidas() {
		listaZonasProtegidas = new ZonaProtegida[TAM_INICIAL];
	}

	/**
	 * Agrega una zona protegida a la lista
	 * 
	 * @param zonaProtegida
	 */
	public void agregarElemento(ZonaProtegida zonaProtegida) {

		// Agrega los elementos en orden izquierda a derecha
		if (cantidadElementos < listaZonasProtegidas.length) {
			this.listaZonasProtegidas[cantidadElementos] = zonaProtegida;
			cantidadElementos = cantidadElementos + 1;
		} else {
			this.duplicarLista();
			this.listaZonasProtegidas[cantidadElementos] = zonaProtegida;
			cantidadElementos = cantidadElementos + 1;
		}

	}

	/**
	 * Duplica la lista de zonas protegidas
	 */
	public void duplicarLista() {
		ZonaProtegida[] newVector = new ZonaProtegida[listaZonasProtegidas.length];
		for (int i = 0; i < listaZonasProtegidas.length; i++) {
			newVector[i] = listaZonasProtegidas[i];
		}
		listaZonasProtegidas = new ZonaProtegida[listaZonasProtegidas.length + 1];
		for (int i = 0; i < newVector.length; i++) {
			listaZonasProtegidas[i] = newVector[i];
		}
	}

	
	

	/**
	 * Muestra el primer reporte de datos
	 * 
	 * @return textoZonas
	 */
	public String reporte1() {

		// Define variables
		String textoZonas = "";
		double sumaMonto = 0;

		// Recorre la lista
		for (int i = 0; i < cantidadElementos; i++) {

			// Suma todos los ingresos de la lista
			sumaMonto += listaZonasProtegidas[i].ingresos();

			if (listaZonasProtegidas != null) {
				textoZonas = textoZonas + " \n" + "\n" + listaZonasProtegidas[i].toString()
						+ ", Ingresos de las zonas: " + listaZonasProtegidas[i].ingresos() + "\n";
			}
		}

		return textoZonas + "\nTotal de ingreso de todas las zonas: " + sumaMonto;
	}

	/**
	 * Muestra el segundo reporte de datos
	 * 
	 * @return textoZonas
	 */
	public String reporte2() {

		// Define variables
		String textoZonas = "";
		double sumaSubvencion = 0;
		double entradasParques = 0;
		double ingresoNoGubernamental = 0;

		// Recorre la lista para sumar las subvenciones, los ingresos por entrada a los
		// parques y las ayudas no gubernamentales
		for (int i = 0; i < cantidadElementos; i++) {

			if (listaZonasProtegidas[i] instanceof ParqueNacional) {
				ParqueNacional parque = (ParqueNacional) listaZonasProtegidas[i];
				sumaSubvencion = sumaSubvencion + parque.calcularSubvencion();
				entradasParques = entradasParques + parque.calcularIngresosEntradas();
			}

			if (listaZonasProtegidas[i] instanceof ReservaBiologica) {
				ReservaBiologica reserva = (ReservaBiologica) listaZonasProtegidas[i];
				sumaSubvencion = sumaSubvencion + reserva.calcularSubvencion();
			}

			if (listaZonasProtegidas[i] instanceof RefugioVidaSilvestreGobierno) {
				RefugioVidaSilvestreGobierno refugio = (RefugioVidaSilvestreGobierno) listaZonasProtegidas[i];
				sumaSubvencion = sumaSubvencion + refugio.calcularSubvencion();
			}

			if (listaZonasProtegidas[i] instanceof RefugioVidaSilvestrePrivado) {
				RefugioVidaSilvestrePrivado refugioPrivado = (RefugioVidaSilvestrePrivado) listaZonasProtegidas[i];
				ingresoNoGubernamental = ingresoNoGubernamental + refugioPrivado.calcularNoGubernamental();
			}

			if (listaZonasProtegidas[i] instanceof PatrimonioCultural) {
				PatrimonioCultural patrimonio = (PatrimonioCultural) listaZonasProtegidas[i];
				ingresoNoGubernamental = ingresoNoGubernamental + patrimonio.NO_GUBERNAMENTAL;

			}
		}

		   if (listaZonasProtegidas != null) {
			textoZonas = textoZonas + "\n\nMonto total de subvención: " + sumaSubvencion
					+ "\n\nIngresos de entradas a los parques: " + entradasParques + "\n\nIngresos no gubernamentales: "
					+ ingresoNoGubernamental;
		}

		return textoZonas;
	}

}