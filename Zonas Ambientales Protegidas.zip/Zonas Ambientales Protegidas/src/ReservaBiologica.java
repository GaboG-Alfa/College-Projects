/**
 * La clase que establece los datos de una reserva biol�gica
 * 
 * @author Gabriel Guzm�n Alfaro
 * @version 19 de noviembre del 2020
 */
public class ReservaBiologica extends ZonaProtegida implements SubvencionEstado {

	// Definir atributos
	private double montoSubsidio;

	/**
	 * Constructor con par�metros
	 * 
	 * @param nombre
	 * @param provincia
	 * @param montoSubsidio
	 */
	public ReservaBiologica(String nombre, String provincia, double montoSubsidio) {
		super(nombre, provincia);
		this.montoSubsidio = montoSubsidio;
	}

	/**
	 * Obtener el monto de subsidio
	 * 
	 * @return
	 */
	public double getMontoSubsidio() {
		return montoSubsidio;
	}

	/**
	 * Establecer el monto de subsidio
	 * 
	 * @param montoSubsidio
	 */
	public void setMontoSubsidio(double montoSubsidio) {
		this.montoSubsidio = montoSubsidio;
	}

	@Override
	public double ingresos() {

		return this.calcularSubvencion();
	}

	/**
	 * Es el subsidio calculado de forma anual
	 * 
	 * @return calcularSubvencion
	 */
	public double calcularSubvencion() {

		// Definir variables
		double calcularSubvencion;

		// Hacer el c�lculo
		calcularSubvencion = montoSubsidio * 12;

		return calcularSubvencion;

	}

	@Override
	public String toString() {
		return "ReservaBiologica,  MontoSubsidio: " + montoSubsidio;
	}

}
