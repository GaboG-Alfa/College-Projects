/**
 * Interface que establece el m�todo para calcular la subvenci�n
 * @author Gabriel Guzm�n Alfaro
 * @version 19 de noviembre del 2020
 */
public interface SubvencionEstado {
	
	//Calcula la subvenci�n que var�a seg�n la zona
	public abstract double calcularSubvencion();

}
