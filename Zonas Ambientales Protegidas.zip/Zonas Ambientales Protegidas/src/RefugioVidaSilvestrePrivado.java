/**
 * La clase que establece los datos de un refugio de vida privado
 * 
 * @author Gabriel Guzm�n Alfaro
 * @version 19 de noviembre del 2020
 */
public class RefugioVidaSilvestrePrivado extends ZonaProtegida implements NoGubernamental {
	
	//Definir atributos
	private double noGubernamental;
     
	/**
	 * Constructor con par�metros
	 * @param nombre
	 * @param provincia
	 * @param noGubernamental
	 */
	public RefugioVidaSilvestrePrivado(String nombre, String provincia, double noGubernamental) {
		super(nombre, provincia);
		this.noGubernamental = noGubernamental;
	}
	
	
	
     /**
      * Obtiene la ayuda no gubernamental
      * @return
      */
	public double getNoGubernamental() {
		return noGubernamental;
	}
     

 
     /**
      * Establece la ayuda no gubernamental
      * @param noGubernamental
      */
	public void setNoGubernamental(double noGubernamental) {
		this.noGubernamental = noGubernamental;
	}

    
	


	@Override
	public double ingresos() {
		
		return this.calcularNoGubernamental();
	}

    
	


	@Override
	public double calcularNoGubernamental() {
		
		//Definir variable 
		double calculoAnual;
		
		//Calcular
		calculoAnual = noGubernamental * 12;
		
		return calculoAnual;
	}



	@Override
	public String toString() {
		return "RefugioVidaSilvestrePrivado, Ingreso no Gubernamental: " + noGubernamental;
	}
	
	
	
	
	

}
