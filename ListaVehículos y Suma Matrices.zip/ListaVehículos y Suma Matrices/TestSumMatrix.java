/**
 * TestSumMatrix that controls the program
 * 
 * @version October 29, 2020
 * @author Gabriel GuzmÃ¡n Alfaro
 */
public class TestSumMatrix {

	/**
	 * Main method
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		// Define variables
		int matrix1[][] = new int[7][4];
		int matrix2[][] = new int[7][3];

		// Define matrix1
		matrix1[0][0] = 10;
		matrix1[0][1] = 17;
		matrix1[0][2] = 24;
		matrix1[0][3] = 31;

		matrix1[1][0] = 11;
		matrix1[1][1] = 18;
		matrix1[1][2] = 25;
		matrix1[1][3] = 32;

		matrix1[2][0] = 12;
		matrix1[2][1] = 19;
		matrix1[2][2] = 26;
		matrix1[2][3] = 33;

		matrix1[3][0] = 13;
		matrix1[3][1] = 20;
		matrix1[3][2] = 27;
		matrix1[3][3] = 34;

		matrix1[4][0] = 14;
		matrix1[4][1] = 21;
		matrix1[4][2] = 28;
		matrix1[4][3] = 35;

		matrix1[5][0] = 15;
		matrix1[5][1] = 22;
		matrix1[5][2] = 29;
		matrix1[5][3] = 36;

		matrix1[6][0] = 16;
		matrix1[6][1] = 23;
		matrix1[6][2] = 30;
		matrix1[6][3] = 37;

		// Define matrix2
		matrix2[0][0] = 10;
		matrix2[0][1] = 17;
		matrix2[0][2] = 24;

		matrix2[1][0] = 11;
		matrix2[1][1] = 18;
		matrix2[1][2] = 25;

		matrix2[2][0] = 12;
		matrix2[2][1] = 19;
		matrix2[2][2] = 26;

		matrix2[3][0] = 13;
		matrix2[3][1] = 20;
		matrix2[3][2] = 27;

		matrix2[4][0] = 14;
		matrix2[4][1] = 21;
		matrix2[4][2] = 28;

		matrix2[5][0] = 15;
		matrix2[5][1] = 22;
		matrix2[5][2] = 29;

		matrix2[6][0] = 16;
		matrix2[6][1] = 23;
		matrix2[6][2] = 30;

		// Show matrix1
		String result1 = "";
		for (int i = 0; i < matrix1.length; i++) {
			for (int j = 0; j < matrix1[i].length; j++) {
				result1 += matrix1[i][j] + ", ";
			}
			result1 += "\n";

		}

		// Show matrix2
		String result2 = "";
		for (int i = 0; i < matrix2.length; i++) {
			for (int j = 0; j < matrix2[i].length; j++) {
				result2 += matrix2[i][j] + ", ";
			}
			result2 += "\n";

		}

		// Print matrix1
		System.out.println("Matrix 1: \n\n" + result1);

		// Print matrix2
		System.out.println("Matrix2: \n\n" + result2);
		
	    //Print the sum of both matrices	
		System.out.println("Result vector 1: \n\t" 
							+ MatrixSum.printMatrix(MatrixSum.SumColumTriangleMagtrix(matrix1)) + "\n");
		System.out.println("Result vector 2: \n\t" 
							+ MatrixSum.printMatrix(MatrixSum.SumColumTriangleMagtrix(matrix2)));

	}
}
