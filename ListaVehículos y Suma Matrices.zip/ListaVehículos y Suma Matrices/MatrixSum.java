/**
 * Matrix class that compute matrix operations
 * 
 * @version October 29, 2020
 * @author Gabriel GuzmÃ¡n Alfaro
 */
public class MatrixSum {

    /**
     * Sum matrices
     * 
     * @param matrix1
     * @param matrix2
     * @return resultVector
     */
    public static int[] SumColumTriangleMagtrix(int[][] matrix1) {
        
        //Create a vector of the rows length
        int resultVector[] = new int[matrix1[0].length];
        
        //Traverse the matrix reducing the range of the sum as a triangle
        for (int i = 0; i < matrix1[i].length; i++) {
            for (int j = i; j < matrix1.length - i; j++) {
                resultVector[i] += matrix1[j][i];
            }
        }
        return resultVector;
    }

    /**
     * Print the matrix
     * 
     * @param vector
     * @return text
     */
    public static String printMatrix(int[] vector) {
        
        //Slip the vector to joining the values
        String text = "Result of Sum: \n\t\t";

        for (int result : vector) {
            if (result != 0) {
                text = text + " " + result;
            } else {
                break;
            }
        }
        return text;
    }

}