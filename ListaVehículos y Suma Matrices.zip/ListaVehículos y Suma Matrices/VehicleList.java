/**
 * List of vehicles
 * 
 * @version October 29, 2020
 * @author Gabriel Guzm�n Alfaro
 */
public class VehicleList {

	// Attributes
	private Vehicle vehicleList[];

	/**
	 * Constructor without parameters
	 */
	public VehicleList(Vehicle vehicleList[]) {
		this.vehicleList = vehicleList;
	}

	/**
	 * Print the list vehicle
	 * 
	 * @return listVehicle
	 */
	public String printList() {
		// Creat the vehicleList copy
		Vehicle vehicleListCopy[] = this.bubbleSortById();

		// Creat a String to return a row
		String listVehicle = "";

		// Perform a slipping of the list
		for (int i = 0; i < vehicleListCopy.length; i++) {
			if (vehicleListCopy[i] != null) {
				listVehicle = listVehicle + " \n" + "\n" + vehicleListCopy[i].toString();
			}
		}
		return listVehicle;
	}

	/**
	 * Define the positon
	 * 
	 * @param vehicle
	 */
	public Vehicle attend(String kind) {

		// Counter
		int i = 0;

		// Save the value that will be extracted
		Vehicle vehicleTemp;

		// Search the vehicle kind
		while (i < vehicleList.length) {

			// Return null if don´t found the kind
			if (vehicleList[i] == null) {
				return null;
			}

			// Break if found the kind
			if (vehicleList[i].getKind().equals(kind)) {
				break;
			}
			i++;
		}

		vehicleTemp = vehicleList[i];

		// Slipping the elements to left
		for (int j = i; j < vehicleList.length; j++) {
			if (j + 1 == vehicleList.length) {
				vehicleList[j] = null;
				break;
			}
			if (vehicleList[j + 1] == null) {
				vehicleList[j] = null;
				break;
			} else {
				vehicleList[j] = vehicleList[j + 1];

			}
		}
		return vehicleTemp;
	}

	/**
	 * Bubble sort method
	 */
	private Vehicle[] bubbleSortById() {

		// Create a new list with the same lenght
		Vehicle vehicleListCopy[] = new Vehicle[vehicleList.length];

		// Perform a slipping and save the old list in the new list
		for (int i = 0; i < vehicleList.length; i++) {
			vehicleListCopy[i] = vehicleList[i];
		}

		// Slipping the list
		for (int i = 0; i < vehicleList.length; i++) {

			for (int n = 0; n < vehicleList.length - 1; n++) {

				// Try not to exceed the lenght
				if (vehicleListCopy[n + 1] != null) {
					String currentClientId = vehicleListCopy[n].getClient().getId();
					String nextClientId = vehicleListCopy[n + 1].getClient().getId();

					// swap and change
					if (currentClientId.compareTo(nextClientId) > 0) {
						Vehicle currentClient = vehicleListCopy[n];
						vehicleListCopy[n] = vehicleListCopy[n + 1];
						vehicleListCopy[n + 1] = currentClient;
					}
				} else {
					break;
				}
			}
		}

		return vehicleListCopy;
	}

}// End ListStudent class