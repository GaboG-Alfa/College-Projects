/**
 * Class vehicle that have all information about a vehicle
 *
 * @version October 29, 2020
 * @autor Gabriel Guzm�n Alfaro
 */
public class Vehicle {

    // Vehicle Attributes
    private String id;
    private String kind;
    private byte year;
    private Client client;

    public Vehicle() {
        this("B1320", "Cargo", (byte) 19, new Client());

    }

    /**
     * Constructor with parameters
     * 
     * @param id
     * @param kind
     * @param year
     * @param client
     */
    public Vehicle(String id, String kind, byte year, Client client) {
        this.id = id;
        this.kind = kind;
        this.year = year;
        this.client = client;
    }

    /**
     * Set the vehicle id
     * 
     * @param id
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * Set the vehicle kind
     * 
     * @param kind
     */
    public void setKind(String kind) {
        this.kind = kind;
    }

    /**
     * Set the vehicle year
     * 
     * @param year
     */
    public void setYear(byte year) {
        this.year = year;
    }

    /**
     * Set the vehicle client
     * 
     * @param client
     */
    public void setClient(Client client) {
        this.client = client;
    }

    /**
     * Get the vehicle id
     * 
     * @return id
     */
    public String getId() {
        return id;
    }

    /**
     * Get the vehicle kind
     * 
     * @return kind
     */
    public String getKind() {
        return kind;
    }

    /**
     * Get the vehicle client
     * 
     * @return client
     */
    public Client getClient() {
        return client;
    }

    /**
     * Return all attributes about vehicle
     */
    public String toString() {
        return "\nVehicle" + "\nId: " + id + "\nYear: " + year + "\nKind: " + kind + client.toString();
    }

}