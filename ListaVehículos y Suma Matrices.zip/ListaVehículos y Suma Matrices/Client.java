/**
 * Class client that have all information about a client
 *
 * @version October 29, 2020
 * @autor Gabriel Guzm�n Alfaro
 */
public class Client {

    // Client attributes
    private String id;
    private String name;
    private String lastName;

    public Client() {
        this("20853671", "Carlos", "Alfaro");
    }

    /**
     * Constructor with parameters
     * 
     * @param id
     * @param name
     * @param lastName
     */
    public Client(String id, String name, String lastName) {
        this.id = id;
        this.name = name;
        this.lastName = lastName;
    }

    /**
     * Set the client id
     * 
     * @param id
     */
    public void setId(String id) {
        this.id = id;
    }

    /**
     * Set the client name
     * 
     * @param name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Set the client lastName
     * 
     * @param lastName
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * Get the client id
     * 
     * @return id
     */
    public String getId() {
        return id;
    }

    /**
     * Get the client Name
     * 
     * @return name
     */
    public String getName() {
        return name;
    }

    /**
     * Get the client lastName
     * 
     * @return lastName
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * Return all attributes about client
     */
    public String toString() {
        return "\nClient" + "\nId: " + id + "\nName: " + name + "\nLast Name: " + lastName;
    }

}