/**
 * TestVehicle that controls the program
 * 
 * @version October 29, 2020
 * @author Gabriel Guzm�n Alfaro
 */
public class TestVehicleList {

	/**
	 * Main method
	 * 
	 * @param args
	 */
	public static void main(String[] args) {

		// Create clients
		Client client1 = new Client("2081233", "Gabriel", "Guzmán");
		Client client2 = new Client("2054332", "Carlos", "Alfaro");
		Client client3 = new Client("2012342", "Luis", "Ruiz");
		Client client4 = new Client("20634435", "Juan", "Madriz");
		Client client5 = new Client("20123343", "Ana", "Ortega");

		// Create vehicles
		Vehicle vehicle1 = new Vehicle("B234", "light", (byte) 20, client1);
		Vehicle vehicle2 = new Vehicle("C9824", "moto", (byte) 97, client2);
		Vehicle vehicle3 = new Vehicle("D134", "cargo", (byte) 19, client3);
		Vehicle vehicle4 = new Vehicle("S23494", "bus", (byte) 82, client4);
		Vehicle vehicle5 = new Vehicle("AM2344", "light", (byte) 99, client5);

		// Creat list to send to vehicleList class
		Vehicle vehicleListToInsert[] = { vehicle1, vehicle2, vehicle3, vehicle4, vehicle5 };
		VehicleList vehicleList = new VehicleList(vehicleListToInsert);

		// Send the vehicle kind to attend method
		System.out.println(vehicleList.attend("light") + "\n\n Was attended!");
		System.out.println(vehicleList.attend("cargo") + "\n\n Was attended!");
		System.out.println(vehicleList.attend("bus") + "\n\n Was attended!");

		// Print the list of vehicles in order
		System.out.println("\n\nStill to attend: " + vehicleList.printList());

	}
}