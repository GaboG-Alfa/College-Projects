package com.example.poo

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    //private lateinit var pok :Pokemon
    object fernanda{
        var apodo = "fer"

        fun saludo(){println("Hola,me llaman $apodo")}
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var num: Int = 0
        var jota: Person = Person("Jota","A23453456")
        var anonimo:Person=Person()
        println(jota.alive)
        println(jota.name)
        println(jota.passport)

        anonimo.Person()
        println(anonimo.alive)
        println(anonimo.name)
        println(anonimo.passport)

        jota.die()
        println(jota.alive)

        /*
        var pikachu:Pokemon = Pokemon()
        println(pikachu.getName())
        println(pikachu.getAttackPower())
        pikachu.setLife(30f)
        println(pikachu.getLife())
       */

        var ani = SubClasses.Anidada()
        println(ani.presentar())

        var inn = SubClasses().Interna()
        println(inn.presentar())

        var pele :Athlete = Athlete("Pelé","C813465","Futbol")

        println(pele.alive)
        println(pele.name)
        println(pele.passport)
        println(pele.sport)

        pele.die()
        println(pele.alive)

        println(fernanda.saludo())
        fernanda.apodo = "SuperFer"
        println(fernanda.saludo())

        var sol: star = star("Sol",696340f,"vía lactea")
        println(sol)

        var betelgeuse : star = star("Betelgeuse",617100000f,"Orión")
        betelgeuse.alive = false
        println(betelgeuse.alive)

        var nueva: star = star()
        println(nueva)

        var hoy: dias = dias.LUNES
        var semana: Array<dias> = dias.values()
        for(i in semana) println(i)

        println(dias.valueOf("MIÉRCOLES"))
        println(hoy.name)
        println(hoy.ordinal)

        println(hoy.saludo())
        println(hoy.laboral)
        println(hoy.jornada)

        hoy = dias.DOMINGO
    }
    /*
       fun createNewPokemon(v:View){
           var etName: findViewById<EditText>(R.id.etName)
           var etAttackPower = findViewById<EditText>(R.id.etAttackPower)

           pok = Pokemon()

           if(!etName.text.isNullOrEmpty() && !etAttackPower.text.toString().toFloat())
              pok.Pokemon(etName.text.toString,etAttackPower.text.toString().toFloat())

           var ivPokemon = findViewById<ImageView>(R.id.ivPokemon)
           ivPokemon.setImageResource(R.mipmap.pokemon)

           var tvPokemon = findviewById<TextView>(R.Id.tvPokemon)
           loadDataPokemon(tvPokemon, pok)
       }



       private fun loadDataPokemon(tv:TextView,p:Pokemon){
           var description: String = ""

           description += p.getName() + " ("
           description += "AP: " + p.getAttackPower().toInt()
           description += "-L: " + p.getLife().toInt() + ")"

           tv.text = description
       }
     */
}