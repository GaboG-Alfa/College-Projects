package com.example.poo

data class star(val name:String = "",val radius: Float = 0f , var galaxy : String = "" ) {
    var alive = true
}