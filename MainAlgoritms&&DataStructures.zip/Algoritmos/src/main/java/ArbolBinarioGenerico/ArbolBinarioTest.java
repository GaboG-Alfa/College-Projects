/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ArbolBinarioGenerico;

/**
 *
 * @author Gabriel Guzmán Alfaro
 */
public class ArbolBinarioTest {
    
    /**
     * 
     * @param args 
     */
    public static void main(String[] args){
        
        try {
            ArbolBinario<Persona> arbol=new ArbolBinario<>();
            
            arbol.insertar(new Persona(208230484,"Gabriel",19));
            arbol.insertar(new Persona(204560789,"Luis",18));
            arbol.insertar(new Persona(207450987,"Ana",16));
            arbol.insertar(new Persona(206780343,"Rosa",15));
            arbol.insertar(new Persona(205670125,"Marco",10));
            arbol.insertar(new Persona(208970345,"Enrique",19));
            System.out.println("Arbol creado");
            System.out.println("\n\nPreOrden");
            System.out.println(arbol.preOrden());
            System.out.println("\n\nPostOrden");
            System.out.println(arbol.postOrden());
            System.out.println("\n\nEnOrden");
            System.out.println(arbol.enOrden());
            System.out.println("\n\nElementos máximos y mínimos");
            System.out.println("Min "+arbol.findMin());
            System.out.println("Max "+arbol.findMax());
            System.out.println("\n\nBuscar elemento");
            System.out.println("Buscar: "+arbol.find(new Persona(208230484,"Gabriel",19)));
            System.out.println("\n\nPreOrden");
            System.out.println(arbol.preOrden());
            System.out.println("\n\nPostOrden");
            System.out.println(arbol.postOrden());
            System.out.println("\n\nEnOrden");
            System.out.println(arbol.enOrden());
            System.out.println("\n\nRemover nodo ");
            arbol.remove(new Persona(208970345,"Enrique",19));
            System.out.println("\n\nPreOrden");
            System.out.println(arbol.preOrden());
            System.out.println("\n\nPostOrden");
            System.out.println(arbol.postOrden());
            System.out.println("\n\nEnOrden");
            System.out.println(arbol.enOrden());
        } catch (ArbolBinarioException ex) {
            System.out.println("Error: "+ex);
        }
    }
    
}
