/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ArbolBinarioGenerico;

import NodosGenericos.*;
import ArbolBinarioPersonas.*;
import ArbolBinario.*;

/**
 *
 * @author Gabriel Guzmán Alfaro
 * @version 10/06/2021
 */
public class ArbolBinarioException extends Exception {
    
    /**
     * 
     * @param exception 
     */
    public ArbolBinarioException(String exception){
        super(exception);
    }
}
