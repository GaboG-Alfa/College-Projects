package ArbolBinarioGenerico; 
 
import NodosGenericos.*;

/** 
 * 
 * @author Gabriel Guzmán 
 */ 
public class Producto { 
    
    //Atrbiutos
    private Integer codigo; 
    private Integer precio; 
    private String descripcion; 
 
    /**
     * 
     * @param codigo
     * @param precio
     * @param descripcion 
     */
    public Producto(Integer codigo, Integer precio, String descripcion) { 
        this.codigo = codigo; 
        this.precio = precio; 
        this.descripcion = descripcion; 
    } 
 
    /**
     * 
     * @return codigo 
     */
    public Integer getCodigo() { 
        return codigo; 
    } 
 
    /**
     * 
     * @param codigo 
     */
    public void setCodigo(Integer codigo) { 
        this.codigo = codigo; 
    } 
 
    /**
     * 
     * @return precio 
     */
    public Integer getPrecio() { 
        return precio; 
    } 
 
    /**
     * 
     * @param precio 
     */
    public void setPrecio(Integer precio) { 
        this.precio = precio; 
    } 
 
    /**
     * 
     * @return descripcion 
     */
    public String getDescripcion() { 
        return descripcion; 
    } 
 
    /**
     * 
     * @param descripcion 
     */
    public void setDescripcion(String descripcion) { 
        this.descripcion = descripcion; 
    } 
    
}
