/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GrafoMatriz;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author GABRIEL
 */
public class Test {
    
    public static void main(String[] args){
        
        Grafo matriz= new Grafo(5);
        try {
            matriz.insertar(1,0,1);
            matriz.insertar(0,0,2);
            matriz.insertar(1,0,3);
            matriz.insertar(0,0,4);
            matriz.insertar(1,1,0);
            matriz.insertar(1,1,2);
            matriz.insertar(0,1,3);
            matriz.insertar(0,1,4);
            matriz.insertar(0,2,0);
            matriz.insertar(1,2,1);
            matriz.insertar(1,2,3);
            matriz.insertar(0,2,4);
            matriz.insertar(1,3,0);
            matriz.insertar(0,3,1);
            matriz.insertar(2,3,2);
            matriz.insertar(1,3,4);
            matriz.insertar(0,4,0);
            matriz.insertar(0,4,1);
            matriz.insertar(0,4,2);
            matriz.insertar(1,4,3);
        } catch (GrafoException ex) {
            Logger.getLogger(Test.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        System.out.println(matriz.imprimirMatriz());
    }
    
}
