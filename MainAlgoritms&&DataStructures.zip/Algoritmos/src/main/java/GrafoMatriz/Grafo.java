/*
 * Clase que se encarga de guardar en una matriz los nombres de las coordenadas
 */
package GrafoMatriz;

/**
 *
 * @author GABRIEL GUZMAN ALFARO
 * @version 8/07/2021
 */
public class Grafo {

    //Atributos
    private int[][] mapa;
    private Vertice[] vector;
    private int contador = 0;

    /**
     *
     */
    public Grafo() {
    }

    /**
     *
     * @param x
     * @param y
     */
    public Grafo(int n) {
        this.mapa = new int[n][n];
        vector = new Vertice[n];
    }

    /**
     *
     * @param nombre
     * @param x
     * @param y
     */
    public void insertar(int peso, int x, int y) throws GrafoException {

        if (x == y) {

            throw new GrafoException("Las diagonales deben estar vacías");

        } else if (mapa[x][y] != 0) {

            throw new GrafoException("La conexión de nodos ya existe");

        } else {
            mapa[x][y] = peso;
        }

    }

    /**
     *
     * @param x
     * @param y
     */
    public void eliminar(int x, int y) throws GrafoException {

        if (mapa[x][y] == 0) {

            throw new GrafoException(" La arista no existe");

        } else {

            mapa[x][y] = 0;

        }

    }

    /**
     *
     * @return txt
     */
    public String imprimirMatriz() {
        String txt = "x | ";
        for (int i = 0; i < mapa[0].length; i++) {
            txt += i + " | ";
        }
        txt += "\n";
        for (int i = 0; i < mapa.length; i++) {
            txt += i + " ";
            for (int j = 0; j < mapa[i].length; j++) {
                if (i == j) {
                    txt += "| x ";
                } else {
                    txt += "| " + mapa[i][j] + " ";
                }
            }
            txt += "|\n";
        }

        return txt;
    }

    /**
     *
     * @param verticeDeSalida
     */
    public void recorrerEnAnchuraMejorado(int verticeDeSalida) {
        for (int i = 0; i < vector.length; i++) {
            vector[i].setNivel(-1);
        }
        vector[verticeDeSalida].setNivel(0);
        boolean ordenado = false;
        int nivel = 0;
        while (!ordenado) {
            ordenado = true;
            //For que recorre los vertices 
            for (int i = 0; i < vector.length; i++) {
                //Comprueba si el nivel del vertice es igual al i, la i es el numero del nivel que est[a iterando, en la prime iteracion comprueba los niveles 1 
                if (vector[i].getNivel() == nivel) {
                    System.out.println("Se entra al vertice #" + i);
                    //finalmente si result[o que el nivel del vertice es igual al nivel que se esta  
                    //recorriendo entonces se procese a setear los niveles hijos  
                    for (int j = 0; j < mapa[i].length; j++) {
                        System.out.println(mapa[i][j]);
                        if (mapa[i][j] != 0) {
                            if (vector[j].getNivel() == -1) {
                                vector[j].setNivel(nivel + 1);
                            }
                        }
                    }
                    ordenado = false;
                }
            }
            nivel++;

        }
    }

    /**
     *
     * @param nombre
     * @param posicion
     */
    public void insertar(Vertice vertice) {

        vector[contador] = vertice;

        contador++;

    }

    /**
     *
     * @return vector
     */
    public Vertice[] getVector() {
        return vector;
    }

    /**
     *
     * @return texto
     */
    public String imprimirVector() {

        String texto = "";

        for (int i = 0; i < vector.length; i++) {
            texto += i + "-" + vector[i].toString() + ".\n";
        }

        return texto;

    }

}
