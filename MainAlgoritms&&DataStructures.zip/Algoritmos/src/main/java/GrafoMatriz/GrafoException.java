/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GrafoMatriz;

/**
 *
 * @author Gabriel Guzmán Alfaro
 * @version 08/07/2021
 */
public class GrafoException extends Exception {
    
    public GrafoException(String exception){
        super(exception);
    }
    
}
