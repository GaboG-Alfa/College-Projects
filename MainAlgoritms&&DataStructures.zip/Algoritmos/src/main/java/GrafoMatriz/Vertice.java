/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package GrafoMatriz;

/**
 *
 * @author GABRIEL GUZMAN ALFARO
 */
public class Vertice {
    
    //Atributoss
    private String nombre;
    private int nivel;

    /**
     * 
     * @param nombre 
     */
    public Vertice(String nombre) {
        this.nombre=nombre;
        this.nivel=-1;
    }
    
    
    /**
     * 
     * @return nombre 
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * 
     * @param nombre 
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * 
     * @return nivel 
     */
    public int getNivel() {
        return nivel;
    }

    /**
     * 
     * @param nivel 
     */
    public void setNivel(int nivel) {
        this.nivel = nivel;
    }

    @Override
    public String toString() {
        return "Vertice:" + "nombre=" + nombre + ", nivel=" + nivel;
    }
    
}
