/*
 * Clase que expresa el funcionamiento de una contraseña ingresada por el usuario
 */
package Ejercicios;

/**
 *
 * @author Gabriel
 */
public class Contrasenna {

    private String contrasennaClase;

    /**
     * Envia dicha variable
     * @return contrasennaClase
     */
    public String getContrasennaClase() {
        return contrasennaClase;
    }
    /**
     * Valida la contraseña
     * @param contrasenna 
     */
    public void validarContrasenna(String contrasenna) {

        //Variables de validación
        boolean upper = false;
        boolean lower = false;
        boolean number = false;
        boolean symbol = false;

        //Recorre el string que es array de char
        for (int i = 0; i < contrasenna.length(); i++) {

            //valida las mayúsculas
            if (Character.isUpperCase(contrasenna.charAt(i))) {

                upper = true;
            }

            //valida las minúsculas
            if (Character.isLowerCase(contrasenna.charAt(i))) {

                lower = true;
            }

            //valida los números
            if (Character.isDigit(contrasenna.charAt(i))) {

                number = true;
                
            }
            
            //valida los números
               if (!(Character.isAlphabetic(contrasenna.charAt(i))) && !(Character.isDigit(contrasenna.charAt(i))) ) {

                symbol = true;
                
            }
            

        }

        //Excepción si no hay mayúsculas
        if (upper == false) {

            throw new IllegalArgumentException("La contraseña debe tener mínimo una mayúscula");
        }

        //Excepción si no hay minúsculas
        if (lower == false) {

            throw new IllegalArgumentException("La contraseña debe tener mínimo una minuscula");
        }

        //Excepción si no hay números
        if (number == false) {

            throw new IllegalArgumentException("La contraseña debe tener mínimo un número");
        }

        //Excepción si no hay símbolos
        if (symbol == false) {

            throw new IllegalArgumentException("La contraseña debe tener mínimo un símbolo");
        }

        contrasennaClase = contrasenna;
    }

}
