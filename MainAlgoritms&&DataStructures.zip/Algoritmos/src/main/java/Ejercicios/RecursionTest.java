/*
 * La clase recursion test proba múltiples métodos de recursion
 */
package Ejercicios;

/**
 *
 * @author Gabriel Guzmán
 */
public class RecursionTest {

    /**
     * Main
     *
     * @param args
     */
    public static void main(String[] args) {

        //Probar el fibonacci
        int limite;
        limite = 5;

        /*for(int i = 0 ; i < limite; i++){
            System.out.println(fibonacci(i));
        }*/
        //Probar el palindromo
        //System.out.println(palindromoCiclo("hola"));
        
        for(int i = 0; i < 100;i++){
        System.out.println("Número en decimal: "+i+" , Número en binario: "+binarioRecursivo(i));

        }
    }

    /**
     * Hacer fibonacci
     *
     * @param dato
     * @return hilera
     */
    public static int fibonacci(int dato) {

        if (dato == 0 || dato == 1) {
            return dato;
        } else {
            return fibonacci(dato - 1) + fibonacci(dato - 2);
        }
    }

    /**
     * Hacer palindromo
     *
     * @param palabra
     * @return hilera
     */
    public static boolean palindromo(String palabra) {

        if (palabra.length() <= 1) {
            return true;
        }
        if (palabra.charAt(0) != palabra.charAt(palabra.length() - 1)) {
            return false;
        }
        return palindromo(palabra.substring(1, (palabra.length() - 1)));
    }

    /**
     * Hacer palindromo en un ciclo
     *
     * @param dato
     * @return hilera
     */
    public static boolean palindromoCiclo(String palabra) {

        String iteradorLineal = " ";
        String iteradorInverso = " ";

        for (int i = 0; i < palabra.length(); i++) {

            iteradorLineal += palabra.charAt(i);

        }

        for (int j = palabra.length() - 1; j >= 0; j--) {

            iteradorInverso += palabra.charAt(j);

        }

        if (iteradorLineal.equals(iteradorInverso)) {

            return true;
        }

        return false;

    }

    /**
     * Método para obtener un binario de forma recursiva
     *
     * @param binario
     * @return
     */
    public static String binarioRecursivo(int binario) {

        if (binario < 2) {
            return binario+"";
        }

        return binarioRecursivo(binario / 2)+binario%2;

    }

}
