/*
 * Clase que se encarga de guardar información de una persona 
 */
package ArbolBinarioPersonas;

import java.util.Comparator;

/**
 *
 * @author Gabriel
 * @version 31/05/2021
 */
public class Persona implements Comparable<Persona> {

    //Atributos 
    private Integer id;
    private String nombre;
    private Integer edad;
            

    /**
     * Constructor
     */
    public Persona() {
    }

    /**
     * 
     * @param id
     * @param nombre
     * @param edad 
     */
    public Persona(int id, String nombre, int edad) {
        this.id = id;
        this.nombre = nombre;
        this.edad = edad;
    }

    /**
     * 
     * @return edad 
     */
    public int getEdad() {
        return edad;
    }

    /**
     * 
     * @param edad 
     */
    public void setEdad(int edad) {
        this.edad = edad;
    }

    /**
     *
     * @return prioridad
     */
    public Integer getId() {
        return id;
    }

    /**
     *
     * @param prioridad
     */
    public void setId(int id) throws PersonaException {
        
        if(id<0){
            
            throw new PersonaException("La cédula debe ser mayor a 0");
        }
        
        this.id = id;
    }

    /**
     * 
     * @return nombre 
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * 
     * @param nombre 
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
  
    
    @Override
    public String toString() {
        return "Persona: " + "Cedula = " + id + ", Nombre = " + nombre+", Edad="+edad;
    } 

  
        // Overriding the compare method to sort the age
        @Override
    public int compareTo(Persona p) {
            return this.id.compareTo(p.getId());
    }
   
   
}


