package ArbolBinarioPersonas;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Gabriel Guzmán Alfaro
 */
public class ArbolBinario {

    //Attributes
    private Nodo raiz;

    /**
     * Insertar un persona
     *
     * @param persona
     */
    public void insertar(Persona persona) throws ArbolBinarioException {
        raiz = insertar(persona, raiz);
    }

    /**
     * Retornar recursivamente el nodo
     *
     * @param persona
     * @param nodo
     * @return nodo
     */
    private Nodo insertar(Persona persona, Nodo temp) throws ArbolBinarioException {

        if (temp == null) {
            temp = new Nodo(persona);
        } else if (persona.getId().compareTo(temp.getPersona().getId()) < 0) {
            temp.setIzquierda(insertar(persona, temp.getIzquierda()));
        } else if (persona.getId().compareTo(temp.getPersona().getId()) > 0) {
            temp.setDerecha(insertar(persona, temp.getDerecha()));
        } else {
            throw new ArbolBinarioException("persona duplicado");
        }

        return temp;
    }

    /**
     * Recorre en preorden
     */
    public String preOrden() {

        return preOrden(raiz);
    }

    /**
     * Recursión
     *
     * @param nodo
     */
    private String preOrden(Nodo temp) {

        if (temp != null) {
            return temp.getPersona() + "\n" + preOrden(temp.getIzquierda()) + preOrden(temp.getDerecha());
        }

        return "";

    }

    /**
     * Recorre en postorden
     */
    public String postOrden() {

        return postOrden(raiz);
    }

    /**
     * Recursión
     *
     * @param nodo
     */
    private String postOrden(Nodo temp) {

        if (temp != null) {
            return postOrden(temp.getIzquierda()) + postOrden(temp.getDerecha()) + temp.getPersona()+"\n";
        }

        return "";
    }

    /**
     * Recorre en orden
     */
    public String enOrden() {

        return enOrden(raiz);
    }

    /**
     * Recursión
     *
     * @param nodo
     */
    private String enOrden(Nodo temp) {

        if (temp != null) {
            return enOrden(temp.getIzquierda())+ temp.getPersona()+"\n"+enOrden(temp.getDerecha());
        }

        return "";
    }

    /**
     * Find min
     *
     * @return elementAt
     */
    public Persona findMin() {

        return elementAt(findMin(raiz));
    }

    /**
     * Find max
     *
     * @return elemntAt
     */
    public Persona findMax() {

        return elementAt(findMax(raiz));
    }

    /**
     * Recursion del elemento
     *
     * @param nodo
     * @return elementAt
     */
    private Persona elementAt(Nodo temp) {
        return temp == null ? null : temp.getPersona();
    }

    /**
     * Recursion del min
     *
     * @param nodo
     * @return nodo
     */
    private Nodo findMin(Nodo temp) {

        if (temp != null) {
            while (temp.getIzquierda() != null) {
                temp = temp.getIzquierda();
            }
        }

        return temp;
    }

    /**
     * Recursion del max
     *
     * @param nodo
     * @return nodo
     */
    private Nodo findMax(Nodo temp) {

        if (temp != null) {
            while (temp.getDerecha() != null) {
                temp = temp.getDerecha();
            }
        }

        return temp;
    }

    /**
     * Imprime el persona
     *
     * @param persona
     */
    private void imprimir(Persona persona) {

        System.out.println("persona: " + persona);
    }

    /**
     * Busca un persona y retorna el nodo
     *
     * @param persona
     * @param nodo
     * @return nodo
     */
    private Nodo find(Integer dato, Nodo temp) throws ArbolBinarioException {

        while (temp != null) {

            if (dato.compareTo(temp.getPersona().getId()) < 0) {
                temp = temp.getIzquierda();
            } else if (dato.compareTo(temp.getPersona().getId()) > 0) {
                temp = temp.getDerecha();
            } else {
                return temp;
            }
        }

        return null;
    }

    /**
     * Find a data
     *
     * @param persona
     * @return
     * @throws ArbolBinarioException
     */
    public Persona find(Integer dato) throws ArbolBinarioException {
        return elementAt(find(dato, raiz));
    }

    /**
     * removeMin
     *
     * @param temp
     * @return temp
     * @throws ArbolBinarioException
     */
    private Nodo removeMin(Nodo temp) throws ArbolBinarioException {

        if (temp == null) {
            throw new ArbolBinarioException("Item no encontrado");
        } else if (temp.getIzquierda() != null) {
            temp.setIzquierda(removeMin(temp.getIzquierda()));
            return temp;
        } else {
            return temp.getDerecha();
        }
    }

    /**
     *
     * @return raiz
     */
    public Nodo removeMin() throws ArbolBinarioException {
        return raiz = removeMin(raiz);
    }

    /**
     * remove
     *
     * @param persona
     * @param temp
     * @return
     * @throws ArbolBinarioException
     */
    private Nodo remove(Integer id, Nodo temp) throws ArbolBinarioException {

        if (temp == null) {
            throw new ArbolBinarioException("Item no encontrado");
        }

        if (id.compareTo(temp.getPersona().getId()) < 0) {
            temp.setIzquierda(remove(id, temp.getIzquierda()));
        } else if (id.compareTo(temp.getPersona().getId()) > 0) {
            temp.setDerecha(remove(id, temp.getDerecha()));
        } else if (temp.getIzquierda() != null && temp.getDerecha() != null) {
            temp.setPersona(findMin(temp.getDerecha()).getPersona());
            temp.setDerecha(removeMin(temp.getDerecha()));
        } else {
            temp = (temp.getIzquierda() != null) ? temp.getIzquierda() : temp.getDerecha();
        }

        return temp;
    }

    /**
     * remove
     *
     * @param persona
     * @throws ArbolBinarioException
     */
    public void remove(Integer dato) throws ArbolBinarioException {
        raiz = remove(dato, raiz);
    }
}
