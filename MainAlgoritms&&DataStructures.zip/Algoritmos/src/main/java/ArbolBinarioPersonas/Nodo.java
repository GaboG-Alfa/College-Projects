/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ArbolBinarioPersonas;


/**
 *
 * @author Gabriel Guzmán Alfaro
 * @version 10/06/2021
 */
public class Nodo {
    
    //Atributo
    private Persona persona;
    private Nodo izquierda;
    private Nodo derecha;

    /**
     * 
     * @param persona 
     */
    public Nodo(Persona persona) {
        this.persona = persona;
    }
    
    
    /**
     * 
     * @return persona 
     */
    public Persona getPersona() {
        return persona;
    }

    /**
     * 
     * @param persona 
     */
    public void setPersona(Persona persona) {
        this.persona = persona;
    }

    /**
     * 
     * @return izquierda 
     */
    public Nodo getIzquierda() {
        return izquierda;
    }

    /**
     * 
     * @param izquierda 
     */
    public void setIzquierda(Nodo izquierda) {
        this.izquierda = izquierda;
    }

    /**
     * 
     * @return derecha 
     */
    public Nodo getDerecha() {
        return derecha;
    }

    /**
     * 
     * @param derecha 
     */
    public void setDerecha(Nodo derecha) {
        this.derecha = derecha;
    }
    
}
