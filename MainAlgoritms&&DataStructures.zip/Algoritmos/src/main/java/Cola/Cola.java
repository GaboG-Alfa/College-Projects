package Cola;

/**
 * 
 * @author Gabriel Guzmán Alfaro
 * @version 20/05/2021 
 */
public class Cola {
    
    //Atributo
    Nodo front, reer;
    int size;
    int max;
    
    /**
     * Constructor
     * @param tamano 
     */
    public Cola(int capacidadMax) throws ColaException {
        
        if(size<0){
            throw new ColaException("El tamaño ingresado es menor a 0");
        }
        front = reer = null;
        size = 0;
        this.max = max;
    }
    
    /**
     * 
     * @return primero
     */
    public boolean isEmpty() {
        return front == null;
    }
    
    /**
     * Inserta el dato
     * @param dato 
     */
    public void enqueue(char dato) throws ColaException {
        
        if(max == size && max > 0){
            throw new ColaException("La cola está llena");
        }
        
        Nodo nuevo = new Nodo();
        nuevo.setDato(dato);
        if (front==null) {
            
            front = nuevo;
            
        } else {
            reer.setSiguiente(nuevo);
        }
        reer = nuevo;
        size++;
    }
    
    /**
     * Extrae el primer elemento
     * @return tmp
     */
    public char dequeue() throws ColaException {
        
        if(front==null){
            throw new ColaException("La cola está vacía");
        }
        
        char tmp = front.getDato();
        front = front.getSiguiente();
        
        
        size--;
        return tmp;
        
    }
    
    /**
     * 
     * @return primero.getDato()
     */
    public char front() throws ColaException {
        
        if(front==null){
            throw new ColaException("La cola está vacía");
        }
        
        return front.getDato();
        
    }
    
    /**
     * Retorna el tamaño de la cola
     * @return tamano 
     */
    public int size() {
        return size;
        
    }
    
    /**
     * 
     * @return chars concatenados 
     */
    public String imprimir(){
        
        String txt = "------>";
                
        for (Nodo temp = front; temp != null; temp = temp.getSiguiente()) {

            txt += " " + temp.getDato();
        }
        
        return txt ;
    }
}
