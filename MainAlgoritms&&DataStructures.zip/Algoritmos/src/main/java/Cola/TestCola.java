/*
 * Clase que se encarga de probar la cola
 */
package Cola;

/**
 *
 * @author Gabriel Guzmán Alfaro
 */
public class TestCola {
    
    /**
     * 
     * @param args 
     */
    public static void main(String[] args){
        
        try {
            Cola cola = new Cola(7);
            cola.enqueue('G');
            cola.enqueue('A');
            cola.enqueue('B');
            cola.enqueue('R');
            cola.enqueue('I');
            cola.enqueue('E');
            cola.enqueue('L');
            System.out.println(cola.imprimir());
            System.out.println(cola.front());
            cola.dequeue();
            System.out.println(cola.imprimir());
            System.out.println(cola.front());
        } catch (ColaException ex) {
            System.out.println("Error:"+ex);
        }
                      
        
        
    }
    
}
