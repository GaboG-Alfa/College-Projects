/*
 * Clase que lanza excepciones a la cola
 */
package Cola;

/**
 *
 * @author Gabriel Guzmán Alfaro
 */
public class ColaException extends Exception {
    
    public ColaException(String exception){
        super(exception);
    }
}
