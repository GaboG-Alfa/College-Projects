/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ListaEnlazadaDobleCircular;

/**
 *
 * @author Gabriel Guzmán Alfaro
 */
public class ListaDobleCircular {

    private Nodo primero;
    private Nodo ultimo;

    /**
     * Agregar nodo al inicio de la lista
     *
     * @param dato
     */
    public boolean insertarInicio(int dato) {

        //Por punteros
        Nodo nuevo = new Nodo();

        nuevo.setDato(dato);

        if (primero == null) {

            primero = ultimo = nuevo;
            primero.setAnterior(ultimo);
            ultimo.setSiguiente(primero);
            return true;
        }

        nuevo.setSiguiente(primero);

        nuevo.setAnterior(ultimo);
        
        primero.setAnterior(nuevo);

        primero = nuevo;
        
        ultimo.setSiguiente(primero);

        return true;
    }

    /**
     * Agregar nodo al final de la lista con punteros
     *
     * @param dato
     */
    public boolean insertarFinal(int dato) {

        //Por punteros
        Nodo nuevo = new Nodo();

        nuevo.setDato(dato);

        if (ultimo == null) {

            primero = ultimo = nuevo;
            primero.setAnterior(ultimo);
            ultimo.setSiguiente(primero);
            return true;

        }

        ultimo.setSiguiente(nuevo);
        nuevo.setAnterior(ultimo);
        ultimo = nuevo;
       
        ultimo.setSiguiente(primero);
        
        primero.setAnterior(ultimo);
        
        return true;
    }

    /**
     * Eliminar un nodo al inicio
     *
     * @return boolean
     */
    public boolean eliminarInicio() {

        if (primero == null) {

            return false;
        }

        if (primero == ultimo) {
            primero = ultimo = null;
            return true;
        } else {

            primero = primero.getSiguiente();

            primero.setAnterior(ultimo);
            
            ultimo.setSiguiente(primero);

            return true;
        }

    }

    /**
     * Eliminar un nodo al final
     *
     * @return boolean
     */
    public boolean eliminarFinal() {

        if (ultimo == null) {
            return false;
        }
        if (primero == ultimo) {
            primero = ultimo = null;

            return true;

        } else {

            ultimo = ultimo.getAnterior();
             
            ultimo.setSiguiente(primero);

            primero.setAnterior(ultimo);
            
            return true;
        }

    }

    /**
     * Elimina un elemento por dato
     *
     * @param dato
     * @return boolean
     */
    public boolean eliminarDato(int dato) {

        if (primero == null) {

            return false;

        }

        if (primero.getDato() == dato) {

            this.eliminarInicio();

            return true;

        } else if (ultimo.getDato() == dato) {

            this.eliminarFinal();

            return true;

        } else {

            Nodo temp;

            temp = primero.getSiguiente();

            while (temp.getSiguiente() != primero) {

                if (temp.getDato() == dato) {

                    temp.getAnterior().setSiguiente(temp.getSiguiente());
                    temp.getSiguiente().setAnterior(temp.getAnterior());

                    return true;
                }

                temp = temp.getSiguiente();
            }

            return true;
        }
    }

    /**
     * Agregar nodo al final de la lista con punteros
     *
     * @param dato
     */
    public boolean insertarDespues(int predecesor, int dato) {

        //Por punteros
        Nodo nuevo = new Nodo();

        nuevo.setDato(dato);

        if (primero == null) {
            return false;
        }

        if (ultimo.getDato() == predecesor) {
            this.insertarFinal(dato);

            return true;
        }

        for (Nodo temp = primero; temp != ultimo; temp = temp.getSiguiente()) {

            if (temp.getDato() == predecesor) {

                nuevo.setSiguiente(temp.getSiguiente());
                nuevo.setAnterior(temp);
                temp.setSiguiente(nuevo);
                nuevo.getSiguiente().setAnterior(nuevo);
                
                return true;

            }

        }
    
        return true;
    }

    /**
     *
     * @return hilera
     */
    public String imprimirPrimeroUltimo() {

        Nodo temp = new Nodo();
        
        temp = primero;
        
        String texto = "-> ";
        
        do{
            
            texto+=temp.getDato()+" ";
            
            temp= temp.getSiguiente();
                    
        }while(temp!=primero);

        return texto;
    }

    /**
     *
     * @return hilera
     */
    public String imprimirUltimoPrimero() {

        Nodo temp = new Nodo();
        
        temp = ultimo;
        
        String texto = "-> ";
        
        do{
            
            texto+=temp.getDato()+" ";
            
            temp= temp.getAnterior();
                    
        }while(temp!=ultimo);

        return texto;
    }

}
