/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ListaEnlazadaDoble;

/**
 *
 * @author Gabriel Guzmán
 * @version 10/05/2021
 */
public class ListaDobleTest {
    
    public static void main(String[] args){
        
        ListaDoble lista = new ListaDoble();
        
       /* lista.insertarInicio(1);
        lista.insertarInicio(2);
        lista.insertarInicio(3);
        lista.insertarInicio(4);
        */        
        
        lista.insertarFinal(1);
        lista.insertarFinal(2);
        lista.insertarFinal(3);
        lista.insertarFinal(4);
       
     
        //lista.eliminarDato(2);
        
        lista.insertarDespues(2, 8);
        
        
        System.out.println("De primero a ultimo: "+lista.imprimirPrimeroUltimo());
        System.out.println("De ultimo a primero: "+lista.imprimirUltimoPrimero());
        
    }
    
}
