/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Pila;

/**
 *
 * @author Gabriel Guzmán
 * @version 07/06/2021
 */
public class MenuConsola {
    
    /**
     * 
     * @param args 
     */
    public static void main(String[] args){
        
        Pila pila = new Pila();
        
        try {
            pila = new Pila(5);
        } catch (PilaException ex) {
            System.out.println("Error: "+ex.getMessage());
        }
        
        try {
            pila.push(1);
        } catch (PilaException ex) {
            System.out.println("Error: "+ex.getMessage());
        }
        
        try {
            pila.push(2);
        } catch (PilaException ex) {
            System.out.println("Error: "+ex.getMessage());
        }
        
        try {
            pila.push(3);
        } catch (PilaException ex) {
            System.out.println("Error: "+ex.getMessage());
        }
        
        try {
            pila.push(4);
        } catch (PilaException ex) {
            System.out.println("Error: "+ex.getMessage());
        }
        
        System.out.println(pila.imprimir());
        
        System.out.println("Size: "+pila.size());
        
        try {
            System.out.println("Top: "+pila.top());
        } catch (PilaException ex) {
            System.out.println("Error: "+ex.getMessage());
        }
        
        System.out.println("Pila después del top: "+pila.imprimir());
        
        try {
            System.out.println("Pop: "+pila.pop());
        } catch (PilaException ex) {
            System.out.println("Error: "+ex.getMessage());
        }
        
        System.out.println("Pila después del pop: "+pila.imprimir());
        
        System.out.println("Está vacía? : "+pila.isEmpty());
        
        System.out.println("Search: "+pila.search(3));
           
        
    }
    
}
