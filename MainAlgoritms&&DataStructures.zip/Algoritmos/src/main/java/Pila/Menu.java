package Pila;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import java.awt.FlowLayout;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

/**
 * 
 * @author Gabriel Gzumán Alfaro
 * @version 7/06/2021
 */
public class Menu extends JFrame {

    private JLabel datoL; // Label para menu
    private JTextField dato;
    private Pila pila;
    private String tamanno, buscar;
    private JButton opcionA, opcionB, opcionC, opcionD, opcionE, opcionF, opcionG, exit; // Botones de mostrar y salir

    /*
    * Clase an�nima para listener, enlace:
    * 
    * http://chuwiki.chuidiang.org/index.php?title=ActionListener#:~:text=%
    * 20ActionListener%20%201%20Los%20ActionListener.%20Los%20componentes,%20...%
    * 20Este%20m%C3%A9todo%20sigue%20presentando...%20More%20
    * 
     */
    public Menu() {
        super("Pila de datos");

        setLayout(new FlowLayout(FlowLayout.LEFT, 5, 10));

        // Declaramos los objetos que estaran dentro del JFrame
        datoL = new JLabel("Ingresar el dato");
        dato = new JTextField(10);
        opcionA = new JButton("Obtener tamaño de pila");
        opcionB = new JButton("Verificar si la pila está vacía");
        opcionC = new JButton("Top");
        opcionD = new JButton("Push");
        opcionE = new JButton("Pop");
        opcionF = new JButton("Buscar dato");
        opcionG = new JButton("Imprimir");

        exit = new JButton("Salir");

        // Agregamos los objetos en el orden deseado al JFrame
        add(datoL);
        add(dato);
        add(opcionA);
        add(opcionB);
        add(opcionC);
        add(opcionD);
        add(opcionE);
        add(opcionF);
        add(opcionG);
        add(exit);

        //Instanciar pila
        tamanno = JOptionPane.showInputDialog(null, "Ingrese el tamaño de la pila:", "Excepción",
                JOptionPane.INFORMATION_MESSAGE);

        try {

            pila = new Pila(Integer.parseInt(tamanno));
            // pila = new Pila(Integer.parseInt(tamanno.getText()));
        } catch (PilaException ex) {
            JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage(), "Excepción",
                    JOptionPane.INFORMATION_MESSAGE);
        }

        // Programamos los Listener de cada Boton
        opcionA.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent evento) {

                JOptionPane.showMessageDialog(null, "Tamaño de la pila: " + pila.size(), "Tamaño de la lista",
                        JOptionPane.INFORMATION_MESSAGE);

            }

        });

        opcionB.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evento) {

                JOptionPane.showMessageDialog(null, "Estado de la pila: " + pila.isEmpty(), "Tamaño de la lista",
                        JOptionPane.INFORMATION_MESSAGE);
            }
        });

        opcionC.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evento) {

                try {
                    JOptionPane.showMessageDialog(null, "Estado de la pila: " + pila.top(), "Tamaño de la lista",
                            JOptionPane.INFORMATION_MESSAGE);
                } catch (PilaException ex) {
                    JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage(), "Excepción",
                            JOptionPane.INFORMATION_MESSAGE);
                }

            }
        });

        opcionD.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evento) {

                try {
                    JOptionPane.showMessageDialog(null, "Push: " + pila.push(Integer.parseInt(dato.getText())), "Push dato",
                            JOptionPane.INFORMATION_MESSAGE);
                } catch (PilaException ex) {
                    JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage(), "Excepción",
                            JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });

        opcionE.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evento) {

                try {
                    JOptionPane.showMessageDialog(null, "Pop: " + pila.pop(), "Pop dato",
                            JOptionPane.INFORMATION_MESSAGE);
                } catch (PilaException ex) {
                    JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage(), "Excepción",
                            JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });

        opcionF.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evento) {

                buscar = JOptionPane.showInputDialog(null, "Ingrese el dato a buscar", "Buscar dato",
                        JOptionPane.INFORMATION_MESSAGE);

                JOptionPane.showMessageDialog(null, "Buscar: " + pila.search(Integer.parseInt(buscar)), "Resultados de búsqueda",
                        JOptionPane.INFORMATION_MESSAGE);
            }
        });

        opcionG.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evento) {

                JOptionPane.showMessageDialog(null, "Imprimir: " + pila.imprimir(), "Buscar dato",
                        JOptionPane.INFORMATION_MESSAGE);
            }
        });

        exit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent evento) {
                JOptionPane.showMessageDialog(null, "Saldra de la aplicacion", "WARNING", JOptionPane.WARNING_MESSAGE);
                System.exit(0);
            }
        });

    }

    // Metodo main()
    public static void main(String args[]) {
        Menu listen = new Menu();
        listen.setLocationRelativeTo(null);
        listen.setSize(300, 175);
        listen.setVisible(true);
    }

}
