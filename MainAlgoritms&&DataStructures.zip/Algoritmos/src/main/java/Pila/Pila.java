/*
 * Clase con estructura de pila
 */
package Pila;

/**
 *
 * @author Gabriel Guzmán Alfaro
 * @version 07/06/2021
 */
public class Pila {

    //Atributo
    private Nodo cima;
    private int capacidadMax;
    private int cantidadElementos;

    /**
     * Constructor
     */
    public Pila() {
    }

    /**
     * 
     * @param capacidadMax
     * @throws PilaException 
     */
    public Pila(int capacidadMax) throws PilaException {

        if (capacidadMax < 0) {
            throw new PilaException("La pila no puede tener una capacidad máxima inferior a 0");
        }

        this.capacidadMax = capacidadMax;

        cantidadElementos = 0;
        cima = null;
    }

    /**
     * 
     * @return cantidadElementos 
     */
    public int size() {
        return cantidadElementos;
    }

    /**
     * 
     * @param dato
     * @return
     * @throws PilaException 
     */
    public int push(int dato) throws PilaException {

        if (capacidadMax != 0 && cantidadElementos == capacidadMax) {
            throw new PilaException("La pila está llena");
        }

        Nodo nuevo = new Nodo();
        nuevo.setDato(dato);
        nuevo.setSiguiente(cima);
        cima = nuevo;
        cantidadElementos++;

        return dato;
    }

    /**
     * 
     * @return tmp
     * @throws PilaException 
     */
    public int pop() throws PilaException {

        if (cima == null) {
            throw new PilaException("La pila no puede estar vacía");
        }

        int tmp = cima.getDato();
        cima = cima.getSiguiente();
        cantidadElementos--;

        return tmp;
    }

    /**
     * 
     * @return cima.getDato()
     * @throws PilaException 
     */
    public int top() throws PilaException {

        if (cima == null) {
            throw new PilaException("La pila no puede estar vacía");
        }

        return cima.getDato();

    }

    /**
     * 
     * @return cima
     */
    public boolean isEmpty() {

        return cima == null;
    }

    /**
     * 
     * @param dato
     * @return -1 
     */
    public int search(int dato) {

        Nodo temp;

        for (temp = cima; temp != null; temp = temp.getSiguiente()) {

            if (dato == cima.getDato()) {

                return cima.getDato();
            }

        }

        return -1;
    }

    /**
     * 
     * @return texto 
     */
    public String imprimir() {

        String texto = "Datos de la pila: ";

        Nodo temp;

        for (temp = cima; temp != null; temp = temp.getSiguiente()) {

            texto += temp.getDato() + ",";
        }

        return texto;

    }

}
