package Pila;

/**
 *
 * @author Gabriel Guzmán
 * @version 7/06/2021
 */
public class PilaException extends Exception {
    
    public PilaException(String exception){
        super(exception);
    }
}
