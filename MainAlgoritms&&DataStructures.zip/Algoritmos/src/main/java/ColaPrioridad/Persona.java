/*
 * Clase que se encarga de guardar información de una persona 
 */
package ColaPrioridad;

/**
 *
 * @author Gabriel
 * @version 31/05/2021
 */
public class Persona {

    //Atributos 
    private int prioridad;
    private String nombre;

    /**
     * Constructor
     */
    public Persona() {
    }

    /**
     * Constructor
     * @param prioridad
     * @param nombre
     */
    public Persona(int prioridad, String nombre) throws PersonaException {
        setPrioridad(prioridad);
        setNombre(nombre);
    }

    /**
     *
     * @return prioridad
     */
    public int getPrioridad() {
        return prioridad;
    }

    /**
     *
     * @param prioridad
     */
    public void setPrioridad(int prioridad) throws PersonaException {
        
        if(prioridad<0){
            
            throw new PersonaException("La cédula debe ser mayor a 0");
        }
        
        this.prioridad = prioridad;
    }

    /**
     * 
     * @return nombre 
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * 
     * @param nombre 
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    @Override
    public String toString() {
        return "Persona: " + "Prioridad = " + prioridad + ", nombre = " + nombre;
    } 

}


