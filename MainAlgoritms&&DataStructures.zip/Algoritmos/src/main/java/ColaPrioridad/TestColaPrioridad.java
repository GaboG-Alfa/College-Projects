/*
 * Clase que se encarga de probar la cola
 */
package ColaPrioridad;

/**
 *
 * @author Gabriel Guzmán Alfaro
 * @version 31/05/2021
 */
public class TestColaPrioridad {
    
    /**
     * 
     * @param args 
     */
    public static void main(String[] args){
        
        try {
            
            Persona juan = new Persona(4,"Juan");
            Persona rosa = new Persona(3,"Rosa");
            Persona marta = new Persona(9,"Juan");
            Persona luis = new Persona(10,"Rosa");
            Persona pedro = new Persona(1,"Rosa");
            
            try {
                ColaPrioridad cola = new ColaPrioridad(5);
                cola.enqueue(juan);
                cola.enqueue(rosa);
                cola.enqueue(marta);
                cola.enqueue(luis);
                cola.enqueue(pedro);
                cola.ordenarPrioridad();
                System.out.println(cola.imprimir());
                System.out.println(cola.front());
                cola.dequeue();
                System.out.println(cola.imprimir());
                System.out.println(cola.front());
                
            } catch (ColaPrioridadException ex) {
                System.out.println("Error:"+ex);
            }
            
            
            
        } catch (PersonaException ex) {
            System.out.println("Error "+ex);
        }
                      
        
        
    }
    
}
