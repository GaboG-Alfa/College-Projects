/*
 * La clase que se encarga de guaradar un nodo con atributo de persona
 */
package ColaPrioridad;

/**
 *
 * @author Gabriel Guzmán Alfaro
 */
public class Nodo {
    
    //Atributo
    private Persona persona;
    private Nodo siguiente;

    /**
     * 
     * @return persona 
     */
    public Persona getPersona() {
        return persona;
    }

    /**
     * 
     * @param persona 
     */
    public void setPersona(Persona persona) {
        this.persona = persona;
    }

    /**
     * 
     * @return siguiente 
     */
    public Nodo getSiguiente() {
        return siguiente;
    }

    /**
     * 
     * @param siguiente 
     */
    public void setSiguiente(Nodo siguiente) {
        this.siguiente = siguiente;
    }
    
}
