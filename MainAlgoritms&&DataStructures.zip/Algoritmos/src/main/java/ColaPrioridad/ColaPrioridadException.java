/*
 * Clase que lanza excepciones a la cola
 */
package ColaPrioridad;

/**
 *
 * @author Gabriel Guzmán Alfaro
 */
public class ColaPrioridadException extends Exception {
    
    public ColaPrioridadException(String exception){
        super(exception);
    }
}
