/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ListaEnlazadaSimpleCircular;

/**
 *
 * @author Gabriel Guzmán Alfaro
 */
public class ListaSimpleCircularTest {

    /**
     * 
     * @param args 
     */
    public static void main(String[] args) {

        ListaSimpleCircular lista = new ListaSimpleCircular();
        
        lista.insertarFinal(1);
        lista.insertarFinal(2);
        lista.insertarFinal(3);
        lista.insertarFinal(4);
        
        lista.eliminarFinal();
        
        System.out.println("Lista circular: "+lista.imprimir());
    }

}
