/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ListaEnlazadaSimpleCircular;

import Pila.Nodo;

/**
 *
 * @author Gabriel Guzmán Alfaro
 * @version 07/06/2021
 */
public class ListaSimpleCircular {

    //Atributes
    private Nodo primero;
    private Nodo ultimo;

    /**
     * Agregar nodo al inicio de la lista circular
     *
     * @param dato
     */
    public boolean insertarInicio(int dato) {

        Nodo nuevo = new Nodo();

        nuevo.setDato(dato);

        if (primero == null) {
            primero = ultimo = nuevo;
            ultimo.setSiguiente(primero);
            return true;
        }
        nuevo.setSiguiente(primero);
        primero = nuevo;
        ultimo.setSiguiente(primero);

        return true;
    }

    /**
     * Agregar nodo al final de la lista circular
     *
     * @param dato
     */
    public boolean insertarFinal(int dato) {

        Nodo nuevo = new Nodo();

        nuevo.setDato(dato);

        if (primero == null) {
            primero = ultimo = nuevo;
            ultimo.setSiguiente(primero);
            
            return true;
            
        } else {

            ultimo.setSiguiente(nuevo);
            nuevo.setSiguiente(primero);
            ultimo = nuevo;
            
            return true;
        }
        
    }

    /**
     * Eliminar un nodo al inicio
     *
     * @return boolean
     */
    public boolean eliminarInicio() {

        if (primero == null) {

            return false;
        }

        if (primero == ultimo) {
            primero = ultimo = null;
            
             return true;
            
        } else {
             
            Nodo temp;
            
            temp = primero.getSiguiente();
            
            ultimo.setSiguiente(temp);
            
            primero = temp;
            
             return true;
        }

    }

    /**
     * Eliminar un nodo al final
     *
     * @return boolean
     */
    public boolean eliminarFinal() {

        if (ultimo == null) {
            return false;
        }
        if (ultimo==primero) {
            primero = ultimo = null;
            
            return true;
            
        } else {

            Nodo temp;
            
            temp = primero;

            while (temp.getSiguiente() != ultimo){
                
                temp = temp.getSiguiente();
            }
          
            temp.setSiguiente(primero);
                      
            ultimo = temp;
            
            
        }
        return true;

    }
   
    /**
     * 
     * @return texto 
     */
    public String imprimir(){
        
        Nodo temp = new Nodo();
        
        temp = primero;
        
        String texto = "-> ";
        
        do{
            
            texto+=temp.getDato()+" ";
            
            temp= temp.getSiguiente();
                    
        }while(temp!=primero);
        
        return texto;
    }

       /*
    public String imprimirRecursivo() {
        if (primero == null) {
            return "No existe ningun dato";
        }
        return primero.getDato() + imprimirRecursivo(primero.getSiguiente());
    }

    private String imprimirRecursivo(Nodo temp) {
        if (temp == primero) {
            return "";
        }
        return "->" + temp.getDato() + imprimirRecursivo(temp.getSiguiente());
    }*/
}
