/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ArbolBinario;

/**
 *
 * @author Gabriel Guzmán Alfaro
 */
public class ArbolBinarioTest {
    
    /**
     * 
     * @param args 
     */
    public static void main(String[] args){
        
        try {
            ArbolBinario arbol=new ArbolBinario();
            
            arbol.insertar(8);
            arbol.insertar(5);
            arbol.insertar(6);
            arbol.insertar(9);
            arbol.insertar(10);
            arbol.insertar(20);
            System.out.println("Arbol creado");
            System.out.println("\n\nPreOrden");
            arbol.preOrden();
            System.out.println("\n\nPostOrden");
            arbol.postOrden();
            System.out.println("\n\nEnOrden");
            arbol.enOrden();
            System.out.println("\n\nElementos máximos y mínimos");
            System.out.println("Min "+arbol.findMin());
            System.out.println("Max "+arbol.findMax());
            System.out.println("\n\nBuscar elemento");
            System.out.println("Buscar: "+arbol.find(43));
            //System.out.println("\n\nRemover el min");
            //arbol.removeMin();
            System.out.println("\n\nPreOrden");
            arbol.preOrden();
            System.out.println("\n\nPostOrden");
            arbol.postOrden();
            System.out.println("\n\nEnOrden");
            arbol.enOrden();
            System.out.println("\n\nRemover nodo ");
            arbol.remove(10);
            System.out.println("\n\nPreOrden");
            arbol.preOrden();
            System.out.println("\n\nPostOrden");
            arbol.postOrden();
            System.out.println("\n\nEnOrden");
            arbol.enOrden();
        } catch (ArbolBinarioException ex) {
            System.out.println("Error: "+ex);
        }
    }
    
}
