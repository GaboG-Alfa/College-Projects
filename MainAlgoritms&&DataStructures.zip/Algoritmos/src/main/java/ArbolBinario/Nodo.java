/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ArbolBinario;

import ArbolesNodo.*;

/**
 *
 * @author Gabriel Guzmán Alfaro
 * @version 10/06/2021
 */
public class Nodo {
    
    //Atributo
    private Integer dato;
    private Nodo izquierda;
    private Nodo derecha;

    /**
     * 
     * @param dato 
     */
    public Nodo(Integer dato) {
        this.dato = dato;
    }
    
    
    /**
     * 
     * @return dato 
     */
    public Integer getDato() {
        return dato;
    }

    /**
     * 
     * @param dato 
     */
    public void setDato(Integer dato) {
        this.dato = dato;
    }

    /**
     * 
     * @return izquierda 
     */
    public Nodo getIzquierda() {
        return izquierda;
    }

    /**
     * 
     * @param izquierda 
     */
    public void setIzquierda(Nodo izquierda) {
        this.izquierda = izquierda;
    }

    /**
     * 
     * @return derecha 
     */
    public Nodo getDerecha() {
        return derecha;
    }

    /**
     * 
     * @param derecha 
     */
    public void setDerecha(Nodo derecha) {
        this.derecha = derecha;
    }
    
}
