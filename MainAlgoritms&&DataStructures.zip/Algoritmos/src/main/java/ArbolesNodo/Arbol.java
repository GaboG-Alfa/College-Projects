/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ArbolesNodo;

/**
 *
 * @author Gabriel Guzmán Alfaro
 * @version 10/06/2021
 */
public class Arbol {
    
    //Atributo
    private Nodo raiz;
    
    
    public Arbol(){
       raiz = new Nodo(15);
       raiz.setIzquierda(new Nodo(25));
       raiz.setDerecha(new Nodo(20));
       raiz.getDerecha().setIzquierda(new Nodo(10));
       
       Nodo temp = raiz;
       temp= temp.getDerecha();
       temp.setDerecha(new Nodo(5));
       temp.setIzquierda(new Nodo(10));
       temp= temp.getDerecha();
       temp.setIzquierda(new Nodo(45));
    }
    
    /**
     *Recorre en preorden 
     */
    public void preOrden(){
        
        preOrden(raiz);
    }
    
    /**
     * Recursión
     * @param nodo 
     */
    private void preOrden(Nodo nodo){
        
        if(nodo!=null){
        imprimir(nodo.getDato());    
        preOrden(nodo.getIzquierda());
        preOrden(nodo.getDerecha());
        }
        
    }
    
    /**
     *Recorre en postorden 
     */
    public void postOrden(){
        
        postOrden(raiz);
    }
    
    /**
     * Recursión
     * @param nodo 
     */
    private void postOrden(Nodo nodo){
        
        if(nodo!=null){    
        postOrden(nodo.getIzquierda());
        postOrden(nodo.getDerecha());
        imprimir(nodo.getDato());
        }
        
    }
    
    /**
     *Recorre en orden 
     */
    public void enOrden(){
        
        enOrden(raiz);
    }
    
    /**
     * Recursión
     * @param nodo 
     */
    private void enOrden(Nodo nodo){
        
        if(nodo!=null){    
        postOrden(nodo.getIzquierda());
        imprimir(nodo.getDato());
        postOrden(nodo.getDerecha());
        }
        
    }
    
    /**
     * Imprime el dato
     * @param dato 
     */
    private void imprimir(Integer dato){
        
        System.out.println("Dato: "+dato);
    }
    
}
