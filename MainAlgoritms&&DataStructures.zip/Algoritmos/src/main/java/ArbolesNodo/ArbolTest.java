/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ArbolesNodo;

/**
 *
 * @author Gabriel Guzmán Alfaro
 */
public class ArbolTest {
    
    public static void main(String[] args){
        
        Arbol arbol=new Arbol();
        
        System.out.println("Arbol creado");
        System.out.println("\n\nPreOrden");
        arbol.preOrden();
        System.out.println("\n\nPostOrden");
        arbol.postOrden();
        System.out.println("\n\nEnOrden");
        arbol.enOrden();
    }
}
