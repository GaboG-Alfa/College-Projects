/*
 * Class with test of matrix tree 
 */
package Arboles.BinaryMatriz;

/**
 *
 * @author Gabriel Guzmán Alfaro 
 * @version 03/06/2021
 */
public class BinaryTreeMatrixTest {
    
    /**
     * 
     * @param args 
     */
    public static void main(String[] args){
        
        BinaryMatrixTree tree = new BinaryMatrixTree(5);
        
        tree.insertRoot(5);
        
        /*
        System.out.println(tree.insertLeft(5, 7));
        System.out.println(tree.insertLeft(7, 4));
        System.out.println(tree.insertRight(7, 3));
        System.out.println(tree.insertRight(5, 9));
        System.out.println(tree.insertRight(3, 1));
*/
        System.out.println(tree.insertar(5, 7, 'I'));
        System.out.println(tree.insertar(3, 2, 'I'));
        System.out.println(tree.insertar(9, 2, 'D'));
      
        
        System.out.println(tree.printMatrix());
        System.out.println(tree.printLeaves());
        
    }
    
}
