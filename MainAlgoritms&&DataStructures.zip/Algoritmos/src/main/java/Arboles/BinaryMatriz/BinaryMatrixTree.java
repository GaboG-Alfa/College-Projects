/*
 *Class with matrix tree
 */
package Arboles.BinaryMatriz;

/**
 *
 * @author Gabriel Guzmán Alfaro
 * @version 03/06/2021
 */
public class BinaryMatrixTree {

    //Atributtes
    private int[][] matrixTree;
    
    /**
     * 
     * @param n 
     */
    public BinaryMatrixTree(int maxNodes) {
        
        matrixTree= new int[3][maxNodes];
        
        
    }
    
    /**
     * 
     * @param root 
     */
    public void insertRoot(int root){
        matrixTree[0][0]= root;
    }
    
    /**
     * 
     * @param key
     * @return -1 
     */
    public int exist(int key){
        
        for(int cont=0; cont < matrixTree[0].length;cont++){
            
            if(matrixTree[0][cont]== key){
                
                return cont;
            }
            
        }
        
        return -1;
    }
    
    public boolean insertar(int father, int son, int location){
        
        int colsFather=0;
        int colsSon=0;
        
        for(int cont=0 ; cont < matrixTree[0].length;cont++){
            
            if(matrixTree[0][cont]== father){
                colsFather=cont;
            }
            
            if(matrixTree[0][cont] == 0){
                
                colsSon=cont;
            }
            
            if(matrixTree[0][cont]==son){
                return false;
            }
        }
        
        if((colsFather==-1)||(colsSon==-1)){
            
            return false;
        }
        
        if(location=='I'){
            
            if(matrixTree[1][colsFather] != 0){
                
                return false;
            }
            
            
        }else{
            
            if(matrixTree[2][colsFather] != 0){
                
                return false;
            }
            
        }
        
        matrixTree[0][colsSon]=son;
        
        if(location=='I'){
            
            matrixTree[1][colsFather] = colsSon;
            
        }else{
            
            matrixTree[2][colsFather] = colsSon; 
            
        }
        
        return true;
    }
    
    /**
     * 
     * @param father
     * @param son
     * @return true 
     */
    public boolean insertLeft(int father, int son){
        
        int colsFather = exist(father);
        
        if(colsFather== -1){
            return false;//Father no exist
        }
        
        if(exist(son) != -1){
           
           return false;//Son exist
        
        }
        
        if(matrixTree[1][colsFather]!=0){
        
        return true;//The father has a left son
        
        }
        
        int colsSon= exist(0);
        
        if(colsSon == -1){
            
            return false;// The tree matrix is full
            
        }
        
        matrixTree[0][colsSon] = son;//Save the new node
        matrixTree[1][colsFather]= colsSon;//Save the the colsSon
        
        
        return true;
    }
    
    /**
     * 
     * @param father
     * @param son
     * @return true 
     */
    public boolean insertRight(int father, int son){
        
        int colsFather = exist(father);
        
        if(colsFather== -1){
            return false;//Father no exist
        }
        
        if(exist(son) != -1){
           
           return false;//Son exist
        
        }
        
        if(matrixTree[2][colsFather]!=0){
        
        return true;//The father has a left son
        
        }
        
        int colsSon= exist(0);
        
        if(colsSon == -1){
            
            return false;// The tree matrix is full
            
        }
        
        matrixTree[0][colsSon] = son;//Save the new node
        matrixTree[1][colsFather]= colsSon;//Save the the colsSon
        
        
        return true;
    }
    
    public String printLeaves(){
        
        String leavesNodes=  "";
        
        for(int count = 0; count < matrixTree[0].length; count++){
            
            if(matrixTree[0][count] !=0 && matrixTree[1][count] ==0 && matrixTree[2][count]==0){
                
                leavesNodes+= matrixTree[0][count] +"\n";
            }
            
        }
        
        return leavesNodes;
    }
    
    public String printMatrix(){
        
        String textMatrix= "";
        
        for(int i=0; i<matrixTree.length;i++){
            
            textMatrix += i + "->";
            
            
            for(int j=0;j < matrixTree[0].length;j++){
                
                textMatrix+=" | "+matrixTree[i][j]; 
                
            }
          
            textMatrix+= "|\n";
            
           
        }
      
        return textMatrix;
    }
    
}
