/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AlgoritmosOrdenamiento;

/**
 *
 * @author Gabriel Guzmán Alfaro
 */
public class ShellShortTest {
    
    public static void main(String[] args){
        
        ShellSort shell = new ShellSort();
      
        for(int i=5000;i<100000;i+=5000){
        
            
        Integer[] desordenado = new Integer[i];
        
        long tiempoInicio,tiempoFinal;
        
         for(int cont=0;cont < desordenado.length;cont++ ){
            
            desordenado[cont] = (int)(Math.random()*desordenado.length)+1;
            
        }
         
         Integer[] temp= desordenado.clone();
         tiempoInicio = System.nanoTime();
         Integer[] ordenado = shell.shellSort(temp);
         tiempoFinal = System.nanoTime();
         System.out.println("Tiempo insertion "+(tiempoFinal-tiempoInicio)+" en iteración #"+i);
         
         if(i==5000){
         
         for(int dato: ordenado){
              
              System.out.println(dato);              
         }
         
         }
         
       }
        
    }
    
}
