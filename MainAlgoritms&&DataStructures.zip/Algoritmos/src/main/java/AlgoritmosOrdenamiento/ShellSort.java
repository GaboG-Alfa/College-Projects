/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AlgoritmosOrdenamiento;

/**
 *
 * @author Gabriel Guzmán Alfaro
 */
public class ShellSort {

    public Integer[] shellSort(Integer[] a) {

        for (int gap = a.length / 2; gap > 0; gap = gap== 2 ? 1 : (int) (gap / 2.2)) {

            for (int i = gap; i < a.length; i++) {

                Integer temp = a[i];

                int j = i;

                for (; j >= gap && temp.compareTo(a[j - gap]) < 0; j -= gap) {
                    a[j] = a[j - gap];
                }

                a[j] = temp;

            }
            
        }
        
         return a;

    }
}
