/*
 * Clase que se encarga de probar el insert sort
 */
package AlgoritmosOrdenamiento;

/**
 *
 * @author Gabriel Guzmán Alfaro
 * @version 24/05/2021
 */
public class InsertionSortTest {
    
    public static void main(String[] args){
        
        InsertionSort insert = new InsertionSort();
      
        for(int i=5000;i<100000;i+=5000){
        
        Integer[] desordenado = new Integer[i];
        
        long tiempoInicio,tiempoFinal;
        
         for(int cont=0;cont < desordenado.length;cont++ ){
            
            desordenado[cont] = (int)(Math.random()*desordenado.length)+1;
            
        }
         
         Integer[] temp= desordenado.clone();
         tiempoInicio = System.nanoTime();
         Integer[] ordenado = insert.insertion(temp);
         tiempoFinal = System.nanoTime();
         System.out.println("Tiempo insertion "+(tiempoFinal-tiempoInicio)+" en iteración #"+i);
         
         for(int dato: ordenado){
             
              System.out.println(dato);              
         }
         
        }
    }
    
}
