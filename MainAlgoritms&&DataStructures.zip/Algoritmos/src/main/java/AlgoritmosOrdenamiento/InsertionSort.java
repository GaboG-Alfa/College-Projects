/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AlgoritmosOrdenamiento;

/**
 *
 * @author Gabriel Guzmán Alfaro
 */
public class InsertionSort  {
    
    /**
     * 
     * @param a
     * @return a 
     */
    public Integer[] insertion(Integer[]a){
        
        for(int i =1; i<a.length;i++){
            
            Integer temp;
            temp=a[i];
            
            int j=i;
            
            for(;j>0 && temp.compareTo(a[j-1]) < 0;j--){
                
                a[j] = a[j-1]; 
            }
            
             a[j] = temp;
            
        }
        
        return a;
               
    }
    
}
