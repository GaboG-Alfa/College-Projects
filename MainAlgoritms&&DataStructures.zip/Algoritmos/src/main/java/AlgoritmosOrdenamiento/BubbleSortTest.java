/*
 * Clase que prueba el tiempo de ejecución del algoritmo de bubble y mejorado
 */
package AlgoritmosOrdenamiento;

/**
 *
 * @author Gabriel Guzmán Alfaro
 * @version 24/05/2021
 */
public class BubbleSortTest {
    
    /**
     * 
     * @param args 
     */
    public static void main(String[] args){
        
        BubbleSort bubble = new BubbleSort();
           
        for(int i=5000;i<100000;i+=5000){
            
        Integer[] desordenado = new Integer[i];
       
        long tiempoInicio,tiempoFinal;
        
        for(int cont=0;cont < desordenado.length;cont++ ){
            
            desordenado[cont] = (int)(Math.random()*desordenado.length)+1;
            
        }
        
        
        
        //Burbuja normal
        Integer[] temp= desordenado.clone();
        
        tiempoInicio = System.nanoTime();
        
        Integer[] ordenado = bubble.bubble(temp);
         
        tiempoFinal = System.nanoTime();
        
        System.out.println("Tiempo burbuja "+(tiempoFinal-tiempoInicio)+" en iteración #"+i);
        
        //Burbuja mejorado
        temp= desordenado.clone();
        
        tiempoInicio = System.nanoTime();
        
        ordenado = bubble.bubbleOP(temp);
        
        tiempoFinal = System.nanoTime();
        
        System.out.println("Tiempo burbuja OP "+(tiempoFinal-tiempoInicio)+" en iteración #"+i);
        
        /*
        for(int dato : ordenado){
            
            System.out.println(dato);
        }*/
        
        }
    }
    
}
