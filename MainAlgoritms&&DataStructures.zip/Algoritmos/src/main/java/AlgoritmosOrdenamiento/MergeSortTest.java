/*
 * La clase se encarga de probar el ordenamiento mezclado
 */
package AlgoritmosOrdenamiento;

/**
 *
 * @author Gabriel Guzmán Alfaro
 */
public class MergeSortTest {

    public static void main(String[]args) {

        MergeSort merge = new MergeSort();

        for (int i = 5000; i < 100000; i += 5000) {

            Integer[] desordenado = new Integer[i];

            long tiempoInicio, tiempoFinal;

            for (int cont = 0; cont < desordenado.length; cont++) {

                desordenado[cont] = (int) (Math.random() * desordenado.length) + 1;

            }

            //Burbuja normal
            Integer[] temp = desordenado.clone();

            tiempoInicio = System.nanoTime();

            merge.mergeSort(temp);

            tiempoFinal = System.nanoTime();

            System.out.println("Tiempo burbuja " + (tiempoFinal - tiempoInicio) + " en iteración #" + i);
            
            for(int dato : temp){
            
            System.out.println(dato);
            
            }
            

        }
    }

}
