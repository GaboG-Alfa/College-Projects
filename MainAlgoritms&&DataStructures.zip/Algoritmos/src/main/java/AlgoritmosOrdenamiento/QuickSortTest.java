/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AlgoritmosOrdenamiento;

/**
 *
 * @author Gabriel Guzmán Alfaro
 */
public class QuickSortTest {
    
     public static void main(String[]args) {

        QuickSort quick = new QuickSort();

        for (int i = 5000; i < 100000; i += 5000) {

            Integer[] desordenado = new Integer[i];

            long tiempoInicio, tiempoFinal;

            for (int cont = 0; cont < desordenado.length; cont++) {

                desordenado[cont] = (int) (Math.random() * desordenado.length) + 1;

            }

            //Burbuja normal
            Integer[] temp = desordenado.clone();

            tiempoInicio = System.nanoTime();

            quick.quickSort(temp);

            tiempoFinal = System.nanoTime();

            System.out.println("Tiempo Quick " + (tiempoFinal - tiempoInicio) + " en iteración #" + i);
            
            for(int dato : temp){
            
            System.out.println(dato);
            
            }
            

        }
    }
    
}
