/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ListaEnlazadaSimple;

/**
 *
 * @author Gabriel Guzmán Alfaro
 */
public class ListaSimple {
    
    //Atributo
    private Nodo primero;
    private Nodo ultimo;

    /**
     * Agregar nodo al inicio de la lista con ciclo
     *
     * @param dato
     */
    public void insertarInicioCiclo(int dato) {

        Nodo nuevo = new Nodo();

        nuevo.setDato(dato);

        if (primero == null) {
            primero = nuevo;
        } else {
            nuevo.setSiguiente(primero);
            primero = nuevo;
        }
    }

    /**
     * Agregar nodo al inicio de la lista con ciclo
     *
     * @param dato
     */
    public boolean buscar(int dato) {

        if (primero == null) {

            return false;
        }

        for (Nodo temp = primero; temp != null; temp = temp.getSiguiente()) {

            if (dato == temp.getDato()) {
                return true;
            }
        }

        return false;
    }

    /**
     * Agregar nodo al inicio de la lista con punteros
     *
     * @param dato
     */
    public void insertarInicioPuntero(int dato) {

        //Por punteros
        Nodo nuevo = new Nodo();

        nuevo.setDato(dato);

        nuevo.setSiguiente(primero);

        primero = ultimo = nuevo;
    }

    /**
     * Agregar nodo al final de la lista con ciclo
     *
     * @param dato
     */
    public void insertarFinalCiclo(int dato) {

        Nodo nuevo = new Nodo();

        nuevo.setDato(dato);

        if (primero == null) {
            primero = nuevo;
        } else {

            Nodo temp;

            /*for (temp = primero; temp.getSiguiente() != null; temp = temp.getSiguiente());
            temp.setSiguiente(nuevo);*/
            temp = primero;

            while (temp.getSiguiente() != null) {

                temp = temp.getSiguiente();
            }

            temp.setSiguiente(nuevo);
        }
    }

    /**
     * Agregar nodo al final de la lista con punteros
     *
     * @param dato
     */
    public void insertarFinalPuntero(int dato) {

        //Por punteros
        Nodo nuevo = new Nodo();

        nuevo.setDato(dato);

        if (ultimo == null) {

            primero = ultimo = nuevo;

        } else {

            ultimo.setSiguiente(nuevo);
            ultimo = nuevo;
        }
    }

    /**
     * Eliminar un nodo al inicio
     *
     * @return boolean
     */
    public boolean eliminarInicio() {

        if (primero == null) {
            
            return false;
        }

        if (primero == ultimo) {
            primero = ultimo = null;
        } else {

            primero = primero.getSiguiente();
        }

        return true;

    }

    /**
     * Eliminar un nodo al final
     *
     * @return boolean
     */
    public boolean eliminarFinal() {

        if (ultimo == null) {
            return false;
        }
        if (primero == ultimo) {
            primero = ultimo = null;
        } else {

            Nodo temp;

            for (temp = primero; temp.getSiguiente() != ultimo; temp = temp.getSiguiente());
            temp.setSiguiente(null);

            ultimo = temp;
        }
        return true;

    }

    /**
     * Elimina un elemento por dato
     *
     * @param dato
     * @return boolean
     */
    public boolean eliminarDatoPuntero(int dato) {

        if (primero == null) {

            return false;

        }

        if (primero.getDato() == dato) {

            this.eliminarInicio();

            return true;

        } else if (ultimo.getDato() == dato) {

            this.eliminarFinal();

            return true;

        } else {

            Nodo temp;

            temp = primero;

            while (temp.getSiguiente() != null) {

                if (temp.getSiguiente().getDato() == dato) {

                    temp.setSiguiente(temp.getSiguiente().getSiguiente());

                    return true;
                }

                temp = temp.getSiguiente();
            }

        }

        return false;
    }

    /**
     * Eliminar dato por ciclo
     *
     * @param dato
     */
    public void eliminarDatoCiclo(int dato) {
        
        boolean encontrado;
        Nodo temp, anterior;

        temp = primero;
        anterior = null;
        encontrado = false;

        while (temp != null && !encontrado) {
            encontrado = (temp.getDato() == dato);
            if (!encontrado) {
                anterior = temp;
                temp = temp.getSiguiente();
            }

            if (temp != null) {

                if (temp == primero) {
                    primero = temp.getSiguiente();
                } else {
                    anterior.setSiguiente(temp.getSiguiente());
                }

            }
        }

    }

    /**
     * Agregar nodo al final de la lista con punteros
     *
     * @param dato
     */
    public boolean insertarDespues(int predecesor, int dato) {

        //Por punteros
        Nodo nuevo = new Nodo();

        nuevo.setDato(dato);

        if (primero == null) {
            return false;
        }

        if (ultimo.getDato() == predecesor) {
            this.insertarFinalPuntero(dato);

            return true;
        }

        for (Nodo temp = primero; temp != ultimo; temp = temp.getSiguiente()) {

            if (temp.getDato() == predecesor) {

                nuevo.setSiguiente(temp.getSiguiente());
                temp.setSiguiente(nuevo);

                return true;

            }

        }

        return true;
    }

    /**
     * Agregar nodo al final de la lista con punteros
     *
     * @param dato
     */
    public boolean insertarOrdenamiento(int dato) {

        if (primero == null) {

            insertarInicioPuntero(dato);

            return true;
        }

        if (dato < primero.getDato()) {

            insertarInicioPuntero(dato);

            return true;
        }

        if (dato > ultimo.getDato()) {

            insertarFinalPuntero(dato);

            return true;
        }

        for (Nodo temp = primero; temp != ultimo; temp = temp.getSiguiente()) {

            if (dato < temp.getSiguiente().getDato()) {

                //Por punteros
                Nodo nuevo = new Nodo();

                nuevo.setDato(dato);

                nuevo.setSiguiente(temp.getSiguiente());
                temp.setSiguiente(nuevo);

                return true;

            }

        }

        return true;
    } 

    public String imprimirRecursivo() {

        return imprimirRecursivo(primero);
    }

    private String imprimirRecursivo(Nodo temp) {

        if (temp == null) {

            return "";
        }

        return "--->" + temp.getDato() + imprimirRecursivo(temp.getSiguiente());
    }

    /**
     * 
     * @return imprimirSuma 
     */
    public int imprimirSuma() {

        return imprimirSuma(primero);
    }

    /**
     * 
     * @param temp
     * @return contador 
     */
    private int imprimirSuma(Nodo temp) {

        int contador = 0;

        if (temp == null) {

            return contador;
        }

        imprimirSuma(temp.getSiguiente());

        return contador = temp.getDato() + imprimirSuma(temp.getSiguiente());
    }

    /**
     *
     * @return hilera
     */
    public String imprimir() {

        String salida = "";

        for (Nodo temp = primero; temp != null; temp = temp.getSiguiente()) {

            salida += "--->" + temp.getDato();
        }

        return salida;
    }

}
