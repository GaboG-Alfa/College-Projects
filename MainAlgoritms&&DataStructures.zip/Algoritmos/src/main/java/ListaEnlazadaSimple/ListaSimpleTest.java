/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ListaEnlazadaSimple;

/**
 *
 * @author Gabriel Guzmán Alfaro
 * @version 07/06/2021
 */
public class ListaSimpleTest {
    
    /**
     * 
     * @param args 
     */
    public static void main(String[] args) {

        ListaSimple lista = new ListaSimple();

        /*
        lista.insertarFinalCiclo(10);
        lista.insertarFinalCiclo(20);
        lista.insertarFinalCiclo(30);
        lista.insertarFinalCiclo(40);
        */
        
        lista.insertarOrdenamiento(15);
        lista.insertarOrdenamiento(30);
        lista.insertarOrdenamiento(2);
        
        //lista.insertarDespues(10, 15);
        
        System.out.println(lista.imprimirRecursivo());
        
        //System.out.println(lista.imprimirSuma());
        
        //System.out.println(lista.buscar(20));

         /* for (int i = 0; i < 1; i++) {
            lista.eliminarFinal();
        }*/

        lista.eliminarDatoPuntero(15);
        
        System.out.println(lista.imprimirRecursivo());

        /*
        lista.insertarInicioCiclo(10);
        lista.insertarInicioCiclo(20);
        lista.insertarInicioCiclo(30);
        lista.insertarInicioCiclo(40);*/

        //System.out.println(lista.imprimir());

        //lista.eliminarDatoCiclo(30);
        //System.out.println(lista.imprimir());

        //lista.eliminarDatoCiclo(10);
        //System.out.println(lista.imprimir());
    }

}
