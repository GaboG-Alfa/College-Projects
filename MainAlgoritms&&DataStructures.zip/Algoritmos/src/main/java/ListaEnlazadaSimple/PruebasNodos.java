/*
 * 
 */
package ListaEnlazadaSimple;

/**
 *
 * @author Gabriel Guzmán Alfaro
 */
public class PruebasNodos {
    
    /**
     * 
     * @param args 
     */
    public static void main(String[] args){
        
        //Atributo
        Nodo primero= new Nodo();
        
        primero.setDato(10);
        
        Nodo nuevo= new Nodo();
         
        nuevo.setSiguiente(primero);
        
        primero = nuevo;
        
        nuevo.setDato(5);
       
        /*Nodo primero = new Nodo();
        Nodo nuevo = new Nodo();
         
        primero.setDato(10);
       
        primero.setSiguiente(nuevo);
        nuevo.setDato(5);*/
       
       
          
        for(Nodo temp= primero;temp != null;temp=temp.getSiguiente()){
            
            System.out.println("Lista: "+temp.getDato());
            
        }
        
        
    }
    
}
