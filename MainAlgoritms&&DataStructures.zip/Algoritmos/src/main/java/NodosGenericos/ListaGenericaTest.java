/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package NodosGenericos;

/**
 *
 * @author Gabriel Guzmán Alfaro
 */
public class ListaGenericaTest {
    
    public static void main(String[] args){
        ListaGenerica<Persona> lista = new ListaGenerica<>();
        
        lista.insertarOrdenamiento(new Persona(208230484,"Gabriel",19));
        lista.insertarOrdenamiento(new Persona(209230543,"María",30));
        lista.insertarOrdenamiento(new Persona(207650534,"Luis",2));
        lista.insertarOrdenamiento(new Persona(208970123,"Ana",29));
        
        System.out.println(lista.imprimir());
        
    }
    
}
