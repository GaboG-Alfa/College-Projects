/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package NodosGenericos;

/**
 *
 * @author Gabriel Guzmán Alfaro
 */
public class ListaGenerica <T extends Comparable<T>>{
    
    //Atributo
    private Nodo <T> primero;
    private Nodo <T> ultimo;

    /**
     * Agregar nodo al inicio de la lista con ciclo
     *
     * @param dato
     */
    public boolean buscar(T dato) {

        if (primero == null) {

            return false;
        }

        for (Nodo <T> temp = primero; temp != null; temp = temp.getSiguiente()) {

            if (dato == temp.getDato()) {
                return true;
            }
        }

        return false;
    }

    /**
     * Agregar nodo al inicio de la lista con punteros
     *
     * @param dato
     */
    public void insertarInicio(T dato) {

        //Por punteros
        Nodo<T> nuevo = new Nodo();

        nuevo.setDato(dato);
        
        if (primero == null) {
            primero =ultimo=nuevo;
        } else {
            nuevo.setSiguiente(primero);
            primero = nuevo;
        }
        
    }

    /**
     * Agregar nodo al final de la lista con ciclo
     *
     * @param dato
     */
    public void insertarFinalCiclo(T dato) {

        Nodo<T> nuevo = new Nodo();

        nuevo.setDato(dato);

        if (primero == null) {
            primero = nuevo;
        } else {

            Nodo<T> temp;

            /*for (temp = primero; temp.getSiguiente() != null; temp = temp.getSiguiente());
            temp.setSiguiente(nuevo);*/
            temp = primero;

            while (temp.getSiguiente() != null) {

                temp = temp.getSiguiente();
            }

            temp.setSiguiente(nuevo);
        }
    }

    /**
     * Agregar nodo al final de la lista con punteros
     *
     * @param dato
     */
    public void insertarFinalPuntero(T dato) {

        //Por punteros
        Nodo<T> nuevo = new Nodo();

        nuevo.setDato(dato);

        if (ultimo == null) {

            primero = ultimo = nuevo;

        } else {

            ultimo.setSiguiente(nuevo);
            ultimo = nuevo;
        }
    }

    /**
     * Eliminar un nodo al inicio
     *
     * @return boolean
     */
    public boolean eliminarInicio() {

        if (primero == null) {
            
            return false;
        }

        if (primero == ultimo) {
            primero = ultimo = null;
        } else {

            primero = primero.getSiguiente();
        }

        return true;

    }

    /**
     * Eliminar un nodo al final
     *
     * @return boolean
     */
    public boolean eliminarFinal() {

        if (ultimo == null) {
            return false;
        }
        if (primero == ultimo) {
            primero = ultimo = null;
        } else {

            Nodo<T> temp;

            for (temp = primero; temp.getSiguiente() != ultimo; temp = temp.getSiguiente());
            temp.setSiguiente(null);

            ultimo = temp;
        }
        return true;

    }

    /**
     * Elimina un elemento por dato
     *
     * @param dato
     * @return boolean
     */
    public boolean eliminarDatoPuntero(T dato) {

        if (primero == null) {

            return false;

        }

        if (primero.getDato() == dato) {

            this.eliminarInicio();

            return true;

        } else if (ultimo.getDato() == dato) {

            this.eliminarFinal();

            return true;

        } else {

            Nodo temp;

            temp = primero;

            while (temp.getSiguiente() != null) {

                if (temp.getSiguiente().getDato() == dato) {

                    temp.setSiguiente(temp.getSiguiente().getSiguiente());

                    return true;
                }

                temp = temp.getSiguiente();
            }

        }

        return false;
    }

    /**
     * Eliminar dato por ciclo
     *
     * @param dato
     */
    public void eliminarDatoCiclo(T dato) {
        
        boolean encontrado;
        Nodo temp, anterior;

        temp = primero;
        anterior = null;
        encontrado = false;

        while (temp != null && !encontrado) {
            encontrado = (temp.getDato() == dato);
            if (!encontrado) {
                anterior = temp;
                temp = temp.getSiguiente();
            }

            if (temp != null) {

                if (temp == primero) {
                    primero = temp.getSiguiente();
                } else {
                    anterior.setSiguiente(temp.getSiguiente());
                }

            }
        }

    }

    /**
     * Agregar nodo al final de la lista con punteros
     *
     * @param dato
     */
    public boolean insertarDespues(T predecesor, T dato) {

        //Por punteros
        Nodo nuevo = new Nodo();

        nuevo.setDato(dato);

        if (primero == null) {
            return false;
        }

        if (ultimo.getDato() == predecesor) {
            this.insertarFinalPuntero(dato);

            return true;
        }

        for (Nodo temp = primero; temp != ultimo; temp = temp.getSiguiente()) {

            if (temp.getDato() == predecesor) {

                nuevo.setSiguiente(temp.getSiguiente());
                temp.setSiguiente(nuevo);

                return true;

            }

        }

        return true;
    }
    
    /**
     *
     */
    public void ordenar(){

        boolean ordenado = false;

        while (ordenado == false) {
            ordenado=true;
            for (Nodo<T> temp = primero; temp.getSiguiente() != null; temp = temp.getSiguiente()) {
                if (temp.getDato().compareTo(temp.getSiguiente().getDato())<0) {
                   
                    T temporal = temp.getDato();
                    temp.setDato(temp.getSiguiente().getDato());
                    temp.getSiguiente().setDato(temporal);
                    ordenado=false;
                    
                }
            }
        }

    }

    /**
     * Agregar nodo al final de la lista con punteros
     *
     * @param dato
     */
    public boolean insertarOrdenamiento(T dato) {

        if (primero == null) {

            insertarInicio(dato);

            return true;
        }

        if (dato.compareTo(primero.getDato())<0) {

            insertarInicio(dato);

            return true;
        }

        if (dato.compareTo(ultimo.getDato())>0) {

            insertarFinalPuntero(dato);

            return true;
        }

        for (Nodo <T> temp = primero; temp != ultimo; temp = temp.getSiguiente()) {

            if (dato.compareTo(temp.getSiguiente().getDato())<0) {
                  
                //Por punteros
                Nodo <T> nuevo = new Nodo();

                nuevo.setDato(dato);

                nuevo.setSiguiente(temp.getSiguiente());
                temp.setSiguiente(nuevo);

                return true;

            }

        }

        return true;
    } 

 
    /**
     *
     * @return hilera
     */
    public String imprimir() {

        String salida = "";

        for (Nodo<T> temp = primero; temp != null; temp = temp.getSiguiente()) {

            salida += "--->" + temp.getDato().toString();
        }

        return salida;
    }

}
