package NodosGenericos; 
 
/** 
 * 
 * @author Gabriel Guzmán Alfaro 
 */ 
public class Test { 
 
    /**
     * 
     * @param args 
     */
    public static void main(String[] args) { 
        Nodo<Persona> nodoPersonas = new Nodo<>(); 
        //Nodo<Producto> nodoProductos = new Nodo<>(); 
        Nodo<Integer> nodoInteger = new Nodo<>(); 
        Persona persona = new Persona(2, "Juan", 3); 
        Producto producto = new Producto(2, 2, "celular"); 
        nodoPersonas.setDato(persona); 
        //nodoProductos.setDato(producto); 
        nodoInteger.setDato(40); 
    } 
}
