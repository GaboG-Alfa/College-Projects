/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ArbolesAVL;

/**
 *
 * @author GABRIEL Guzmán Alfaro
 */
public class AVLArbol <T extends Comparable<T>> {
    
    //Attributes
    private AVLNode<T> root;

    /**
     * Insertar un dato
     *
     * @param dato
     */
    public void insert(T dato) throws ArbolBinarioException {
        root = insert(dato, root);
    }


    /**
     * Recorre en preorden
     */
    public String preOrden() {

        return preOrden(root);
    }

    /**
     * Recursión
     *
     * @param AVLNode
     */
    private String preOrden(AVLNode<T> temp) {

        if (temp != null) {
            return temp.element + "\n" + preOrden(temp.left) + preOrden(temp.right);
        }

        return "";

    }

    /**
     * Recorre en postorden
     */
    public String postOrden() {

        return postOrden(root);
    }

    /**
     * Recursión
     *
     * @param AVLNode
     */
    private String postOrden(AVLNode<T> temp) {

        if (temp != null) {
            return postOrden(temp.left) + postOrden(temp.right) + temp.element+"\n";
        }

        return "";
    }

    /**
     * Recorre en orden
     */
    public String enOrden() {

        return enOrden(root);
    }

    /**
     * Recursión
     *
     * @param AVLNode
     */
    private String enOrden(AVLNode<T> temp) {

        if (temp != null) {
            return enOrden(temp.left)+ temp.element+"\n"+enOrden(temp.right);
        }

        return "";
    }

    /**
     * Find min
     *
     * @return elementAt
     */
    public T findMin() {

        return elementAt(findMin(root));
    }

    /**
     * Find max
     *
     * @return elemntAt
     */
    public T findMax() {

        return elementAt(findMax(root));
    }

    /**
     * Recursion del elemento
     *
     * @param AVLNode
     * @return elementAt
     */
    private T elementAt(AVLNode<T> temp) {
        return temp == null ? null : temp.element;
    }

    /**
     * Recursion del min
     *
     * @param AVLNode
     * @return AVLNode
     */
    private AVLNode<T> findMin(AVLNode<T> temp) {

        if (temp != null) {
            while (temp.left != null) {
                temp = temp.left;
            }
        }

        return temp;
    }

    /**
     * Recursion del max
     *
     * @param AVLNode
     * @return AVLNode
     */
    private AVLNode<T> findMax(AVLNode<T> temp) {

        if (temp != null) {
            while (temp.right != null) {
                temp = temp.right;
            }
        }

        return temp;
    }

    /**
     * Imprime el dato
     *
     * @param dato
     */
    private void imprimir(T dato) {

        System.out.println("dato: " + dato);
    }

    /**
     * Busca un dato y retorna el AVLNode
     *
     * @param dato
     * @param AVLNode
     * @return AVLNode
     */
    private AVLNode<T> find(T dato, AVLNode<T> temp) throws ArbolBinarioException {

        while (temp != null) {

            if (dato.compareTo(temp.element) < 0) {
                temp = temp.left;
            } else if (dato.compareTo(temp.element) > 0) {
                temp = temp.right;
            } else {
                return temp;
            }
        }

        return null;
    }

    /**
     * Find a data
     *
     * @param dato
     * @return
     * @throws ArbolBinarioException
     */
    public T find(T dato) throws ArbolBinarioException {
        return elementAt(find(dato, root));
    }

    /**
     * 
     * @param k2
     * @return k1 
     */
    private AVLNode<T> rotateWithLeftChild(AVLNode<T> k2){
    
        AVLNode k1= k2.left;
        k2.left= k1.right;
        k1.right = k2;
        
        return k1;
        
    }
    
    /**
     * 
     * @param k1
     * @return k2 
     */
    private AVLNode<T> rotateWithRightChild(AVLNode<T> k1){
    
        AVLNode k2= k1.right;
        k2.right = k2.left;
        k2.left = k1;
        
        return k2;
        
    }
    
    /**
     * 
     * @param k3
     * @return rotateWithLeftChild(k3) 
     */
    private AVLNode<T> doubleRotateWithLeftChild(AVLNode<T> k3){
         
         k3.left = rotateWithRightChild(k3.left);
         
         return rotateWithLeftChild(k3);
         
     }
     
    /**
     * 
     * @param k1
     * @return return rotateWithRightChild(k1); 
     */
     private AVLNode<T> doubleRotateWithRightChild(AVLNode<T> k1){
         
         k1.right = rotateWithLeftChild(k1.right);
         
         return rotateWithRightChild(k1);
         
     }
    
    
    /**
     * 
     * @param t
     * @return int 
     */
    private int height(AVLNode<T> t){
        
        return t==null ? -1: t.height;
    
    }
    
    /**
     * 
     * @param lhs
     * @param rhs
     * @return int 
     */
    private int max(int lhs, int rhs){
        
        return lhs > rhs ? lhs : rhs;
    
    }
    
    /**
     * 
     * @param x
     * @param t
     * @return t 
     */
    private AVLNode<T> insert(T x, AVLNode<T> t){
        
        if(t==null){
            t= new AVLNode<>(x,null,null);
        }else if (x.compareTo(t.element)<0){
            t.left = insert(x,t.left);
        
        
        if(height(t.left)-height(t.right)==2)
            
            if(x.compareTo(t.left.element)<0)
                
                t= rotateWithLeftChild(t);
            
            else
                
                t= doubleRotateWithLeftChild(t);
        }
        
        else if(x.compareTo(t.element)>0){
            
            t.right = insert(x,t.right);
            
            if(height(t.right)-height(t.left)==2)
                
                if(x.compareTo(t.right.element)>0)
                    t = rotateWithRightChild(t);
            
                else
                
                t= doubleRotateWithRightChild(t);
        } 
        
        else
            t.height = max(height(t.left),height(t.right))+1;
        
        
        return t;
        
    }
    
}
