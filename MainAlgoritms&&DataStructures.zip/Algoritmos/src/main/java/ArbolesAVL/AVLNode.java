/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ArbolesAVL;

/**
 *
 * @author GABRIEL
 */
public class AVLNode <T extends Comparable<T>> {
    
    //Atributtes
    T element;
    AVLNode<T> left;
    AVLNode<T> right;
    int height;

    public AVLNode(T theElement) {
        
        this(theElement,null,null);
    }
    
    public AVLNode(T theElement,AVLNode<T> lt,AVLNode<T> rt ) {
        
        element = theElement;
        left = lt;
        right = rt;
        height = 0;
    }
    
}
